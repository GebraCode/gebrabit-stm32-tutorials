param([string]$ProjectDirectory = (Join-Path $PSScriptRoot 'gebrabit_lesson41_fromisr'))
$ErrorActionPreference='Stop'
Push-Location -LiteralPath $ProjectDirectory
try {
  & cmake --preset Debug
  if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed' }
  & cmake --build --preset Debug --clean-first
  if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
  & arm-none-eabi-objcopy -O binary build/Debug/gebrabit_lesson41_fromisr.elf build/Debug/gebrabit_lesson41_fromisr.bin
  if ($LASTEXITCODE -ne 0) { throw 'BIN export failed' }
  & arm-none-eabi-size build/Debug/gebrabit_lesson41_fromisr.elf
  if ($LASTEXITCODE -ne 0) { throw 'ELF size failed' }
} finally { Pop-Location }

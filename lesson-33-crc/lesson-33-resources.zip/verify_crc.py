"""Expected CRC arithmetic and actual-file checks; no MCU execution claimed."""
from pathlib import Path
import json,zlib,hashlib,zipfile
from elf_audit import inspect_elf,inspect_hex
P=Path(__file__).resolve().parent;checks=[]
def check(n,c):
 assert c,n
 checks.append(n)
def rev(x,bits):return int(f'{x:0{bits}b}'[::-1],2)
class CRCModel:
 def __init__(self):self.state=0xFFFFFFFF
 def write(self,value,width):
  # REV_IN_BYTE, MSB-first polynomial0x04C11DB7, actualwritewidth8/16/32.
  value=int.from_bytes(bytes(rev(x,8)for x in value.to_bytes(width//8,'big')),'big')
  for bit in range(width-1,-1,-1):
   top=((self.state>>31)^((value>>bit)&1))&1
   self.state=((self.state<<1)&0xFFFFFFFF)^(0x04C11DB7 if top else 0)
 def feed(self,data):
  i=0
  while len(data)-i>=4:self.write(int.from_bytes(data[i:i+4],'big'),32);i+=4
  if len(data)-i>=2:self.write(int.from_bytes(data[i:i+2],'big'),16);i+=2
  if len(data)-i:self.write(data[i],8)
 def raw(self):return rev(self.state,32)
 def result(self):return self.raw()^0xFFFFFFFF
vector=b'123456789';m=CRCModel();m.feed(vector)
check('IEEEcheckvector9bytes',m.result()==zlib.crc32(vector)==0xCBF43926)
check('rawDRbeforefinalXOR',m.raw()==0x340BC6D9)
for split in range(10):
 m=CRCModel();m.feed(vector[:split]);m.feed(vector[split:]);check('split'+str(split),m.result()==zlib.crc32(vector))
for n in range(132):
 data=bytes(range(131))[:n];m=CRCModel();m.feed(data);check('length'+str(n),m.result()==zlib.crc32(data))
for chunk in [1,2,3,4,5,7,8,16,63,64,65]:
 data=bytes(range(131));m=CRCModel()
 for i in range(0,len(data),chunk):m.feed(data[i:i+chunk])
 check('streamchunk'+str(chunk),m.result()==zlib.crc32(data))
check('Calculate_suffix_is_not_fullstream',zlib.crc32(b'56789')!=zlib.crc32(vector))
check('NULchangesmessage',zlib.crc32(vector+b'\0')!=zlib.crc32(vector))
settings=bytes([0x47,0x42,1,0,4,0,0x10,0x20,0x30,0x40,0x50,0x60])
for kind in ['projects','build-artifacts']:
 z=zipfile.ZipFile(P/f'lesson-33-{kind}.zip');check(kind+'CRC',z.testzip()is None)
 manifest=json.loads((P/(kind+'-manifest.json')).read_text());check(kind+'SHA',all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items()))
 if kind=='projects':
  root='gebrabit_lesson33_crc/';main=z.read(root+'Core/Src/main.c').decode();crc=z.read(root+'Core/Src/crc.c').decode()
  check('generatedIEEEformat',all(x in crc for x in ['CRC_INPUTDATA_INVERSION_BYTE','CRC_OUTPUTDATA_INVERSION_ENABLE','CRC_INPUTDATA_FORMAT_BYTES']))
  check('alignedscratchnocastsourceoffset','_Alignas(uint32_t) static uint8_t crc_scratch[64]' in main and 'memcpy(crc_scratch, bytes, chunk)' in main)
  check('noFlashwrite',all(x not in main for x in ['HAL_FLASH_Program','HAL_FLASHEx_Erase','HAL_FLASH_OB_']))
 else:
  root='gebrabit_lesson33_crc/gebrabit_lesson33_crc';e=inspect_elf(z.read(root+'.elf'));binary=z.read(root+'.bin');hexmem=inspect_hex(z.read(root+'.hex').decode())
  check('realBINequalsELFloadimageFFgaps',binary==e['image'])
  check('realHEXequalsBIN',all(e['image_start']<=a<e['image_end']and binary[a-e['image_start']]==b for a,b in hexmem.items()))
  s=e['symbols'];c_end=s['_sidata']+s['_edata']-s['_sdata'];check('CreadonlyimageintervalequalsBIN',c_end==e['image_end'] and e['image_start']==0x08000000)
  image={'start':hex(e['image_start']),'end_exclusive':hex(c_end),'bytes':len(binary),'CRC32_IEEE':f'{zlib.crc32(binary):08X}','SHA256':hashlib.sha256(binary).hexdigest(),'gap_fill':'0xFF','expected_crc_storage':'externalmanifest not embedded/self-covered','hardware_readback':'PENDING'}
  (P/'firmware-image-manifest.json').write_text(json.dumps(image,indent=2)+'\n')
r={'scope':'IndependentMSB-polynomialhardware-behaviormodelvsPythonzlib andactualsource/ELF/BIN/HEX/archivechecks; no boardCRCresult or timing measurement','checks_passed':len(checks),'checks':checks,'expected_vector_final':'CBF43926','expected_vector_raw':'340BC6D9','expected_prefix4':f'{zlib.crc32(vector[:4]):08X}','expected_suffix5_reset':f'{zlib.crc32(vector[4:]):08X}','expected_words_numeric31323334_35363738':f'{zlib.crc32(vector[:8]):08X}','expected_settings_fixture':f'{zlib.crc32(settings):08X}','compiled_runtime_test_count_expected':146,'compiled_runtime_tests_actually_executed_on_board':False,'image_manifest':image}
(P/'crc-model-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

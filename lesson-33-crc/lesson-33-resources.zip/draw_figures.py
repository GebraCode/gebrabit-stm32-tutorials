"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent



LESSON=33
def save(im,n):im.save(OUT/f'lesson33-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Byte order can change a CRC','Offline calculated examples, not hardware readings; no checksum detects every corruption')
 panel(d,65,290,470,250,'Bytes 01 02',['Sum8 = 03','CRC32 = B6CC4292'])
 panel(d,665,290,470,250,'Bytes 02 01',['Sum8 = 03','CRC32 = 04E840EB'])
 tx(d,75,650,'A small shift-register model explains feedback',43,TEAL,True)
 for k,a in enumerate(['R3','R2','R1','R0']):
  panel(d,75+k*280,850,210,150,a,())
  if k<3:arrow(d,[(345+k*280,925),(295+k*280,925)])
 d.line((180,850,180,740,1050,740,1050,830),fill=ORANGE,width=6)
 d.ellipse((1018,748,1082,812),fill=WHITE,outline=ORANGE,width=4);tx(d,1034,747,'+',44,ORANGE,True)
 arrow(d,[(1140,780),(1083,780)],TEAL);tx(d,800,780,'Input bit',38,TEAL,True)
 d.line((880,740,880,900),fill=ORANGE,width=5)
 d.ellipse((855,900,905,950),fill=WHITE,outline=ORANGE,width=4);tx(d,865,890,'+',44,ORANGE,True)
 d.line((915,925,905,925),fill=TEAL,width=6);d.line((855,925,845,925),fill=TEAL,width=6)
 d.polygon([(845,925),(855,918),(855,932)],fill=TEAL)
 arrow(d,[(1050,830),(1050,850)],ORANGE)
 tx(d,75,1120,'4-bit toy: x^4 + x + 1; not the CRC32 circuit',44,ORANGE,True)
 panel(d,75,1320,1050,290,'This 4-cell sketch is a teaching model',['It is not the real CRC32 gate topology.','CRC32 uses a 32-bit state and defined parameters.','CRC is not authentication or encryption.'])
 foot(d,'Python zlib CRC values; both Sum8 values are the same.');save(im,1)
def figure2():
 im,d=begin('Follow the functional CRC data path','Original register-role diagram; no claim about exact internal gates or timing')
 blocks=[('AHB write to CRC_DR','8 / 16 / 32-bit accesses feed data.'),('REV_IN input bit reversal','BYTE reverses bit order inside each byte.'),('CRC engine / internal running state','CRC_POL sets polynomial; CRC_INIT sets seed.'),('REV_OUT output bit reversal','Output formatting does not reset internal state.'),('Read CRC_DR result','CRC_IDR is a separate independent data register.')]
 for k,(a,b)in enumerate(blocks):
  yy=285+k*260;panel(d,75,yy,1050,220,a,[b])
  if k<4:arrow(d,[(600,yy+225),(600,yy+250)])
 foot(d,'Bit reversal is not boolean NOT and not a byte-order swap.');save(im,2)
def figure3():
 im,d=begin('Match CRC32 with the complete parameters','Expected model for ASCII 123456789: exactly 9 bytes, no trailing NUL')
 blocks=[('Input bytes: 31 32 33 34 35 36 37 38 39','REV_IN = BYTE; no invented padding bytes.'),('32-bit polynomial / initial state','POL = 0x04C11DB7; INIT = 0xFFFFFFFF'),('Hardware output reversal enabled','RefIn=true and RefOut=true for ISO-HDLC.'),('HAL return / formatted DR','Expected raw value = 0x340BC6D9'),('Software final XOR, once','0x340BC6D9 XOR 0xFFFFFFFF = 0xCBF43926')]
 for k,(a,b)in enumerate(blocks):
  yy=285+k*260;panel(d,75,yy,1050,220,a,[b])
  if k<4:arrow(d,[(600,yy+225),(600,yy+250)])
 foot(d,'CBF43926 is the model check value, not an observed board result.');save(im,3)
def figure4():
 im,d=begin('Map configuration to HAL and registers','Original settings diagram, not a CubeMX screenshot or an observed GUI session')
 fields=[('Polynomial width / defaults','32 bits; polynomial 0x04C11DB7; INIT 0xFFFFFFFF'),('InputDataInversionMode = BYTE','CRC_CR.REV_IN[1:0] = 01'),('OutputDataInversionMode = ENABLE','CRC_CR.REV_OUT = 1'),('InputDataFormat = BYTES','HAL BufferLength counts bytes, not uint32_t elements.')]
 for k,(a,b)in enumerate(fields):
  yy=300+k*295;panel(d,75,yy,1050,235,a,[b])
  if k<3:arrow(d,[(600,yy+245),(600,yy+280)])
 panel(d,75,1510,1050,105,'Final XOR is software responsibility.',())
 foot(d,'A uint32_t pointer API does not change BYTES length semantics.');save(im,4)
def figure5():
 im,d=begin('Reset once, then continue the stream','Expected model results; the single hardware CRC unit needs serialized ownership')
 panel(d,65,300,470,330,'Calculate',['Reset state to INIT.','Process a new stream.'])
 panel(d,665,300,470,330,'Accumulate',['Keep running state.','Process the next chunk.'])
 arrow(d,[(300,650),(300,750),(600,750),(600,830)]);arrow(d,[(900,650),(900,750),(600,750)])
 panel(d,75,850,1050,250,'Calculate 1234 -> Accumulate 56789',['Final XOR result: 0xCBF43926','Calculate only 56789 resets -> 0x131DA070'])
 panel(d,75,1200,1050,250,'Byte tails are not zero / FF padding',['4 bytes: packed 32-bit; 3-byte tail: 16 + 8.','Wrapper: aligned scratch, arbitrary chunks.'])
 tx(d,75,1530,'Do not XOR and reseed the hardware between chunks.',42,ORANGE,True)
 foot(d,'Apply final XOR only when reporting the completed stream.');save(im,5)
def figure6():
 im,d=begin('Check an exact binary image interval','Actual build artifact and external manifest; no invented custom bootloader or golden word')
 tx(d,75,290,'Covered: [0x08000000, 0x08004838)',46,TEAL,True)
 tx(d,75,380,'Length: 18488 bytes; expected CRC32 = 249DA1ED',42,TEAL,True)
 labels=[('Vectors','0x08000000','.. 0x08000187'),('FF-filled gap','0x08000188','.. 0x0800018F'),('Rest of image','0x08000190','.. 0x08004837')]
 for k,(a,b,c)in enumerate(labels):panel(d,65+k*370,580,350,260,a,[b,c],ORANGE if k==1 else TEAL)
 tx(d,75,920,'Gap bytes are part of the chosen image.',44,ORANGE,True)
 arrow(d,[(600,1010),(600,1120)])
 panel(d,75,1140,1050,230,'External manifest defines the comparison',['Base / exclusive end / gap-fill policy / expected CRC.','The expected CRC field is outside this covered image.'])
 panel(d,75,1440,1050,165,'CRC detects accidental corruption, not authenticity',())
 foot(d,'This artifact check is not physical Flash readback or a signature.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson33-refresh-figure1.png', 'alt': 'ترتیب بایت و بازخورد در مدل CRC', 'caption': 'مثال محاسباتی تألیفی جابه\u200cجایی دو بایت 01 02 و 02 01: sum8 هر دو 03 است ولی zlib.crc32 به\u200cترتیب B6CC4292 و 04E840EB می\u200cدهد. مدل 4 خانه با چندجمله\u200cای آموزشی x^4+x+1 فقط برای توضیح feedback و XOR است، نه نقشهٔ واقعی گیت\u200cهای CRC32. این مثال اثبات کشف همهٔ جابه\u200cجایی\u200cها یا همهٔ خرابی\u200cها نیست؛ CRC احراز اصالت یا رمزنگاری نیست.', 'purpose': 'ترتیب بایت و بازخورد در مدل CRC', 'placement': 'بخش 1: پس از توضیح تفاوت\u200cهای متدهای کشف خطا', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc.c', 'version': 'HAL953955a', 'scope': 'Calculate/Accumulate, byte packing and tail writes'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc_ex.c', 'version': 'HAL953955a', 'scope': 'Bit reversal configuration'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted CRC sections', 'scope': 'Functional CRC registers and parameters'}, {'url': 'https://docs.python.org/3/library/zlib.html#zlib.crc32', 'version': 'Python official zlib documentation', 'scope': 'Offline CRC32 comparison, not a hardware measurement'}], 'type': 'original functional diagram / offline calculated example', 'source': 'Original Codex Pillow geometry based on accepted AG questions and pinned HAL/actual artifact facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 2, 'filename': 'lesson33-refresh-figure2.png', 'alt': 'مسیر عملکردی داده در واحد CRC', 'caption': 'نمودار تألیفی نقش CRC_DR، REV_IN، حالت داخلی موتور، CRC_POL، CRC_INIT و REV_OUT. reversal ترتیب بیت\u200cها را عوض می\u200cکند و NOT منطقی یا جابه\u200cجایی بایت نیست. خروجی قالب\u200cبندی\u200cشده به معنی reset شدن حالت داخلی نیست و CRC_IDR رجیستر مستقل است. شکل معماری گیت دقیق یا زمان محاسبه را ادعا نمی\u200cکند.', 'purpose': 'مسیر عملکردی داده در واحد CRC', 'placement': 'بخش 2: در بخش رجیسترها و ساختار داخلی سخت\u200cافزار', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc.c', 'version': 'HAL953955a', 'scope': 'Calculate/Accumulate, byte packing and tail writes'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc_ex.c', 'version': 'HAL953955a', 'scope': 'Bit reversal configuration'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted CRC sections', 'scope': 'Functional CRC registers and parameters'}, {'url': 'https://docs.python.org/3/library/zlib.html#zlib.crc32', 'version': 'Python official zlib documentation', 'scope': 'Offline CRC32 comparison, not a hardware measurement'}], 'type': 'original functional diagram / offline calculated example', 'source': 'Original Codex Pillow geometry based on accepted AG questions and pinned HAL/actual artifact facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 3, 'filename': 'lesson33-refresh-figure3.png', 'alt': 'پارامترهای کامل CRC32 و مقدار مورد انتظار', 'caption': 'نمودار محاسباتی تألیفی برای 9 بایت ASCII رشتهٔ 123456789 بدون NUL: width برابر 32، polynomial برابر 04C11DB7، init برابر FFFFFFFF، reverse ورودی به تفکیک بایت و reverse خروجی فعال؛ raw مورد انتظار 340BC6D9 و پس از XOR نرم\u200cافزاری FFFFFFFF برابر CBF43926 است. مقدار، نتیجهٔ مدل و آزمون شناخته\u200cشده است؛ مشاهدهٔ برد نیست.', 'purpose': 'پارامترهای کامل CRC32 و مقدار مورد انتظار', 'placement': 'بخش 3: در مبحث انطباق با استاندارد IEEE 802.3', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc.c', 'version': 'HAL953955a', 'scope': 'Calculate/Accumulate, byte packing and tail writes'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc_ex.c', 'version': 'HAL953955a', 'scope': 'Bit reversal configuration'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted CRC sections', 'scope': 'Functional CRC registers and parameters'}, {'url': 'https://docs.python.org/3/library/zlib.html#zlib.crc32', 'version': 'Python official zlib documentation', 'scope': 'Offline CRC32 comparison, not a hardware measurement'}], 'type': 'original functional diagram / offline calculated example', 'source': 'Original Codex Pillow geometry based on accepted AG questions and pinned HAL/actual artifact facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 4, 'filename': 'lesson33-refresh-figure4.png', 'alt': 'نگاشت تنظیمات به HAL و رجیستر', 'caption': 'جدول\u200cنمودار تألیفی تنظیمات واقعی پروژه: polynomial و init پیش\u200cفرض 32 بیتی، REV_IN=BYTE با bits برابر 01، REV_OUT فعال و InputDataFormat=BYTES. طول ورودی در این حالت تعداد بایت است، هرچند نوع pointer API برابر uint32_t* باشد. HAL final XOR را خودکار اعمال نمی\u200cکند؛ شکل GUI ساختگی نیست.', 'purpose': 'نگاشت تنظیمات به HAL و رجیستر', 'placement': 'بخش 4: در تشریح پیکربندی نرم\u200cافزاری CubeMX', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc.c', 'version': 'HAL953955a', 'scope': 'Calculate/Accumulate, byte packing and tail writes'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc_ex.c', 'version': 'HAL953955a', 'scope': 'Bit reversal configuration'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted CRC sections', 'scope': 'Functional CRC registers and parameters'}, {'url': 'https://docs.python.org/3/library/zlib.html#zlib.crc32', 'version': 'Python official zlib documentation', 'scope': 'Offline CRC32 comparison, not a hardware measurement'}], 'type': 'original functional diagram / offline calculated example', 'source': 'Original Codex Pillow geometry based on accepted AG questions and pinned HAL/actual artifact facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 5, 'filename': 'lesson33-refresh-figure5.png', 'alt': 'تفاوت شروع تازه و ادامهٔ محاسبه', 'caption': 'مدل تألیفی Calculate که حالت را از INIT بازنشانی می\u200cکند و Accumulate که ادامه می\u200cدهد. Calculate روی 1234 و سپس Accumulate روی 56789 پس از final XOR، CBF43926 می\u200cدهد؛ Calculate تازه فقط روی 56789 مقدار 131DA070 می\u200cدهد. wrapper واقعی scratch هم\u200cتراز دارد؛ tail سه\u200cبایتی با نوشتن 16 و 8 بیتی پردازش می\u200cشود و padding اضافه نمی\u200cشود. همهٔ این مقادیر مدل\u200cاند، نه مشاهدهٔ سخت\u200cافزار.', 'purpose': 'تفاوت شروع تازه و ادامهٔ محاسبه', 'placement': 'بخش 5: در تحلیل توابع درایور HAL', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc.c', 'version': 'HAL953955a', 'scope': 'Calculate/Accumulate, byte packing and tail writes'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc_ex.c', 'version': 'HAL953955a', 'scope': 'Bit reversal configuration'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted CRC sections', 'scope': 'Functional CRC registers and parameters'}, {'url': 'https://docs.python.org/3/library/zlib.html#zlib.crc32', 'version': 'Python official zlib documentation', 'scope': 'Offline CRC32 comparison, not a hardware measurement'}], 'type': 'original functional diagram / offline calculated example', 'source': 'Original Codex Pillow geometry based on accepted AG questions and pinned HAL/actual artifact facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 6, 'filename': 'lesson33-refresh-figure6.png', 'alt': 'محدودهٔ واقعی فایل و manifest بیرونی', 'caption': 'نقشهٔ تألیفی تصویر واقعی build با بازهٔ نیمه\u200cباز [0x08000000,0x08004838) و طول 18488 B و CRC مورد انتظار 249DA1ED. شکاف [0x08000188,0x08000190) با FF پر شده و داخل محاسبه است. manifest بیرونی base، end، سیاست gap-fill و CRC را مشخص می\u200cکند؛ bootloader یا golden CRC خیالی داخل Flash ساخته نشده است. این بررسی فایل، readback فیزیکی یا امضای اصالت نیست.', 'purpose': 'محدودهٔ واقعی فایل و manifest بیرونی', 'placement': 'بخش 6: در مبحث اعتبارسنجی فریمور در حافظه فلش', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc.c', 'version': 'HAL953955a', 'scope': 'Calculate/Accumulate, byte packing and tail writes'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_crc_ex.c', 'version': 'HAL953955a', 'scope': 'Bit reversal configuration'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted CRC sections', 'scope': 'Functional CRC registers and parameters'}, {'url': 'https://docs.python.org/3/library/zlib.html#zlib.crc32', 'version': 'Python official zlib documentation', 'scope': 'Offline CRC32 comparison, not a hardware measurement'}], 'type': 'original functional diagram / offline calculated example', 'source': 'Original Codex Pillow geometry based on accepted AG questions and pinned HAL/actual artifact facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}]
if __name__=='__main__':run()

# منابع فنی درس 36

تاریخ بررسی: 2026-11-02. خلاصه‌های این فایل تألیفی هستند؛ متن یا شکل کتاب بازنشر نشده است.

- [کتاب رسمی FreeRTOS، فصل 1](https://github.com/FreeRTOS/FreeRTOS-Kernel-Book/blob/V1.1.0/ch01.md)، بخش‌های 1.1.1، 1.1.4 و 1.1.6: تعریف نیاز زمانی، کاربرد و هزینه‌های RTOS و مجوز. برای تعریف Hard و Soft real-time و تصمیم استفاده از RTOS خوانده شد. نسخهٔ ثابت کتاب Release 1.1.0 مرجع مفهومی است؛ نسخهٔ هستهٔ پروژه از فایل‌های واقعی پروژه مشخص می‌شود.
- [مستند رسمی زمان‌بندی FreeRTOS](https://www.freertos.org/Documentation/02-Kernel/02-Kernel-features/01-Tasks-and-co-routines/04-Task-scheduling): سیاست پیش‌دستانه بر اساس اولویت، تنها یک Task در حال اجرا روی هر هسته و گزینهٔ تقسیم زمان. این مدل زمان اجرای واقعی این سیاست را اندازه نمی‌گیرد.
- [راهنمای رسمی مبانی هستهٔ FreeRTOS در AWS](https://docs.aws.amazon.com/freertos/latest/userguide/dev-guide-freertos-kernel.html): اجزای اصلی هسته و ملاحظهٔ پیش‌بینی‌پذیری عملیات هسته. قابلیت هسته به معنای تضمین مهلت همهٔ برنامه‌ها نیست.
- [مجوز هستهٔ FreeRTOS در نسخهٔ V11.2.0](https://github.com/FreeRTOS/FreeRTOS-Kernel/blob/V11.2.0/LICENSE.md): مجوز MIT و الزام حفظ متن مجوز در نسخه‌های توزیع‌شدهٔ مشمول آن. شرایط سایر اجزای یک پروژه باید جدا بررسی شود.
- [سربرگ رسمی task.h در V11.2.0](https://github.com/FreeRTOS/FreeRTOS-Kernel/blob/V11.2.0/include/task.h): شناسایی نسخه و نام API اصلی؛ جزئیات عملی در درس‌های بعدی آموزش داده می‌شوند.
- [معرفی CMSIS-RTOS2 از Arm](https://arm-software.github.io/CMSIS_6/latest/RTOS2/index.html) و [مخزن رسمی CMSIS-FreeRTOS](https://github.com/ARM-software/CMSIS-FreeRTOS): CMSIS-RTOS2 یک رابط عمومی برای هسته‌هاست؛ پیاده‌سازی CMSIS-FreeRTOS آن را به FreeRTOS متصل می‌کند. این رابط با هستهٔ FreeRTOS دو سیستم‌عامل مستقل نیستند.

در بخش FreeRTOS این دوره، API اصلی FreeRTOS انتخاب شده است تا نام‌ها و مفاهیم مورد استفاده در Word و نمونه‌های عملی یکدست بمانند. این یک تصمیم آموزشی برای این دوره است؛ به معنای بی‌اعتباری CMSIS-RTOS2 یا برتری همیشگی API اصلی نیست.

"""Educational discrete-time model, not FreeRTOS execution or board measurement.

Python standard library only. Output is deterministic and contains no measured
STM32 timing. Integer slots have an assumed duration of 1 ms. All CPU/context
switch/interrupt overheads are deliberately omitted and explicitly reported.
"""
from pathlib import Path
import csv
import json

ROOT = Path(__file__).resolve().parent
HORIZON_MS = 100
MODES = ("long_nonpreemptive_jobs", "ideal_preemptive_priority", "cooperative_1ms_chunks")
TASKS = (
    {"name": "sense", "period_ms": 10, "execution_ms": 1, "deadline_ms": 2, "priority": 2},
    {"name": "display", "period_ms": 50, "execution_ms": 12, "deadline_ms": 50, "priority": 1},
)


def simulate(mode):
    """Select higher-priority ready work; long mode runs one whole job."""
    assert mode in MODES
    jobs = []
    timeline = []
    current = None
    for now in range(HORIZON_MS):
        for task in TASKS:
            if now % task["period_ms"] == 0:
                jobs.append({
                    "task": task["name"], "release_ms": now,
                    "absolute_deadline_ms": now + task["deadline_ms"],
                    "remaining_ms": task["execution_ms"], "priority": task["priority"],
                    "start_ms": None, "finish_ms": None,
                })
        ready = [job for job in jobs if job["remaining_ms"] > 0]
        # In long mode the current job cannot be interrupted by another job.
        # In the other modes selection occurs at every 1 ms slot boundary.
        if mode != "long_nonpreemptive_jobs" or current is None:
            current = max(ready, key=lambda job: (job["priority"], -job["release_ms"]), default=None)
        if current is None:
            timeline.append({"time_ms": now, "task": "idle", "job_release_ms": ""})
            continue
        if current["start_ms"] is None:
            current["start_ms"] = now
        timeline.append({"time_ms": now, "task": current["task"], "job_release_ms": current["release_ms"]})
        current["remaining_ms"] -= 1
        if current["remaining_ms"] == 0:
            current["finish_ms"] = now + 1
            current = None
    for job in jobs:
        finish = job["finish_ms"]
        job["response_ms"] = None if finish is None else finish - job["release_ms"]
        job["deadline_missed"] = finish is None or finish > job["absolute_deadline_ms"]
    assert all(job["remaining_ms"] == 0 for job in jobs), "Increase horizon or account for incomplete work."
    assert sum(row["task"] != "idle" for row in timeline) == 34
    sense_jobs = [job for job in jobs if job["task"] == "sense"]
    summary = {
        "mode": mode, "completed_jobs": len(jobs),
        "sense_jobs": len(sense_jobs),
        "sense_max_response_ms": max(job["response_ms"] for job in sense_jobs),
        "sense_deadline_misses": sum(job["deadline_missed"] for job in sense_jobs),
        "all_deadline_misses": sum(job["deadline_missed"] for job in jobs),
    }
    return jobs, timeline, summary


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    output = ROOT / "model-output"
    output.mkdir(exist_ok=True)
    summaries = []
    checks = 0
    for mode in MODES:
        jobs, timeline, summary = simulate(mode)
        write_csv(output / f"{mode}-jobs.csv", jobs)
        write_csv(output / f"{mode}-timeline.csv", timeline)
        summaries.append(summary)
        assert summary["completed_jobs"] == 12
        assert summary["sense_jobs"] == 10
        checks += 2
    assert summaries[0]["sense_max_response_ms"] == 4
    assert summaries[0]["sense_deadline_misses"] == 2
    assert summaries[1]["sense_max_response_ms"] == summaries[2]["sense_max_response_ms"] == 1
    assert summaries[1]["all_deadline_misses"] == summaries[2]["all_deadline_misses"] == 0
    checks += 4
    results = {
        "kind": "educational_model_not_measurement",
        "actual_freertos_kernel_executed": False,
        "stm32_board_executed": False,
        "horizon_ms": HORIZON_MS, "slot_ms": 1, "tasks": TASKS,
        "assumptions": [
            "All releases and work boundaries align with 1 ms integer slots.",
            "There is one CPU and no ISR interference, resource contention, cache or bus timing model.",
            "Context switches, scheduler selection and polling checks have zero modeled execution cost.",
            "Long nonpreemptive jobs represent one deliberately blocking loop design, not all bare-metal software.",
            "The cooperative design voluntarily returns after each 1 ms work chunk.",
            "The preemptive policy is an idealized priority model, not a FreeRTOS timing simulator.",
            "Task execution times and deadlines are illustrative assumptions, not measured or safety-certified values.",
        ],
        "summaries": summaries,
        "verification": {"assertions_passed": checks, "status": "PASS"},
    }
    (output / "results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()

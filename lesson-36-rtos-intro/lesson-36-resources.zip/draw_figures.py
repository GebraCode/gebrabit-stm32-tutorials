"""Original scientific diagrams; CSV-derived timing model, never measured data.

Pillow is used only for plots and vector-like diagram primitives. Each drawing
is also exported as editable SVG from the same geometry. No copied artwork,
AI-generated screenshots, external image assets or redistributed fonts.
"""
from pathlib import Path
import csv
import hashlib
import html
import json
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'images'
OUT.mkdir(exist_ok=True)
W, H = 1200, 1700
INK, BLUE, TEAL, RED = '#152C43', '#285BBA', '#087A75', '#B6323B'
GRAY, LIGHT, WHITE, GRID = '#596B7A', '#F0F4F7', '#FFFFFF', '#CCD6DF'
FONT = Path('C:/Windows/Fonts/arial.ttf')
BOLD = Path('C:/Windows/Fonts/arialbd.ttf')


class Figure:
    def __init__(self, number, title, subtitle):
        self.number = number
        self.image = Image.new('RGB', (W, H), WHITE)
        self.draw = ImageDraw.Draw(self.image)
        self.svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
                    f'<title>{html.escape(title)}</title>',
                    f'<desc>{html.escape(subtitle)} Original educational diagram, not measurement.</desc>',
                    '<rect width="100%" height="100%" fill="white"/>']
        self.text(75, 65, f'GEBRABIT  /  STM32  /  LESSON 36  /  FIGURE {number}', 27, GRAY, True)
        self.paragraph(75, 135, title, 1050, 54, INK, True, gap=8)
        self.paragraph(75, 285, subtitle, 1050, 35, GRAY, gap=8)

    def text(self, x, y, text, size=42, color=INK, bold=False, anchor=None):
        font = ImageFont.truetype(str(BOLD if bold else FONT), size)
        # Coordinates are top-left, consistently converted to SVG baseline.
        if anchor == 'center':
            x -= self.draw.textlength(text, font=font) / 2
        self.draw.text((x, y), text, font=font, fill=color, anchor='lt')
        self.svg.append(f'<text x="{x:.2f}" y="{y+size*.91:.2f}" font-family="Arial,sans-serif" font-size="{size}" font-weight="{"700" if bold else "400"}" fill="{color}">{html.escape(text)}</text>')

    def paragraph(self, x, y, text, width=1050, size=42, color=INK, bold=False, gap=12):
        font = ImageFont.truetype(str(BOLD if bold else FONT), size)
        lines, line = [], ''
        for word in text.split():
            trial = (line + ' ' + word).strip()
            if line and self.draw.textlength(trial, font=font) > width:
                lines.append(line); line = word
            else:
                line = trial
        if line:
            lines.append(line)
        for item in lines:
            self.text(x, y, item, size, color, bold)
            y += size + gap
        return y

    def rect(self, x, y, width, height, fill=LIGHT, outline=GRID, stroke=3):
        self.draw.rectangle((x, y, x+width, y+height), fill=fill, outline=outline, width=stroke)
        self.svg.append(f'<rect x="{x}" y="{y}" width="{width}" height="{height}" fill="{fill}" stroke="{outline}" stroke-width="{stroke}"/>')

    def line(self, points, color=INK, width=4, dashed=False):
        if dashed:
            for (x1,y1),(x2,y2) in zip(points,points[1:]):
                length=((x2-x1)**2+(y2-y1)**2)**.5
                for k in range(0,int(length),20):
                    a=k/length; z=min(k+10,length)/length
                    self.draw.line((x1+(x2-x1)*a,y1+(y2-y1)*a,x1+(x2-x1)*z,y1+(y2-y1)*z),fill=color,width=width)
        else:
            self.draw.line(points, fill=color, width=width, joint='curve')
        coords=' '.join(f'{x},{y}' for x,y in points)
        self.svg.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="{width}"'+(' stroke-dasharray="10 10"' if dashed else '')+'/>')

    def arrow(self, points, color=INK, width=5):
        self.line(points,color,width)
        x,y=points[-1]; px,py=points[-2]
        import math
        angle=math.atan2(y-py,x-px)
        poly=[(x,y),(x-22*math.cos(angle-.42),y-22*math.sin(angle-.42)),(x-22*math.cos(angle+.42),y-22*math.sin(angle+.42))]
        self.draw.polygon(poly,fill=color)
        self.svg.append('<polygon points="'+' '.join(f'{a:.1f},{b:.1f}' for a,b in poly)+f'" fill="{color}"/>')

    def card(self, y, heading, body, height=190, x=75, width=1050, color=INK):
        self.rect(x,y,width,height)
        yy=self.paragraph(x+25,y+23,heading,width-50,44,color,True,gap=8)
        self.paragraph(x+25,yy+12,body,width-50,38,INK,gap=9)

    def finish(self, note):
        self.line([(75,1585),(1125,1585)],GRID,3)
        self.paragraph(75,1610,note,1050,31,GRAY,gap=5)
        stem=f'lesson36-figure{self.number}'
        self.image.save(OUT/f'{stem}.png',optimize=True)
        (OUT/f'{stem}.svg').write_text('\n'.join(self.svg+['</svg>']),'utf8')
        for width in (390,600):
            self.image.resize((width,round(H*width/W)),Image.Resampling.LANCZOS).save(OUT/f'{stem}-preview{width}.png')


def rows(mode):
    with (ROOT/'model-output'/f'{mode}-timeline.csv').open(encoding='utf8') as stream:
        return list(csv.DictReader(stream))


def intervals(mode, task, horizon=20):
    starts=[]; begin=None
    for row in rows(mode)[:horizon]:
        t=int(row['time_ms'])
        if row['task']==task and begin is None:begin=t
        elif row['task']!=task and begin is not None:starts.append((begin,t));begin=None
    if begin is not None:starts.append((begin,horizon))
    return starts


def axis(f,y,x=100,width=1000):
    f.line([(x,y),(x+width,y)],INK,4)
    for tick in range(0,21,5):
        xx=x+width*tick/20
        f.line([(xx,y-7),(xx,y+13)],INK,4)
        f.text(xx,y+27,str(tick),38,anchor='center')
    f.text(x+width/2,y+83,'Time (ms)',40,anchor='center')


def timing_strip(f,mode,y,height=105,chunk=False):
    x,width=100,1000
    colors={'sense':BLUE,'display':TEAL,'idle':'#E0E7ED'}
    names={'sense':'S','display':'D','idle':'Idle'}
    for task in ('sense','display','idle'):
        for start,end in intervals(mode,task):
            xx=x+start*width/20; ww=(end-start)*width/20
            f.rect(xx,y,ww,height,colors[task],INK,3)
            if ww>90:
                f.text(xx+ww/2,y+32,names[task],38,WHITE if task!='idle' else GRAY,True,anchor='center')
            elif task=='sense':
                f.text(xx+ww/2,y+32,'S',36,WHITE,True,anchor='center')
            if chunk and task=='display':
                for tick in range(start+1,end):
                    f.line([(x+tick*width/20,y),(x+tick*width/20,y+height)],WHITE,3)
    axis(f,y+height+16)


def figure1():
    f=Figure(1,'A long job delays the next sensor job','Educational model from actual CSV output; no board timing measured.')
    f.text(100,405,'Sense jobs',43,BLUE,True)
    for a,b in intervals('long_nonpreemptive_jobs','sense'):
        f.rect(100+a*50,470,(b-a)*50,100,BLUE,INK,3)
    f.text(100,625,'Display job',43,TEAL,True)
    for a,b in intervals('long_nonpreemptive_jobs','display'):
        f.rect(100+a*50,690,(b-a)*50,100,TEAL,INK,3)
    for tick,color in [(10,GRAY),(12,RED),(14,BLUE)]:
        f.line([(100+tick*50,450),(100+tick*50,830)],color,4,True)
    axis(f,840)
    for xx,title,value,color in [(75,'Released','10ms',INK),(435,'Deadline','12ms',RED),(795,'Finished','14ms',BLUE)]:
        f.rect(xx,1045,330,155)
        f.text(xx+20,1066,title,39,color,True);f.text(xx+20,1128,value,45,color,True)
    f.card(1250,'Response = finish - release','14ms - 10ms = 4ms; relative deadline = 2ms.',190,color=RED)
    f.paragraph(85,1480,'Waiting = 13ms - 10ms = 3ms; execution = 1ms.',1030,36)
    f.finish('One blocking design only. Other bare-metal designs can avoid this wait.')


def figure2():
    f=Figure(2,'Two designs can meet this model deadline','Identical illustrative jobs; one CPU; switching and polling cost assumed zero.')
    f.text(100,410,'Ideal preemptive priority',46,INK,True)
    timing_strip(f,'ideal_preemptive_priority',500)
    f.text(100,760,'Cooperative 1ms chunks',46,INK,True)
    timing_strip(f,'cooperative_1ms_chunks',850,chunk=True)
    f.rect(100,1125,45,45,BLUE,INK);f.text(165,1124,'S = Sense',39)
    f.rect(570,1125,45,45,TEAL,INK);f.text(635,1124,'D = Display',39)
    f.card(1230,'Sense runs from 10ms to 11ms in both','Response = 1ms; no missed deadlines in this 100ms model.',220)
    f.paragraph(85,1480,'All releases and work boundaries align to 1ms slots.',1030,36)
    f.finish('Conceptual policy model, not a FreeRTOS simulator or measured equivalence.')


def deadline_line(f,y):
    f.arrow([(150,y),(1060,y)],GRAY,4)
    for x,label,col in [(170,'Release',INK),(700,'Deadline',RED),(1000,'Late finish',INK)]:
        f.line([(x,y-25),(x,y+20)],col,4)
        f.text(x,y+45,label,36,col,True,anchor='center')
    f.line([(170,y-72),(700,y-72)],BLUE,4)
    f.text(435,y-125,'Allowed response interval',34,BLUE,anchor='center')


def figure3():
    f=Figure(3,'Hard and soft describe the requirement','The distinction is the consequence of missing a deadline, not CPU speed.')
    f.text(85,425,'HARD real-time requirement',46,INK,True)
    deadline_line(f,650)
    f.card(790,'A miss violates the required function','The consequence need not always be physical damage.',190)
    f.text(85,1050,'SOFT real-time requirement',46,INK,True)
    deadline_line(f,1250)
    f.paragraph(100,1395,'A miss reduces service quality within the stated application requirements.',1000,42)
    f.finish('Original concept diagram. Line spacing has no measured time or utility scale.')


def figure4():
    f=Figure(4,'Two API paths to the same kernel','Native API is the course choice; CMSIS-RTOS2 is a standardized interface.')
    f.card(410,'Application logic','Choose the API and verify its implementation.',165)
    f.arrow([(330,590),(330,670)]);f.arrow([(870,590),(870,670)])
    f.rect(75,690,500,220);f.rect(625,690,500,220)
    f.paragraph(100,722,'Native API',450,44,INK,True)
    f.paragraph(100,805,'xTaskCreate',450,39,BLUE)
    f.paragraph(650,722,'CMSIS-RTOS2 API',450,44,INK,True)
    f.paragraph(650,805,'osThreadNew',450,39,BLUE)
    f.line([(325,925),(325,1180),(600,1180)])
    f.arrow([(875,925),(875,965)])
    f.rect(625,980,500,145)
    f.paragraph(650,1004,'CMSIS-FreeRTOS adapter',450,39,INK,True)
    f.line([(875,1140),(875,1180),(600,1180)])
    f.arrow([(600,1180),(600,1205)])
    f.card(1205,'FreeRTOS kernel','Same kernel; compatible behavior still needs checking.',170)
    f.arrow([(600,1390),(600,1430)])
    f.rect(75,1450,1050,95)
    f.text(600,1472,'Cortex-M4 hardware',43,INK,True,anchor='center')
    f.finish('CMSIS-RTOS2 is a specification; CMSIS-FreeRTOS supplies an implementation.')


def figure5():
    f=Figure(5,'Choose from requirements, not a cutoff','No fixed RAM amount or number of states decides whether RTOS is needed.')
    cards=[
        ('1  Timing','What are the deadlines and worst-case work times?'),
        ('2  Coordination','Which activities wait, share data or block each other?'),
        ('3  Resources','Can RAM, stack space and CPU overhead fit?'),
        ('4  Maintenance','Does task separation simplify testing and future changes?'),
    ]
    for i,(title,body) in enumerate(cards):f.card(410+i*230,title,body,195)
    f.card(1365,'Compare the actual designs','A bounded loop/state machine may suffice; RTOS can organize more involved work.',185,color=TEAL)
    f.finish('Assess a design against its requirements; neither choice is an automatic guarantee.')


def figure6():
    f=Figure(6,'Two counters with separate ownership','Actual shared lesson37 baseline, compiled for STM32F303CBT6; not board-tested.')
    f.card(410,'Shared MCU clock configuration','HCLK = 72MHz; TIM6 input clock = 72MHz.',175)
    f.arrow([(325,600),(325,690)]);f.arrow([(875,600),(875,690)])
    for x,title,body in [(75,'TIM6','HAL timebase'),(625,'SysTick','Kernel tick')]:
        f.rect(x,715,500,215)
        f.text(x+250,748,title,47,INK,True,anchor='center')
        f.text(x+250,831,body,41,INK,anchor='center')
        f.arrow([(x+250,945),(x+250,1010)])
        f.rect(x,1030,500,190)
        f.text(x+250,1060,'1000Hz / 1ms',41,BLUE,True,anchor='center')
    f.text(325,1138,'HAL tick counter',38,INK,anchor='center')
    f.text(875,1138,'Kernel tick counter',38,INK,anchor='center')
    f.card(1300,'Separate counters, not separate oscillators','This avoids tick ownership overlap. Blocking waits in ISRs are not made universally safe.',235)
    f.finish('Source: generated HAL TIM6 timebase and actual FreeRTOSConfig.h, V11.2.0.')


def main():
    for fn in (figure1,figure2,figure3,figure4,figure5,figure6):fn()
    plan_path=ROOT.parent/'accepted-plan.json'
    if plan_path.exists():
        plan=json.loads(plan_path.read_text('utf8'))
        meta=[]
        for i,item in enumerate(plan['images'],1):
            png=OUT/f'lesson36-figure{i}.png'
            meta.append(dict(id=item['id'],filename=str(png.relative_to(ROOT)).replace('\\','/'),
                svg=f'images/lesson36-figure{i}.svg',width=W,height=H,
                sha256=hashlib.sha256(png.read_bytes()).hexdigest(),bytes=png.stat().st_size,
                alt=item['alt'],caption=item['caption'],placement=item['placement'],question=item['question'],
                type='original scientific plot / explanatory diagram',source=item['source'],
                rights='Original geometry and labels; no official artwork copied; system font not redistributed. Original assets under accompanying MIT license.',
                AI_generated_image=False,physical_measurement=False,
                visual_review='pending actual viewing of all 390px and600px previews by Codex'))
        (ROOT/'image-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n','utf8')
    print('Created 6 PNG, 6 editable SVG and 12 width previews.')


if __name__=='__main__':main()

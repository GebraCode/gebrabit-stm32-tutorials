"""Check actual archived source/artifact formats and nominal timing, never touches target."""
from pathlib import Path
import json,zipfile,hashlib,struct,re
P=Path(__file__).resolve().parent;checks=[]
def check(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
f=json.loads((P/'toolchain-and-validation-v2.json').read_text(encoding='utf-8'))
z=zipfile.ZipFile(P/'lesson-06-project-v2.zip');src={n.split('/',1)[1]:z.read(n) for n in z.namelist() if not n.endswith('/')}
m=json.loads((P/'source-manifest-v2.json').read_text())
check('source ZIP CRC',z.testzip() is None)
check('85 source hashes match',len(src)==85 and all(hashlib.sha256(src[k]).hexdigest()==v for k,v in m.items()))
main=src['Core/Src/main.c'].decode();hal=src['Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.c'].decode()
check('actual user loop statements',bool(re.search(r'/\* USER CODE BEGIN 3 \*/\s*HAL_GPIO_TogglePin\(USER_LED_GPIO_Port, USER_LED_Pin\);\s*HAL_Delay\(500U\);',main)))
check('HAL adds tick to threshold','wait += (uint32_t)(uwTickFreq);' in hal)
delay_ms=500;tick_ms=1
timing={'requested_half_period_ms':delay_ms,'nominal_full_period_ms':2*delay_ms,'nominal_frequency_hz':1000/(2*delay_ms),'HAL_wait_threshold_ticks':(delay_ms+tick_ms)//tick_ms}
check('two toggles make nominal cycle',timing['nominal_full_period_ms']==1000 and timing['nominal_frequency_hz']==1)
check('501 tick threshold not exact501ms',timing['HAL_wait_threshold_ticks']==501)
az=zipfile.ZipFile(P/'lesson-06-build-artifacts-v2.zip');check('artifact ZIP CRC',az.testzip() is None);artifact_results={}
for preset,meta in f['builds'].items():
 blobs={}
 for ext,v in meta['files'].items():
  n=next(n for n in az.namelist() if ('/'+preset+'/' in '/'+n) and n.endswith('.'+ext));b=az.read(n);blobs[ext]=b
  check(preset+' '+ext+' SHA and disk size',len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'])
 b=blobs['elf'];check(preset+' actual ARM ELF32 littleendian',b[:6]==b'\x7fELF\x01\x01' and struct.unpack_from('<H',b,18)[0]==40)
 h=struct.unpack_from('<16sHHIIIIIHHHHHH',b);sh=[struct.unpack_from('<IIIIIIIIII',b,h[6]+i*h[11]) for i in range(h[12])];st=sh[h[13]];names=b[st[4]:st[4]+st[5]]
 sec={names[x[0]:].split(b'\0',1)[0].decode():{'address':x[3],'bytes':x[5],'type':x[1]} for x in sh}
 check(preset+' exact RAM sections',sec['.data']['bytes']==12 and sec['.bss']['bytes']==32 and sec['._user_heap_stack']['bytes']==1540)
 check(preset+' exact DWARF presence',sec['.debug_info']['bytes']==meta['DWARF_debug_info_section_bytes'])
 check(preset+' RAM total includes alignment',12+32+4+512+1024==meta['ram_region_bytes']==1584)
 check(preset+' BIN image vs ELF disk size',len(blobs['bin'])==meta['flash_region_bytes'] and len(blobs['elf'])>len(blobs['bin']))
 image={};base=0;end=False
 for line in blobs['hex'].decode().splitlines():
  if not line:continue
  if not line.startswith(':'):raise AssertionError('HEX missing colon')
  r=bytes.fromhex(line[1:]);assert len(r)==r[0]+5 and sum(r)%256==0
  off=(r[1]<<8)|r[2];typ=r[3];payload=r[4:-1]
  if typ==4:base=int.from_bytes(payload,'big')<<16
  elif typ==2:base=int.from_bytes(payload,'big')<<4
  elif typ==0:
   for i,v in enumerate(payload):
    address=base+off+i
    if address in image and image[address]!=v:raise AssertionError('contradictory HEX overlap')
    image[address]=v
  elif typ==1:end=True
 check(preset+' HEX records valid and EOF',end and bool(image))
 check(preset+' actual HEX flash start',min(image)==0x08000000)
 reconstructed=bytes(image.get(i,0) for i in range(min(image),max(image)+1))
 check(preset+' HEX payload equals raw BIN',reconstructed==blobs['bin'])
 artifact_results[preset]={'flash_bytes':meta['flash_region_bytes'],'ELF_disk_bytes':len(b),'RAM_sections':{k:sec[k] for k in ['.data','.bss','._user_heap_stack']},'DWARF_debug_info_bytes':sec['.debug_info']['bytes'],'HEX_payload_matches_BIN':True}
report={'kind':'archived source/artifact checks and nominal timing; separate real build reports','checks_passed':len(checks),'checks':checks,'timing':timing,'artifacts':artifact_results,'limits':'No programming, target reads, GUI import/build, Option Bytes operation or board timing measurement. ReleaseC-g0 does not guarantee every linked object has no DWARF. HAL wait threshold is not exact physical501ms; tick phase/clock/interrupts affect observation.'}
(P/'blink-artifact-results-v2.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))

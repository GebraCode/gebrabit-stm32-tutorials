"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=6
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Know which file answers which question','Actual build tools produce distinct target and host-side artifacts')
 panel(d,70,300,490,170,'C source',['GCC compiler'])
 panel(d,650,300,480,170,'Assembly source',['Assembler'])
 arrow(d,[(300,490),(300,600),(600,600),(600,680)]);arrow(d,[(900,490),(900,600),(600,600)])
 panel(d,70,700,1060,190,'Object files + linker script -> linker',['ELF program image + MAP memory report'])
 arrow(d,[(600,910),(600,1030)])
 panel(d,70,1050,1060,220,'objcopy from ELF',['HEX: text records with addresses','BIN: raw bytes; the load address is separate'])
 panel(d,70,1390,1060,185,'Debug / Release are actual flag selections',['C: -O0 -g3 versus -Os -g0 in this project'])
 foot(d,'Release ELF still contains some DWARF in this actual build.');save(im,1)
def figure2():
 im,d=begin('Separate stored bytes from reserved RAM','Actual lesson6 RAM breakdown; block heights are not proportional')
 panel(d,60,300,500,180,'Flash: 128 KiB',['0x08000000 base'])
 panel(d,650,300,490,180,'Main SRAM: 32 KiB',['0x20000000 base'])
 for k,(a,b)in enumerate([('Vectors + code','.data: 12 bytes'),('Read-only constants','.bss: 32 bytes'),('Initial .data bytes','Alignment: 4 bytes')]):
  y=590+k*200;panel(d,60,y,500,145,a,());panel(d,650,y,490,145,b,())
 arrow(d,[(570,1050),(610,1050),(610,655),(640,655)],ORANGE)
 tx(d,65,1200,'Startup copies .data and zeroes .bss',43,ORANGE)
 panel(d,65,1330,1070,245,'RAM link-region total: 1584 bytes',['12 + 32 + 4 + 512 heap + 1024 stack','Heap/stack section: 1540 including alignment'])
 foot(d,'Reservations are not measured live stack or heap use.');save(im,2)
def figure3():
 im,d=begin('Connect signals before assuming power','Logical SWD connection; check the manual for your exact probe')
 tx(d,75,300,'Probe',48,TEAL,True);tx(d,760,300,'Target board',48,TEAL,True)
 rows=[('SWDIO','PA13'),('SWCLK','PA14'),('GND','Common GND'),('Target reference','VDD reference'),('NRST','NRST')]
 for k,(a,b)in enumerate(rows):
  y=470+k*170;tx(d,75,y,a,40,TEAL,True);tx(d,765,y,b,40,TEAL,True);arrow(d,[(465,y+30),(735,y+30)])
 panel(d,75,1310,1050,300,'Reference is not power',['VTref does not guarantee automatic level shifting.','Use a known board power path; never feed 5 V to 3V3.'])
 foot(d,'Standard ST-LINK/V2 outputs require model-specific checking.');save(im,3)
def figure4():
 im,d=begin('Program a known image deliberately','Procedure model; no device connection or programming was performed')
 steps=[('1 Check target and probe','Power, reference, ground and logical SWD signals'),('2 Connect and inspect identity','Use Normal or justified Under Reset with NRST'),('3 Select the correct image','HEX/ELF carry addresses; BIN needs a load address'),('4 Program and verify','Readback agreement checks stored bytes'),('5 Reset / run and observe','Correct behavior still needs a real board check')]
 for k,(a,b)in enumerate(steps):
  y=290+k*255;panel(d,80,y,1040,195,a,[b])
  if k<4:arrow(d,[(600,y+202),(600,y+245)])
 foot(d,'For this linked image, Flash starts at 0x08000000.');save(im,4)
def figure5():
 im,d=begin('Read protection is not a practice switch','Conceptual RDP states for STM32F303; this lesson only inspects settings')
 panel(d,75,300,1050,210,'Level 0',['No read protection; other access conditions still apply'])
 arrow(d,[(600,525),(600,660)],ORANGE)
 panel(d,75,675,1050,210,'Level 1',['Restricted access to protected memory'])
 arrow(d,[(1080,900),(1080,1090)],RED)
 tx(d,75,960,'Entering Level 2 has no return.',42,RED)
 panel(d,75,1110,1050,210,'Level 2: irreversible',['Do not activate it as an educational experiment'],RED)
 tx(d,75,1410,'Level 1 -> 0: Flash erase on regression',42,ORANGE)
 tx(d,75,1490,'Arrows illustrate protection changes, not commands to run.',40)
 tx(d,75,1570,'No actual Option Bytes read or write was performed.',40)
 foot(d,'No recovery arrow is shown from Level 2.');save(im,5)
def figure6():
 im,d=begin('Diagnose a failed connection one layer at a time','A decision path, not proof of any one hardware fault')
 qs=[('Power and reference plausible?','If not: check the known supply path and common ground.'),('Logical wiring and reset correct?','If not: check PA13, PA14, NRST and probe pinout.'),('Could running software obstruct access?','Try justified Under Reset with NRST and correct settings.'),('Still blocked?','Check boot configuration and device/probe documentation.')]
 for k,(a,b)in enumerate(qs):
  y=300+k*310;panel(d,75,y,1050,220,a,[b])
  if k<3:arrow(d,[(600,y+230),(600,y+300)])
 tx(d,75,1570,'BOOT0 is not a universal repair; do not leave NRST held LOW.',40,ORANGE)
 foot(d,'No detached-HSE test applies to this HSI-only project.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson06-refresh-figure1.png', 'alt': 'مسیر واقعی ابزارهای ساخت و قالب\u200cهای خروجی', 'caption': 'نمودار تألیفی ورودی\u200cهای C و اسمبلی تا فایل\u200cهای شیء و لینک ELF و MAP و تبدیل objcopy به HEX و BIN. پرچم\u200cهای C در پروژهٔ واقعی Debug برابر -O0 -g3 و Release برابر -Os -g0 است؛ ELF حالت Release همچنان مقداری DWARF دارد و اندازهٔ فایل روی دیسک مصرف Flash نیست.', 'purpose': 'مسیر واقعی ابزارهای ساخت و قالب\u200cهای خروجی', 'placement': 'در بخش کالبدشکافی فایل\u200cهای خروجی کامپایل', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um1075-stlinkv2-incircuit-debuggerprogrammer-for-stm8-and-stm32-stmicroelectronics.pdf', 'version': 'UM1075 Rev10 April2024, p5footnote/Table4', 'scope': 'Probe-specific reference/outputs, logical SWD'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified revision asserted', 'scope': 'STM32F303 memory/protection concepts'}, {'url': 'local:toolchain-and-validation.json and actual build/ELF reports', 'version': 'Fresh unchanged GCC13.2.1 builds; HAL953955a', 'scope': 'Exact flags and memory sections'}, {'url': 'https://dev.st.com/stm32cube-docs/prog/2.23.0/en/docs/markup/CubeProg_Command_Lines.html', 'version': 'STM32CubeProgrammer2.23 official documentation', 'scope': 'UnderReset needsNRST; procedure not actualGUItest'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Real C flags not universal IDE defaults. ReleaseELF.debug_info576 bytes despite C-g0; no claim all stages remove DWARF.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson06-refresh-figure2.png', 'alt': 'جای\u200cگیری بخش\u200cها در Flash و SRAM', 'caption': 'نمودار تألیفی نقش بخش\u200cهای حافظه با ارتفاع\u200cهای غیرنسبی. در ساخت واقعی data برابر 12 و bss اشیاء برابر 32 بایت است؛ 4 بایت هم\u200cترازی، 512 رزرو heap و 1024 رزرو stack مجموع ناحیهٔ RAM را به 1584 بایت می\u200cرساند. مصرف زمان اجرا یا اوج stack اندازه\u200cگیری نشده است.', 'purpose': 'جای\u200cگیری بخش\u200cها در Flash و SRAM', 'placement': 'در بخش تحلیل گزارش اندازه و مصرف حافظه', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um1075-stlinkv2-incircuit-debuggerprogrammer-for-stm8-and-stm32-stmicroelectronics.pdf', 'version': 'UM1075 Rev10 April2024, p5footnote/Table4', 'scope': 'Probe-specific reference/outputs, logical SWD'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified revision asserted', 'scope': 'STM32F303 memory/protection concepts'}, {'url': 'local:toolchain-and-validation.json and actual build/ELF reports', 'version': 'Fresh unchanged GCC13.2.1 builds; HAL953955a', 'scope': 'Exact flags and memory sections'}, {'url': 'https://dev.st.com/stm32cube-docs/prog/2.23.0/en/docs/markup/CubeProg_Command_Lines.html', 'version': 'STM32CubeProgrammer2.23 official documentation', 'scope': 'UnderReset needsNRST; procedure not actualGUItest'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual12+32+4+512+1024=1584; heapstacksection1540 includes alignment. No bss36 error.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson06-refresh-figure3.png', 'alt': 'اتصال منطقی SWD و مرجع ولتاژ هدف', 'caption': 'نمودار تألیفی سیگنال\u200cهای SWD، زمین مشترک، مرجع ولتاژ هدف و NRST بدون شماره\u200cگذاری کانکتور. مرجع ولتاژ خروجی تغذیهٔ همگانی نیست و سازگاری سطح منطقی به مدل دقیق پروب وابسته است؛ ST-LINK/V2 استاندارد الزاماً همهٔ خروجی\u200cها را با VTref تغییر نمی\u200cدهد.', 'purpose': 'اتصال منطقی SWD و مرجع ولتاژ هدف', 'placement': 'در بخش اتصال سخت\u200cافزاری پروگرامر ST-LINK به هدر برد', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um1075-stlinkv2-incircuit-debuggerprogrammer-for-stm8-and-stm32-stmicroelectronics.pdf', 'version': 'UM1075 Rev10 April2024, p5footnote/Table4', 'scope': 'Probe-specific reference/outputs, logical SWD'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified revision asserted', 'scope': 'STM32F303 memory/protection concepts'}, {'url': 'local:toolchain-and-validation.json and actual build/ELF reports', 'version': 'Fresh unchanged GCC13.2.1 builds; HAL953955a', 'scope': 'Exact flags and memory sections'}, {'url': 'https://dev.st.com/stm32cube-docs/prog/2.23.0/en/docs/markup/CubeProg_Command_Lines.html', 'version': 'STM32CubeProgrammer2.23 official documentation', 'scope': 'UnderReset needsNRST; procedure not actualGUItest'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'UM1075Rev10 standardV2 outputs3.3V even for lowerVDD. No assumed target supply, levelshifter or clone/header pinout.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson06-refresh-figure4.png', 'alt': 'روند پیشنهادی برنامه\u200cریزی و اعتبارسنجی حافظه', 'caption': 'روندنمای تألیفی بررسی اتصال، شناسایی هدف، انتخاب فایل، نوشتن و Verify و مشاهدهٔ رفتار. HEX و ELF آدرس دارند و BIN به آدرس بارگذاری جدا نیاز دارد؛ آدرس Flash این پروژه 0x08000000 است. هیچ اتصال، پروگرام یا نتیجهٔ Verify واقعی گزارش نشده است.', 'purpose': 'روند پیشنهادی برنامه\u200cریزی و اعتبارسنجی حافظه', 'placement': 'در بخش فلش\u200cکردن مستقل با نرم\u200cافزار STM32CubeProgrammer', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um1075-stlinkv2-incircuit-debuggerprogrammer-for-stm8-and-stm32-stmicroelectronics.pdf', 'version': 'UM1075 Rev10 April2024, p5footnote/Table4', 'scope': 'Probe-specific reference/outputs, logical SWD'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified revision asserted', 'scope': 'STM32F303 memory/protection concepts'}, {'url': 'local:toolchain-and-validation.json and actual build/ELF reports', 'version': 'Fresh unchanged GCC13.2.1 builds; HAL953955a', 'scope': 'Exact flags and memory sections'}, {'url': 'https://dev.st.com/stm32cube-docs/prog/2.23.0/en/docs/markup/CubeProg_Command_Lines.html', 'version': 'STM32CubeProgrammer2.23 official documentation', 'scope': 'UnderReset needsNRST; procedure not actualGUItest'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'No fakeID0x422/pass. BIN loadaddress separate, verify readback bytes not logical/timing correctness.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson06-refresh-figure5.png', 'alt': 'سطوح RDP و برگشت\u200cناپذیری سطح 2', 'caption': 'نمودار مفهومی تألیفی حفاظت خواندن STM32F303. بازگشت از سطح 1 به 0 با پاک\u200cشدن Flash همراه است و سطح 2 برگشت\u200cناپذیر است. پیکان\u200cها فرمان اجرا نیستند؛ این درس فقط مشاهده و ثبت تنظیمات را توضیح می\u200cدهد و هیچ Option Bytes واقعی خوانده یا نوشته نشده است.', 'purpose': 'سطوح RDP و برگشت\u200cناپذیری سطح 2', 'placement': 'در بخش سطوح حفاظت خواندن RDP', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um1075-stlinkv2-incircuit-debuggerprogrammer-for-stm8-and-stm32-stmicroelectronics.pdf', 'version': 'UM1075 Rev10 April2024, p5footnote/Table4', 'scope': 'Probe-specific reference/outputs, logical SWD'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified revision asserted', 'scope': 'STM32F303 memory/protection concepts'}, {'url': 'local:toolchain-and-validation.json and actual build/ELF reports', 'version': 'Fresh unchanged GCC13.2.1 builds; HAL953955a', 'scope': 'Exact flags and memory sections'}, {'url': 'https://dev.st.com/stm32cube-docs/prog/2.23.0/en/docs/markup/CubeProg_Command_Lines.html', 'version': 'STM32CubeProgrammer2.23 official documentation', 'scope': 'UnderReset needsNRST; procedure not actualGUItest'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Concept only; no user request to activate protection, no SRAMmass-erase claim, no actual operation.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson06-refresh-figure6.png', 'alt': 'مسیر تشخیص خطای اتصال', 'caption': 'روندنمای تألیفی بررسی لایه\u200cبه\u200cلایهٔ تغذیه و مرجع، سیم\u200cبندی و ریست و شرایط نرم\u200cافزار. Under Reset به اتصال NRST و تنظیم مناسب وابسته است؛ BOOT0 درمان همگانی نیست. پروژهٔ HSI-only با قطع کریستال خارجی آزمون عیب\u200cیابی نمی\u200cشود.', 'purpose': 'مسیر تشخیص خطای اتصال', 'placement': 'در بخش راهنمای گام\u200cبه\u200cگام رفع خطای اتصال', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um1075-stlinkv2-incircuit-debuggerprogrammer-for-stm8-and-stm32-stmicroelectronics.pdf', 'version': 'UM1075 Rev10 April2024, p5footnote/Table4', 'scope': 'Probe-specific reference/outputs, logical SWD'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified revision asserted', 'scope': 'STM32F303 memory/protection concepts'}, {'url': 'local:toolchain-and-validation.json and actual build/ELF reports', 'version': 'Fresh unchanged GCC13.2.1 builds; HAL953955a', 'scope': 'Exact flags and memory sections'}, {'url': 'https://dev.st.com/stm32cube-docs/prog/2.23.0/en/docs/markup/CubeProg_Command_Lines.html', 'version': 'STM32CubeProgrammer2.23 official documentation', 'scope': 'UnderReset needsNRST; procedure not actualGUItest'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Safe diagnostic path; no guaranteed underreset cure, BOOT0 universalboot/recovery, unverified hardware diagnosis or detachedHSE experiment.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

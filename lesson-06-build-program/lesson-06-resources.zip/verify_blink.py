"""Calculate nominal blink timing and HAL tick wait threshold, not hardware timing."""
from pathlib import Path
import json
delay_ms=500
tick_ms=1
result={'requested_half_period_ms':delay_ms,'nominal_full_period_ms':2*delay_ms,'nominal_frequency_hz':1000/(2*delay_ms),'default_hal_tick_ms':tick_ms,'hal_delay_wait_threshold_ticks':(delay_ms+tick_ms)//tick_ms,'note':'HAL_Delay adds one default tick to its comparison threshold. Tick phase, execution time, clock tolerance and interrupts affect observed timing. No exact hardware period is claimed.'}
out=Path(__file__).resolve().parent/'blink-calculations.json'
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))

"""Original educational diagrams; no copied source layouts or measured data."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
ROOT=Path(__file__).parent
N='#17334a';T='#087f8c';O='#a7601b';G='#526778';BG='#f2f6f9';B='#c8d7e0'
def font(n=43,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def text(d,xy,s,n=43,color=N,b=False):d.text(xy,s,font=font(n,b),fill=color)
def start(title,sub,h=1580):
 im=Image.new('RGB',(1200,h),BG);d=ImageDraw.Draw(im);text(d,(45,32),title,49,b=True);text(d,(45,110),sub,31,G);return im,d
def box(d,xy,title,lines=(),color=T):
 x,y,x2,y2=xy;d.rounded_rectangle(xy,20,fill='white',outline=B,width=3);text(d,(x+25,y+20),title,43,color,True)
 for i,s in enumerate(lines):text(d,(x+25,y+85+i*55),s,39)
def arr(d,pts,color=T,w=7):
 d.line(pts,fill=color,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0]);d.polygon([(x,y),(x-24*math.cos(a-.5),y-24*math.sin(a-.5)),(x-24*math.cos(a+.5),y-24*math.sin(a+.5))],fill=color)
def foot(d,h,s):text(d,(45,h-110),s,29,G);text(d,(45,h-65),'Original diagram / model. No board or scope result.',29,G)
def save(im,n,i):
 p=ROOT;im.save(p/f'lesson{n}-figure{i}.png',optimize=True)
def flow(title,sub,items,n,i):
 h=380+len(items)*235;im,d=start(title,sub,h)
 for k,(a,b) in enumerate(items):
  y=190+k*235;box(d,(70,y,1130,y+170),a,b)
  if k<len(items)-1:arr(d,[(600,y+175),(600,y+227)])
 foot(d,h,'Technical basis: exact F3 HAL / CMSIS and official manuals.');save(im,n,i)
# 10.1 Vector addressing and weak resolution
im,d=start('From a vector to a handler','STM32F303xC | Linked Flash example, VTOR = 0x08000000',1760)
rows=[('0x08000000','Initial MSP value'),('0x08000004','Reset_Handler address'),('0x08000058','EXTI0_IRQHandler address'),('0x0800005C','EXTI1_IRQHandler address')]
for k,(a,b) in enumerate(rows):
 y=200+k*140;box(d,(55,y,1145,y+115),a+'   '+b,())
text(d,(70,825),'External IRQn: vector index = 16 + IRQn',44,b=True)
text(d,(70,900),'EXTI0: 16 + 6 = 22; byte offset = 4 x22 = 0x58',39)
arr(d,[(600,985),(600,1040)])
box(d,(55,1060,1145,1270),'Linker resolves the named symbol',['Strong user handler replaces weak alias','Otherwise startup alias -> Default_Handler'])
arr(d,[(600,1280),(600,1330)])
box(d,(55,1350,1145,1560),'ISR returns through exception return',['First table word is a stack value, not a function','Boot alias and run-time VTOR are separate concepts'])
foot(d,1760,'Basis: actual startup_stm32f303xc.s, device header, linker.');save(im,10,1)
# 10.2 byte bit layout + grouping, visually explicit
im,d=start('Four implemented priority bits','Exact STM32F303xC device | Logical priority 0..15',1660)
for k in range(8):
 x=70+k*135;bit=7-k;active=bit>=4;d.rectangle((x,250,x+130,410),fill=T if active else '#d8e1e7');text(d,(x+40,275),str(bit),50,'white' if active else N,True)
text(d,(95,450),'Implemented [7:4]',47,T,True);text(d,(665,450),'Unused [3:0] = 0',43,G)
text(d,(75,570),'Register byte = logical priority << 4',47,b=True)
text(d,(75,655),'Logical 2 -> register 0x20; lower number wins.',40)
for k,(group,pre,sub) in enumerate([(4,4,0),(3,3,1),(2,2,2),(1,1,3),(0,0,4)]):
 y=800+k*125;text(d,(70,y),f'GROUP{group}',42,b=True)
 for j in range(4):
  x=400+j*165;ispre=j<pre;d.rectangle((x,y-8,x+150,y+75),fill=T if ispre else O);text(d,(x+18,y+8),'PRE' if ispre else 'SUB',36,'white',True)
foot(d,1660,'HAL group suffix is not the raw AIRCR.PRIGROUP value.');save(im,10,2)
# 10.3 states with main transitions
im,d=start('Pending is different from Active','States describe one exception, not a count of all events',1680)
for xy,a,b in [((65,220,1135,410),'Inactive',['Not pending, not active']),((65,530,1135,720),'Pending',['Request waits: enable + priority + masks decide']),((65,840,1135,1030),'Active',['Handler entered; request accepted']),((65,1150,1135,1340),'Active + Pending',['Another request while the handler is active'])]:box(d,xy,a,b)
for y,s in [(420,'New request'),(730,'Exception entry'),(1040,'New request')]:
 arr(d,[(170,y),(170,y+95)]);text(d,(230,y+10),s,40,T,True)
text(d,(75,1420),'Active -> Inactive: return, no pending request',40)
text(d,(75,1480),'Active + Pending -> Pending: return, request waits',38)
foot(d,1680,'Peripheral flags and NVIC pending bits are separate.');save(im,10,3)
# 10.4 nested marker timeline
im,d=start('Two priorities, two execution orders','Ideal sequence model | Horizontal axis is event order',1780)
for top,title,nested in [(200,'A: GROUP4 | low2, high1 -> preemption',True),(900,'B: GROUP3 | same PRE1 -> no nesting',False)]:
 text(d,(55,top),title,44,T,True)
 for y,label in [(top+160,'PB6 LOW ISR'),(top+370,'PB7 HIGH ISR')]:text(d,(65,y-70),label,40,b=True);d.line([(120,y),(1110,y)],fill=B,width=2)
 x=[120,320,520,740,930,1110]
 if nested:
  d.line([(x[0],top+160),(x[1],top+160),(x[1],top+60),(x[4],top+60),(x[4],top+160),(x[5],top+160)],fill=T,width=7)
  d.line([(x[0],top+370),(x[2],top+370),(x[2],top+270),(x[3],top+270),(x[3],top+370),(x[5],top+370)],fill=O,width=7)
  text(d,(180,top+470),'LOW entry -> HIGH entry/exit -> LOW exit',42)
 else:
  d.line([(x[0],top+160),(x[1],top+160),(x[1],top+60),(x[3],top+60),(x[3],top+160),(x[5],top+160)],fill=T,width=7)
  d.line([(x[0],top+370),(x[3],top+370),(x[3],top+270),(x[4],top+270),(x[4],top+370),(x[5],top+370)],fill=O,width=7)
  text(d,(180,top+470),'LOW entry/exit -> HIGH entry/exit',42)
 text(d,(160,top+545),'LOW triggers HIGH by NVIC_SetPendingIRQ.',38)
foot(d,1780,'PB6 stays High during nesting. Pulse widths not predicted.');save(im,10,4)
# 10.5 physical signal wiring
im,d=start('Observe two CPU pin signals','Logical connections, not physical header positions',1720)
box(d,(75,200,1125,500),'GB100ST V2.0 / STM32F303CBT6',['PB6 = LQFP48 pin42; also drives LED via NPN','PB7 = LQFP48 pin43; GND = board ground'])
for x,y2,label,color in [(240,1050,'PB6 -> CH1',T),(610,1050,'PB7 -> CH2',O),(970,1050,'GND -> GND',N)]:
 d.ellipse((x-14,485,x+14,513),fill=color);d.line([(x,515),(x,y2)],fill=color,width=8);text(d,(x-160,700),label,36,color,True)
box(d,(75,1070,1125,1330),'Oscilloscope / compatible logic analyzer',['Use board signal headers and nearby common GND','3.3V logic; choose probes for short ISR pulses','Keep SWD PA13 / PA14 reserved'])
text(d,(75,1420),'Do not use LED visibility as a timing measurement.',42,b=True)
foot(d,1720,'Basis: DS9118 LQFP48 pinout and board V2.0 schematic.');save(im,10,5)
# 10.6 mask grid
im,d=start('PRIMASK and BASEPRI are different','GROUP4 example | BASEPRI = 0x40 = logical threshold4',1620)
text(d,(75,200),'Priority',39,b=True);text(d,(370,200),'PRIMASK = 1',39,b=True);text(d,(785,200),'BASEPRI 0x40',39,b=True)
for k,label in enumerate(['NMI / HardFault','0..3','4..15']):
 y=340+k*250;box(d,(60,y,1140,y+190),label)
 text(d,(395,y+90),'Allowed' if k==0 else 'Masked',43,T if k==0 else O,True)
 text(d,(835,y+90),'Masked' if k==2 else 'Allowed',43,O if k==2 else T,True)
text(d,(75,1190),'BASEPRI = 0 disables this threshold mask.',43,b=True)
text(d,(75,1275),'Save and restore the previous mask value.',43)
text(d,(75,1360),'volatile does not make counter++ atomic.',43)
foot(d,1620,'Other masks, current priority and enable state still apply.');save(im,10,6)

print("Created6 original lesson figures.")

"""Priority/trace arithmetic model, not an NVIC/CPU simulator or target capture."""
from pathlib import Path
import json,struct,zipfile
def encode(group,pre,sub):
 prebits=min(7-group,4);subbits=max(group+4-7,0)
 return ((pre&((1<<prebits)-1))<<subbits)|(sub&((1<<subbits)-1))
assert encode(3,2,0)==2 and encode(3,1,0)==1
assert encode(4,1,1)==3 and encode(4,1,0)==2
def trace(low_pre,high_pre):return [1,2,3,4] if high_pre<low_pre else [1,3,4,2]
assert trace(2,1)==[1,2,3,4] and trace(1,1)==[1,3,4,2]
def primask_restore(saved):return saved
assert primask_restore(0)==0 and primask_restore(1)==1
def inspect(data):
 h=struct.unpack_from('<16sHHIIIIIHHHHHH',data);assert h[0][:6]==b'\x7fELF\x01\x01' and h[2]==40
 sections=[struct.unpack_from('<IIIIIIIIII',data,h[6]+i*h[11]) for i in range(h[12])]
 sh=sections[h[13]];strings=data[sh[4]:sh[4]+sh[5]]
 def cs(s,o):return s[o:s.find(b'\0',o)].decode()
 named={cs(strings,s[0]):s for s in sections};symbols={}
 for s in sections:
  if s[1]!=2:continue
  st=sections[s[6]];ss=data[st[4]:st[4]+st[5]]
  for o in range(s[4],s[4]+s[5],s[9]):
   n,v,z,info,other,index=struct.unpack_from('<IIIBBH',data,o);name=cs(ss,n)
   if name in ['EXTI0_IRQHandler','EXTI1_IRQHandler','Default_Handler']:symbols[name]={'address':v,'binding':info>>4}
 v=named['.isr_vector'];vector=data[v[4]:v[4]+v[5]]
 for irq,name in [(6,'EXTI0_IRQHandler'),(7,'EXTI1_IRQHandler')]:
  actual=struct.unpack_from('<I',vector,(16+irq)*4)[0]
  assert actual==symbols[name]['address'] and symbols[name]['binding']==1
 return {'scope':'Actual offline ELF metadata inspection, not execution','vector_section_address':v[3],'symbols':symbols,'strong_handler_vector_entries_verified':True}
root=Path(__file__).parent
with zipfile.ZipFile(root/'lesson-10-build-artifacts.zip') as z:elf={n:inspect(z.read(n)) for n in z.namelist() if n.endswith('.elf')}
result={'scope':'Predicted ordering only; no target trace or timing measured','default_GROUP4_PRIGROUP3':{'logical_low':2,'logical_high':1,'IPR_low_hex':'0x20','IPR_high_hex':'0x10','trace':trace(2,1),'expected_high_saw_low_active':1},'comparison_GROUP3_PRIGROUP4':{'preempt_low':1,'sub_low':1,'preempt_high':1,'sub_high':0,'IPR_low_hex':'0x30','IPR_high_hex':'0x20','trace':trace(1,1),'expected_high_saw_low_active':0},'trace_legend':{'1':'low enter','2':'high enter','3':'low resumed / still running','4':'low exit'},'checks_passed':['CMSIS priority partition arithmetic','different preemption ordering','equal preemption ordering','PRIMASK prior state restoration','actual strong handlers occupy real ELF vector slots'],'ELF':elf}
(root/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

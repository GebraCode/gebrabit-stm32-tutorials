"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=10
def save(im,n):
 name=f'lesson{LESSON:02d}-refresh-figure{n}'+('-v2' if n==1 else '')+'.png'
 im.save(OUT/name,optimize=True)

def figure1():
 im,d=begin('Recognize the exception first','Cortex-M4 exception numbering is not the same as CMSIS IRQn values')
 panel(d,75,300,1050,180,'Exception model',['Core exceptions and device-specific external IRQs'])
 arrow(d,[(600,495),(600,580),(300,580),(300,650)])
 arrow(d,[(600,580),(900,580),(900,650)])
 panel(d,65,670,470,480,'Core examples',['Reset: exception 1','NMI: 2 / HardFault: 3','SVCall: 11','PendSV: 14 / SysTick: 15'])
 panel(d,665,670,470,480,'External IRQs',['Exception = 16 + IRQn','EXTI0: IRQ6 -> 22','EXTI1: IRQ7 -> 23','Only implemented lines exist.'])
 panel(d,75,1350,1050,240,'Fixed versus configurable priorities',['PRIMASK / BASEPRI do not mask NMI or HardFault.','IRQn IDs and priority values differ.'])
 foot(d,'Device-specific availability comes from the actual F303 header.');save(im,1)
def figure2():
 im,d=begin('Resolve vector entries at link time','Actual linked vector section starts at 0x08000000; VTOR is not measured')
 rows=[('Offset 0x00','Initial MSP'),('Offset 0x04','Reset_Handler'),('Offset 0x58','Exception 22: EXTI0 handler'),('Offset 0x5C','Exception 23: EXTI1 handler')]
 for k,(a,b)in enumerate(rows):
  y=300+k*180;panel(d,75,y,1050,135,a+' -> '+b,())
 tx(d,75,1090,'Handler symbol resolution',48,TEAL,True)
 panel(d,75,1200,480,290,'No strong definition',['Startup weak alias','Default_Handler'])
 panel(d,650,1200,480,290,'Strong handler',['Application body','Overrides weak alias'])
 para(d,75,1515,'The vector stores the resolved handler address; pointer bit 0 denotes Thumb execution state.',1040,41)
 foot(d,'Offline ELF evidence is not a live VTOR or debugger reading.');save(im,2)
def figure3():
 im,d=begin('Track pending and active independently','Inactive means not pending or active; it does not mean disabled')
 tx(d,75,265,'Selected state transitions',38,MUTED)
 for x,y,title,lines in [(75,340,'Inactive',['No current request']), (650,340,'Pending',['Waiting for service']), (650,940,'Active',['Handler not returned']), (75,940,'Active + pending',['Another request awaits'])]:panel(d,x,y,475,230,title,lines)
 arrow(d,[(560,450),(640,450)]);tx(d,75,660,'Request -> pending',42,TEAL,True)
 arrow(d,[(890,590),(890,920)]);tx(d,590,710,'Eligible entry',40,TEAL,True)
 arrow(d,[(640,1060),(560,1060)],ORANGE)
 tx(d,75,1230,'A new request while active can also become pending.',41,ORANGE)
 panel(d,75,1320,1050,290,'Enable and masks are separate gates',['Disabled or masked IRQs can still be pending.','A preempted handler remains active.','Save PRIMASK, mask briefly, restore the saved value.'])
 foot(d,'Pending is a state bit, not a queue of every request.');save(im,3)
def figure4():
 im,d=begin('Split implemented priority bits deliberately','STM32F303 has 4 implemented bits; smaller numbers are more urgent')
 for k in range(8):
  x=80+k*130;fill=TEAL if k<4 else LINE;d.rectangle((x,340,x+120,480),fill=fill)
  tx(d,x+40,380,str(7-k),44,WHITE if k<4 else INK,True)
 tx(d,75,550,'IPR[7:4]: implemented',44,TEAL,True);tx(d,75,635,'IPR[3:0]: not implemented',44,MUTED)
 tx(d,75,780,'HAL group       Preemption bits       Subpriority bits',40,TEAL,True)
 for k,(g,pre,sub)in enumerate([(4,4,0),(3,3,1),(2,2,2),(1,1,3),(0,0,4)]):
  y=900+k*110;tx(d,140,y,str(g),46);tx(d,570,y,str(pre),46);tx(d,1000,y,str(sub),46);d.line((75,y+75,1125,y+75),fill=LINE,width=2)
 tx(d,75,1500,'HAL uses logical priorities: 1 -> IPR 0x10; do not shift twice.',40)
 foot(d,'Subpriority orders eligible pending work; it does not preempt.');save(im,4)
def blocks(d,y,names,widths):
 x=75
 for label,w in zip(names,widths):
  d.rounded_rectangle((x,y,x+w,y+160),12,fill=WHITE,outline=TEAL,width=3);para(d,x+18,y+20,label,w-36,40,TEAL,True);x+=w+15
 return x
def figure5():
 im,d=begin('See what exception mechanisms avoid','Relative phase models; no board latency or fixed cycle counts are shown')
 tx(d,75,300,'Separate return and next entry',46,TEAL,True)
 blocks(d,420,['ISR1 ends','Restore frame','Save frame','ISR2 starts'],[250,250,250,250])
 tx(d,75,750,'Tail-chaining to eligible pending work',46,TEAL,True)
 blocks(d,870,['ISR1 ends','Reuse stacked frame','ISR2 starts'],[300,390,310])
 tx(d,75,1210,'Late arrival during exception entry',46,TEAL,True)
 blocks(d,1330,['Frame save in progress','More urgent request','Urgent ISR first'],[350,330,320])
 tx(d,75,1550,'Memory, bus and FPU conditions affect actual timing.',40)
 foot(d,'A basic frame has 8 words; alignment/FPU can add more.');save(im,5)
def level(d,pts,hi,lo,c):
 out=[]
 for x,v in pts:
  if out:out.append((x,out[-1][1]))
  out.append((x,hi if v else lo))
 d.line(out,fill=c,width=7)
def figure6():
 im,d=begin('Predict the two NVIC trial orders','Software-pended IRQ6/7; no EXTI peripheral or physical edge is configured')
 tx(d,75,300,'GROUP 4: preemption 2 versus 1',46,TEAL,True)
 tx(d,75,390,'Predicted trace [1,2,3,4]; high sees low active=1',40)
 tx(d,75,510,'PB6',40);level(d,[(250,0),(350,1),(1050,0),(1120,0)],520,610,TEAL)
 tx(d,75,710,'PB7',40);level(d,[(250,0),(530,1),(750,0),(1120,0)],720,810,ORANGE)
 tx(d,75,900,'GROUP 3: same preemption, different subpriority',44,TEAL,True)
 tx(d,75,990,'Predicted trace [1,3,4,2]; high sees low active=0',40)
 tx(d,75,1110,'PB6',40);level(d,[(250,0),(350,1),(700,0),(1120,0)],1120,1210,TEAL)
 tx(d,75,1310,'PB7',40);level(d,[(250,0),(780,1),(1010,0),(1120,0)],1320,1410,ORANGE)
 tx(d,75,1510,'Left -> right: relative order only, not a measured time axis.',41)
 foot(d,'Nested pulses do not establish a measured tail-chain cycle count.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson10-refresh-figure1-v2.png', 'alt': 'شمارهٔ استثنا و تفاوت وقفه\u200cهای هسته و خارجی', 'caption': 'نمودار طبقه\u200cبندی تألیفی استثناهای Cortex-M4 و رابطهٔ شمارهٔ استثنای خارجی با IRQn: EXTI0 با IRQ6 به شمارهٔ 22 و EXTI1 با IRQ7 به 23 می\u200cرسند. IRQn شناسه است، نه مقدار اولویت. منفی\u200cبودن شناسهٔ CMSIS به معنی اولویت ثابت نیست: اولویت SysTick و PendSV قابل تنظیم و اولویت Reset و NMI و HardFault ثابت است. PRIMASK و BASEPRI، NMI و HardFault را ماسک نمی\u200cکنند.', 'purpose': 'شمارهٔ استثنا و تفاوت وقفه\u200cهای هسته و خارجی', 'placement': 'پس از بخش H3: تفاوت وقفه سخت\u200cافزاری (IRQ) با استثناهای سیستمی هسته (Reset، NMI، HardFault و SysTick)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10 March2020', 'scope': 'Exceptions, priority, active/pending, masking and entry mechanisms'}, {'url': 'local:actual lesson10 source, CMSIS/device headers and ELF vector verification', 'version': 'CubeF3V1.11.6 HAL953955a GCC13.2.1 fresh Debug builds', 'scope': 'Exactdevice4prioritybits, IRQ6/7, strongvectors and actualtrialsourcepredictions'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Exact device identity; no inferred boardheader'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'No guessedIRQ0..84availability; exceptionnumbers not prioritynumbers; fixedpriorityexceptions distinct. IRQn IDs are not priority values; negative CMSIS IDs include configurable SysTick/PendSV as well as fixed-priority exceptions.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson10-refresh-figure2.png', 'alt': 'جدول بردار لینک\u200cشده و جایگزینی هندلر weak', 'caption': 'نمودار تألیفی چند ورودی واقعی بخش بردار لینک\u200cشده در 0x08000000: MSP اولیه و Reset و ورودی\u200cهای 22 و 23 در آفست\u200cهای 0x58 و 0x5C. تعریف قوی برنامه alias ضعیف startup را در لینک جایگزین می\u200cکند. این شکل خواندن زندهٔ VTOR نیست؛ بیت 0 اشاره\u200cگر حالت اجرای Thumb را مشخص می\u200cکند.', 'purpose': 'جدول بردار لینک\u200cشده و جایگزینی هندلر weak', 'placement': 'پس از بخش H3: بردار شیارهای 22 و 23 (آفست 0x58 و 0x5C) مربوط به EXTI0 و EXTI1', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10 March2020', 'scope': 'Exceptions, priority, active/pending, masking and entry mechanisms'}, {'url': 'local:actual lesson10 source, CMSIS/device headers and ELF vector verification', 'version': 'CubeF3V1.11.6 HAL953955a GCC13.2.1 fresh Debug builds', 'scope': 'Exactdevice4prioritybits, IRQ6/7, strongvectors and actualtrialsourcepredictions'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Exact device identity; no inferred boardheader'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualofflineELFstronghandlers/vectors; no claim currentVTOR08000000 or Thumb-2pointerstate. Selected entries, weakvsstrong.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson10-refresh-figure3.png', 'alt': 'حالت\u200cهای Pending و Active و گیت\u200cهای مستقل', 'caption': 'نمودار تألیفی حالت\u200cها و چند گذار منتخب: Inactive به معنی disabled نیست و IRQ ماسک\u200cشده یا غیرفعال می\u200cتواند pending شود. Active تا بازگشت handler می\u200cماند و شامل handler تعلیق\u200cشده بر اثر preemption هم می\u200cشود. ذخیره و بازگرداندن PRIMASK با فعال\u200cسازی بی\u200cقیدوشرط فرق دارد.', 'purpose': 'حالت\u200cهای Pending و Active و گیت\u200cهای مستقل', 'placement': 'پس از بخش H3: ثبات\u200cهای فعال\u200cسازی (ISER/ICER) و تحریک دستی با ثبات\u200cهای معلق\u200cسازی (ISPR/ICPR)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10 March2020', 'scope': 'Exceptions, priority, active/pending, masking and entry mechanisms'}, {'url': 'local:actual lesson10 source, CMSIS/device headers and ELF vector verification', 'version': 'CubeF3V1.11.6 HAL953955a GCC13.2.1 fresh Debug builds', 'scope': 'Exactdevice4prioritybits, IRQ6/7, strongvectors and actualtrialsourcepredictions'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Exact device identity; no inferred boardheader'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Selectedtransitionsonly; Pendingnotqueue. Enable/maskindependent; preemptedsuspendedstillactive; savedmaskrestore.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson10-refresh-figure4.png', 'alt': 'چهار بیت اولویت و گروه\u200cبندی HAL در STM32F303', 'caption': 'نمودار تألیفی بیت\u200cهای پیاده\u200cسازی\u200cشدهٔ IPR در STM32F303 و جدول تقسیم 4 بیت بین preemption و subpriority. HAL ورودی منطقی می\u200cگیرد؛ اولویت 1 در IPR برابر 0x10 کد می\u200cشود و نباید دوباره shift شود. subpriority وقفهٔ فعال هم\u200cاولویت را قطع نمی\u200cکند.', 'purpose': 'چهار بیت اولویت و گروه\u200cبندی HAL در STM32F303', 'placement': 'پس از بخش H3: گروه\u200cبندی اولویت در HAL و تفاوت اولویت تقدم (Preemption) با زیر\u200cاولویت (Subpriority)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10 March2020', 'scope': 'Exceptions, priority, active/pending, masking and entry mechanisms'}, {'url': 'local:actual lesson10 source, CMSIS/device headers and ELF vector verification', 'version': 'CubeF3V1.11.6 HAL953955a GCC13.2.1 fresh Debug builds', 'scope': 'Exactdevice4prioritybits, IRQ6/7, strongvectors and actualtrialsourcepredictions'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Exact device identity; no inferred boardheader'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Device__NVIC_PRIO_BITS4 notallSTM32. HALGROUP4..0 splits4/0..0/4; lowernumbermoreurgent, no double-shift.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson10-refresh-figure5.png', 'alt': 'مدل فازهای Tail-chaining و Late arrival', 'caption': 'نمودار تألیفی و کیفی فازهای بازگشت و ورود جداگانه، استفادهٔ دوباره از frame در tail-chaining و ورود درخواست فوری\u200cتر هنگام ذخیرهٔ frame. طول بلوک\u200cها مقیاس زمان واقعی ندارد و شمارش ثابت 12 یا 6 سیکل یا تأخیر برد ادعا نشده است. frame پایه 8 word است و هم\u200cترازی و FPU می\u200cتواند به آن اضافه کند.', 'purpose': 'مدل فازهای Tail-chaining و Late arrival', 'placement': 'پس از بخش H3: مدیریت وقفه فوری\u200cتر در آستانه ورود با مکانیزم Late Arrival', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10 March2020', 'scope': 'Exceptions, priority, active/pending, masking and entry mechanisms'}, {'url': 'local:actual lesson10 source, CMSIS/device headers and ELF vector verification', 'version': 'CubeF3V1.11.6 HAL953955a GCC13.2.1 fresh Debug builds', 'scope': 'Exactdevice4prioritybits, IRQ6/7, strongvectors and actualtrialsourcepredictions'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Exact device identity; no inferred boardheader'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Qualitativearchitecturalphases, no fake12/6cycleboardproof or universal32byteframe. Eligiblependingrules stillapply.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson10-refresh-figure6.png', 'alt': 'ترتیب پیش\u200cبینی\u200cشدهٔ دو آزمایش نرم\u200cافزاری NVIC', 'caption': 'مدل تألیفی ترتیب نشانگرهای PB6 و PB7 در دو پروژهٔ واقعی: GROUP4 با تقدم متفاوت trace برابر [1,2,3,4] و high_saw_low_active برابر 1 را پیش\u200cبینی می\u200cکند؛ GROUP3 با تقدم برابر و زیر\u200cاولویت متفاوت trace برابر [1,3,4,2] و مقدار 0 را پیش\u200cبینی می\u200cکند. IRQ6 و IRQ7 مستقیماً در NVIC نرم\u200cافزاری pending می\u200cشوند؛ پریفرال EXTI یا لبهٔ فیزیکی پیکربندی نشده و شکل ثبت اسیلوسکوپ یا اثبات سیکل tail-chain نیست.', 'purpose': 'ترتیب پیش\u200cبینی\u200cشدهٔ دو آزمایش نرم\u200cافزاری NVIC', 'placement': 'پس از بخش H3: آزمایش حالت دوم (GROUP_3): اولویت تقدم یکسان، زیر\u200cاولویت متفاوت و مشاهده توالی 1، 3، 4 و 2 ناشی از Tail-Chaining', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10 March2020', 'scope': 'Exceptions, priority, active/pending, masking and entry mechanisms'}, {'url': 'local:actual lesson10 source, CMSIS/device headers and ELF vector verification', 'version': 'CubeF3V1.11.6 HAL953955a GCC13.2.1 fresh Debug builds', 'scope': 'Exactdevice4prioritybits, IRQ6/7, strongvectors and actualtrialsourcepredictions'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Exact device identity; no inferred boardheader'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualeventIDs1lowenter2highenter3lowafterrequest4lownearexit; not arbitraryscopepointlabels. Softwarependingonly, relativeorderingnotmeasuredtime.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

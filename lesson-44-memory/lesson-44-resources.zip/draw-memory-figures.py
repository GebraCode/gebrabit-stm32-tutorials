"""Original lesson 44 diagrams. Run this file with Python + Pillow.

Uses Segoe UI from the operating system, or DejaVu Sans as a fallback.
Font files are not distributed. Images are not instrument screenshots.
"""
from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent
Q=P.parent/'visual-qa';Q.mkdir(exist_ok=True)
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e';LINE='#ccdbe3'
BG='#f5f8fa';FREE='#d8f0e9';USED='#f5d9dc';WHITE='white'
def font(n=44,b=False):
 paths=['C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf','DejaVuSans'+('-Bold' if b else '')+'.ttf']
 for p in paths:
  try:return ImageFont.truetype(p,n)
  except OSError:pass
 raise RuntimeError('Install Segoe UI or DejaVu Sans')
def text(d,x,y,s,w=1050,n=44,c=INK,b=False):
 lines=[];line=''
 for word in s.split():
  trial=(line+' '+word).strip()
  if line and d.textlength(trial,font=font(n,b))>w:lines.append(line);line=word
  else:line=trial
 if line:lines.append(line)
 for ln in lines:
  bounds=d.textbbox((x,y),ln,font=font(n,b));assert bounds[2]<=W-25 and bounds[3]<H-20,(s,bounds)
  d.text((x,y),ln,font=font(n,b),fill=c);y+=n+13
 return y
def box(d,x,y,w,h,fill='white',outline=LINE):
 d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=fill,outline=outline,width=4)
def arrow(d,x,y,x2,y2,c=TEAL):
 d.line((x,y,x2,y2),fill=c,width=7);a=math.atan2(y2-y,x2-x)
 d.polygon([(x2,y2),(x2-25*math.cos(a-.5),y2-25*math.sin(a-.5)),(x2-25*math.cos(a+.5),y2-25*math.sin(a+.5))],fill=c)
def header(title,sub):
 im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
 y=text(d,65,35,title,1070,58,INK,True)
 text(d,65,y+12,sub,1070,42,MUTED)
 d.line((65,245,1135,245),fill=LINE,width=3)
 return im,d
def card(d,y,title,body,h=250,c=TEAL):
 box(d,65,y,1070,h,outline=c)
 yy=text(d,90,y+18,title,1020,46,c,True)
 yy=text(d,90,yy+14,body,1020,43)
 assert yy<=y+h-10,(title,yy,y+h)
def footer(d,s='Original conceptual diagram; no board measurement.'):
 d.line((65,1640,1135,1640),fill=LINE,width=3)
 text(d,65,1660,s,1070,38,MUTED)
def save(im,index):
 im.save(P/f'lesson44-figure{index}.png',optimize=True)
 for size in [390,600]:im.resize((size,H*size//W),Image.Resampling.LANCZOS).save(Q/f'fig{index}-{size}.png')

# 1: exact arithmetic model for the linked normal ELF, with intentionally unscaled blocks.
im,d=header('Adjacent free blocks merge','heap_4: source + ELF arithmetic model, not runtime data')
def blocks(y,parts):
 x=75
 for width,label,color in parts:
  box(d,x,y,width,155,color,TEAL if color==FREE else RED)
  yy=y+18
  for ln in label:yy=text(d,x+16,yy,ln,width-28,43,INK,True)
  x+=width+12
text(d,75,290,'1. Allocate A, B and C',1050,48,TEAL,True)
blocks(375,[(172,['A','264 B'],USED),(172,['B','520 B'],USED),(172,['C','264 B'],USED),(475,['Free tail','11224 B'],FREE)])
text(d,75,565,'Block sizes include allocation headers. Not to scale.',1040,40,MUTED)
arrow(d,600,665,600,740)
text(d,75,765,'2. Free A and C',1050,48,TEAL,True)
blocks(850,[(240,['Free A','264 B'],FREE),(240,['Used B','520 B'],USED),(523,['Free C + tail','11488 B'],FREE)])
text(d,75,1038,'B still separates two free regions.',1040,43)
arrow(d,600,1130,600,1205)
text(d,75,1230,'3. Free B: adjacent regions coalesce',1050,48,TEAL,True)
blocks(1320,[(1027,['One free region: 12272 B'],FREE)])
text(d,75,1510,'Coalescing reduces fragmentation; it cannot remove all of it.',1050,42,ORANGE)
footer(d,'Original allocator model; 12288 B configured, alignment and end marker excluded.')
save(im,1)

# 2: distinguish stack fill scan from SP.
im,d=header('A task stack grows downward','Cortex-M4 ARM_CM4F port: one stack word = 4 bytes')
text(d,85,285,'Higher addresses',1000,45,MUTED,True)
box(d,95,365,670,390,USED,RED)
text(d,130,420,'Frames, locals and saved context',595,48,INK,True)
text(d,130,580,'Previously written area',595,45)
arrow(d,995,405,995,1160)
text(d,800,630,'Growth',280,44,TEAL,True)
d.line((85,760,785,760),fill=ORANGE,width=8)
text(d,95,790,'Saved SP / current frame boundary',1040,42,ORANGE,True)
box(d,95,895,670,345,FREE,TEAL)
text(d,130,945,'Untouched 0xA5 fill',595,48,TEAL,True)
text(d,130,1060,'This is a conceptual state, not a dump.',585,43)
box(d,95,1265,670,120,'#e2e9f6',INK)
text(d,125,1287,'First 4 guard words',610,46,INK,True)
text(d,85,1410,'Lower addresses: stack base',1040,45,MUTED,True)
text(d,85,1500,'Fill-pattern history and the current SP answer different questions.',1050,43,ORANGE)
footer(d,'Conceptual layout. A fill pattern is not a hardware access boundary.')
save(im,2)

# 3: method 2 keeps method 1's pointer test.
im,d=header('Stack overflow checks','FreeRTOS 11.2.0, downward-growing ARM_CM4F stack')
card(d,300,'Method 1: saved stack pointer','At a task switch, compare saved SP with the lower stack boundary.',270)
arrow(d,600,585,600,645)
card(d,665,'Method 2: pointer AND guard tests','Keep the saved-SP boundary check. Also verify the first 4 words are 0xA5A5A5A5.',320)
arrow(d,600,1000,600,1060)
card(d,1080,'Failure detected: call the hook','The hook records minimal data and halts. It is not a recovery mechanism.',260,RED)
text(d,85,1410,'A large overwrite or Fault can occur before the next switch. A damaged TCB can also defeat the check.',1030,45,ORANGE)
footer(d,'Software checks are not MPU protection and do not detect every overflow.')
save(im,3)

# 4: deliberately illustrative fill-history values, not real workload timings.
im,d=header('High-water mark is history','Illustration only: every used word is assumed written')
text(d,75,290,'Margin in a 256-word stack',1050,46,TEAL,True)
text(d,75,355,'Green bar: current / teal line: history',1050,41,MUTED)
bars=[('Path A',180),('Path B',100),('Path C',140)]
for j,(name,current) in enumerate(bars):
 y=445+j*245
 text(d,75,y,name,1040,46,INK,True)
 # Orange bar denotes illustrative available-space state; teal marker is history.
 box(d,75,y+80,1020,105,'#e9eef2',LINE)
 d.rectangle((80,y+85,80+current*1010/256,y+180),fill=FREE)
 history=min(v for _,v in bars[:j+1]);hx=80+history*1010/256
 d.line((hx,y+70,hx,y+195),fill=TEAL,width=8)
 text(d,80,y+195,f'Historical untouched minimum: {history} words',1040,41,TEAL)
card(d,1220,'After B, history stays at 100 words','100 words x 4 bytes = 400 bytes of untouched fill. It does not rise when a later path uses less stack.',270)
text(d,85,1510,'Unwritten reserved locals can make fill scans optimistic.',1030,43,ORANGE)
footer(d,'Illustration only. Test all relevant paths and justify an additional margin.')
save(im,4)

# 5: static is not memory free and heap array usually lives in BSS too.
im,d=header('Static tasks still consume RAM','Two allocation paths; both need a TCB and a stack')
text(d,85,295,'Dynamic: xTaskCreate',1030,48,TEAL,True)
box(d,85,385,1030,340,'white',TEAL)
text(d,120,410,'FreeRTOS heap array in RAM',950,47,INK,True)
box(d,120,510,430,150,USED,RED);text(d,155,550,'Task TCB',350,48,INK,True)
box(d,585,510,490,150,FREE,TEAL);text(d,620,550,'Task stack',410,48,INK,True)
text(d,85,770,'Allocation can fail if the heap cannot satisfy it.',1030,44,ORANGE)
text(d,85,925,'Static: xTaskCreateStatic',1030,48,TEAL,True)
box(d,85,1015,1030,340,'white',TEAL)
text(d,120,1040,'Caller-owned permanent RAM buffers',950,47,INK,True)
box(d,120,1140,430,150,USED,RED);text(d,155,1180,'StaticTask_t',370,43,INK,True)
box(d,585,1140,490,150,FREE,TEAL);text(d,620,1180,'StackType_t[]',430,43,INK,True)
text(d,85,1410,'No heap request for this task. The buffers must remain valid for its whole lifetime.',1030,45)
text(d,85,1540,'Static allocation does not prevent every memory error.',1030,43,ORANGE)
footer(d,'In this project the heap array and static task buffers are both placed in BSS.')
save(im,5)

# 6: two distinct mechanisms, not a blanket claim of newlib thread safety.
im,d=header('newlib: two separate concerns','Per-task C-library state is not a global malloc lock')
text(d,75,290,'1. Per-task reentrancy state',1050,48,TEAL,True)
box(d,75,385,485,215,FREE,TEAL);text(d,105,410,'Task A',415,48,INK,True);text(d,105,505,'Own _reent',415,44)
box(d,620,385,485,215,FREE,TEAL);text(d,650,410,'Task B',415,48,INK,True);text(d,650,505,'Own _reent',415,44)
arrow(d,320,620,490,730);arrow(d,860,620,690,730)
text(d,115,755,'_impure_ptr follows the running task',1000,46,TEAL,True)
text(d,95,860,'configUSE_NEWLIB_REENTRANT = 1 enables this integration; its RAM cost depends on the library.',1030,43)
d.line((75,1060,1125,1060),fill=LINE,width=4)
text(d,75,1100,'2. Shared malloc pool',1050,48,RED,True)
box(d,75,1190,1030,210,USED,RED)
text(d,110,1220,'Allocator locks and system stubs',960,47,INK,True)
text(d,110,1310,'Need separate implementation and review',960,42)
text(d,85,1460,'A per-task _reent does not serialize concurrent calls into one global allocation pool.',1030,45,ORANGE)
footer(d,'Current project: newlib reentrancy = 0; no allocating libc calls are used.')
save(im,6)

pin='https://github.com/FreeRTOS/FreeRTOS-Kernel/blob/0adc196d4bd52a2d91102b525b0aafc1e14a2386/'
captions=[
 'مدل محاسباتی ادغام بلوک‌های مجاور در heap_4 برای نسخهٔ کامپایل‌شدهٔ این پروژه؛ اندازه‌ها شامل سربار تخصیص‌اند و طول شکل‌ها متناسب با اندازه نیست. آزادسازی B دو ناحیهٔ آزاد را به هم متصل می‌کند. این سازوکار همهٔ انواع تکه‌تکه‌شدن را حذف نمی‌کند و اعداد، اندازه‌گیری روی برد نیستند.',
 'نمودار تألیفی پشتهٔ نزولی یک Task در پورت ARM_CM4F؛ ناحیهٔ دست‌نخوردهٔ 0xA5 با موقعیت کنونی یا ذخیره‌شدهٔ اشاره‌گر پشته یک مفهوم نیست. نگهبان‌های پایین پشته مرز حفاظتی سخت‌افزاری ایجاد نمی‌کنند.',
 'نمودار تألیفی دو روش بررسی سرریز در FreeRTOS 11.2.0؛ روش 2 علاوه بر مقایسهٔ اشاره‌گر ذخیره‌شده با مرز پشته، 4 کلمهٔ نگهبان را هم بررسی می‌کند. خرابی حافظه یا Fault ممکن است پیش از نوبت بررسی رخ دهد و Hook تضمین تشخیص یا بازیابی نیست.',
 'مثال مفهومی رفتار ردپای پشته برای یک پشتهٔ 256 کلمه‌ای؛ مقدار تاریخی 100 کلمه معادل 400 بایتِ دست‌نخورده است و با سبک‌تر شدن مسیر بعدی افزایش نمی‌یابد. این مقادیر نمونه‌اند و دادهٔ دیباگر یا سنجش روی برد نیستند. فضای رزروشده ولی نوشته‌نشده می‌تواند برداشت از حاشیهٔ واقعی را خوش‌بینانه کند.',
 'نمودار تألیفی مقایسهٔ تخصیص Task؛ در روش پویا TCB و پشته از Heap گرفته می‌شوند و در روش ایستا بافرهای ماندگار را برنامه فراهم می‌کند. هر دو روش RAM مصرف می‌کنند؛ ایستا بودن مانع همهٔ خطاهای حافظه نمی‌شود. در این پروژه، آرایهٔ Heap و بافرهای ایستا هر دو در BSS قرار دارند.',
 'نمودار تألیفی تفکیک دو مسئله در newlib؛ دادهٔ بازدرآمد اختصاصی هر Task با قفل‌کردن مخزن مشترک malloc متفاوت است. فعال‌کردن configUSE_NEWLIB_REENTRANT به‌تنهایی malloc را در برابر فراخوانی هم‌زمان ایمن نمی‌کند. پروژهٔ این درس این گزینه را 0 نگه می‌دارد و تابع تخصیص‌دهندهٔ libc فراخوانی نمی‌کند.'
]
alts=['ادغام سه ناحیهٔ آزاد در heap_4 پس از آزادسازی بلوک میانی، با مقادیر مدل محاسباتی پروژه','پشتهٔ نزولی Task با فریم‌ها، اشاره‌گر ذخیره‌شده و الگوی دست‌نخوردهٔ 0xA5','روش 1 مقایسهٔ اشاره‌گر و روش 2 مقایسهٔ اشاره‌گر همراه با نگهبان‌ها و محدودیت بررسی هنگام تعویض Task','مثال مفهومی ثابت‌ماندن کمترین تعداد کلمه‌های دست‌نخورده پس از اجرای مسیر سبک‌تر','مقایسهٔ مصرف RAM برای TCB و پشته در ساخت Task پویا و ایستا','ساختار reent اختصاصی دو Task در برابر قفل موردنیاز برای مخزن مشترک malloc']
sources=[pin+'portable/MemMang/heap_4.c; current project normal ELF symbols and memory-model-output.json',pin+'tasks.c; '+pin+'portable/GCC/ARM_CM4F/portmacro.h',pin+'include/stack_macros.h; '+pin+'tasks.c',pin+'tasks.c (prvTaskCheckFreeStackSpace); invented illustrative values, not measured',pin+'tasks.c; actual lesson44 linker and static buffers',pin+'examples/template_configuration/FreeRTOSConfig.h; https://sourceware.org/newlib/libc.html sections 3.26 and 11']
metadata=[{'id':f'fig{i:02d}','filename':f'lesson44-figure{i}.png','width':W,'height':H,'caption':captions[i-1],'alt':alts[i-1],'source':sources[i-1],'license':'Original diagram and drawing code by GEBRA ENG, CC BY 4.0. Source documents cited, not reproduced.','kind':'original conceptual diagram' if i!=1 else 'original source-and-ELF arithmetic model','pixels_reviewed':False} for i in range(1,7)]
(P/'image-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf8')
for size in [390,600]:
 sheet=Image.new('RGB',(size*3,H*size//W*2),'white')
 for i in range(1,7):sheet.paste(Image.open(Q/f'fig{i}-{size}.png'),(((i-1)%3)*size,((i-1)//3)*(H*size//W)))
 sheet.save(Q/f'contact-sheet-{size}.png')
print('6 figures generated; visual review remains required.')




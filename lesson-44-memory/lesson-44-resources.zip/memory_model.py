"""Allocator arithmetic model from the compiled symbol address, NOT board data."""
from pathlib import Path
import json,re
P=Path(__file__).resolve().parent
symbols=(P/'symbols-Debug.txt').read_text()
m=re.search(r'^([0-9a-f]+)\s+([0-9a-f]+)\s+\w\s+ucHeap$',symbols,re.M)
address,size=(int(x,16) for x in m.groups())
alignment=8
header=8
start=(address+alignment-1)&~(alignment-1)
end=(address+size-header)&~(alignment-1)
usable=end-start
cost=lambda n:(n+header+alignment-1)&~(alignment-1)
allocated=cost(256)+cost(512)+cost(256)
samples=[
 {'stage':0,'description':'before application allocations','free':usable,'largest':usable,'blocks':1,'minimum':usable-cost(8)},
 {'stage':1,'description':'allocate A256 B512 C256','free':usable-allocated,'largest':usable-allocated,'blocks':1,'minimum':usable-allocated},
 {'stage':2,'description':'free A and C; B separates two free regions','free':usable-cost(512),'largest':usable-cost(256)-cost(512),'blocks':2,'minimum':usable-allocated},
 {'stage':3,'description':'free B; adjacent blocks coalesce','free':usable,'largest':usable,'blocks':1,'minimum':usable-allocated}]
assert cost(256)==264 and cost(512)==520
assert usable%8==0 and usable<size
assert samples[2]['free']>samples[2]['largest']
assert samples[3]['free']==samples[0]['free']
assert samples[3]['minimum']<samples[3]['free']
result={'kind':'source-and-ELF arithmetic model; not measured runtime output','heap_address':hex(address),'configured_bytes':size,'header_bytes':header,'alignment_bytes':alignment,'usable_bytes':usable,'samples':samples,'stack_bytes':{'monitor':384*4,'worker':256*4,'idle':128*4,'timer_daemon':256*4},'TCB_bytes_from_ELF':92,'runtime_results_available':False}
(P/'memory-model-output.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result,indent=2))

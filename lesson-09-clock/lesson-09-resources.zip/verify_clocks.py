"""Nominal clock arithmetic, not silicon/scope simulation. Python standard library."""
from pathlib import Path
import json

def latency(hclk):
    if not 0 < hclk <= 72000000: raise ValueError('HCLK outside lesson operating range')
    return 0 if hclk <= 24000000 else 1 if hclk <= 48000000 else 2

def predict(source_hz, prediv=1, multiplier=1, ahb_div=1, apb1_div=1, apb2_div=1, mco_source='HSI'):
    sysclk=source_hz//prediv*multiplier
    hclk=sysclk//ahb_div; p1=hclk//apb1_div; p2=hclk//apb2_div
    if p1>36000000: raise ValueError('APB1 exceeds36MHz')
    mco={'HSI':8000000,'HSE':8000000,'PLLCLK_DIV2':sysclk//2}[mco_source]
    return dict(sysclk_hz=sysclk,hclk_hz=hclk,pclk1_hz=p1,pclk2_hz=p2,
        apb1_timer_path_hz=p1*(1 if apb1_div==1 else 2),apb2_timer_path_hz=p2*(1 if apb2_div==1 else 2),
        flash_latency_ws=latency(hclk),mco_source=mco_source,mco_divider=1,mco_hz=mco,mco_period_ns=1e9/mco,
        systick_reload_for_1ms=hclk//1000-1)

cases={'HSI8-MCO-HSI8':predict(8000000),
       'HSEPLL72-MCO-PLLdiv2':predict(8000000,multiplier=9,apb1_div=2,mco_source='PLLCLK_DIV2'),
       'HSEPLL72-MCO-HSE8':predict(8000000,multiplier=9,apb1_div=2,mco_source='HSE')}
assert cases['HSI8-MCO-HSI8']['systick_reload_for_1ms']==7999
b=cases['HSEPLL72-MCO-PLLdiv2']
assert [b[k] for k in ['sysclk_hz','hclk_hz','pclk1_hz','pclk2_hz']]==[72000000,72000000,36000000,72000000]
assert b['mco_hz']==36000000 and b['flash_latency_ws']==2 and b['systick_reload_for_1ms']==71999
assert b['apb1_timer_path_hz']==b['apb2_timer_path_hz']==72000000
assert cases['HSEPLL72-MCO-HSE8']['mco_hz']==8000000
assert latency(24000000)==0 and latency(24000001)==1 and latency(48000000)==1 and latency(48000001)==2
assert predict(8000000,multiplier=9,apb1_div=4)['apb1_timer_path_hz']==36000000
try: predict(8000000,multiplier=9)
except ValueError: pass
else: raise AssertionError('Invalid APB1 accepted')
try: latency(72000001)
except ValueError: pass
else: raise AssertionError('Invalid HCLK accepted')
result={'scope':'Nominal configuration arithmetic; no actual frequency, jitter, waveform or HAL runtime measured.',
 'chip_MCOPRE_supported':False,'general_MCO_DIV16_supported':False,
 'timer_caveat':'APB-derived path only; implemented timers and their independent kernel muxes must be checked.',
 'measurement_error_ppm_formula':'(measured_hz - nominal_hz) / nominal_hz * 1000000',
 'cases':cases,'checks_passed':['baseline clock ratios','three MCO paths','timer APB x1/x2','APB /4 counterexample','Flash boundary24/48MHz','invalid APB1 rejected','invalid HCLK rejected','SysTick nominal reloads']}
(Path(__file__).parent/'clock-model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))

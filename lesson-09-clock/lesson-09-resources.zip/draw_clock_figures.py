"""Original figures from reviewed lesson 9 image plan; Pillow, no copied layouts."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
OUT=Path(__file__).parent
N='#17334a'; T='#087f8c'; G='#526778'; BG='#f2f6f9'; OR='#a65d18'
def f(n,b=False): return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def base(title,subtitle,h=1800):
 im=Image.new('RGB',(1200,h),BG);d=ImageDraw.Draw(im);d.text((45,35),title,font=f(51,True),fill=N);d.text((45,115),subtitle,font=f(31),fill=G);return im,d
def card(d,y,title,lines,height=270):
 d.rounded_rectangle((45,y,1155,y+height),radius=22,fill='white',outline='#c7d6df',width=2);d.text((75,y+20),title,font=f(49,True),fill=T)
 for k,line in enumerate(lines):d.text((75,y+90+k*54),line,font=f(40),fill=N)
def arrow(d,y):
 d.line([(600,y),(600,y+45)],fill=T,width=7);d.polygon([(600,y+55),(584,y+34),(616,y+34)],fill=T)
def footer(d,h,lines):
 for k,s in enumerate(lines):d.text((45,h-115+k*42),s,font=f(29),fill=G)
im,d=base('Four clock sources, four roles','STM32F303CBT6 | GB100ST V2.0 | Original concept diagram',1640)
for y,title,lines in [(185,'HSI: internal RC, nominal 8 MHz',['Fast startup / internal reference','Accuracy varies with trim and conditions']), (485,'HSE: onboard crystal, 8 MHz',['Passive AKER C3E crystal: HSE_ON','Board loading also affects actual error']), (785,'LSI: internal RC, nominal 40 kHz',['Independent watchdog / RTC option','Nominal frequency is not precision time']), (1085,'LSE: external crystal, 32.768 kHz',['RTC low-frequency reference','Reserved pins do not mean running'])]:card(d,y,title,lines,265)
footer(d,1640,['PLL changes frequency, not relative reference accuracy.','Technical basis: DS9118, RM0316, board V2.0, AKER C3E.'])
im.save(OUT/'stm32f303-clock-sources-comparison.png')
im,d=base('The course baseline: 72 MHz','Expected configuration | HSE crystal 8 MHz | No measurement',1860)
card(d,180,'HSE 8 MHz -> PREDIV /1',['PLL input = 8 MHz'],190);arrow(d,377)
card(d,440,'PLL x9 -> SYSCLK 72 MHz',['8 MHz /1 x9 = 72 MHz'],190);arrow(d,637)
card(d,700,'AHB /1 -> HCLK 72 MHz',['Core 72 MHz / Flash latency 2 WS'],190)
d.line([(600,890),(600,965),(310,965),(310,1030)],fill=T,width=7)
d.line([(600,965),(890,965),(890,1030)],fill=T,width=7)
for x in [310,890]:d.polygon([(x,1040),(x-16,1019),(x+16,1019)],fill=T)
for x,title,lines in [(45,'APB1 /2',['From HCLK','PCLK1 = 36 MHz','Bus maximum36','Timer path72']), (630,'APB2 /1',['From HCLK','PCLK2 = 72 MHz','Timer path72','Check other muxes'])]:
 d.rounded_rectangle((x,1050,x+525,1450),radius=22,fill='white',outline='#c7d6df',width=2);d.text((x+25,1080),title,font=f(52,True),fill=T)
 for i,s in enumerate(lines):d.text((x+25,1170+i*59),s,font=f(39),fill=N)
d.text((75,1520),'Parallel branches from HCLK; frequencies in MHz.',font=f(38,True),fill=N)
footer(d,1860,['Only peripherals present on this exact device apply.','Source: actual generated SystemClock_Config and ST RCC rules.'])
im.save(OUT/'stm32f303-baseline-clock-tree.png')
im,d=base('Flash must keep up with HCLK','STM32F303xB/C | Wait states, not a time measurement',1660)
d.text((70,190),'Minimum wait states (WS)',font=f(46,True),fill=T)
left,right=150,1090; bottom,top=850,310
for ws in [0,1,2]:
 y=bottom-ws*240;d.line([(left,y),(right,y)],fill='#ccdce5',width=2);d.text((80,y-28),str(ws),font=f(48,True),fill=N)
for mhz in [0,24,48,72]:
 x=left+mhz/72*(right-left);d.line([(x,top),(x,bottom+15)],fill='#ccdce5',width=2);d.text((x-25,bottom+35),str(mhz),font=f(43),fill=N)
d.line([(left,bottom),(right,bottom)],fill=N,width=4);d.line([(left,bottom),(left,top)],fill=N,width=4)
x24=left+(right-left)/3;x48=left+2*(right-left)/3
d.line([(left,bottom),(x24,bottom)],fill=T,width=8);d.line([(x24,bottom-240),(x48,bottom-240)],fill=T,width=8);d.line([(x48,bottom-480),(right,bottom-480)],fill=T,width=8)
for x,lower in [(x24,bottom),(x48,bottom-240)]:
 d.line([(x,lower),(x,lower-240)],fill=T,width=3);d.ellipse((x-9,lower-9,x+9,lower+9),fill=T);d.ellipse((x-9,lower-249,x+9,lower-231),fill=BG,outline=T,width=3)
d.text((700,945),'HCLK (MHz)',font=f(46,True),fill=N)
d.text((80,1030),'24 MHz: 0 WS | 48 MHz: 1 WS | 72 MHz: 2 WS',font=f(40),fill=N)
card(d,1140,'Increasing HCLK: set latency first',['1. Raise Flash latency and verify it','2. Switch to the faster system clock','Reducing HCLK: lower clock first'],320)
footer(d,1660,['Applicable supply / operating limits still apply.','Source: RM0316 Flash + actual HAL_RCC_ClockConfig implementation.'])
im.save(OUT/'flash-latency-frequency-relationship.png')
im,d=base('APB clock is not always timer clock','Rule for the APB-derived timer path | Original concept diagram',1700)
card(d,185,'If APB divider = 1',['TIMxCLK = PCLKx','APB2 /1: 72 -> timer 72 MHz'],270)
card(d,530,'If APB divider > 1',['TIMxCLK = 2 x PCLKx','APB1 /2: 36 -> timer 72 MHz'],270)
card(d,880,'A useful counterexample',['APB1 /4: PCLK1 = 18 MHz','Timer path = 2 x18 = 36 MHz','It does not always restore HCLK'],320)
card(d,1265,'Check the actual timer and mux',['Apply only to implemented timers','Check independent kernel-clock selection'],240)
footer(d,1700,['No timer peripheral is started by this lesson project.','Technical basis: RM0316 clock tree and exact F303xC device.'])
im.save(OUT/'apb-timer-clock-doubler-logic.png')
im,d=base('Connect PA8 to the probe tip','Logical connection diagram | No physical header layout',1860)
d.rounded_rectangle((80,200,1120,540),radius=25,fill='white',outline=N,width=4)
d.text((130,245),'GebraBit GB100ST V2.0',font=f(52,True),fill=T)
d.text((130,325),'Use board header signals; not IC legs.',font=f(40),fill=N)
d.text((165,435),'PA8 / MCO',font=f(48,True),fill=T);d.text((835,435),'GND',font=f(48,True),fill=N)
for x,color in [(300,T),(900,N)]:d.ellipse((x-18,522,x+18,558),fill='white',outline=color,width=6)
d.line([(300,560),(300,900)],fill=T,width=10)
for y in range(560,895,35):d.line([(900,y),(900,min(y+22,900))],fill=N,width=8)
d.text((355,630),'Signal -> TIP',font=f(47,True),fill=T)
d.text((355,725),'Short ground lead',font=f(45),fill=N)
d.rounded_rectangle((80,920,1120,1240),radius=25,fill='white',outline=N,width=4)
for x,color in [(300,T),(900,N)]:d.ellipse((x-18,902,x+18,938),fill='white',outline=color,width=6)
d.text((245,960),'TIP',font=f(50,True),fill=T);d.text((835,960),'GND',font=f(50,True),fill=N)
d.text((130,1065),'Oscilloscope / compatible probe',font=f(46,True),fill=N)
d.text((130,1145),'Check loading and bandwidth at8/36MHz',font=f(39),fill=N)
card(d,1315,'PA8 = LQFP48 physical pin 29',['Logical terminal positions are illustrative','Header position is not IC pin number','3.3 V MCU; keep SWD PA13 /PA14'],310)
footer(d,1860,['Do not probe OSC_IN / OSC_OUT; follow equipment grounding rules.','Source: board V2.0 schematic + DS9118 pin table.'])
im.save(OUT/'gebrabit-f303-mco-pa8-wiring.png')
im,d=base('MCO: three nominal predictions','Ideal logic 0/1 model | Not voltage, jitter, or scope evidence',1820)
for top,title,hz in [(180,'HSI core 8 MHz / MCO HSI',8000000),(660,'PLL core 72 MHz / MCO HSE',8000000),(1140,'PLL core 72 MHz / MCO PLL/2',36000000)]:
 d.text((50,top),title,font=f(45,True),fill=T);d.text((50,top+65),f'{hz/1e6:g} MHz | T = {1e9/hz:.2f} ns | DIV1',font=f(44),fill=N)
 left,right=135,1115; high,low=top+165,top+295
 for k in range(5):
  x=left+k*(right-left)/4;d.line([(x,high-20),(x,low+15)],fill='#d5dfe6',width=2);d.text((x-16,low+30),str(k*125),font=f(29),fill=G)
 d.text((60,high-15),'1',font=f(35),fill=N);d.text((60,low-18),'0',font=f(35),fill=N)
 pts=[]; last=None
 for k in range(1001):
  ns=k/2; level=(ns*hz/1e9)%1<0.5; y=high if level else low;x=left+ns/500*(right-left)
  if last is not None:pts.append((x,last))
  pts.append((x,y));last=y
 d.line(pts,fill=T,width=4);d.text((980,low+75),'Time (ns)',font=f(30),fill=G)
footer(d,1820,['Ideal 50% duty and sharp edges are modeling assumptions.','F303xC has no MCOPRE: no general MCO /16 option.'])
im.save(OUT/'predicted-mco-waveform-comparison.png')
im,d=base('Two different HSE failure paths','Conditional mechanism diagram | Baseline CSS is DISABLED',1920)
card(d,180,'Startup: HSE does not become ready',['HAL_RCC_OscConfig waits using HAL tick','Returns HAL_TIMEOUT if limit exceeded'],270);arrow(d,465)
card(d,530,'Generated Error_Handler',['Disables IRQ, then loops forever','No implemented software fallback'],260)
card(d,885,'Run time: ONLY if CSS enabled',['HSE fails -> hardware selects HSI','HSE / affected PLL stopped; NMI raised','This is not a Reset'],320);arrow(d,1220)
card(d,1290,'Recovery is application work',['NMI -> HAL_RCC_NMI_IRQHandler','Callback / CSS flag handling required','Reconcile clocks, tick and peripherals'],320)
footer(d,1920,['No CSS recovery or fault injection is implemented or bench-tested.','Source: RM0316 + pinned HAL; no uninterrupted timing guarantee.'])
im.save(OUT/'clock-security-system-failure-flow.png')
print('Created 7 original concept/model PNGs.')

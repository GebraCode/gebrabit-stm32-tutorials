"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=9
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Give fast and slow clocks different jobs','Nominal values; selected course path: HSE through PLL')
 panel(d,65,300,470,180,'HSI: 8 MHz',['Internal fast oscillator'])
 panel(d,665,300,470,180,'HSE: board 8 MHz',['External crystal'])
 arrow(d,[(900,500),(900,610)])
 panel(d,665,625,470,180,'PLL path',['HSE / 1 x 9 = 72 MHz'])
 arrow(d,[(300,500),(300,950),(440,950)])
 arrow(d,[(900,820),(900,950),(760,950)])
 panel(d,450,880,300,160,'SYSCLK',())
 arrow(d,[(600,1055),(600,1160)])
 tx(d,300,1180,'AHB and APB distribution',46,TEAL,True)
 panel(d,65,1360,470,230,'LSI: 40 kHz',['Internal slow clock','IWDG / RTC'])
 panel(d,665,1360,470,230,'LSE: 32.768 kHz',['Board slow crystal','Example: RTC'])
 foot(d,'LSI and LSE are not PLL inputs in this diagram.');save(im,1)
def figure2():
 im,d=begin('Calculate one PLL path before configuring it','Actual selected course values; constraints still come from the device documents')
 vals=[('HSE input','8 MHz'),('PREDIV / 1','8 MHz'),('PLLMUL x 9','72 MHz'),('SYSCLK selected from PLL','72 MHz')]
 for k,(a,b)in enumerate(vals):
  y=300+k*290;panel(d,75,y,1050,190,a,[b])
  if k<3:arrow(d,[(600,y+205),(600,y+280)])
 tx(d,75,1485,'f_PLL = (f_HSE / PREDIV) x PLLMUL',46,TEAL,True)
 tx(d,75,1570,'72 MHz is the maximum system clock for this device.',40)
 foot(d,'A legal arithmetic result alone does not validate every PLL setting.');save(im,2)
def figure3():
 im,d=begin('Distinguish the bus clock from a timer clock','Actual course dividers; TIM2 is the simple APB1 example')
 panel(d,375,300,450,170,'HCLK: 72 MHz',())
 arrow(d,[(600,485),(600,570),(300,570),(300,640)])
 arrow(d,[(600,570),(900,570),(900,640)])
 panel(d,65,655,470,220,'APB1 divider / 2',['PCLK1: 36 MHz'])
 panel(d,665,655,470,220,'APB2 divider / 1',['PCLK2: 72 MHz'])
 arrow(d,[(300,890),(300,1000)]);arrow(d,[(900,890),(900,1000)])
 panel(d,65,1015,470,220,'Timer path x 2',['TIM2 clock: 72 MHz'])
 panel(d,665,1015,470,220,'Selected PCLK path',['Timer clock: 72 MHz'])
 panel(d,65,1380,1070,245,'Check the timer-specific clock selection',['PCLK path: /1 -> PCLK; otherwise -> 2 x PCLK.','TIM1 / TIM8 have additional clock-source choices.'])
 foot(d,'Do not extend one simple timer rule to every clock mux.');save(im,3)
def figure4():
 im,d=begin('Match Flash wait states to HCLK','Nominal 3.3 V course supply; model of the documented frequency bands')
 x0=170;y0=1230;scale=12;ys={0:1130,1:850,2:570}
 arrow(d,[(x0,1350),(x0,390)],INK,4);arrow(d,[(120,y0),(1120,y0)],INK,4)
 tx(d,75,300,'Wait states',44,TEAL,True)
 for ws,y in ys.items():tx(d,85,y-25,str(ws),46);d.line((170,y,1060,y),fill=LINE,width=2)
 for f in [0,24,48,72]:
  x=x0+f*scale;d.line((x,y0-15,x,y0+15),fill=INK,width=3);tx(d,x-25,y0+45,str(f),42)
 for a,b,ws in [(0,24,0),(24,48,1),(48,72,2)]:
  xa=x0+a*scale;xb=x0+b*scale;y=ys[ws];d.line((xa,y,xb,y),fill=TEAL,width=10)
  if a:d.ellipse((xa-14,y-14,xa+14,y+14),fill=BG,outline=TEAL,width=4)
  d.ellipse((xb-14,y-14,xb+14,y+14),fill=TEAL)
 tx(d,820,1360,'HCLK (MHz)',44,TEAL,True)
 tx(d,75,1470,'0 WS: <= 24     1 WS: > 24 and <= 48',42)
 tx(d,75,1550,'2 WS: > 48 and <= 72; course uses 72 MHz / 2 WS.',42)
 foot(d,'Filled boundary belongs to the lower wait-state band.');save(im,4)
def figure5():
 im,d=begin('Startup timeout and runtime CSS differ','Conceptual paths; no crystal failure was physically tested')
 tx(d,75,300,'Startup software path',48,TEAL,True)
 panel(d,75,400,1050,190,'HAL_RCC_OscConfig waits for HSE ready',['If the configured timeout expires: HAL_TIMEOUT'])
 arrow(d,[(600,605),(600,700)])
 panel(d,75,715,1050,170,'Generated application checks the status',['Non-OK status -> Error_Handler; no automatic retry'])
 tx(d,75,1000,'CSS concept: disabled in the delivered firmware',48,ORANGE,True)
 panel(d,75,1100,1050,205,'HSE failure while used by the system clock',['Documented HSI switch / NMI path depends on clock selection'])
 arrow(d,[(600,1320),(600,1400)],ORANGE)
 panel(d,75,1415,1050,195,'NMI handling and application recovery',['Clear CSS flag; review clock and timebase.'])
 foot(d,'Fallback does not guarantee correct application timing.');save(im,5)
def square(d,x,y,w,period,cycles,c=TEAL):
 pts=[(x,y+100)]
 for k in range(cycles):
  a=x+k*period;pts.extend([(a,y+100),(a,y),(a+period/2,y),(a+period/2,y+100),(a+period,y+100)])
 d.line(pts,fill=c,width=7)
def figure6():
 im,d=begin('Export a supported MCO source on PA8','Calculated source and period models, not oscilloscope captures')
 panel(d,65,300,470,300,'Sources',['HSI: 8 MHz / HSE: 8 MHz','PLL / 2: 36 MHz'])
 arrow(d,[(550,420),(660,420)])
 panel(d,675,300,455,230,'MCO -> PA8 AF0',['No arbitrary / 16 divider'])
 tx(d,75,650,'8 MHz: nominal period 125 ns',46,TEAL,True)
 square(d,110,770,980,300,3)
 tx(d,75,910,'Shown time span: 375 ns',40)
 tx(d,75,1020,'36 MHz: nominal period 27.78 ns',46,ORANGE,True)
 square(d,110,1140,980,125,7,ORANGE)
 tx(d,75,1280,'Shown time span: 194.44 ns',40)
 panel(d,75,1370,1050,250,'MCO is configured in USER CODE',['PA8 starts as GPIO; HAL_RCC_MCOConfig selects AF0.','Use suitable bandwidth and a short probe ground.'])
 foot(d,'Separately scaled time models; no measured duty or jitter.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson09-refresh-figure1.png', 'alt': 'منابع تند و کند کلاک و نقش\u200cهای متفاوت آن\u200cها', 'caption': 'نمودار تألیفی مسیرهای ساده\u200cشدهٔ منابع کلاک: مسیر دوره از HSE برابر 8 MHz به PLL و SYSCLK می\u200cرسد. LSI اسمی 40 kHz و LSE برابر 32.768 kHz برای کاربردهای کم\u200cسرعت جدا نمایش داده شده\u200cاند و ورودی PLL نیستند. مقادیر فرکانس اندازه\u200cگیری فیزیکی نیستند.', 'purpose': 'منابع تند و کند کلاک و نقش\u200cهای متفاوت آن\u200cها', 'placement': 'بخش منابع چهارگانه فرکانس در STM32F303CB', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device clock/electrical constraints'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'RCC sources, timers, Flashlatency, CSS and MCO'}, {'url': 'local:actual lesson09 source/IOC and fresh build reports', 'version': 'CubeMX6.14.0 CubeF3V1.11.6 HAL953955a GCC13.2.1', 'scope': 'ActualHSEPLL72/HSI8/HSE8MCOvariants; no board measurements'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'No invalidLSI/LSEPLLpaths; HSI nominal8/HSEboard8/LSInominal40/LSE32.768; onlyselectedHSEPLLpath highlighted.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson09-refresh-figure2.png', 'alt': 'محاسبهٔ مسیر PLL انتخاب\u200cشده', 'caption': 'مدل محاسباتی تألیفی پیکربندی واقعی دوره: HSE برابر 8 MHz، PREDIV برابر 1 و ضریب 9 خروجی 72 MHz می\u200cسازند. درست\u200cبودن حساب به\u200cتنهایی مجازبودن هر ترکیب PLL را اثبات نمی\u200cکند؛ سقف سیستم این قطعه 72 MHz است.', 'purpose': 'محاسبهٔ مسیر PLL انتخاب\u200cشده', 'placement': 'بخش واحد ضرب\u200cکننده فرکانس (PLL)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device clock/electrical constraints'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'RCC sources, timers, Flashlatency, CSS and MCO'}, {'url': 'local:actual lesson09 source/IOC and fresh build reports', 'version': 'CubeMX6.14.0 CubeF3V1.11.6 HAL953955a GCC13.2.1', 'scope': 'ActualHSEPLL72/HSI8/HSE8MCOvariants; no board measurements'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual8/1*9=72. Omit unverified1..24MHz/table43inputlimit; no generalallSTM32constraint.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson09-refresh-figure3.png', 'alt': 'تفاوت کلاک باس و تایمر در پیکربندی دوره', 'caption': 'نمودار تألیفی تقسیم HCLK برابر 72 MHz به APB1 برابر 36 و APB2 برابر 72 MHz. TIM2 نمونهٔ مسیر مشتق از PCLK1 با ضریب 2 است؛ قاعدهٔ PCLK-derived به هر انتخابگر کلاک تعمیم ندارد و TIM1 و TIM8 گزینه\u200cهای اضافی دارند.', 'purpose': 'تفاوت کلاک باس و تایمر در پیکربندی دوره', 'placement': 'بخش ساختار باس\u200cهای AHB، APB1 و APB2', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device clock/electrical constraints'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'RCC sources, timers, Flashlatency, CSS and MCO'}, {'url': 'local:actual lesson09 source/IOC and fresh build reports', 'version': 'CubeMX6.14.0 CubeF3V1.11.6 HAL953955a GCC13.2.1', 'scope': 'ActualHSEPLL72/HSI8/HSE8MCOvariants; no board measurements'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'TIM2example; conditionalPCLKtimerx2 rule andTIM1/TIM8muxexceptions, no genericTIM2..7allinstancesclaim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson09-refresh-figure4.png', 'alt': 'مدل پله\u200cای تعداد Wait State حافظهٔ Flash', 'caption': 'نمودار تألیفی بازه\u200cهای فرکانس در تغذیهٔ اسمی 3.3 V دوره: تا و شامل 24 MHz برابر 0 WS، بالاتر از 24 تا و شامل 48 برابر 1 WS، و بالاتر از 48 تا و شامل 72 برابر 2 WS. نقاط پر متعلق به بازهٔ پایین\u200cترند؛ تصویر اندازه\u200cگیری زمان دسترسی نیست.', 'purpose': 'مدل پله\u200cای تعداد Wait State حافظهٔ Flash', 'placement': 'بخش زمان انتظار حافظه فلش (Flash Latency)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device clock/electrical constraints'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'RCC sources, timers, Flashlatency, CSS and MCO'}, {'url': 'local:actual lesson09 source/IOC and fresh build reports', 'version': 'CubeMX6.14.0 CubeF3V1.11.6 HAL953955a GCC13.2.1', 'scope': 'ActualHSEPLL72/HSI8/HSE8MCOvariants; no board measurements'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Boundary24inclusive0WS/48inclusive1WS/72inclusive2WS underdocumentedvoltageconditions. Notmeasuredlatency.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson09-refresh-figure5.png', 'alt': 'تفاوت timeout راه\u200cاندازی و CSS زمان اجرا', 'caption': 'روندنمای تألیفی دو مسیر جدا: در راه\u200cاندازی، timeout تابع تنظیم نوسان\u200cساز به HAL_TIMEOUT و بررسی وضعیت در Error_Handler می\u200cرسد؛ این بازگشت خودکار برنامه به HSI نیست. CSS فعال در خرابی HSE استفاده\u200cشده برای سیستم مسیر شرطی HSI و NMI دارد؛ نرم\u200cافزار باید پرچم و وضعیت کلاک و پایگاه زمان را مدیریت کند. تداوم صحیح زمان\u200cبندی تضمین نشده و خرابی کریستال آزموده نشده است. CSS در هر 3 فریم\u200cور تحویلی غیرفعال است.', 'purpose': 'تفاوت timeout راه\u200cاندازی و CSS زمان اجرا', 'placement': 'بخش مدیریت خطا و مکانیزم\u200cهای تاب\u200cآوری کلاک', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device clock/electrical constraints'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'RCC sources, timers, Flashlatency, CSS and MCO'}, {'url': 'local:actual lesson09 source/IOC and fresh build reports', 'version': 'CubeMX6.14.0 CubeF3V1.11.6 HAL953955a GCC13.2.1', 'scope': 'ActualHSEPLL72/HSI8/HSE8MCOvariants; no board measurements'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'StartupHALtimeout vs enabledruntimeCSSconditionalonHSE/PLLclock; no withoutstoppingguarantee, clearCSS/reviewtimebase.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson09-refresh-figure6.png', 'alt': 'منابع مجاز MCO و دوره\u200cهای محاسباتی آن\u200cها', 'caption': 'نمودار تألیفی منابع واقعی پروژه\u200cهای MCO: HSI و HSE برابر 8 MHz با دورهٔ اسمی 125 ns و PLL/2 برابر 36 MHz با دورهٔ حدود 27.78 ns. PA8 ابتدا GPIO است و فراخوانی USER CODE آن را به AF0 می\u200cبرد. تقسیم دلخواه /16 وجود ندارد؛ شکل موج مدل است و duty یا jitter اندازه\u200cگیری\u200cشده نیست. دو محور زمان جداگانه مقیاس شده\u200cاند: بازهٔ اول 375 ns و بازهٔ دوم 194.44 ns است.', 'purpose': 'منابع مجاز MCO و دوره\u200cهای محاسباتی آن\u200cها', 'placement': 'بخش سنجش عملی فرکانس با استفاده از خروجی MCO', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device clock/electrical constraints'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'RCC sources, timers, Flashlatency, CSS and MCO'}, {'url': 'local:actual lesson09 source/IOC and fresh build reports', 'version': 'CubeMX6.14.0 CubeF3V1.11.6 HAL953955a GCC13.2.1', 'scope': 'ActualHSEPLL72/HSI8/HSE8MCOvariants; no board measurements'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualUSERCODEMCOAF0/highspeed followsinitialGPIO; noMCOPRE/16 and no claim newbugoldarticlealreadyrejects/16. Idealperiodmodelnotcapture.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

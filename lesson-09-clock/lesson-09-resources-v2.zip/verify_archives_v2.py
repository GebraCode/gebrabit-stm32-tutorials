"""Read-only source/artifact checks, not a CPU simulator or board test."""
from pathlib import Path
import json,zipfile,hashlib,struct,re
P=Path(__file__).resolve().parent;checks=[]
def check(name,c):
 if not c:raise AssertionError(name)
 checks.append(name)
TAG='09'
sz=zipfile.ZipFile(P/('lesson-'+TAG+'-projects-v2.zip'));az=zipfile.ZipFile(P/('lesson-'+TAG+'-build-artifacts-v2.zip'))
check('source ZIP CRC',sz.testzip() is None);check('artifact ZIP CRC',az.testzip() is None)
for filename,z in [('source-manifest-v2.json',sz),('artifact-manifest-v2.json',az)]:
 m=json.loads((P/filename).read_text());check(filename+' all SHA256',all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in m.items()))
sections={}
for n in az.namelist():
 if not n.endswith('.elf'):continue
 b=az.read(n);h=struct.unpack_from('<16sHHIIIIIHHHHHH',b);check(n+' ARM ELF32',h[0][:6]==b'\x7fELF\x01\x01' and h[2]==40)
 sh=[struct.unpack_from('<IIIIIIIIII',b,h[6]+i*h[11]) for i in range(h[12])];st=sh[h[13]];strings=b[st[4]:st[4]+st[5]]
 sec={strings[x[0]:].split(b'\0',1)[0].decode():{'address':x[3],'bytes':x[5]} for x in sh}
 expected_bss=48 if TAG=='09' else 80
 check(n+' concrete RAM sections',sec['.data']['bytes']==12 and sec['.bss']['bytes']==expected_bss and sec['._user_heap_stack']['bytes']==1540)
 check(n+' Flash vector location',sec['.isr_vector']['address']==0x08000000)
 sections[n]={k:sec[k] for k in ['.data','.bss','._user_heap_stack','.isr_vector']}
for root in sorted({n.split('/')[0] for n in sz.namelist()}):
 s=sz.read(root+'/Core/Src/main.c').decode();ioc=sz.read(root+'/'+root+'.ioc').decode()
 check(root+' exact device','Mcu.CPN=STM32F303CBT6' in ioc and 'Mcu.Package=LQFP48' in ioc)
 check(root+' SWD retained','PA13.Signal=SYS_JTMS-SWDIO' in ioc and 'PA14.Signal=SYS_JTCK-SWCLK' in ioc)
 check(root+' no CSS experiment','HAL_RCC_EnableCSS();' not in s)
 if TAG=='09':
  check(root+' MCO in USER CODE2',bool(re.search(r'/\* USER CODE BEGIN 2 \*/.*?HAL_RCC_MCOConfig\(',s,re.S)))
  check(root+' PA8 safe GPIO IOC','PA8.Signal=GPIO_Output' in ioc and 'MCO_SAFE_START' in ioc)
  h=sz.read(root+'/Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f303xc.h').decode()
  check(root+' exact chip has no general MCOPRE','RCC_CFGR_MCOPRE' not in h)
 else:
  check(root+' four priority bits',bool(re.search(r'#define\s+__NVIC_PRIO_BITS\s+4',sz.read(root+'/Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f303xc.h').decode())))
  check(root+' saved mask restored','__get_PRIMASK()' in s and '__set_PRIMASK(saved_primask)' in s)
  check(root+' software NVIC request not physical EXTI','NVIC_SetPendingIRQ(EXTI0_IRQn)' in s and 'GPIO_EXTI' not in ioc)
  check(root+' no HAL_Delay in IRQ definitions','HAL_Delay' not in s[s.index('/* USER CODE BEGIN 4 */'):s.index('/* USER CODE END 4 */')])
report={'scope':'Offline file/source checks only; separate clean C build reports and unperformed board/GUI tests','checks_passed':len(checks),'checks':checks,'ELF_sections':sections,'runtime_measurement':False}
(P/'archive-check-results-v2.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))

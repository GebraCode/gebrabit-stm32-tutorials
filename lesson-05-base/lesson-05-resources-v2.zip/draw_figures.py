"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=5
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Reserve debug pins before adding functions','Serial Wire is a configuration choice, not a guarantee against every fault')
 panel(d,70,300,490,265,'Preserve the debug path',['SYS: Serial Wire'])
 panel(d,650,300,480,265,'Risky later reuse',['Application changes pins'])
 for y,a in [(650,'PA13 / SWDIO'),(870,'PA14 / SWCLK')]:
  tx(d,90,y,a,46,TEAL,True);arrow(d,[(150,y+110),(485,y+110)])
  tx(d,700,y,'GPIO / alternate use',40,ORANGE);d.line((720,y+100,1060,y+100),fill=RED,width=8)
 panel(d,70,1200,1060,360,'What the setting means',['It reserves PA13 and PA14 for debugging.','No Debug alone does not prove immediate access loss.','Pin changes, reset and low power can affect access.'])
 foot(d,'Logical paths only; no actual connection test is shown.');save(im,1)
def figure2():
 im,d=begin('Reserved crystal pins are not running clocks','This template still selects only nominal HSI 8 MHz for the system')
 chip(d,370,520,470,530,'STM32F303CBT6','Crystal pin reservations')
 panel(d,65,300,500,160,'Board HSE: 8 MHz',())
 panel(d,650,300,480,160,'Board LSE: 32.768 kHz',())
 arrow(d,[(300,470),(300,600),(345,600)]);arrow(d,[(900,470),(900,600),(865,600)])
 tx(d,65,1100,'PF0 / PF1',46,TEAL,True);tx(d,650,1100,'PC14 / PC15',46,TEAL,True)
 panel(d,65,1260,1065,285,'Generated initializer: HSI only',['HSI -> SYSCLK -> HCLK: nominal 8 MHz','PLL is not selected as system clock source.','Reserved pins do not prove HSERDY or LSERDY.'])
 foot(d,'Functional drawing; no capacitor values or header positions.');save(im,2)
def figure3():
 im,d=begin('Build a millisecond counter from clock ticks','Nominal timing model; no measured tick accuracy is implied')
 tx(d,75,300,'8 MHz HCLK / 1000 events per second',47,TEAL,True)
 tx(d,75,410,'8000 clocks per event; LOAD = 8000 - 1 = 7999',42)
 d.line((90,850,1110,850),fill=INK,width=4)
 for x,label in [(120,'7999'),(400,'...'),(700,'1'),(1020,'0')]:
  d.line((x,805,x,895),fill=TEAL,width=5);tx(d,x-30,715,label,46,TEAL,True)
 arrow(d,[(1070,810),(1070,590),(140,590),(140,690)],ORANGE)
 tx(d,320,520,'Reload and count down again',42,ORANGE)
 arrow(d,[(1020,910),(1020,1030),(600,1030),(600,1120)])
 panel(d,75,1135,1050,220,'SysTick handler -> HAL_IncTick',['uwTick advances by 1 at the default 1 ms setting.'])
 para(d,75,1450,'Interrupt delay, halted debugging and clock tolerance separate software ticks from outside time.',1040,43)
 foot(d,'Expected LOAD 7999 is calculated, not read from a debugger.');save(im,3)
def figure4():
 im,d=begin('Choose an interface to the same peripheral','Qualitative software structure; no speed or code-size benchmark')
 for x,title,desc in [(70,'HAL','Handles + state + common operations'),(665,'LL','Register-oriented inline functions')]:
  panel(d,x,330,465,190,'Application',())
  arrow(d,[(x+230,535),(x+230,650)])
  panel(d,x,665,465,330,title,[desc])
  arrow(d,[(x+230,1010),(x+230,1130)])
  panel(d,x,1140,465,190,'Peripheral registers',())
 para(d,75,1450,'The delivered template uses HAL. Mixing interfaces needs clear ownership of state, flags and interrupts.',1050,43)
 foot(d,'LL is not always faster; HAL portability is not unconditional.');save(im,4)
def figure5():
 im,d=begin('Organize generated and user code','Protected regions help regeneration; they do not replace backups')
 folder(d,65,300,470,210,'Core/Src/main.c')
 folder(d,665,300,470,210,'Core/Src/gpio.c')
 tx(d,100,620,'Main application',44,TEAL,True);tx(d,690,620,'GPIO initialization',42,TEAL,True)
 d.rounded_rectangle((100,800,1100,1290),18,fill=WHITE,outline=TEAL,width=5)
 tx(d,135,835,'USER CODE BEGIN',46,TEAL,True)
 d.rectangle((135,950,1065,1130),fill=PALE)
 tx(d,175,1010,'Your application logic',48,TEAL,True)
 tx(d,135,1180,'USER CODE END',46,TEAL,True)
 arrow(d,[(600,1310),(600,1410)])
 tx(d,100,1480,'KeepUserCode + source backup + review the changes',43)
 foot(d,'Use the matching named USER regions in generated files.');save(im,5)
def figure6():
 im,d=begin('Version the recipe, not the temporary kitchen','A Git boundary for this generated CMake project')
 d.rounded_rectangle((65,320,1135,930),20,fill=WHITE,outline=TEAL,width=4)
 tx(d,100,350,'Keep under version control',48,TEAL,True)
 items=['.ioc configuration','Core/ user and generated source','Drivers/ with upstream licenses','CMake configuration, startup and linker files']
 for k,a in enumerate(items):tx(d,115,480+k*100,a,42)
 d.rounded_rectangle((65,1040,1135,1430),20,fill=WHITE,outline=ORANGE,width=4)
 tx(d,100,1075,'Usually ignore generated working files',46,ORANGE,True)
 tx(d,115,1200,'build/ caches, .o/.d files, workspace metadata',42)
 tx(d,115,1305,'Record intentional release artifacts separately.',42)
 tx(d,70,1530,'A build artifact can be useful without belonging in source Git.',40)
 foot(d,'Keep essential project settings; follow actual .gitignore.');save(im,6)

def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson05-refresh-figure1.png', 'alt': 'رزرو پایه\u200cهای SWD و خطر بازپیکربندی آن\u200cها', 'caption': 'نمودار تألیفی مسیر منطقی SWD و خطر استفادهٔ کاربردی از پایه\u200cهای آن. Serial Wire پایه\u200cهای PA13 و PA14 را رزرو می\u200cکند؛ انتخاب No Debug به\u200cتنهایی قطع فوری اتصال را اثبات نمی\u200cکند و این شکل گزارش اتصال واقعی نیست.', 'purpose': 'رزرو پایه\u200cهای SWD و خطر بازپیکربندی آن\u200cها', 'placement': 'در بخش «پیکربندی رابط دیباگ (SYS Debug) و صیانت از خطوط SWD» پس از توضیح خطرات قطع دیباگ', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device logical pins'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical crystal and board circuit facts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a in CubeF3V1.11.6', 'scope': 'Actual source behavior; fresh template source separately audited'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'NoDebug alone is not immediate hardware disconnection; reserve PA13/PA14, later software pin reuse or low power can affect access.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson05-refresh-figure2.png', 'alt': 'رزرو کریستال\u200cهای خارجی و کلاک HSI فعال', 'caption': 'نمودار تألیفی اتصالات منطقی کریستال HSE برابر 8 MHz به PF0/PF1 و LSE برابر 32.768 kHz به PC14/PC15. در این قالب پایه\u200cها رزرو شده\u200cاند اما initializer فقط HSI اسمی 8 MHz را شروع می\u200cکند؛ آماده\u200cبودن کریستال\u200cها یا اندازه\u200cگیری فرکانس ادعا نشده است.', 'purpose': 'رزرو کریستال\u200cهای خارجی و کلاک HSI فعال', 'placement': 'در بخش «تعیین منابع نوسان\u200cساز (RCC) مطابق شماتیک برد GB100ST V2.0»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device logical pins'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical crystal and board circuit facts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a in CubeF3V1.11.6', 'scope': 'Actual source behavior; fresh template source separately audited'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'PF0/PF1 not erroneous PD0/PD1; no invented capacitors; reservation not startup.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson05-refresh-figure3.png', 'alt': 'مدل محاسبهٔ پایگاه زمان HAL', 'caption': 'مدل تألیفی SysTick در HCLK اسمی 8 MHz: برای رخداد اسمی 1 ms تعداد 8000 کلاک لازم است و LOAD برابر 7999 محاسبه می\u200cشود. تأخیر وقفه و توقف دیباگ می\u200cتواند زمان نرم\u200cافزاری را از زمان بیرونی جدا کند؛ مقدار رجیستر در سخت\u200cافزار خوانده نشده است.', 'purpose': 'مدل محاسبهٔ پایگاه زمان HAL', 'placement': 'در بخش «منبع پایگاه زمان (Timebase) در فریم\u200cورک HAL»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device logical pins'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical crystal and board circuit facts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a in CubeF3V1.11.6', 'scope': 'Actual source behavior; fresh template source separately audited'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Nominal8000clocks/LOAD7999; handler increments uwTick at default1ms, not measured jitter or exact delay.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson05-refresh-figure4.png', 'alt': 'مقایسهٔ ساختاری HAL و LL', 'caption': 'نمودار تألیفی دو مسیر دسترسی نرم\u200cافزاری به پریفرال. پروژهٔ تحویلی از HAL استفاده می\u200cکند؛ مسیر LL مقایسهٔ مفهومی است و برتری قطعی سرعت یا حجم و قابلیت انتقال بی\u200cقیدوشرط ادعا نشده است.', 'purpose': 'مقایسهٔ ساختاری HAL و LL', 'placement': 'در بخش «مقایسه و راهبرد انتخاب درایور: لایهٔ HAL در برابر LL»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device logical pins'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical crystal and board circuit facts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a in CubeF3V1.11.6', 'scope': 'Actual source behavior; fresh template source separately audited'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'HAL handles/state versus LL register-oriented inline functions; no OOP assertion, benchmark or universal portability.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson05-refresh-figure5.png', 'alt': 'بلوک\u200cهای USER CODE و فایل\u200cهای ماژولار', 'caption': 'نمودار تألیفی تفکیک فایل\u200cها و مرزهای مفهومی USER CODE. کد کاربر باید در ناحیهٔ نام\u200cدار مناسب نوشته شود؛ تنظیم حفظ کد جای پشتیبان\u200cگیری و بررسی تغییرات را نمی\u200cگیرد.', 'purpose': 'بلوک\u200cهای USER CODE و فایل\u200cهای ماژولار', 'placement': 'در بخش «گزینه\u200cهای تولید کد (Code Generation) و سازمان\u200cدهی پروژه»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device logical pins'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical crystal and board circuit facts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a in CubeF3V1.11.6', 'scope': 'Actual source behavior; fresh template source separately audited'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Protected regions and actual separate gpio.c/header; not universal guaranteed preservation.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson05-refresh-figure6.png', 'alt': 'مرزبندی فایل\u200cهای پروژه در کنترل نسخه', 'caption': 'نمودار تألیفی فایل\u200cهای ماندگار پیکربندی، منبع، لینک و مجوزها در برابر کش ساخت و فایل\u200cهای میانی. خروجی نهایی می\u200cتواند آگاهانه در انتشار جداگانه نگهداری شود؛ شکل حذف همهٔ ELFها از همهٔ گردش\u200cکارها را تجویز نمی\u200cکند.', 'purpose': 'مرزبندی فایل\u200cهای پروژه در کنترل نسخه', 'placement': 'در بخش «مدیریت فایل .ioc و ساختار کنترل نسخه با Git»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device logical pins'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical crystal and board circuit facts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a in CubeF3V1.11.6', 'scope': 'Actual source behavior; fresh template source separately audited'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Preserve essential config/startup/linker/licenses; ignore temporary files, intentional release artifacts separately.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

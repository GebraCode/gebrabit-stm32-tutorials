"""Source/manifest/arithmetic checks only. A real clean C build has a separate report."""
from pathlib import Path
import json,zipfile,hashlib
P=Path(__file__).resolve().parent;checks=[]
def check(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
f=json.loads((P/'toolchain-and-validation-v2.json').read_text(encoding='utf-8'))
z=zipfile.ZipFile(P/'lesson-05-project-v2.zip')
src={n.split('/',1)[1]:z.read(n) for n in z.namelist() if not n.endswith('/')}
m=json.loads((P/'source-manifest-v2.json').read_text())
check('ZIP CRC',z.testzip() is None)
check('all 85 source file hashes',len(src)==85 and all(hashlib.sha256(src[k]).hexdigest()==v for k,v in m.items()))
ioc=next(v.decode() for k,v in src.items() if k.endswith('.ioc'));main=src['Core/Src/main.c'].decode()
check('exact CPN and package','Mcu.CPN=STM32F303CBT6' in ioc and 'Mcu.Package=LQFP48' in ioc)
check('SWD pins reserved','PA13.Signal=SYS_JTMS-SWDIO' in ioc and 'PA14.Signal=SYS_JTCK-SWCLK' in ioc)
check('both crystal modes reserved','HSE-External-Oscillator' in ioc and 'LSE-External-Oscillator' in ioc)
check('HSI only initializer','OscillatorType = RCC_OSCILLATORTYPE_HSI;' in main and 'SYSCLKSource = RCC_SYSCLKSOURCE_HSI;' in main and 'RCC_HSE_ON' not in main and 'RCC_LSE_ON' not in main)
check('PLL not selected','PLLState = RCC_PLL_NONE;' in main)
check('timebase formula actually present','SystemCoreClock / (1000U / uwTickFreq)' in src['Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.c'].decode())
check('generated handler increments software tick','HAL_IncTick();' in src['Core/Src/stm32f3xx_it.c'].decode())
check('fixed package and USER CODE preservation','ProjectManager.LastFirmware=false' in ioc and 'ProjectManager.KeepUserCode=true' in ioc)
def model(hclk,tick_hz):
 if type(hclk)is not int or type(tick_hz)is not int or hclk<=0 or tick_hz<=0:raise ValueError('positive integers required')
 count=hclk//tick_hz
 if not 1<=count<=0x1000000:raise ValueError('24bit reload cannot represent this count')
 return {'hclk_hz':hclk,'requested_tick_hz':tick_hz,'input_count':count,'LOAD_expected':count-1,'modeled_period_s':count/hclk,'requested_rate_exact':hclk%tick_hz==0}
r=model(f['hclk_hz'],1000)
check('8000 clock counts',r['input_count']==8000)
check('LOAD is count minus one',r['LOAD_expected']==7999)
check('1ms model only',r['modeled_period_s']==0.001)
check('wrong LOAD8000 is 8001counts',(8000+1)/8000000!=0.001)
check('24bit maximum representable',model(0x1000000,1)['LOAD_expected']==0xFFFFFF)
check('noninteger division explicitly marked',not model(8000001,1000)['requested_rate_exact'])
for args in [(0,1000),(1,0),(1,1000),(0x1000001,1),(-8,1)]:
 try:model(*args)
 except ValueError:checks.append('reject invalid or unrepresentable '+str(args))
 else:raise AssertionError(args)
b=f['ram_breakdown'];check('RAM section correction',b['data_bytes']==12 and b['bss_objects_bytes']==32 and b['alignment_bytes']==4 and b['heap_stack_section_bytes']==1540 and 12+32+4+512+1024==1584)
report={'kind':'source plus arithmetic model; not register observation, C compilation or board test','checks_passed':len(checks),'checks':checks,'timebase':r,'RAM_breakdown':b,'limitations':'HSI nominal; no measured oscillator/tick. Minimum heap/stack reservations are not runtime peak measurements. Fresh clean C build evidence is a separate report.'}
(P/'timebase-results-v2.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))

"""Reproduce expected SysTick arithmetic. Does not access or test a board."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
facts=json.loads((root/'toolchain-and-validation.json').read_text(encoding='utf8'))
hclk=facts['hclk_hz']
tick_hz=1000
assert hclk % tick_hz == 0
ticks_per_interrupt=hclk//tick_hz
reload=ticks_per_interrupt-1
assert reload <= 0xFFFFFF
result={'hclk_hz':hclk,'tick_hz':tick_hz,'ticks_per_interrupt':ticks_per_interrupt,'systick_reload_expected':reload,'period_seconds_expected':ticks_per_interrupt/hclk,'validation':'arithmetic only, not a register measurement or board test'}
(root/'timebase-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))

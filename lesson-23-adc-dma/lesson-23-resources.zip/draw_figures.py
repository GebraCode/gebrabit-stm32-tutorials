"""Six original course teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson{LESSON}-course-figure{n}.png',optimize=True)

LESSON=23

def figure1():
    im,d=begin('Three ways to move ADC results','Data paths explain CPU work; no fixed CPU-use percentages')
    for y,title,middle,c in [(300,'POLLING: foreground waits / reads','CPU',TEAL),(720,'INTERRUPT: per-conversion service','CPU ISR',ORANGE),(1140,'DMA: bus engine moves data','DMA1',TEAL)]:
        tx(d,65,y,title,44,c,True)
        for x,w,label in [(65,250,'ADC1_DR'),(485,250,middle),(905,230,'SRAM')]:panel(d,x,y+120,w,140,label,())
        arrow(d,[(335,y+190),(465,y+190)],c);arrow(d,[(755,y+190),(885,y+190)],c)
    para(d,65,1460,'DMA still needs setup, buffer checks, interrupt handling and processing. Polling does not imply 100% CPU in every application.',1070,42,ORANGE)
    foot(d,'No measured CPU load or maximum rate is plotted.');save(im,1)

def figure2():
    im,d=begin('Timer-triggered ADC data reaches SRAM','Actual TIM3 -> ADC1 -> DMA1 Channel1 path')
    steps=[('TIM3 update -> TRGO','PSC 71, ARR 99 -> nominal 10k triggers/s'),('ADC1 / PA1 / IN2','181.5 sample +12.5 SAR cycles at 18 MHz'),('DMA1 Channel1','Halfword both sides; Circular 128 x uint16'),('Main SRAM buffer','128 samples; ADC repeat requests enabled')]
    for k,(a,b) in enumerate(steps):
        y=255+k*250;panel(d,70,y,1060,185,a,[b])
        if k<3:arrow(d,[(600,y+200),(600,y+235)])
    tx(d,65,1305,'One 100 us trigger interval (nominal)',44,b=True)
    d.line((140,1470,1100,1470),fill=INK,width=4)
    d.rectangle((140,1385,244,1455),fill=TEAL)
    tx(d,300,1385,'Conversion about 10.7778 us',42,TEAL,True)
    tx(d,130,1510,'0',38);tx(d,970,1510,'100 us',38)
    foot(d,'Start ADC DMA before starting the timer triggers.');save(im,2)

def figure3():
    im,d=begin('A completed half has a limited lifetime','128 samples,64 per half | DMA keeps running during CPU delays')
    panel(d,65,275,520,185,'Half 0: 0..63',['64 uint16 values'])
    panel(d,615,275,520,185,'Half 1: 64..127',['64 uint16 values'],ORANGE)
    x=lambda ms:170+ms*70
    tx(d,65,600,'DMA write target',46,b=True)
    for a,b,label,c in [(0,6.4,'Half 0',TEAL),(6.4,12.8,'Half 1',ORANGE)]:
        d.rectangle((x(a),740,x(b),865),fill=c);tx(d,x(a)+90,775,label,46,'white',True)
    for t in [0,6.4,12.8]:
        dashed(d,x(t),690,x(t),1210,MUTED,3);tx(d,x(t)-18,915,str(t),40)
    arrow(d,[(x(6.4),1100),(x(12.8),1100)],TEAL,5)
    tx(d,65,1220,'Half 0 must be copied before DMA reuses it.',45,TEAL,True)
    tx(d,65,1330,'Maximum window: 6.4 ms from hardware completion.',43,b=True)
    para(d,65,1440,'IRQ latency uses part of the window. A callback does not restart the deadline.',1070,43,ORANGE)
    foot(d,'Timing model, not hardware double buffering.');save(im,3)

def figure4():
    im,d=begin('Sample, half-event and buffer rates differ','A shared nominal 12.8 ms window; marker edges are not wave cycles')
    x=lambda ms:165+ms*70
    for top,title in [(300,'ADC samples:10000 /s'),(730,'HT + TC half-events:156.25 /s'),(1160,'Full buffer boundaries:78.125 /s')]:
        tx(d,65,top,title,45,TEAL,True);d.line((x(0),top+200,x(12.8),top+200),fill=INK,width=3)
    for i in range(1,129):d.line((x(i*.1),430,x(i*.1),500),fill=TEAL,width=3)
    for t in [0,6.4,12.8]:tx(d,x(t)-15,540,str(t),38)
    tx(d,850,625,'Time (ms)',40,b=True)
    for t,a in [(6.4,'HT'),(12.8,'TC')]:
        arrow(d,[(x(t),850),(x(t),930)],ORANGE,5);tx(d,x(t)-30,975,a,42,ORANGE,True)
    arrow(d,[(x(12.8),1280),(x(12.8),1360)],TEAL,5)
    tx(d,65,1450,'10000 /64 =156.25; 10000 /128 =78.125',43,b=True)
    tx(d,65,1550,'PB7 toggles per half-event: full wave is 78.125 Hz.',42)
    foot(d,'Rates are nominal calculations, not measured throughput.');save(im,4)

def figure5():
    im,d=begin('Copy only after checking DMA ownership','Actual guards use sequence + NDTR + DWT, not a flag alone')
    stages=[('ISR publishes completed half + sequence','Main expects exactly one pending half.'),('Check DMA position (NDTR)','The chosen half must currently be inactive.'),('Copy 64 values to owned SRAM','Measure copy interval with DWT.'),('Recheck before accepting data','Sequence + NDTR + remaining-time budget must agree.'),('Guard fails -> stop and discard','Stop TIM3, then ADC DMA. No auto-restart.')]
    for k,(a,b) in enumerate(stages):
        y=245+k*255;panel(d,75,y,1050,190,a,[b],RED if k==4 else TEAL)
        if k<4:arrow(d,[(600,y+202),(600,y+240)])
    tx(d,65,1535,'Pass: process owned copy. Fail: stop and discard.',42,TEAL,True)
    foot(d,'Guards reject unsafe copies; no blanket lossless proof.');save(im,5)

def figure6():
    im,d=begin('Two marker edges make one full waveform','PB7 model for DMA half callbacks | No scope capture')
    x=lambda ms:165+ms*35
    wave(d,[(0,0),(6.4,1),(12.8,0),(19.2,1),(25.6,0)],x,425,660)
    for t in [0,6.4,12.8,19.2,25.6]:
        dashed(d,x(t),350,x(t),730,LINE,3);tx(d,x(t)-25,780,str(t),39)
    tx(d,880,880,'Time (ms)',42,b=True)
    tx(d,65,1000,'Toggle every 6.4 ms -> period 12.8 ms ->78.125 Hz',44,TEAL,True)
    panel(d,70,1160,1060,275,'Ideal 10-second prediction',['100000 samples','781 full buffers +32 remaining samples','Hardware timing still needs checking.'])
    tx(d,65,1540,'Prediction is not a 10-second hardware result.',43,ORANGE,True)
    foot(d,'The separate ADC-IT variant has a different marker rate.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson23-course-figure1.png', 'alt': 'سه مسیر دریافت ADC', 'caption': 'نمودار تألیفی Polling و وقفه و DMA؛ هیچ بار ثابت 100% برای Polling یا CPU صفر برای DMA ادعا نشده است. پیکربندی و سرویس وقفه و پردازش بافر همچنان کار دارند.', 'purpose': 'سه مسیر دریافت ADC چگونه تفسیر می\u200cشود؟', 'placement': "در بخش 'مقایسه سه الگوی دریافت داده در ADC' پس از شرح معایب روش وقفه در فرکانس\u200cهای بالا", 'type': 'original explanatory diagram / synthetic model', 'source': 'Original Codex geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision', 'scope': 'ADC triggers and DMA'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955a'}], 'rights': 'Original drawing; no official layout copied or assumed CC license', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Polling/IT/DMA paths; no fixed CPU percentage.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 2, 'filename': 'lesson23-course-figure2.png', 'alt': 'زنجیرهٔ TIM3 تا SRAM', 'caption': 'نمودار تألیفی پروژه: TIM3 با PSC=71 و ARR=99 تریگر 10k/s می\u200cسازد؛ ADC1/PA1/IN2 در 18 MHz با 181.5+12.5 سیکل تبدیل می\u200cشود. DMA1 Channel1 با Halfword دوطرفه به Circular 128 می\u200cنویسد. ADC DMA پیش از تایمر شروع می\u200cشود.', 'purpose': 'زنجیرهٔ TIM3 تا SRAM چگونه تفسیر می\u200cشود؟', 'placement': "در بخش 'تحریک سخت\u200cافزاری با تایمر' پیش از ورود به محاسبات PSC و ARR", 'type': 'original explanatory diagram / synthetic model', 'source': 'Original Codex geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision', 'scope': 'ADC triggers and DMA'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955a'}], 'rights': 'Original drawing; no official layout copied or assumed CC license', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'TIM3TRGO10k;ADC1Ts181.5+12.5@18M;DMA1Ch1halfwordCircular 128;startADCbeforetimer.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 3, 'filename': 'lesson23-course-figure3.png', 'alt': 'مهلت محدود نیم\u200cبافر', 'caption': 'مدل تألیفی دو نیمهٔ 64 نمونه\u200cای؛ 6.4 ms حداکثر زمان از تکمیل سخت\u200cافزاری تا بازاستفاده است. تأخیر IRQ از مهلت باقی\u200cمانده کم می\u200cکند؛ callback فرصت تازهٔ 6.4 ms نمی\u200cدهد و این روش Double Buffer سخت\u200cافزاری نیست.', 'purpose': 'مهلت محدود نیم\u200cبافر چگونه تفسیر می\u200cشود؟', 'placement': "در بخش 'پردازش بافر چرخشی و تکنیک Ping-Pong' پس از معرفی توابع Callback", 'type': 'original explanatory diagram / synthetic model', 'source': 'Original Codex geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision', 'scope': 'ADC triggers and DMA'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955a'}], 'rights': 'Original drawing; no official layout copied or assumed CC license', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Half64 deadline6.4 ms fromhardwarecompletion,remaininglessafterlatency.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 4, 'filename': 'lesson23-course-figure4.png', 'alt': 'سه نرخ متفاوت', 'caption': 'مدل محاسباتی: 10000 نمونه/s، هرکدام از HT و TC به\u200cتنهایی 78.125/s، مجموع HT+TC برابر156.25/s و چرخهٔ بافر78.125/s است. این مقادیر اندازه\u200cگیری throughput نیستند.', 'purpose': 'سه نرخ متفاوت چگونه تفسیر می\u200cشود؟', 'placement': "در انتهای بخش مقایسه الگوها ذیل عنوان 'تفکیک سه نرخ فرکانسی مستقل'", 'type': 'original explanatory diagram / synthetic model', 'source': 'Original Codex geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision', 'scope': 'ADC triggers and DMA'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955a'}], 'rights': 'Original drawing; no official layout copied or assumed CC license', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'fs10000;HT78.125;TC78.125;combined156.25;full78.125.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 5, 'filename': 'lesson23-course-figure5.png', 'alt': 'بررسی مالکیت پیش و پس از کپی', 'caption': 'فلوچارت تألیفی کد واقعی: توالی و NDTR پیش از کپی، زمان کپی با DWT و توالی و NDTR پس از کپی بررسی می\u200cشوند. شکست guard، کپی را دور می\u200cریزد و TIM3 سپس ADC DMA را متوقف می\u200cکند؛ بازیابی خودکار یا تشخیص همهٔ افت\u200cها ادعا نشده است.', 'purpose': 'بررسی مالکیت پیش و پس از کپی چگونه تفسیر می\u200cشود؟', 'placement': "در بخش پردازش بافر چرخشی ذیل 'پروتکل انتقال امن داده از وقفه به حلقه اصلی'", 'type': 'original explanatory diagram / synthetic model', 'source': 'Original Codex geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision', 'scope': 'ADC triggers and DMA'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955a'}], 'rights': 'Original drawing; no official layout copied or assumed CC license', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'seq-consumed==1;NDTRinactivehalf;copy64;DWT<(transfers_to_boundary-1)*7200;recheckseqNDTR;failStopTIM3thenADC_DMA,NORESTART.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 6, 'filename': 'lesson23-course-figure6.png', 'alt': 'نشانگر و پیش\u200cبینی شمارش', 'caption': 'شکل موج مدل Toggle هر6.4 ms، دورهٔ12.8 ms و فرکانس78.125 Hz می\u200cدهد. پیش\u200cبینی ایدئال10s برابر100000 نمونه،781 بافر کامل و32 نمونهٔ باقی\u200cمانده است؛ شکل موج و شمارش روی برد ثبت نشده\u200cاند.', 'purpose': 'نشانگر و پیش\u200cبینی شمارش چگونه تفسیر می\u200cشود؟', 'placement': "در بخش 'پایداری زمانی، تشخیص خطاها و آزمایش\u200cهای عملی' ذیل تشریح آزمایش اول", 'type': 'original explanatory diagram / synthetic model', 'source': 'Original Codex geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision', 'scope': 'ADC triggers and DMA'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955a'}], 'rights': 'Original drawing; no official layout copied or assumed CC license', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'PB7HTTCtoggle6.4 ms=>wave78.125 Hz;10s ideal100000=781x128+32;ITvariantdifferent.', 'status': 'prepared-awaiting-final-visual-review'}]
if __name__=='__main__':run()

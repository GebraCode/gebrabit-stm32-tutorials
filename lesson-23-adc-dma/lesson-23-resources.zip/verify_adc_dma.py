"""Ideal timing and ownership-guard models; no physical ADC samples."""
import json
checks={}
def test(name,condition):checks[name]=bool(condition);assert condition,name
def inactive(half,n):return 0<n<=128 and (n<=64 if half==0 else n>64)
test('TIM3_10kHz',72_000_000/(71+1)/(99+1)==10000)
test('half_budget_6p4ms',64/10000==0.0064)
test('ADC_conversion_fits',194/18_000_000<1/10000)
test('half0_safe_while_half1_active',inactive(0,64) and inactive(0,1))
test('half0_unsafe_while_half0_active',not inactive(0,128) and not inactive(0,65))
test('half1_safe_while_half0_active',inactive(1,128) and inactive(1,65))
test('half1_unsafe_while_half1_active',not inactive(1,64) and not inactive(1,1))
test('zero_counter_rejected',not inactive(0,0) and not inactive(1,0))
test('backlog_sequence_rejected',(3-0)!=1)
test('copy_deadline_rejected',7200 >= (2-1)*7200)
test('unsigned_sequence_wrap',((0-0xffffffff)&0xffffffff)==1)
test('fullbuffer_count',100000//128==781 and 100000%128==32)
test('PB7_toggle_frequency',1/(2*0.0064)==78.125)
test('IT_PB7_frequency',10000/2==5000)
test('UART_raw16bit_too_fast_115200',10000*2*10>115200)
print(json.dumps({'checks':checks,'passed_checks':len(checks),'model_only':True,'sample_rate_sps':10000,'conversion_us':194/18,'half_budget_ms':6.4,'full_buffer_ms':12.8,'fullbuffers_in_exact10s':781.25,'PB7_DMA_waveform_hz':78.125,'PB7_IT_waveform_hz':5000,'adc_buffer_bytes':256,'private_copy_bytes':128,'raw16bit_UART_required_baud_8N1':200000,'measured_values':None},indent=2))

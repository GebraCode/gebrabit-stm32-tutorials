"""Hardware-rate/budget arithmetic only. No ADC/UART/reset measurement."""
from fractions import Fraction
import json
adc_hz=72000000//4
adc_cycles=Fraction(363,2)+Fraction(25,2)
assert adc_cycles==194
assert 8*5*4==160
assert 5*10+4+2==56
assert Fraction(64*(624+1),40000)==1
assert Fraction(64*(624+1),50000)==Fraction(4,5)
assert (5-1)*10==40
result={"ADC_Hz":adc_hz,"ADC_sample_plus_convert_cycles":int(adc_cycles),"ADC_nominal_conversion_us":float(adc_cycles/adc_hz*1000000),"log_queue_payload_bytes":160,"generic_five_uint32_CSV_max_bytes":56,"TX_buffer_bytes":96,"56byte_115200_8N1_wire_ms":float(Fraction(56*10*1000,115200)),"IWDG_seconds_by_assumed_LSI_Hz":{str(f):float(Fraction(64*625,f)) for f in [30000,40000,50000]},"health_window_ms":600,"five_samples_at10ms_first_to_last_span_ms":40,"raw_ADC_codes_and_calculated_mV_assuming3300mV":{str(raw):(raw*3300+2047)//4095 for raw in [0,1,2048,4094,4095]},"note":"Periods are task-relative delays plus execution. Sample qualification is 5 readings, not guaranteed50ms. Actual LSI/VDDA/ADC settling/IRQ latency need measurement; progress flags do not prove all semantic correctness."}
print(json.dumps(result,indent=2))

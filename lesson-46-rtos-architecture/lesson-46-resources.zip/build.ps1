param([Parameter(Mandatory=$true)][string]$ProjectDirectory)
$ErrorActionPreference='Stop'
Push-Location -LiteralPath $ProjectDirectory
try {
  & cmake --preset Debug
  if ($LASTEXITCODE -ne 0) { throw 'Configure failed' }
  & cmake --build --preset Debug --clean-first
  if ($LASTEXITCODE -ne 0) { throw 'Compile failed' }
} finally { Pop-Location }

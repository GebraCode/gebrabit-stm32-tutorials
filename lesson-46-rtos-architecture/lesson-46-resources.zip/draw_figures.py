"""Original educational diagrams, not GUI/instrument captures. Requires Pillow.
Run from a lesson public folder with argument45 or46. Relative outputs.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math,sys
P=Path(__file__).resolve().parent;W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e';LINE='#ccdbe3';BG='#f5f8fa';WHITE='#ffffff'
def font(n=44,b=False):
 for f in [f'C:/Windows/Fonts/segoeui{"b" if b else ""}.ttf',f'/usr/share/fonts/truetype/dejavu/DejaVuSans{"-Bold" if b else ""}.ttf']:
  if Path(f).exists():return ImageFont.truetype(f,n)
 raise FileNotFoundError('Install Segoe UI or DejaVu Sans.')
def text(d,x,y,s,n=44,c=INK,b=False):
 assert s.isascii(),s
 z=d.textbbox((x,y),s,font=font(n,b));assert z[2]<=W-25 and z[3]<=H-15,(s,z)
 d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,w=1040,n=44,c=INK,b=False):
 line='';lines=[]
 for word in s.split():
  q=(line+' '+word).strip()
  if line and d.textlength(q,font=font(n,b))>w:lines.append(line);line=word
  else:line=q
 if line:lines.append(line)
 for s in lines:text(d,x,y,s,n,c,b);y+=n+12
 return y
def start(title,sub):
 im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
 y=para(d,65,35,title,1070,55,INK,True);y=para(d,65,y+10,sub,1070,40,MUTED)
 assert y<245,(title,y)
 d.line((65,250,1135,250),fill=LINE,width=3);return im,d
def foot(d,s='Original conceptual diagram; no hardware measurement supplied.'):
 d.line((65,1640,1135,1640),fill=LINE,width=3);para(d,65,1660,s,1070,37,MUTED)
def box(d,x,y,w,h,title,lines=(),c=TEAL,n=43):
 d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=c,width=4)
 yy=para(d,x+22,y+15,title,w-44,n,c,True)
 for s in lines:yy=para(d,x+22,yy+9,s,w-44,n-2)
 assert yy<=y+h-10,(title,yy,y+h)
def arrow(d,x,y,x2,y2,c=TEAL):
 d.line((x,y,x2,y2),fill=c,width=7);a=math.atan2(y2-y,x2-x)
 d.polygon([(x2,y2),(x2-24*math.cos(a-.5),y2-24*math.sin(a-.5)),(x2-24*math.cos(a+.5),y2-24*math.sin(a+.5))],fill=c)
def flows(title,sub,rows,footer='Original control-flow diagram; no execution or timing measurement.'):
 im,d=start(title,sub);count=len(rows);height={4:250,5:220,6:185}[count];gap={4:80,5:45,6:35}[count]
 for i,(t,lines) in enumerate(rows):
  y=290+i*(height+gap);box(d,80,y,1040,height,t,lines,n=41)
  if i<count-1:arrow(d,600,y+height+5,600,y+height+gap-8)
 foot(d,footer);return im
def fig45_1():
 im,d=start('Sleep is not Stop','The stock Cortex-M4F tickless port uses shallow Sleep.')
 box(d,80,300,1040,470,'Sleep: the core waits',['CPU instructions pause during WFI.','Enabled peripheral clocks and SysTick can keep running.','TIM2 keeps counting; SRAM/CCM contents are retained.','An interrupt can end the wait.'],n=43)
 box(d,80,890,1040,470,'Stop: the main clocks stop',['HSE and PLL stop; SysTick and TIM2 stop.','SRAM/CCM are retained; enabled LSE/RTC can run.','A valid wake event is needed; wake uses HSI.','Software restores the 72 MHz clock configuration.'],c=ORANGE,n=43)
 box(d,80,1450,1040,150,'Two distinct builds in this lesson',['Stock Sleep: config 1. Custom RTC Stop: config 2.'],n=41)
 foot(d,'Board LED, regulator, debug probe and external loads affect current.');return im
def fig45_2():
 return flows('Stock tickless Sleep','Native port V11.2.0, configUSE_TICKLESS_IDLE = 1.',[
 ('1. Idle predicts a quiet interval',['Only Idle is Ready; confirm sleep is still allowed.']),
 ('2. Reprogram the SysTick reload',['24-bit limit: at 72 MHz /1000 Hz, at most 233 ticks.']),
 ('3. PRE hook suppresses HAL TIM6 IRQ',['Otherwise the HAL 1 ms interrupt would keep waking the CPU.']),
 ('4. WFI: wait for an interrupt',['SysTick or an earlier external event can end Sleep.']),
 ('5. Restore normal tick operation',['Port corrects RTOS ticks/partial phase. POST hook approximately compensates HAL time using TIM2.'])])
def fig45_3():
 return flows('Custom RTC-assisted Stop','Experimental user port, configUSE_TICKLESS_IDLE = 2.',[
 ('1. Confirm sleep, then freeze SysTick',['Under PRIMASK, stop the counter then recheck the pending tick. If pending, restore its phase and abort.']),
 ('2. Preserve time, then enter Stop',['Save SysTick phase and RTC timestamp; suspend HAL tick, arm RTC wake, then WFI.']),
 ('3. Wake on HSI; restore HSE + PLL',['Bounded register polling restores 72 MHz. Flash latency 2WS is retained.']),
 ('4. Convert elapsed RTC cycles to ticks',['Safe vTaskStepTick portion; late ticks are pended for normal scheduler processing.']),
 ('5. Resume counters and interrupts',['Restore partial SysTick phase; compensate HAL time approximately. Quantization and overhead remain.'])], 'Custom path is compiled, not hardware-validated production support.')
def fig45_4():
 return flows('Observe the task state','Raw project data; debugger RTOS support depends on its version.',[
 ('Task control blocks in kernel RAM',['Two application tasks plus Idle store state, priority, stack and runtime information.']),
 ('uxTaskGetSystemState(array, 4, &total)',['The Monitor task captures raw TaskStatus_t entries. Snapshotting suspends scheduling briefly.']),
 ('Inspect g_task_stats and g_stats_entries',['Names, priorities, states and high-water values are snapshots. Stack words x4 = bytes on this port.']),
 ('Interpret the evidence carefully',['A high-water result is not proof of every future path. Halting the debugger changes timing; no RTOS GUI was tested.'])])
def fig45_5():
 im,d=start('TIM2 runtime statistics','32-bit counter, 1 MHz nominal at the steady 72 MHz clock.')
 box(d,80,300,1040,190,'Clock calculation',['72 MHz / (PSC 71 + 1) = 1 MHz; no timer IRQ.'],n=42)
 arrow(d,600,505,600,565)
 box(d,80,585,1040,240,'At task switches: accumulate counter differences',['Kernel adds the completed running interval to the task. Raw counters are sampled by the Monitor task.'],n=42)
 box(d,80,930,1040,220,'Stock Sleep: TIM2 continues',['Sleep time spent as Idle is included in the Idle counter. Snapshot/ISR overhead still affects interpretation.'],n=42)
 box(d,80,1250,1040,330,'Stop: TIM2 stops',['It does not measure the full wall-clock sleep interval. HSI restoration also changes its count rate temporarily.','Do not label these raw counters as wall-clock CPU-load percentages.'],c=ORANGE,n=42)
 foot(d,'Counter wraps after 4294.967296 s (~71.58 min); no runtime measured.');return im
def fig45_6():
 return flows('What an event trace would add','Concept only: no recorder, trace transport or PC trace was captured here.',[
 ('Kernel / ISR event occurs',['A recorder hook can identify task switches, waits or interrupt entry/exit.']),
 ('Timestamp + event identifier',['Integration must match the kernel, recorder and trace transport configuration.']),
 ('Buffer / transport to an analysis tool',['Examples: SystemView or Tracealyzer. Capacity, dropped events and recorder overhead matter.']),
 ('Reconstruct the event order',['A real capture can explain who ran and why. A task percentage alone cannot show each deadline or event sequence.'])])
def fig46_1():
 im,d=start('Separate roles and dependencies','Actual structure: Services use a driver interface and a pure model.')
 box(d,80,290,1040,210,'Composition: App/Rtos + App/Config',['Create queues/tasks; centralize timing, capacities and health-bit constants.'],n=43)
 arrow(d,600,515,600,570)
 box(d,80,590,1040,250,'Services: Sensor, Logger, Button, Supervisor',['Own task behavior and RTOS calls. Depend on a HAL-free BoardResult / BoardUartEvent interface.'],n=43)
 arrow(d,340,860,340,970);arrow(d,860,860,860,970)
 box(d,65,990,520,300,'Drivers / BSP',['Own ADC, GPIO, UART DMA and IWDG HAL calls. No RTOS includes here.'],n=41)
 box(d,620,990,515,300,'Pure Model',['Scaling, debounce and CSV formatting. No HAL or RTOS dependency.'],n=41)
 box(d,80,1400,1040,200,'UART events return through a registered callback',['Logger registers the ISR callback; the driver forwards completion/error. The service callback notifies its task.'],c=ORANGE,n=40)
 foot(d,'Boundary tests can call the pure Model without MCU peripherals.');return im
def fig46_2():
 return flows('Follow the actual message path','The Supervisor watches health; it is not the ADC/log data controller.',[
 ('Button task: debounce PA3 presses',['Toggle mode; send the latest command with overwrite.']),
 ('Mode queue: 1 x uint32_t',['Sensor reads the latest mode. Rapid changes can merge; this is a deliberate policy.']),
 ('Sensor task: ADC1 PA1 -> SampleMessage',['sequence, tick, raw, millivolts, mode: 20 bytes.']),
 ('Log queue: 8 copied messages',['160 payload bytes. A full queue rejects a new sample and increments g_log_dropped.']),
 ('Logger: sole UART DMA transmitter',['Keep the static 96-byte buffer unchanged until final UART TC or a failure/reset policy.'])])
def fig46_3():
 im,d=start('Supervise progress before feeding','Only the Supervisor task refreshes the IWDG.')
 box(d,80,300,1040,260,'Three task-health bits',['Sensor: successful ADC step. Logger: healthy operation or queue wait. Button: poll/debounce step.'],n=43)
 arrow(d,600,575,600,635)
 box(d,80,655,1040,240,'Wait for ALL bits, up to 600 ms',['Clear the bits when all have arrived. Also check that g_fatal_error is still 0.'],n=43)
 arrow(d,350,915,350,1000);arrow(d,850,915,850,1000)
 box(d,65,1020,520,300,'ALL + no fatal',['Refresh IWDG.','Start a new health window.'],n=42)
 box(d,620,1020,515,300,'Missing / fatal',['Do not refresh.','Hardware watchdog may reset later.'],c=RED,n=42)
 box(d,80,1410,1040,190,'A heartbeat proves limited progress',['It does not prove all data are correct or that a remote UART host received the bytes.'],c=ORANGE,n=40)
 foot(d,'IWDG: 64 x (624+1) / assumed 40 kHz = 1 s nominal, not measured.');return im
def fig46_4():
 im,d=start('Two modes, one debounced button','PA3: released HIGH, pressed LOW. Initial mode is 0.')
 box(d,65,310,440,370,'Fast: mode 0',['Delay after each sample:','100 ms nominal.'],n=43)
 box(d,695,310,440,370,'Slow: mode 1',['Delay after each sample:','500 ms nominal.'],n=43)
 arrow(d,525,430,675,430);text(d,540,365,'press',38,MUTED)
 arrow(d,675,570,525,570);text(d,540,595,'press',38,MUTED)
 box(d,80,800,1040,280,'Qualification: 5 identical samples',['Poll every 10 ms nominal. First-to-last sample span is 40 ms; scheduling adds uncertainty.','A held press produces one mode-change event.'],n=42)
 box(d,80,1190,1040,200,'The mode queue keeps the latest command',['Sensor may apply it on its next loop; there is no guarantee of an immediate mode transition.'],n=42)
 box(d,80,1410,1040,200,'PB6 toggles on completed UART log sends',['No standby state or special steady-LED state is implemented.'],c=ORANGE,n=40)
 foot(d,'Task-relative delay includes execution/wait overhead; not an exact period.');return im
def fig46_5():
 im,d=start('Budget the actual main SRAM','ELF allocation: 14784 of 32768 bytes; categories are not address order.')
 categories=[(12288,TEAL),(956,ORANGE),(1540,RED),(17984,LINE)]
 x=80
 for size,color in categories:
  width=1040*size/32768;d.rectangle((x,350,x+width,530),fill=color);x+=width
 rows=[('12288 B: heap_4 array',['Dynamic task stacks, TCBs and queues live INSIDE it.'],TEAL),('956 B: other static data',['Includes the static 96-byte UART DMA buffer.'],ORANGE),('1540 B: linker heap/stack reserve + alignment',['Minimum reservation, not a measured interrupt-stack peak.'],RED),('17984 B: outside allocated ELF sections',['Not a validated worst-case safety margin. CCM 8192 B is separate and not used for DMA.'],MUTED)]
 for i,(title,lines,c) in enumerate(rows):box(d,80,640+i*240,1040,195,title,lines,c=c,n=41)
 foot(d,'Do not add dynamic task stacks again on top of the heap array.');return im
def fig46_6():
 return flows('Preserve reset evidence at startup','Actual Board_Init captures raw flags; it does not print a reset banner.',[
 ('A service stalls or reports a fatal error',['Example test: set g_test_pause_sensor = 1, then resume.']),
 ('Supervisor stops refreshing IWDG',['Reset is expected only after the hardware timeout. Debug freeze settings can change an experiment.']),
 ('After reset: read RCC->CSR first',['Store the full value in g_reset_flags before clearing it.']),
 ('Clear reset flags with RMVF',['Inspect the saved bits, including IWDGRSTF. Several causes may be indicated together.']),
 ('Restart initialization and normal supervision',['An IWDG flag alone does not identify which software module failed; correlate other evidence.'])])
META={45:[
('نمودار تألیفی مقایسهٔ Sleep و Stop؛ پورت پیش‌فرض Tickless در این درس از Sleep استفاده می‌کند. Stop کلاک‌های اصلی و شمارش SysTick و TIM2 را متوقف می‌کند و به زمان‌سنج مستقل و بازیابی کلاک نیاز دارد.','مقایسهٔ دو حالت Sleep و Stop و نقش کلاک‌ها و حافظه و RTC'),
('نمودار تألیفی مسیر نسخهٔ پیش‌فرض Tickless Sleep؛ پورت SysTick را برای بازهٔ طولانی‌تر تنظیم می‌کند و زمان هسته را پس از بیداری اصلاح می‌کند. قلاب‌های برنامه، وقفهٔ 1 میلی‌ثانیه‌ای TIM6 را هنگام خواب سرکوب و زمان HAL را تقریبی جبران می‌کنند.','مراحل نسخهٔ پیش‌فرض Tickless Sleep با محدودیت 233 تیک SysTick'),
('نمودار تألیفی نسخهٔ سفارشی و آزمایشی Stop؛ زمان RTC و بخش باقی‌ماندهٔ SysTick ثبت می‌شوند. پس از بیداری با HSI، HSE و PLL با انتظار محدود بازیابی می‌شوند؛ تیک‌های کامل و بخش کسری جبران می‌شوند. این مسیر روی برد اعتبارسنجی نشده است.','مراحل مسیر سفارشی Stop با RTC و بازیابی کلاک و جبران تیک‌های RTOS'),
('نمودار تألیفی مشاهدهٔ وظایف از دادهٔ واقعی برنامه؛ Monitor با uxTaskGetSystemState وضعیت‌ها را در آرایه می‌گذارد. شکل، اسکرین‌شات CubeIDE نیست و مقدار حداقل پشته به‌تنهایی تضمین پایداری همهٔ مسیرهای آینده نیست.','مسیر اطلاعات وظایف از TCB تا آرایهٔ TaskStatus و مشاهده در دیباگر'),
('نمودار تألیفی آمار اجرا با TIM2 در نرخ اسمی 1 مگاهرتز؛ شمارنده در Sleep ادامه دارد، اما در Stop متوقف می‌شود و هنگام بازیابی با HSI نرخ متفاوتی دارد. بنابراین آمار این شمارنده در نسخهٔ Stop درصد بار مبتنی بر زمان دیواری نیست.','محاسبهٔ کلاک TIM2 و تفاوت تفسیر آمار اجرا در Sleep و Stop'),
('نمودار تألیفی مفهوم ردیابی رویداد؛ ضبط واقعی به یکپارچه‌سازی ثبت‌کننده، مسیر انتقال و ابزار تحلیل سازگار نیاز دارد. در این پروژه ردگیری یا نمودار اندازه‌گیری‌شده‌ای ثبت نشده است.','ثبت مفهومی زمان و شناسهٔ رویداد و انتقال به ابزار تحلیل مانند SystemView یا Tracealyzer')],46:[
('نمودار تألیفی لایه‌های واقعی پروژه؛ سرویس‌ها از رابط BoardResult و callback ثبت‌شده استفاده می‌کنند و فراخوانی HAL در درایور قرار دارد. مدل خالصِ تبدیل داده، حذف لرزش کلید و قالب‌بندی CSV، وابستگی به HAL یا RTOS ندارد.','لایه‌های راه‌اندازی و پیکربندی و سرویس و درایور و مدل خالص در پروژهٔ RTOS'),
('نمودار تألیفی مسیر پیام‌های پروژه؛ کلید، آخرین فرمان حالت را به Sensor می‌دهد و Sensor رکورد اندازه‌گیری را در صف لاگ می‌گذارد. Logger تنها مالک ارسال UART با DMA است و Supervisor در مسیر کنترل داده قرار ندارد.','مسیر فرمان حالت از کلید به Sensor و رکورد ADC تا صف لاگ و Logger'),
('نمودار تألیفی نظارت بر پیشرفت؛ Supervisor تا 600 میلی‌ثانیه برای همهٔ بیت‌های سلامت منتظر می‌ماند و تنها در نبود خطای نهایی، IWDG را تازه می‌کند. اعلام پیشرفت، صحت کامل داده یا دریافت آن در رایانه را تضمین نمی‌کند.','شرط همهٔ بیت‌های سلامت و نبود خطای نهایی برای تازه‌کردن واچ‌داگ'),
('نمودار تألیفی دو حالت واقعی برنامه؛ هر فشار معتبر PA3 حالت را میان تأخیر 100 و 500 میلی‌ثانیه‌ای پس از نمونه‌برداری جابه‌جا می‌کند. اعتبار فشار به 5 نمونهٔ پیاپی وابسته است، نه تأخیر دقیق و تضمین‌شدهٔ 50 میلی‌ثانیه.','دو حالت سریع و کند با کلید فعال با سطح پایین و حذف لرزش 5 نمونه‌ای'),
('نمودار تألیفی بودجهٔ SRAM اصلی بر اساس ELF نهایی؛ آرایهٔ 12288 بایتی heap_4 از قبل در تخصیص ثابت حساب شده است و پشته‌ها و صف‌های پویا داخل آن ساخته می‌شوند. فضای خارج از بخش‌های تخصیص‌یافته، حاشیهٔ ایمنیِ آزموده‌شده نیست.','بودجهٔ 32768 بایت SRAM با heap_4 و داده‌های ثابت و رزرو پیونددهنده و فضای تخصیص‌نیافته'),
('نمودار تألیفی حفظ شواهد ریست؛ Board_Init ابتدا RCC_CSR را در g_reset_flags ذخیره و سپس پرچم‌ها را پاک می‌کند. پرچم IWDG علت نرم‌افزاری دقیق را نشان نمی‌دهد و چند بیت می‌توانند هم‌زمان ثبت شده باشند؛ پیام راه‌اندازی خودکار چاپ نمی‌شود.','جریان عدم تغذیهٔ واچ‌داگ تا ثبت و تفسیر غیرانحصاری پرچم‌های ریست') ]}
def main(n):
 qa=P.parent/'visual-qa';qa.mkdir(exist_ok=True);meta=[]
 for k in range(1,7):
  im=globals()[f'fig{n}_{k}']();name=f'lesson{n}-figure{k}.png';im.save(P/name,optimize=True)
  for width in [390,600]:im.resize((width,H*width//W),Image.Resampling.LANCZOS).save(qa/f'fig{k}-{width}.png')
  cap,alt=META[n][k-1];meta.append({'id':f'fig{k:02d}','filename':name,'width':W,'height':H,'caption':cap,'alt':alt,'source':('Original diagram based on actual compiled lesson45 source, pinned FreeRTOS V11.2.0 ARM_CM4F port/tasks and STM32F3 HAL source.' if n==45 else 'Original diagram based on actual compiled lesson46 source, final ELF allocation, pinned FreeRTOS V11.2.0 and STM32F3 HAL source.'),'license':'Original diagram and drawing code by GEBRA ENG, CC BY 4.0; cited source documents are not copied.','kind':'original conceptual diagram','pixels_reviewed':False})
 (P/'image-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
 for width in [390,600]:
  sheet=Image.new('RGB',(width*3,H*width//W*2),WHITE)
  for k in range(1,7):sheet.paste(Image.open(qa/f'fig{k}-{width}.png'),(((k-1)%3)*width,((k-1)//3)*H*width//W))
  sheet.save(qa/f'contact-sheet-{width}.png')
 print(n,'6 original diagrams ready')
if __name__=='__main__':main(int(sys.argv[1]))

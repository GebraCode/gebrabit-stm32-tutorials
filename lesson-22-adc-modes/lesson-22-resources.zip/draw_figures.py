"""Six original course teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson{LESSON}-course-figure{n}.png',optimize=True)

LESSON=22

def figure1():
    im,d=begin('Channel count and continuity differ','Channel count and conversion continuity are different axes')
    tx(d,300,280,'Single sequence',43,TEAL,True);tx(d,785,280,'Continuous',43,ORANGE,True)
    for xx,yy,title,flow in [(230,450,'One channel','A'),(730,450,'One channel','A -> A -> A'),(230,950,'Scan ranks','A -> B -> R'),(730,950,'Scan ranks','A B R | A B R')]:
        d.rounded_rectangle((xx,yy,xx+430,yy+350),20,fill=WHITE,outline=LINE,width=4)
        tx(d,xx+25,yy+35,title,43,TEAL,True)
        para(d,xx+25,yy+150,flow,380,44,INK,True)
        arrow(d,[(xx+50,yy+265),(xx+360,yy+265)],ORANGE if xx==730 else TEAL)
    tx(d,65,580,'ONE',39,b=True);tx(d,65,1070,'MANY',39,b=True)
    para(d,65,1430,'Actual examples: controlled one-rank software starts, and a continuous single channel paced by AutoWait.',1070,43)
    foot(d,'This conceptual matrix is not four tested board captures.');save(im,1)

def figure2():
    im,d=begin('Calibrate before starting conversions','Family-specific HAL sequence; no invented startup duration')
    items=[('Internal regulator','HAL applies the required startup handling.'),('ADC disabled','Calibration requires ADEN =0.'),('Single-ended calibration','Start calibration and wait for completion.'),('Enable ADC','Wait for the ready condition.'),('Start a conversion','Then use EOC/EOS or the selected transfer path.')]
    for k,(a,b) in enumerate(items):
        y=245+k*260;panel(d,75,y,1050,185,a,[b]);
        if k<4:arrow(d,[(600,y+200),(600,y+245)])
    foot(d,'Use the pinned F3 HAL; no arbitrary 10 us delay substituted.');save(im,2)

def figure3():
    im,d=begin('A higher source resistance slows settling','Assumed normalized RC curves; not F303 resistor/capacitor values')
    x=lambda t:180+t*105;y=lambda v:1100-v*560
    tx(d,65,285,'Capacitor fraction of final voltage',45,b=True)
    d.line((180,420,180,1150,1120,1150),fill=INK,width=4)
    for v in [0,.5,1]:tx(d,65,y(v)-23,str(v),38)
    for tau,c in [(1,TEAL),(4,ORANGE)]:
        d.line([(x(i/100),y(1-math.exp(-i/100/tau))) for i in range(801)],fill=c,width=7)
    xx=x(4);dashed(d,xx,420,xx,1190,RED,4)
    tx(d,440,340,'Assumed sample window ends here',42,RED,True)
    for t in [0,2,4,6,8]:tx(d,x(t)-10,1195,str(t),38)
    tx(d,740,1290,'Time / tau_ref',41,b=True)
    tx(d,65,1400,'Teal: tau =1; orange: tau =4 (model units)',43,b=True)
    tx(d,65,1510,'Do not infer actual R_ADC or C_ADC from these curves.',41,ORANGE)
    foot(d,'Actual sample time 181.5 /18 MHz =10.0833 us.');save(im,3)

def figure4():
    im,d=begin('Three ranks, three controlled software starts','One rank per start | Software gaps are not fixed-rate')
    for k,(rank,channel,flag) in enumerate([(1,'PA1 / IN2','EOC'),(2,'PA2 / IN3','EOC'),(3,'VREFINT / IN18','EOC + EOS')]):
        top=280+k*405;tx(d,65,top,f'Start {rank} -> Rank {rank}: {channel}',45,TEAL,True)
        d.rectangle((160,top+115,780,top+225),fill=TEAL);tx(d,210,top+143,'Sample 181.5 cycles',43,'white',True)
        d.rectangle((795,top+115,1080,top+225),fill=ORANGE);tx(d,825,top+143,'SAR 12.5',42,'white',True)
        tx(d,650,top+275,flag+' -> read DR',43,ORANGE,True)
        if k<2:tx(d,65,top+320,'Software gap before the next start',40,MUTED)
    tx(d,65,1540,'Bar lengths illustrate phases; not clock-exact scale.',41)
    foot(d,'18 MHz ADC clock; result read before next software start.');save(im,4)

def figure5():
    im,d=begin('Controlled starts reduce one overrun hazard','Status checks still matter; no zero-risk guarantee')
    tx(d,65,260,'A: unpaced sequence, CPU reads too late',45,RED,True)
    for k,(x,label) in enumerate([(160,'rank 1'),(540,'rank 2'),(920,'rank 3')]):
        d.rectangle((x,405,x+200,515),fill=TEAL);tx(d,x+30,435,label,42,'white',True)
    arrow(d,[(260,560),(1040,560)],RED,5)
    tx(d,65,660,'Unread result + next completion -> OVR condition',43,RED,True)
    tx(d,65,850,'B: one software start releases one rank',45,TEAL,True)
    for y,a,b in [(990,'Start rank 1','Wait EOC; read DR'),(1210,'Start rank 2','Wait EOC; read DR')]:
        panel(d,70,y,480,150,a,());arrow(d,[(570,y+75),(630,y+75)])
        panel(d,650,y,480,150,b,())
    tx(d,65,1480,'Timeout, invalid flags and software mistakes remain possible.',41,ORANGE)
    foot(d,'Discontinuous control is not an absolute no-OVR proof.');save(im,5)

def figure6():
    im,d=begin('Estimate VDDA with the factory word','Use this exact F303 calibration location, not a guessed address')
    panel(d,70,265,1060,225,'Factory 16-bit calibration word',['VREFINT_CAL_ADDR =0x1FFFF7BA','Factory reference supply: 3300 mV'])
    arrow(d,[(600,510),(600,620)])
    panel(d,70,640,1060,190,'Runtime VREFINT conversion',['Rank 3 / ADC1 channel 18 -> code_vref'])
    arrow(d,[(600,850),(600,960)])
    panel(d,70,980,1060,205,'VDDA_est =3300 mV x cal_word / code_vref',['External voltage endpoint estimate:','code x VDDA_est /4095'])
    para(d,65,1310,'Reject invalid factory words or zero reference readings. Apply the project range checks before publishing an estimate.',1070,43,ORANGE)
    tx(d,65,1535,'Reference correction does not remove all ADC errors.',42,RED,True)
    foot(d,'Factory word is not a fixed example value or live readout.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson22-course-figure1.png', 'alt': 'دو محور مستقل انتخاب حالت ADC', 'caption': 'ماتریس مفهومی تألیفی انتخاب کانال در برابر تداوم تبدیل؛ تعداد کانال\u200cها مستقل از یک\u200cباره یا پیوسته بودن است. پروژه\u200cهای واقعی این درس، توالی سه\u200cرتبه\u200cای Discontinuous با یک تبدیل در هر Start و تک\u200cکانال Continuous با AutoWait هستند؛ تصویر ادعای آزمون چهار ترکیب روی برد ندارد.', 'purpose': 'تعداد کانال و تداوم تبدیل چه تفاوتی دارند؟', 'placement': 'بخش دو انتخاب مستقل در پیکربندی ADC: ماتریس 2×2', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': '2x2single/scanversussingle-sequence/continuousconcept; actualcontrolleddiscontinuous3rankandcontinuoussingleAutoWait,notall4tested;continuousnotfixedfsifpaced.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 2, 'filename': 'lesson22-course-figure2.png', 'alt': 'آماده\u200cسازی و کالیبراسیون ADC خانوادهٔ F3', 'caption': 'توالی تألیفی راه\u200cاندازی رگولاتور و رعایت انتظار لازم توسط HAL، کالیبراسیون با ADEN=0 و سپس فعال\u200cسازی و انتظار Ready. عدد دلخواه 10us جایگزین مسیر واقعی HAL نشده است.', 'purpose': 'چرا کالیبراسیون باید پیش از فعال\u200cشدن ADC انجام شود؟', 'placement': 'بخش تفاوت\u200cهای معماری و الزامات راه\u200cاندازی ADC در میکروکنترلرهای STM32F3', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'RegulatorstartuphandledbyactualHAL;ADEN0duringADC_SINGLE_ENDEDcalibration,waitcompletionthenenable/ready/start. No assumed10usstartup.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 3, 'filename': 'lesson22-course-figure3.png', 'alt': 'اثر مقاومت منبع بر نشست نمونه', 'caption': 'مدل تألیفی دو ثابت زمانی فرضی 1 و 4 برابر مرجع؛ محور زمان نرمال است و خط پایان نمونه\u200cبرداری نیز یک فرض آموزشی است. از این منحنی\u200cها مقدار واقعی مقاومت سوئیچ یا خازن F303 و دقت ولتاژ نتیجه\u200cگیری نمی\u200cشود.', 'purpose': 'برای یک پنجرهٔ نمونه\u200cبرداری، تفاوت ثابت زمانی چه اثری دارد؟', 'placement': 'بخش مدل ذهنی نمونه\u200cبرداری و زمان\u200cبندی مدارهای تبدیل SAR', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'TwoassumednormalizedRCcurves tau1and4 withassumedwindow4tau_ref;noRADC1k/noCADC5-10pFasfacts;actualconfiguredTs181.5@18MHzseparate.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 4, 'filename': 'lesson22-course-figure4.png', 'alt': 'ترتیب EOC و EOS در سه رتبهٔ کنترل\u200cشده', 'caption': 'نمودار تألیفی توالی واقعی PA1/IN2 و PA2/IN3 و VREFINT/IN18؛ هر Start نرم\u200cافزاری تنها یک رتبه را آزاد می\u200cکند و پیش از Start بعدی DR خوانده می\u200cشود. EOC در پایان هر تبدیل و EOS در پایان توالی مطرح است؛ فاصلهٔ نرم\u200cافزاری و نسبت طول نوارها مقیاس دقیق زمان نیست.', 'purpose': 'در توالی کنترل\u200cشده کدام نتیجه به کدام رتبه تعلق دارد؟', 'placement': 'بخش خواندن چندکاناله، همگام\u200cسازی داده و مدیریت رخداد Overrun', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ADC1ranks1PA1IN2,2PA2IN3,3VREFINT18,discontinuouscount1/EOCsingle/all181.5@18MHz;oneSWstartperrankwithSWgaps;EOCeach/EOSlast;notconcurrent.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 5, 'filename': 'lesson22-course-figure5.png', 'alt': 'کاهش خطر جلو افتادن توالی با Discontinuous', 'caption': 'مقایسهٔ تألیفی: توالی بدون سرویس به\u200cموقع می\u200cتواند با نتیجهٔ خوانده\u200cنشده و OVR روبه\u200cرو شود؛ در پروژهٔ کنترل\u200cشده، رتبهٔ بعدی پیش از Start بعدی اجرا نمی\u200cشود. این روش خطر مشخصی را کم می\u200cکند، اما حذف مطلق OVR یا خطا و timeout را تضمین نمی\u200cکند.', 'purpose': 'چرا شروع کنترل\u200cشدهٔ رتبه\u200cها جای ادعای ریسک صفر را نمی\u200cگیرد؟', 'placement': 'بخش خواندن چندکاناله، همگام\u200cسازی داده و مدیریت رخداد Overrun', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'NaivescanunreadDR+nextcompletionOVR;actualone-rankSWstartsreadbeforelaterstart. RemovezeroOVRrisk. ActualOVRmodeandHALstatusstillmatter.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 6, 'filename': 'lesson22-course-figure6.png', 'alt': 'محاسبهٔ تخمینی VDDA از مرجع کارخانه', 'caption': 'نمودار تألیفی آدرس صحیح 16 بیتی VREFINT_CAL_ADDR=0x1FFFF7BA و مرجع کارخانهٔ 3300mV؛ VDDA_est از نسبت cal_word به خواندن VREFINT محاسبه می\u200cشود. مقدار صفر یا نامعتبر و حدود پروژه بررسی می\u200cشوند. این اصلاح همهٔ خطاهای ADC و مرجع و دما را حذف نمی\u200cکند و مقدار کارخانه در شکل خواندن واقعی نمایش داده نشده است.', 'purpose': 'مرجع کارخانه چگونه به تخمین VDDA کمک می\u200cکند و چه محدودیتی باقی می\u200cماند؟', 'placement': 'بخش تبدیل کد دیجیتال به ولتاژ واقعی و جبران خطای تغذیه با VREFINT', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Correctfactory16bit0x1FFFF7BA/cal3300mV;VDDAest3300*factory/runtimevref;guardsfactory1..4095/rawnonzero/estimate2000..3600;endpointVinestimate/4095notperfectinverseorallerrorremoval.', 'status': 'prepared-for-Codex-final-visual-review'}]
if __name__=='__main__':run()

"""ADC rank ordering and VREFINT arithmetic models; no board measurements."""
import json,math
checks=0
def check(value):
 global checks
 assert value
 checks+=1
def corrected(raw,cal):
 if len(raw)!=3 or any(not 0<=x<=4095 for x in raw) or not 1<=cal<=4095 or raw[2]==0:
  raise ValueError('InvalidADC/calibrationcode')
 supply=3300*cal//raw[2]
 if not 2000<=supply<=3600: raise ValueError('VDDAoutsideguardrange')
 return supply,[x*supply//4095 for x in raw[:2]]
# Synthetic factory/runtime data chosen for arithmetic only, not a real device.
supply,volts=corrected([1024,3072,1551],1504)
check(supply==3200)
check(volts==[800,2400])
check([1024*3300//4095,3072*3300//4095]==[825,2475])
for data,cal in [([1,2,0],1504),([1,2,1551],0),([1,2,1551],65535),([4096,2,1551],1504),([1,2,1],1504)]:
 try: corrected(data,cal)
 except ValueError: checks+=1
 else: raise AssertionError('invaliddataaccepted')
rank=0;received=[]
for trigger in range(6):
 received.append(['PA1_IN2','PA2_IN3','VREFINT'][rank]);rank=(rank+1)%3
check(received==['PA1_IN2','PA2_IN3','VREFINT']*2)
check(rank==0)
# A failed partial sequence is not retried by the delivered scan application.
valid=[True,False,True]
check(not all(valid))
adc_clock=72000000/4
sample_us=181.5/adc_clock*1e6
conv_us=(181.5+12.5)/adc_clock*1e6
check(math.isclose(conv_us,10.777777777777779))
check(sample_us>2.2)
check(math.isclose(math.log(2**13),9.010913347279288))
# AutoWait concept: no new completed conversion can overwrite unread DR.
dr_full=False;conversions=0;reads=0
for _ in range(32):
 check(not dr_full)
 dr_full=True;conversions+=1
 # A delayed CPU read stalls further conversion in this conceptual AutoWait model.
 check(dr_full)
 dr_full=False;reads+=1
check(conversions==reads==32)
print(json.dumps({'checks_passed':checks,'hardware':'NOT TESTED',
 'synthetic_calibration_example':{'factory_code':1504,'runtime_VREFINT':1551,'VDDA_mV':supply,'external_mV':volts},
 'halfLSB_RC_settling_time_constants':math.log(2**13),'sample_us':sample_us,'single_conversion_us_nominal':conv_us,
 'three_rank_analog_conversion_time_sum_us':3*conv_us,
 'continuous32_analog_conversion_time_sum_us':32*conv_us,
 'notes':['Sum excludes software gaps and is not measured sequence duration.',
 'AutoWait continuous conversion cadence is paced by DR reads; not a fixed-rate sampling guarantee.',
 'Four conceptual combinations are single/scan crossed with once/continuous; discontinuous is a further scan pacing choice.',
 'VREFINT correction does not remove all ADC noise, offset, INL or sensor error.']},indent=2))

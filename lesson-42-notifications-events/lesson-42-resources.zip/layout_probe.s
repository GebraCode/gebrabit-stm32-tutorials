	.cpu cortex-m4
	.arch armv7e-m
	.fpu fpv4-sp-d16
	.eabi_attribute 27, 1
	.eabi_attribute 28, 1
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"layout_probe.c"
	.text
	.global	semaphore_bytes
	.section	.rodata
	.align	2
	.type	semaphore_bytes, %object
	.size	semaphore_bytes, 4
semaphore_bytes:
	.word	80
	.global	event_group_bytes
	.align	2
	.type	event_group_bytes, %object
	.size	event_group_bytes, 4
event_group_bytes:
	.word	28
	.global	task_control_bytes
	.align	2
	.type	task_control_bytes, %object
	.size	task_control_bytes, 4
task_control_bytes:
	.word	92
	.global	stack_word_bytes
	.align	2
	.type	stack_word_bytes, %object
	.size	stack_word_bytes, 4
stack_word_bytes:
	.word	4
	.global	alignment_bytes
	.align	2
	.type	alignment_bytes, %object
	.size	alignment_bytes, 4
alignment_bytes:
	.word	8
	.ident	"GCC: (Arm GNU Toolchain 13.2.rel1 (Build arm-13.7)) 13.2.1 20231009"

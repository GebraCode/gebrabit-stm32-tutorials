"""Compile current project types and model extra heap_4 semaphore allocation.
Requires arm-none-eabi-gcc on PATH. No target execution or runtime measurement.
"""
from pathlib import Path
import subprocess,json,re
P=Path(__file__).resolve().parent
project=P/'gebrabit_lesson42_notifications'
if not project.is_dir():raise SystemExit('Extract project-and-build.zip beside this script first.')
args=['arm-none-eabi-gcc','-mcpu=cortex-m4','-mthumb','-mfpu=fpv4-sp-d16','-mfloat-abi=hard','-Wall','-Werror','-S',str(P/'layout_probe.c'),'-o',str(P/'local-layout.s')]
for inc in ['App/Rtos','Middlewares/Third_Party/FreeRTOS-Kernel/include','Middlewares/Third_Party/FreeRTOS-Kernel/portable/GCC/ARM_CM4F']:args+=['-I',str(project/inc)]
subprocess.run(args,check=True)
s=(P/'local-layout.s').read_text()
names=['semaphore_bytes','event_group_bytes','task_control_bytes','stack_word_bytes','alignment_bytes']
v={name:int(re.search(r'^'+name+r':\s*\n\s*\.word\s+(\d+)',s,re.M)[1]) for name in names}
# heap_4 BlockLink_t has pointer+size_t on this 32-bit ARM ABI, rounded to alignment.
align=v['alignment_bytes'];header=(2*4+align-1)&~(align-1)
v['heap_4_header_bytes']=header
v['expected_extra_semaphore_heap_allocation']=(v['semaphore_bytes']+header+align-1)&~(align-1)
v['expected_notification_extra_separate_allocation']=0
v['classification']='Compile-time layout and allocator model; NOT hardware measurement'
(P/'local-layout-model.json').write_text(json.dumps(v,indent=2),encoding='utf8');print(json.dumps(v,indent=2))

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"
const unsigned semaphore_bytes = sizeof(StaticSemaphore_t);
const unsigned event_group_bytes = sizeof(StaticEventGroup_t);
const unsigned task_control_bytes = sizeof(StaticTask_t);
const unsigned stack_word_bytes = sizeof(StackType_t);
const unsigned alignment_bytes = portBYTE_ALIGNMENT;

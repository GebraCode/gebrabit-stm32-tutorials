"""Inspect a CSV copied from an actual card. Does not invent sample data."""
import csv,argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('csv_file',type=Path);a=p.parse_args()
with a.csv_file.open(newline='',encoding='ascii') as f:
 rows=list(csv.DictReader(f))
if not rows:raise SystemExit('No data rows.')
samples=[{k:int(r[k]) for k in ['uptime_ms','adc_raw','estimated_mv']} for r in rows]
bad=[i+2 for i,r in enumerate(samples) if not(0<=r['adc_raw']<=4095) or r['estimated_mv']!=(r['adc_raw']*3300+2047)//4095]
intervals=[(samples[i]['uptime_ms']-samples[i-1]['uptime_ms'])&0xFFFFFFFF for i in range(1,len(samples))]
print(json.dumps({'rows':len(rows),'invalid_row_line_numbers':bad,'interval_min_ms':min(intervals) if intervals else None,'interval_max_ms':max(intervals) if intervals else None,'classification':'Analysis of user-supplied actual CSV; estimated_mv assumes VDDA3300mV, not calibrated voltage.'},indent=2))

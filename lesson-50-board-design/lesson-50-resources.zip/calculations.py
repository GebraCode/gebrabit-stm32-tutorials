"""Reproducible hypothetical arithmetic; not board measurements."""
import json
CL_pF=8.0; Cs_pF=3.0
C_pF=2*(CL_pF-Cs_pF)
assert C_pF==10.0 and C_pF/2+Cs_pF==CL_pF
loss_W=(5.0-3.3)*0.1
assert abs(loss_W-0.17)<1e-12
exercise_CL_pF=12.0; exercise_Cs_pF=3.5
exercise_C_pF=2*(exercise_CL_pF-exercise_Cs_pF)
assert exercise_C_pF==17.0
exercise_loss_9V_W=(9.0-3.3)*0.12
exercise_loss_5V_W=(5.0-3.3)*0.12
assert abs(exercise_loss_9V_W-0.684)<1e-12
assert abs(exercise_loss_5V_W-0.204)<1e-12
print(json.dumps({'hypothetical_crystal':{'CL_pF':CL_pF,'Cs_pF':Cs_pF,'C1_C2_pF':C_pF},'LDO_loss_W_excludes_Iq':loss_W,'NRST_ideal_RC_ms':10000*100e-9*1000,'exercise_crystal':{'CL_pF':exercise_CL_pF,'Cs_pF':exercise_Cs_pF,'C1_C2_pF':exercise_C_pF},'exercise_LDO_load_loss_excludes_Iq':{'load_A':0.12,'VIN9V_loss_W':exercise_loss_9V_W,'VIN5V_loss_W':exercise_loss_5V_W},'measurement':False},indent=2))

from pathlib import Path
import sys,json,importlib.util,math
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;P=R;pub=R;qa=R/'visual-qa';qa.mkdir(exist_ok=True)
sp=importlib.util.spec_from_file_location('d',R/'drawing_helpers.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def text(d,x,y,s,w=1020,n=44,c=m.INK,b=False):return m.para(d,x,y,s,w,n,c,b)
def box(d,r,outline=m.TEAL):d.rounded_rectangle(r,18,fill='white',outline=outline,width=4)
def start(title,sub):
 im=Image.new('RGB',(1200,1800),'#f5f8fa');d=ImageDraw.Draw(im);y=text(d,65,35,title,1070,56,m.INK,True);text(d,65,y+12,sub,1070,40,m.MUTED);d.line((65,250,1135,250),fill=m.LINE,width=3);return im,d
meta=[]
def save(im,i,caption,alt,source):
 d=ImageDraw.Draw(im);d.line((65,1640,1135,1640),fill=m.LINE,width=3);text(d,65,1660,'Original educational drawing; no PCB or measurement.',1070,37,m.MUTED)
 name=f'lesson50-figure{i}.png';im.save(pub/name,optimize=True)
 for size in [390,600]:im.resize((size,1800*size//1200),Image.Resampling.LANCZOS).save(qa/f'fig{i}-{size}.png')
 meta.append({'id':f'fig{i:02d}','filename':name,'width':1200,'height':1800,'caption':caption,'alt':alt,'source':source,'license':'Original diagram and drawing code by GEBRA ENG, CC BY 4.0; source drawings are not copied.','kind':'original educational diagram','pixels_reviewed':False})
# 1: logical minimal system, intentionally not a pin-by-pin schematic.
im,d=start('Before drawing the board','STM32F303CBT6 / LQFP48: logical planning map')
for y,title,ls in [(300,'1  Power + analog supply',['3.3 V nominal; connect EVERY supply pin.','Budget current, regulator losses and decoupling.']),(690,'2  Clock + reset + boot',['HSI first bringup; HSE and LSE as required.','Keep NRST and BOOT0 accessible and defined.']),(1080,'3  Debug + application pins',['Reserve PA13 SWDIO / PA14 SWCLK.','Assign ADC, serial and GPIO before PCB routing.'])]:
 m.card(d,y,title,ls,300)
text(d,80,1490,'The companion IOC is a minimal HSI bringup baseline.',1040,43,m.ORANGE)
save(im,1,'نمودار تألیفی برنامه‌ریزی برد: ابتدا تغذیه، کلاک و راه دسترسی SWD را مشخص کنید؛ این شکل، شماتیک کامل یا نقشهٔ PCB نیست.','سه گروه نیازهای برد اختصاصی: تغذیه، راه‌اندازی و پایه‌های کاربردی','DS9118 Figure4; AN4206 sections1–5')
# 2: VDD branch sketch, all capacitor branches go to ground.
im,d=start('3.3 V decoupling: a shunt path','LQFP48: VDD 24 / 36 / 48; VSS 23 / 35 / 47')
text(d,80,290,'One local 100 nF at EACH VDD/VSS pair',1040,45,m.TEAL,True)
d.line((100,460,1100,460),fill=m.TEAL,width=7)
for x,label in [(250,'VDD24'),(590,'VDD36'),(930,'VDD48')]:
 d.line((x,460,x,550),fill=m.INK,width=5);d.line((x-65,550,x+65,550),fill=m.INK,width=7);d.line((x-65,580,x+65,580),fill=m.INK,width=7);d.line((x,580,x,690),fill=m.INK,width=5)
 text(d,x-110,395,label,300,40,m.TEAL,True);text(d,x-105,785,'100 nF',280,42)
 for delta,half in [(0,80),(18,52),(36,25)]:d.line((x-half,690+delta,x+half,690+delta),fill=m.INK,width=5)
text(d,80,880,'Each capacitor returns to the nearest low-impedance ground.',1040,44)
m.card(d,1045,'Digital bulk + analog decoupling',['Reference bulk: 4.7 uF across VDD / VSS.','VDDA reference: 10 nF + 1 uF to VSSA.'],290)
m.card(d,1390,'Do not copy values without context',['GB100ST VDDA: 100 nF + 10 uF after 10 uH.','Check VDDA >= VDD, including power-up transients.'],220,m.ORANGE)
save(im,2,'شماتیک مفهومی تألیفی دکوپلینگ: خازن‌ها بین تغذیه و زمین قرار می‌گیرند. مقادیر مرجع دیتاشیت و مقادیر مشاهده‌شده در GB100ST از یکدیگر جدا شده‌اند.','سه خازن 100 نانوفاراد برای سه جفت تغذیهٔ بستهٔ LQFP48 و توضیح VDDA','DS9118 6.1.6 Figure11 and Figure4; actual GB100ST V2.0 schematic')
# 3: educational external crystal connection; internal amplifier omitted.
im,d=start('Calculate the crystal load','External passive network; internal amplifier omitted')
for x,label in [(230,'OSC_IN'),(970,'OSC_OUT')]:
 text(d,x-130,300,label,320,45,m.TEAL,True);d.ellipse((x-10,425,x+10,445),fill=m.TEAL)
 d.line((x,435,x,590),fill=m.INK,width=5);d.line((x-60,590,x+60,590),fill=m.INK,width=7);d.line((x-60,620,x+60,620),fill=m.INK,width=7);d.line((x,620,x,750),fill=m.INK,width=5);d.line((x-70,750,x+70,750),fill=m.INK,width=5)
 text(d,x-65,785,'C1' if x<500 else 'C2',200,46,m.TEAL,True)
 text(d,x-60,685,'GND',230,40,m.MUTED)
d.line((230,435,470,435),fill=m.INK,width=5);d.line((730,435,970,435),fill=m.INK,width=5)
box(d,(470,380,730,490));text(d,505,390,'Crystal',230,44,m.TEAL,True)
m.card(d,940,'Effective load at the crystal',['CL = C1*C2 / (C1+C2) + Cs','Only if C1 = C2: C = 2*(CL-Cs)'],270)
m.card(d,1290,'Hypothetical calculation, NOT board data',['CL = 8 pF, Cs = 3 pF -> C1 = C2 = 10 pF','Also verify ESR, C0, drive and startup margin.'],290,m.ORANGE)
save(im,3,'مدار و محاسبهٔ تألیفی خازن بار کریستال؛ اعداد مثال فرضی‌اند و مشخصات کریستال واقعی GB100ST را اثبات نمی‌کنند. تقویت‌کنندهٔ داخلی در شکل حذف شده است.','شبکهٔ خارجی کریستال با دو خازن به زمین و فرمول ظرفیت بار','AN2867 Rev25 section3.3; separate component qualification required')
# 4: exact logical MCU pins, header numbers intentionally excluded.
im,d=start('Keep the debug path available','Logical signals; match the actual probe connector pinout')
for y,a,b in [(320,'PA13 / pin34','SWDIO'),(490,'PA14 / pin37','SWCLK'),(660,'NRST / pin7','RESET'),(830,'VSS / ground','GND'),(1000,'3.3 V target','VTref')]:
 box(d,(70,y,550,y+130));text(d,95,y+25,a,440,43,m.INK,True);d.line((550,y+65,735,y+65),fill=m.TEAL,width=7);box(d,(735,y,1130,y+130));text(d,760,y+25,b,350,44,m.TEAL,True)
m.card(d,1220,'GB100ST P2 is a 6-pin header',['It also includes PB3 / SWO, MCU pin39.','VTref is a voltage reference, not assumed power.'],260,m.ORANGE)
text(d,80,1520,'BOOT0 pin44: board jumper defaults to GND.',1030,43)
save(im,4,'نمودار تألیفی تطبیق سیگنال‌های SWD با شمارهٔ پایهٔ تراشه؛ ترتیب فیزیکی کانکتور پروگرامر باید جداگانه بررسی شود. P2 برد GB100ST شامل SWO نیز هست.','نگاشت SWDIO و SWCLK و ریست و زمین و مرجع ولتاژ بین تراشه و پروگرامر','DS9118 Figure4; AN4206 section4; GB100ST V2.0 P2')
# 5: same schematic, different geometric loop, intentionally no general via prohibition.
im,d=start('Layout changes the current loop','Conceptual geometry only; not a fabricated PCB')
for y,title,near in [(320,'A  Longer supply-return loop',False),(880,'B  Local capacitor + short return',True)]:
 text(d,80,y,title,1040,47,m.TEAL,True);yy=y+110
 box(d,(90,yy,370,yy+200));text(d,125,yy+60,'MCU',230,50,m.INK,True)
 cx=530 if near else 1000;d.line((370,yy+45,cx,yy+45,cx,yy+85),fill=m.TEAL,width=7)
 d.line((cx-45,yy+85,cx+45,yy+85),fill=m.INK,width=7);d.line((cx-45,yy+115,cx+45,yy+115),fill=m.INK,width=7)
 d.line((cx,yy+115,cx,yy+230,370,yy+230,370,yy+155),fill=m.ORANGE,width=7)
 text(d,80,yy+280,'Teal: supply path. Orange: return path.',1040,42)
m.card(d,1400,'Short loops, not a universal via ban',['Check the actual PCB and crystal routing.','This sketch is not a layout validation.'],220,m.ORANGE)
save(im,5,'مقایسهٔ هندسی تألیفی مسیر رفت و برگشت جریان دکوپلینگ؛ شکل مقیاس واقعی ندارد و وجود ویا به‌تنهایی عیب محسوب نمی‌شود. چیدمان واقعی برد در این درس بررسی نشده است.','مقایسهٔ حلقهٔ بلند تغذیه با حلقهٔ کوتاه خازن نزدیک تراشه','DS9118 6.1.6; AN4206 5.3–5.4; engineering illustration')
# 6: review gates and limits.
im,d=start('Review before fabrication','Use the downloadable checklist; record evidence, not guesses')
for y,t,ls in [(300,'1  Schematic + component evidence',['Pin numbers / power budget / crystal datasheets','BOOT0 / NRST / debug / interface protection']),(700,'2  Layout + design checks',['Placement / return paths / clearances / ERC + DRC','Manufacturing and assembly review are separate steps.']),(1100,'3  Bringup + measurement',['Power-limited startup -> SWD -> HSI heartbeat','Then verify HSE, analog noise and application behavior.'])]:
 m.card(d,y,t,ls,300)
text(d,80,1490,'Here: schematic review + compiled companion only.',1040,43,m.ORANGE,True)
save(im,6,'فلوچارت تألیفی مراحل بازبینی تا راه‌اندازی؛ چک‌لیست همراه برای ثبت شواهد خالی است. در این کار فقط بازبینی شماتیک و کامپایل پروژهٔ همراه انجام شده است.','سه مرحلهٔ بازبینی شماتیک، بررسی چیدمان و آزمایش راه‌اندازی','Word lesson50 scope; reviewed DS9118/AN4206/AN2867; no ERC/DRC result claimed')
(pub/'image-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
sheet=Image.new('RGB',(1170,1170),'white')
for i in range(6):sheet.paste(Image.open(qa/f'fig{i+1}-390.png'),((i%3)*390,(i//3)*585))
sheet.save(qa/'contact-sheet.png');print('6 diagrams50 drawn')

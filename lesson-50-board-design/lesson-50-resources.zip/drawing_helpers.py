"""Reproducible original educational diagrams, not instrument screenshots.
Requires Pillow. Uses locally installed Segoe UI, font files are not distributed.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math,sys,textwrap
R=Path(__file__).parent;W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e';LINE='#ccdbe3'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def para(d,x,y,s,width=1040,n=44,color=INK,bold=False):
 line='';lines=[]
 for word in s.split():
  q=(line+' '+word).strip()
  if line and d.textlength(q,font=font(n,bold))>width:lines.append(line);line=word
  else:line=q
 if line:lines.append(line)
 for line in lines:
  bounds=d.textbbox((x,y),line,font=font(n,bold));assert bounds[2]<W-24 and bounds[3]<H-22,(s,bounds)
  d.text((x,y),line,font=font(n,bold),fill=color);y+=n+14
 return y
def arrow(d,x,y,x2,y2,color=TEAL):
 d.line((x,y,x2,y2),fill=color,width=7);a=math.atan2(y2-y,x2-x)
 d.polygon([(x2,y2),(x2-24*math.cos(a-.5),y2-24*math.sin(a-.5)),(x2-24*math.cos(a+.5),y2-24*math.sin(a+.5))],fill=color)
def card(d,y,title,lines,h=230,color=TEAL):
 d.rounded_rectangle((65,y,1135,y+h),18,fill='white',outline=color,width=4)
 yy=para(d,90,y+18,title,1020,46,color,True)
 for t in lines:yy=para(d,90,yy+8,t,1020,42)
 assert yy<y+h-3,(title,yy,y+h)
def render(c,spec):
 n=c['n'];p=R.parent/c['local'];pub=p/'public';pub.mkdir(exist_ok=True);qa=p/'visual-qa';qa.mkdir(exist_ok=True)
 out=[]
 for i,s in enumerate(spec,1):
  im=Image.new('RGB',(W,H),'#f5f8fa');d=ImageDraw.Draw(im)
  y=para(d,65,32,s['title'],1070,56,INK,True);para(d,65,y+10,s['subtitle'],1070,40,MUTED)
  d.line((65,250,1135,250),fill=LINE,width=3)
  if s.get('kind')=='memory':
   card(d,300,'Target task control block (TCB)',['Notification value: 32 bits + pending state.','The slot is already present in BOTH builds.'],280)
   arrow(d,600,590,600,665)
   card(d,680,'One receiving task',['Notification sender identifies this task handle.','Several senders may notify the same task.'],280)
   for j in range(8):
    xx=80+j*132;d.rectangle((xx,1090,xx+116,1190),fill='#dceef0',outline=TEAL,width=3);para(d,xx+20,1110,str(j),90,40)
   para(d,80,1000,'Same byte Queue: 8 slots in BOTH modes',1040,44,TEAL,True)
   para(d,80,1230,'Queued payload survives coalesced doorbell events.',1040,42)
   card(d,1380,'Semaphore alternative',['Separate heap object; it carries a token, not payload.'],200,ORANGE)
  elif s.get('kind')=='bits':
   para(d,80,300,'Example: bits 1 and 0 are the requested flags',1040,46,TEAL,True)
   for j in range(8):
    xx=80+j*132;bit=7-j;d.rectangle((xx,435,xx+116,550),fill=TEAL if bit<2 else '#dceef0',outline=TEAL,width=3);para(d,xx+30,458,str(bit),90,44,'white' if bit<2 else INK,True)
   para(d,80,585,'Mask 0x03 = bits 1 | 0; bits 24..31 are reserved.',1040,40)
   card(d,750,'ANY: one requested bit is enough',['0x01 OR 0x02 satisfies the wait condition.'],230)
   card(d,1070,'ALL: both requested bits are needed',['0x03 satisfies the combined wait condition.'],230)
   card(d,1390,'Flags are not event counters',['Repeated setting of one bit coalesces.','On timeout, inspect the returned mask.'],210,ORANGE)
  elif s.get('kind')=='timerplot':
   para(d,80,300,'Ideal initial releases, before any period change',1040,46,TEAL,True)
   for yy,label,vals in [(580,'Auto-reload: every 250 ticks',list(range(250,2001,250))),(980,'One-shot: 2000 ticks once',[2000])]:
    para(d,80,yy-120,label,1040,44,TEAL,True);d.line((100,yy,1100,yy),fill=INK,width=4)
    for tick in range(0,2001,250):
     x=100+tick/2;d.line((x,yy-12,x,yy+12),fill=INK,width=3)
     if tick%500==0:para(d,max(65,x-42),yy+25,str(tick),150,36,MUTED)
    for tick in vals:
     x=100+tick/2;d.ellipse((x-17,yy-17,x+17,yy+17),fill=TEAL)
   card(d,1230,'Nominal tick positions only',['Markers do not show measured callback start times.','The actual project later requests a 500-tick period.'],320,ORANGE)
  elif s.get('kind')=='timeline':
   for j,row in enumerate(s['rows']):
    y=320+j*330;para(d,75,y,row['name'],1050,46,TEAL,True)
    for block in row['blocks']:
     x=80+block[0]*9;w=block[1]*9;d.rectangle((x,y+90,x+w,y+190),fill=block[3]);para(d,x+10,y+108,block[2],max(w-20,20),38,'white',True)
    para(d,80,y+205,row['note'],1035,40)
   card(d,1350,s['note_title'],s['notes'],240,ORANGE)
  else:
   rows=s['cards'];count=len(rows);h={3:320,4:245,5:190}[count];gap={3:115,4:70,5:65}[count]
   for j,row in enumerate(rows):
    y=300+j*(h+gap);card(d,y,row[0],row[1:],h,RED if row[0].startswith('STOP') else TEAL)
    if s.get('kind')=='flow' and j<count-1:arrow(d,600,y+h+8,600,y+h+gap-10)
  d.line((65,1640,1135,1640),fill=LINE,width=3);para(d,65,1660,s.get('footer','Original conceptual diagram; no physical measurement.'),1070,37,MUTED)
  name=f'lesson{n}-figure{i}.png';im.save(pub/name,optimize=True)
  for size in [390,600]:im.resize((size,H*size//W),Image.Resampling.LANCZOS).save(qa/f'fig{i}-{size}.png')
  out.append({'id':f'fig{i:02d}','filename':name,'width':W,'height':H,'caption':s['caption'],'alt':s['alt'],'source':s['source'],'license':'Original diagram and drawing code by GEBRA ENG, CC BY 4.0; source documents are cited, not copied.','kind':'original conceptual diagram','pixels_reviewed':False})
 (pub/'image-metadata.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf8')
 sheet=Image.new('RGB',(390*3,585*2),'white')
 for i in range(1,7):sheet.paste(Image.open(qa/f'fig{i}-390.png'),(((i-1)%3)*390,((i-1)//3)*585))
 sheet.save(qa/'contact-sheet.png')
 print(n,'6 figures')
if __name__=='__main__':
 cfg=json.loads((R/'config.json').read_text('utf8'));spec=json.loads((R/'figure-specs.json').read_text('utf8'))
 for c in cfg:
  if len(sys.argv)>1 and c['n'] not in map(int,sys.argv[1:]):continue
  render(c,spec[str(c['n'])])

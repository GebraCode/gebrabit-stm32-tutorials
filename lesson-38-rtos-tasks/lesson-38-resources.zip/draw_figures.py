"""Original flat technical diagrams. Requires Pillow; no AI image synthesis.
Rebuild with Python. Images are explanatory models, never lab screenshots.
Font fallback: Segoe UI on Windows, DejaVu Sans on Linux. Fonts not bundled.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json,hashlib,zipfile,ast,shutil
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f5f8fa';LINE='#ccdbe3';PALE='#dceef0';WHITE='#ffffff'
ROOT=Path(__file__).resolve().parents[1]
FOLDERS={37:'lesson37-architecture',38:'lesson38-tasks',39:'lesson39-scheduling'}
def font(n=44,b=False):
    paths=[f'C:/Windows/Fonts/segoeui{"b" if b else ""}.ttf',f'/usr/share/fonts/truetype/dejavu/DejaVuSans{"-Bold" if b else ""}.ttf']
    for p in paths:
        if Path(p).exists():return ImageFont.truetype(p,n)
    raise FileNotFoundError('Set an installed sans-serif font path in font().')
def tx(d,x,y,s,n=44,c=INK,b=False):
    box=d.textbbox((x,y),s,font=font(n,b))
    assert box[2]<=W-30 and box[3]<=H-15,(s,box)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1050,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        new=(line+' '+word).strip()
        if line and d.textlength(new,font=font(n,b))>width:lines.append(line);line=word
        else:line=new
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,60,35,title,1080,54,b=True)
    y=para(d,60,y+12,subtitle,1080,40,MUTED)
    assert y<=240,(title,y)
    d.line((60,250,1140,250),fill=LINE,width=3)
    return im,d
def foot(d,s='Original diagram; no physical measurement supplied.'):
    d.line((60,1640,1140,1640),fill=LINE,width=3)
    y=para(d,60,1670,s,1080,38,MUTED)
    assert y<=1790
def arrow(d,points,c=TEAL,w=7):
    d.line(points,fill=c,width=w);x,y=points[-1];px,py=points[-2];a=math.atan2(y-py,x-px)
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,p0,p1,c=ORANGE):
    x0,y0=p0;x1,y1=p1;dist=math.hypot(x1-x0,y1-y0)
    for a in range(0,int(dist),30):
        b=min(a+14,dist);d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=4)
def box(d,x,y,w,h,title,lines=(),c=TEAL,n=44):
    d.rounded_rectangle((x,y,x+w,y+h),16,fill=WHITE,outline=c,width=3)
    yy=para(d,x+22,y+15,title,w-44,n,c,True)
    for line in lines:yy=para(d,x+22,yy+10,line,w-44,n-2)
    assert yy+10<=y+h,(title,yy,y+h)
def axis(d,x,y,w,start,end,label,ticks):
    arrow(d,[(x,y),(x+w,y)],INK,4)
    for t in ticks:
        xx=x+(t-start)/(end-start)*w;d.line((xx,y-12,xx,y+12),fill=INK,width=3)
        tx(d,max(40,xx-25),y+20,str(t),38,MUTED)
    tx(d,x,y+83,label,40,MUTED)
def rect(d,x,y,w,h,label,c=TEAL,n=42):
    d.rectangle((x,y,x+w,y+h),fill=c)
    if label:tx(d,x+14,y+10,label,n,WHITE,True)
def save(im,n,k):
    im.save(Path(__file__).resolve().parent/f'lesson{n}-figure{k}.png',optimize=True)



def fig38_1():
    im,d=begin('Follow a task through its states','Explicit suspend/resume path in this lesson; snapshot labels are not a full trace')
    box(d,100,350,420,170,'Ready',['Eligible, not running'],n=42)
    box(d,680,350,420,170,'Running',['One task on this core'],n=42)
    arrow(d,[(535,390),(665,390)]);tx(d,520,285,'Select',38,MUTED)
    arrow(d,[(665,480),(535,480)],ORANGE)
    tx(d,520,545,'Preempt',38,ORANGE)
    box(d,680,1000,420,205,'Blocked',['Delay or event wait'],n=42)
    arrow(d,[(890,540),(890,970)]);tx(d,680,740,'vTaskDelay',42,TEAL,True)
    arrow(d,[(890,1220),(890,1280),(70,1280),(70,435),(90,435)])
    tx(d,430,1215,'Event / timeout',42,TEAL,True)
    box(d,100,1000,420,205,'Suspended',['Explicitly paused'],n=42)
    arrow(d,[(180,985),(180,540)],ORANGE)
    arrow(d,[(440,540),(440,985)],ORANGE)
    tx(d,220,810,'Resume',40,ORANGE,True)
    tx(d,220,900,'Pause',40,ORANGE,True)
    para(d,95,1325,'vTaskSuspend can pause a task. vTaskResume makes this explicitly suspended task Ready again; it does not guarantee immediate execution.',1010,44)
    foot(d,'State-query edge cases and ISR-safe resume are discussed in text.');save(im,38,1)

def fig38_2():
    im,d=begin('Task creation reserves two blocks','Conceptual allocations from heap_4; positions and TCB size are not literal addresses')
    box(d,90,300,1020,175,'xTaskCreate(...,256,... )',['Check pdPASS; stack depth counts words.'],n=42)
    arrow(d,[(600,490),(600,560)])
    box(d,90,590,430,330,'TCB',['Task state and priority','pxTopOfStack pointer'],n=40)
    box(d,670,590,430,710,'Task stack',['Higher addresses'],n=42)
    for k,label in enumerate(['Saved context','Temporary data','Unused margin']):
        yy=800+k*140;d.rectangle((700,yy,1070,yy+105),fill=PALE,outline=LINE,width=2);tx(d,720,yy+20,label,38)
    tx(d,700,1240,'Lower addresses',38,MUTED)
    arrow(d,[(535,850),(640,850)],ORANGE)
    arrow(d,[(1120,790),(1120,1210)],ORANGE)
    box(d,90,1400,1020,200,'256 words x 4 bytes = 1024 bytes',['TCB and allocator bookkeeping are extra.'],n=44)
    foot(d,'Stack grows toward lower addresses in the ARM_CM4F port.');save(im,38,2)

def fig38_3():
    im,d=begin('A Ready task can still starve','Illustrative scheduling intervals, not a capture of the example firmware')
    tx(d,90,300,'Higher-priority task stays Ready',44,ORANGE,True)
    for k,label in enumerate(['High / P2','Low / P1','Idle / P0']):
        yy=450+k*150;tx(d,90,yy,label,40);rect(d,390,yy,700,90,'Running' if k==0 else 'Ready, but no CPU',ORANGE if k==0 else MUTED,40)
    tx(d,90,955,'Blocking creates opportunities',44,TEAL,True)
    for k,label in enumerate(['High / P2','Low / P1','Idle / P0']):
        yy=1090+k*150;tx(d,90,yy,label,40)
        d.rectangle((390,yy,1090,yy+90),fill=PALE)
    rect(d,390,1090,200,90,'Run',TEAL,40);rect(d,900,1090,190,90,'Run',TEAL,40)
    rect(d,600,1240,170,90,'Run',TEAL,40);rect(d,780,1390,110,90,'Run',TEAL,38)
    tx(d,600,1100,'Blocked',42,MUTED)
    foot(d,'Time -> schematic only. Lower rows may run when higher tasks block.');save(im,38,3)

def fig38_4():
    im,d=begin('Deletion has two cleanup paths','Pinned single-core kernel; this lesson uses Control to delete the non-running Fast task')
    tx(d,90,310,'Self-delete',46,ORANGE,True);tx(d,640,310,'Delete another task',44,TEAL,True)
    left=[('vTaskDelete(NULL)','Current task removes itself.'),('Deferred cleanup','Its own stack is still active.'),('Idle gets CPU time','Cleanup runs from Idle.'),('Free kernel memory','TCB and dynamic task stack.')]
    right=[('Control deletes Fast','Target is not the running task.'),('Direct cleanup','Kernel frees TCB and stack.'),('Clear the handle','g_fast_task = NULL'),('Never query old handle','GPIO keeps its last level.')]
    for col,items in enumerate([left,right]):
        x=80+col*555;c=ORANGE if col==0 else TEAL
        for k,(a,b) in enumerate(items):
            yy=420+k*265;box(d,x,yy,485,220,a,[b],c,n=40)
            if k<3:arrow(d,[(x+240,yy+225),(x+240,yy+255)],c)
    para(d,95,1510,'User-owned resources are not automatically released.',1010,44,c=ORANGE)
    foot(d,'No heap-leak or runtime test is claimed by this conceptual flow.');save(im,38,4)

def fig38_5():
    im,d=begin('Two tasks, two observable outputs','Functional wiring guide; package pin numbers differ from module header numbers')
    box(d,90,300,1020,235,'GB100ST V2.0 / STM32F303CBT6',['PB6: MCU 42 / header 28; onboard active-high LED','PB7: MCU 43 / header 31; external output'],n=40)
    box(d,80,650,440,190,'Fast / priority 2',['Toggle PB6; delay 250 ms'],n=40)
    box(d,680,650,440,190,'Onboard LED',['Full cycle nominal 500 ms'],n=40)
    arrow(d,[(535,745),(665,745)])
    box(d,80,970,440,190,'Slow / priority 1',['Toggle PB7; delay 750 ms'],n=40)
    tx(d,670,1015,'PB7 -> 1 kOhm -> LED',40,TEAL,True)
    tx(d,670,1080,'-> shared GND',40,TEAL,True)
    arrow(d,[(535,1060),(645,1060)])
    box(d,80,1320,1040,250,'Alternative: logic analyzer inputs',['PB6 -> CH0; PB7 -> CH1; GND -> GND','Inputs must accept 3.3 V; do not drive MCU outputs.'],n=40)
    foot(d,'Logical guide only; no second onboard LED or measured waveform.');save(im,38,5)

def fig38_6():
    im,d=begin('Observe the variables, not a mock GUI','Original observation guide; no debugger screenshot or measured values supplied')
    rows=[('Control / priority 3','g_control_state: self-query is Running'),('Fast / priority 2','Query g_fast_state only while handle is valid.'),('Slow / priority 1','g_slow_state: current state snapshot')]
    for k,(a,b) in enumerate(rows):box(d,90,300+k*240,1020,195,a,[b],n=42)
    box(d,90,1060,1020,245,'High-water marks count words',['g_fast_free_words / g_slow_free_words','Historical unused stack pattern; not a safety proof.'],n=40)
    box(d,90,1370,1020,225,'Debugger commands: 1 / 2 / 3',['Suspend Fast / resume Fast / delete Fast','Resume execution for Control to process a command.'],n=40)
    foot(d,'Halting changes timing; state samples are not a complete history.');save(im,38,6)

if __name__=="__main__":
    for k in range(1,7):globals()[f"fig38_{k}"]()

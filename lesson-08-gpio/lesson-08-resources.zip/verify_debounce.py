"""Synthetic sampled-input model of the delivered C algorithm; no board simulation."""
from pathlib import Path
import json

def model(samples):
    first_time, initial = samples[0]
    raw = stable = initial
    changed_at = first_time & 0xffffffff
    changes = presses = led = 0
    trace = []
    for time, sample in samples:
        now = time & 0xffffffff
        if sample != raw:
            raw = sample
            changes += 1
            changed_at = now
        if raw != stable and ((now - changed_at) & 0xffffffff) >= 20:
            stable = raw
            if stable == 0:
                presses += 1
                led ^= 1
        trace.append(dict(time=time, tick=now, raw=raw, stable=stable, raw_changes=changes, presses=presses, led=led))
    return trace

def schedule(events, end, start=0, stride=1):
    result=[]
    for time in range(start, end+1, stride):
        level=events[0][1]
        for edge,value in events:
            if edge <= time: level=value
        result.append((time, level))
    return result

events=[(0,1),(10,0),(11,1),(12,0),(14,1),(16,0),(70,1),(71,0),(73,1),(110,0)]
timeline=model(schedule(events,150))
assert timeline[35]['presses']==0 and timeline[36]['presses']==1
assert timeline[92]['stable']==0 and timeline[93]['stable']==1
assert timeline[93]['presses']==1 and timeline[129]['presses']==1
assert timeline[130]['presses']==2 and timeline[150]['led']==0
boot=model(schedule([(0,0),(100,1),(140,0)],180))
assert boot[99]['presses']==0 and boot[159]['presses']==0 and boot[160]['presses']==1
short=model(schedule([(0,1),(10,0),(29,1)],80))
assert short[-1]['presses']==0
held=model(schedule([(0,1),(10,0)],500))
assert held[29]['presses']==0 and held[30]['presses']==1 and held[-1]['presses']==1
wrap=model(schedule([(0xfffffff0,1),(0xfffffffa,0)],0x100000030,0xfffffff0))
assert next(x for x in wrap if x['tick']==13)['presses']==0
assert next(x for x in wrap if x['tick']==14)['presses']==1
fast=model(schedule(events,150)); slow=model(schedule(events,150,stride=10))
assert fast[-1]['raw_changes']!=slow[-1]['raw_changes']
assert fast[-1]['presses']==slow[-1]['presses']==2
result={'scope':'Synthetic sampled-input arithmetic only; RC, contact physics, MCU execution and physical timing are not simulated.',
 'qualification_ms':20,'cases_passed':['bouncing press and release','release does not toggle','second press','boot held does not create press','short pulse rejected','19/20 ms boundary','held press counted once','uint32 tick wrap','sampling can miss transitions'],
 'sampled_edges_1ms':fast[-1]['raw_changes'],'sampled_edges_10ms':slow[-1]['raw_changes'],
 'accepted_presses':fast[-1]['presses'],'timeline':timeline}
(Path(__file__).parent/'debounce-model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='timeline'},indent=2))

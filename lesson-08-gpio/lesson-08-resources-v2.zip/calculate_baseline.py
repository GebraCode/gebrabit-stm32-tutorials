"""Nominal configuration arithmetic, not a measured RC response or MCU clock."""
import json
from pathlib import Path

pullup_ohm = 10000
capacitor_farad = 100e-9
tau_ms = pullup_ohm * capacitor_farad * 1000
assert abs(tau_ms - 1.0) < 1e-12
hclk_hz = 8_000_000
systick_hz = 1000
reload_value = hclk_hz // systick_hz - 1
assert reload_value == 7999
qualification_ms = 20
assert qualification_ms * systick_hz // 1000 == 20
result = {
    'scope': 'Nominal arithmetic only. External RC values do not guarantee contact debounce; HSI physical frequency and actual loop timing not measured.',
    'external_pullup_ohm': pullup_ohm,
    'capacitor_farad': capacitor_farad,
    'nominal_RC_ms': tau_ms,
    'configured_HCLK_hz': hclk_hz,
    'default_HAL_SysTick_hz': systick_hz,
    'expected_SysTick_reload': reload_value,
    'qualification_ms': qualification_ms,
}
(Path(__file__).parent / 'baseline-calculations.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps(result, indent=2))

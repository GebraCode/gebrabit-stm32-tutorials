"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=8
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def ground(d,x,y):
 d.line((x,y,x,y+20),fill=INK,width=5)
 for yy,ww in [(y+20,30),(y+35,20),(y+50,10)]:d.line((x-ww,yy,x+ww,yy),fill=INK,width=4)
def resistor(d,x,y,w=150):
 d.rectangle((x,y-20,x+w,y+20),fill=WHITE,outline=INK,width=4)
def figure1():
 im,d=begin('See how an output drives HIGH and LOW','Simplified switch model, not a complete transistor or protection schematic')
 for x,label,upper in [(300,'Push-pull',True),(900,'Open-drain',False)]:
  tx(d,x-180,300,label,48,TEAL,True);tx(d,x-80,460,'VDD',44,TEAL,True)
  d.line((x,530,x,610),fill=INK,width=5)
  if upper:
   d.line((x,610,x+50,680),fill=TEAL,width=6);d.line((x,700,x,830),fill=INK,width=5)
  else:
   resistor(d,x-20,600,40);d.line((x,625,x,830),fill=INK,width=5);tx(d,x-240,650,'External',38);tx(d,x-240,705,'pull-up',38)
  d.ellipse((x-10,820,x+10,840),fill=INK);d.line((x,830,x+150,830),fill=INK,width=5);tx(d,x+45,870,'PIN',42,TEAL,True)
  d.line((x,830,x,1010),fill=INK,width=5);d.line((x,1010,x+50,1080),fill=TEAL,width=6);d.line((x,1100,x,1200),fill=INK,width=5);ground(d,x,1200)
 tx(d,90,1320,'Drives HIGH / LOW',42,TEAL,True)
 tx(d,700,1320,'Sinks LOW',42,TEAL,True)
 panel(d,75,1400,1050,210,'Input sampling reads IDR',['Pull resistors and electrical limits depend on pin and mode.'])
 foot(d,'Do not infer a universal diode topology or 5 V tolerance.');save(im,1)
def figure2():
 im,d=begin('Bit commands and whole toggles differ','Two conceptual writers update separate bits of the same output register')
 tx(d,70,300,'Read-modify-write on ODR',48,ORANGE,True)
 steps=[('Main reads','00'),('IRQ sets bit 1','10'),('Main writes old + bit 0','01')]
 for k,(a,b)in enumerate(steps):
  x=75+k*370;panel(d,x,450,320,260,a,[b])
  if k<2:arrow(d,[(x+325,580),(x+360,580)],ORANGE)
 tx(d,70,800,'Bit 1 update was lost in this interleaving.',44,RED,True)
 tx(d,70,980,'Separate BSRR bit-set commands',48,TEAL,True)
 steps=[('Initial state','00'),('Set bit 1','10'),('Set bit 0','11')]
 for k,(a,b)in enumerate(steps):
  x=75+k*370;panel(d,x,1110,320,210,a,[b])
  if k<2:arrow(d,[(x+325,1210),(x+360,1210)])
 para(d,75,1430,'F3 WritePin RESET writes BRR. TogglePin reads ODR then writes BSRR; the whole toggle is not a multiwriter atomic protocol.',1040,42)
 foot(d,'BSRR low 16 bits set; high 16 bits reset, without a prior read.');save(im,2)
def figure3():
 im,d=begin('Choose a supported route to a pin','A future-course AF example; no AF peripheral is configured in lesson 8')
 panel(d,75,330,480,210,'TIM3 channel 1',['Verified PA6 alternate function: AF2'])
 d.polygon([(710,350),(990,500),(990,1050),(710,1200)],fill=WHITE,outline=TEAL,width=5)
 tx(d,755,690,'AF mux',46,TEAL,True)
 arrow(d,[(570,440),(700,440)])
 arrow(d,[(1000,780),(1130,780)])
 tx(d,990,860,'PA6',43,TEAL,True)
 tx(d,75,800,'Other functions',44,MUTED)
 dashed(d,75,920,695,920,MUTED)
 tx(d,75,1020,'Only if listed for this pin',40)
 arrow(d,[(550,1320),(830,1320),(830,1160)],ORANGE)
 tx(d,75,1290,'AFR selection',44,ORANGE,True)
 panel(d,75,1400,1050,210,'Check both sides of the route',['Correct AF row + configured peripheral + correct pin mode'])
 foot(d,'AF0..AF15 codes do not imply 16 functions on every pin.');save(im,3)
def figure4():
 im,d=begin('Read the two onboard user circuits','Functional redraw, not board placement or a copied official layout')
 tx(d,75,300,'PA3 button: active LOW',48,TEAL,True)
 tx(d,180,420,'3V3',43,TEAL,True);d.line((240,490,240,540),fill=INK,width=5);resistor(d,220,565,40);d.line((240,590,240,760),fill=INK,width=5)
 tx(d,300,530,'10 kOhm pull-up',42)
 d.line((240,760,850,760),fill=INK,width=5);tx(d,900,720,'PA3',46,TEAL,True)
 d.line((460,760,460,840),fill=INK,width=5);d.line((425,840,495,840),fill=INK,width=5);d.line((425,875,495,875),fill=INK,width=5);d.line((460,875,460,950),fill=INK,width=5);ground(d,460,950)
 tx(d,570,835,'100 nF',42)
 d.line((240,760,240,840),fill=INK,width=5);d.line((240,840,300,900),fill=TEAL,width=6);d.line((240,920,240,950),fill=INK,width=5);ground(d,240,950)
 tx(d,75,1050,'Nominal R x C = 1 ms; not a debounce guarantee',42,ORANGE)
 tx(d,75,1200,'PB6 LED: HIGH requests light ON',47,TEAL,True)
 panel(d,75,1310,320,200,'PB6',['Logic output'])
 arrow(d,[(410,1410),(470,1410)])
 panel(d,485,1310,280,200,'NPN Q1',['Sink driver'])
 arrow(d,[(780,1410),(840,1410)])
 panel(d,855,1310,275,200,'LED load',['From 3V3'])
 foot(d,'LED resistor and base network omitted from this functional path.');save(im,4)
def figure5():
 im,d=begin('Read electrical limits under their conditions','Absolute maximum values are not normal operating targets')
 steps=[('1 Identify the exact pin class','Pin, mode, supply state and datasheet footnotes matter.'),('2 Use normal output specifications','At 2.7<VDD<3.6 V and 8 mA: VOL<=0.4 V; VOH>=VDD-0.4 V.'),('3 Respect combined current limits','Per pin 25 mA, total IO 80 mA and supply 160 mA are absolute limits.')]
 for k,(a,b)in enumerate(steps):
  y=300+k*350;panel(d,75,y,1050,260,a,[b])
  if k<2:arrow(d,[(600,y+270),(600,y+340)])
 panel(d,75,1400,1050,200,'No blanket 5 V permission',['Board power at 5 V does not make GPIO a 5 V supply.'])
 foot(d,'Values require DS9118 tables 22, 54, 55 conditions and footnotes.');save(im,5)
def wave(d,segments,high,low,c=TEAL):
 pts=[]
 for t,v in segments:
  x=100+t*12
  if pts:pts.append((x,pts[-1][1]))
  pts.append((x,high if v else low))
 d.line(pts,fill=c,width=7)
def figure6():
 im,d=begin('Wait for a stable sampled button state','Synthetic sampled-level model, not a measured bounce waveform')
 tx(d,75,300,'Observed raw samples after the board circuit',44,TEAL,True)
 wave(d,[(0,1),(5,0),(8,1),(10,0),(55,1),(80,1)],550,710)
 tx(d,75,850,'Accepted state after 20 ms unchanged',44,ORANGE,True)
 wave(d,[(0,1),(30,0),(75,1),(80,1)],1020,1180,ORANGE)
 for t in [0,10,30,55,75]:
  x=100+t*12;dashed(d,x,740,x,810,LINE);dashed(d,x,950,x,1230,LINE);tx(d,x-20,1270,str(t),40)
 tx(d,950,1350,'Time (ms)',40)
 arrow(d,[(220,780),(460,780)],ORANGE);tx(d,245,715,'20 ms',40,ORANGE)
 panel(d,75,1400,1050,210,'Accepted LOW -> count press and toggle PB6',['raw_changes counts sampled changes, not contact bounces.'])
 foot(d,'Short unsampled changes can be missed; release does not toggle.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson08-refresh-figure1.png', 'alt': 'مدل سادهٔ خروجی Push-pull و Open-drain', 'caption': 'نمودار تألیفی کلیدی و ساده\u200cشده: Push-pull سطح بالا و پایین را فعال می\u200cراند؛ Open-drain سطح پایین را می\u200cکشد و برای سطح بالا به pull-up مناسب نیاز دارد. مسیر ورودی از IDR خوانده می\u200cشود. شکل مدار کامل ترانزیستوری یا توپولوژی همگانی دیود محافظ نیست و تحمل 5 V را نتیجه نمی\u200cدهد.', 'purpose': 'مدل سادهٔ خروجی Push-pull و Open-drain', 'placement': "زیر بخش 'طبقه خروجی: مقایسه فنی و کاربردی Push-Pull و Open-Drain'", 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14 Tables13,22,54,55 and AFtable', 'scope': 'Pin classes, electricalconditions, PA6AF2'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'GPIO registers and conceptual circuit behavior'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3 buttonRC and PB6NPN functional path'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a and actual fresh lesson08 source', 'scope': 'ReadPinIDR, ResetBRR, ToggleODR+BSRR; actualdebounce algorithm'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Simplified switches, no universal diode topology or exact internalpull40k guarantee.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson08-refresh-figure2.png', 'alt': 'رقابت خواندن و تغییر و نوشتن در برابر فرمان بیتی', 'caption': 'مدل تألیفی دو نویسندهٔ مفهومی: نوشتن ODR بر اساس مقدار قدیمی می\u200cتواند تغییر بیت دیگر در وقفه را از دست بدهد؛ فرمان\u200cهای set جداگانهٔ BSRR به خواندن قبلی نیاز ندارند. در HAL دقیق F3 شاخهٔ RESET در WritePin از BRR و TogglePin از خواندن ODR و سپس BSRR استفاده می\u200cکند؛ کل Toggle پروتکل اتمیک چندنویسنده نیست.', 'purpose': 'رقابت خواندن و تغییر و نوشتن در برابر فرمان بیتی', 'placement': "زیر بخش 'خواندن از IDR و نوشتن در ODR در تقابل با رجیستر اتمیک BSRR'", 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14 Tables13,22,54,55 and AFtable', 'scope': 'Pin classes, electricalconditions, PA6AF2'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'GPIO registers and conceptual circuit behavior'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3 buttonRC and PB6NPN functional path'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a and actual fresh lesson08 source', 'scope': 'ReadPinIDR, ResetBRR, ToggleODR+BSRR; actualdebounce algorithm'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Conceptinterleaving00->10->01 versus00->10->11. No singleCPUcycle guarantee; actual F3 WritePin RESET via BRR and Toggle readwrite caveat.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson08-refresh-figure3.png', 'alt': 'انتخاب مسیر تابع جایگزین برای یک پایه', 'caption': 'نمودار تألیفی نمونهٔ تأییدشدهٔ PA6/TIM3_CH1 با AF2 برای درس\u200cهای بعد. کدهای AF0 تا AF15 به معنی وجود 16 تابع در هر پایه نیست؛ هم ردیف جدول و هم حالت پایه و پیکربندی پریفرال باید درست باشد. پروژهٔ این درس پریفرال AF تازه\u200cای ندارد.', 'purpose': 'انتخاب مسیر تابع جایگزین برای یک پایه', 'placement': "زیر بخش 'سازوکار مالتی\u200cپلکسر داخلی و رجیسترهای AFRL و AFRH'", 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14 Tables13,22,54,55 and AFtable', 'scope': 'Pin classes, electricalconditions, PA6AF2'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'GPIO registers and conceptual circuit behavior'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3 buttonRC and PB6NPN functional path'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a and actual fresh lesson08 source', 'scope': 'ReadPinIDR, ResetBRR, ToggleODR+BSRR; actualdebounce algorithm'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Verified PA6TIM3CH1AF2, not fictional16functionsallpins or inventedPA2/PA3route.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson08-refresh-figure4.png', 'alt': 'مدار منطقی کلید PA3 و درایور LED روی PB6', 'caption': 'بازترسیم عملکردی تألیفی مدار برد: pull-up خارجی 10 kOhm و خازن 100 nF کلید PA3 ثابت زمانی اسمی 1 ms می\u200cسازند؛ این محاسبه حذف همهٔ bounce را تضمین نمی\u200cکند. PB6 درایور NPN را کنترل می\u200cکند و HIGH درخواست روشن\u200cشدن LED است. مقادیر غیرضروری شبکهٔ بیس و مقاومت LED در شکل حذف شده و شمارهٔ کانکتور فرض نشده است.', 'purpose': 'مدار منطقی کلید PA3 و درایور LED روی PB6', 'placement': "زیر بخش 'تحلیل مدارهای کلید و LED در برد GebraBit GB100ST V2.0'", 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14 Tables13,22,54,55 and AFtable', 'scope': 'Pin classes, electricalconditions, PA6AF2'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'GPIO registers and conceptual circuit behavior'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3 buttonRC and PB6NPN functional path'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a and actual fresh lesson08 source', 'scope': 'ReadPinIDR, ResetBRR, ToggleODR+BSRR; actualdebounce algorithm'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'BoardlogicalPA3pull10kC100nFnominalRC1ms. PB6NPNactiveHIGH, no inventedR13/physicalpin/header or saturation guarantee.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson08-refresh-figure5.png', 'alt': 'خواندن حدود الکتریکی با شروط دیتاشیت', 'caption': 'نمودار تألیفی سه گام بررسی کلاس دقیق پایه و شرایط مشخصات معمول و حدود مطلق. اعداد 25 mA برای هر پایه، 80 mA مجموع I/O و 160 mA تغذیه حدود مطلق تحت شروط جدول\u200cاند و هدف طراحی یا امکان جریان هم\u200cزمان همهٔ پایه\u200cها نیستند. مشخصات 8 mA در بازهٔ 2.7<VDD<3.6 V با حدود VOL و VOH جدا نمایش داده شده است؛ اجازهٔ همگانی 5 V داده نشده است.', 'purpose': 'خواندن حدود الکتریکی با شروط دیتاشیت', 'placement': "زیر بخش 'بررسی سازگاری با ولتاژ 5V در پایه\u200cهای FT در مقایسه با محدودیت\u200cهای پایه\u200cهای TTa'", 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14 Tables13,22,54,55 and AFtable', 'scope': 'Pin classes, electricalconditions, PA6AF2'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'GPIO registers and conceptual circuit behavior'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3 buttonRC and PB6NPN functional path'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a and actual fresh lesson08 source', 'scope': 'ReadPinIDR, ResetBRR, ToggleODR+BSRR; actualdebounce algorithm'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'DS9118Tables22,54,55 exactconditions. No incorrect20mA/120total or blanketFT5.5/VDDA+.3normalrange.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson08-refresh-figure6.png', 'alt': 'مدل نمونه\u200cبرداری و تأیید کلید پس از 20 ms', 'caption': 'مدل تألیفی و مصنوعی سطح نمونه\u200cبرداری\u200cشده: پس از آخرین تغییر مشاهده\u200cشده در 10 ms، سطح LOW در 30 ms پذیرفته می\u200cشود؛ release از 55 ms در 75 ms پذیرفته می\u200cشود و LED را Toggle نمی\u200cکند. raw_changes تغییرهای دیده\u200cشده بعد از مدار برد را می\u200cشمارد، نه تعداد واقعی جهش تماس؛ پالس نمونه\u200cبرداری\u200cنشده می\u200cتواند دیده نشود.', 'purpose': 'مدل نمونه\u200cبرداری و تأیید کلید پس از 20 ms', 'placement': "زیر بخش 'الگوریتم دیبانس نرم\u200cافزاری غیرمسدودکننده 20ms با تفاضل امن زمانی در HAL_GetTick'", 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14 Tables13,22,54,55 and AFtable', 'scope': 'Pin classes, electricalconditions, PA6AF2'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'GPIO registers and conceptual circuit behavior'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3 buttonRC and PB6NPN functional path'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL953955a and actual fresh lesson08 source', 'scope': 'ReadPinIDR, ResetBRR, ToggleODR+BSRR; actualdebounce algorithm'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Syntheticlevelsnotmeasurement. Actual20msunsignedqualification, sampledraw_changes notraw_edges or physicalbouncecount; acceptedLOWonlytoggles. Timeaxisillustrative.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

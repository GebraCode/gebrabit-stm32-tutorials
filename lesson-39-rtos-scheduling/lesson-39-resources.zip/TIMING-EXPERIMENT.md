# Timing experiment — no measurements supplied

Run the firmware continuously for60 s without breakpoints. When g_test_done becomes1, halt and export only the populated entries indicated by g_relative_count and g_absolute_count. Fill hardware-observations-BLANK.csv with stream,index,elapsed_ticks. Use relative/absolute as stream labels and contiguous indices starting0.

Run `python timing_model.py --measured hardware-observations-BLANK.csv` after filling real data. Do not rename ideal-model.csv as measurement. The script does not acquire data itself.

Phase error for a stream is `(t[k]-t[0])-k*100` ticks; intervals are differences of consecutive starts. The tick is1 ms, so tick timestamps do not establish submillisecond jitter. For finer timing, capture both outputs with a suitable external analyzer. Adjacent toggles are iteration boundaries; the full square-wave cycle spans2 toggles. A board reset is required before a fresh capture.

The ideal model assumes one isolated worker,20 ms work, zero overhead and no competing task or interrupt. The real firmware runs two equal-priority workers together, so its samples need not match the ideal model exactly. The absolute schedule prevents accumulation of work time into the intended release timeline; it does not guarantee zero execution jitter.

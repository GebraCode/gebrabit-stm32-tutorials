"""Ideal isolated-worker model and optional analysis of measured tick CSV.

This script is not a FreeRTOS emulator and does not measure hardware.
Run: python timing_model.py [--measured collected.csv]
Measured CSV headers: stream,index,elapsed_ticks
stream must be relative or absolute; export only populated entries from RAM.
"""
from pathlib import Path
import argparse,csv,json
P=Path(__file__).resolve().parent
PERIOD=100
WORK=20
WINDOW=60000
def model():
    rows=[]
    for stream,spacing in [('relative',PERIOD+WORK),('absolute',PERIOD)]:
        for index,t in enumerate(range(0,WINDOW,spacing)):
            rows.append({'stream':stream,'index':index,'elapsed_ms':t,
                         'phase_error_ms':t-index*PERIOD,'kind':'IDEAL MODEL, NOT MEASURED'})
    return rows
def analyze(path):
    groups={'relative':[],'absolute':[]}
    with Path(path).open(newline='',encoding='utf8') as f:
        for r in csv.DictReader(f):
            groups[r['stream']].append((int(r['index']),int(r['elapsed_ticks'])))
    results={}
    for stream,values in groups.items():
        values.sort()
        if not values:continue
        assert [k for k,t in values]==list(range(len(values))), 'Indices must be contiguous from0'
        start=values[0][1]
        elapsed=[(t-start)&0xffffffff for k,t in values]
        assert all(b>=a for a,b in zip(elapsed,elapsed[1:])), 'Capture must be monotonic and span less than32-bit wrap'
        errors=[t-k*PERIOD for k,t in enumerate(elapsed)]
        intervals=[b-a for a,b in zip(elapsed,elapsed[1:])]
        results[stream]={'samples':len(values),'last_phase_error_ticks':errors[-1],
                         'min_interval_ticks':min(intervals) if intervals else None,
                         'max_interval_ticks':max(intervals) if intervals else None,
                         'tick_rate_hz':1000,'tick_resolution_ms':1,
                         'measurement_origin':'USER-SUPPLIED CSV; not collected by this script'}
    return results
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--measured');args=parser.parse_args()
    rows=model()
    with (P/'ideal-model.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    summary={'kind':'IDEAL MODEL, NOT BOARD MEASUREMENT','assumptions':['each worker considered in isolation','tick phase0','no interrupt, scheduling or context-switch overhead','no competing tasks','work20ms, relative wait100ms, absolute period100ms','capture interval [0,60000)ms'],
             'streams':{s:{'starts':len(a:=[r for r in rows if r['stream']==s]),'last_start_ms':a[-1]['elapsed_ms'],'last_phase_error_ms':a[-1]['phase_error_ms']} for s in ['relative','absolute']}}
    assert summary['streams']['relative']=={'starts':500,'last_start_ms':59880,'last_phase_error_ms':9980}
    assert summary['streams']['absolute']=={'starts':600,'last_start_ms':59900,'last_phase_error_ms':0}
    (P/'ideal-model-summary.json').write_text(json.dumps(summary,indent=2),'utf8')
    if args.measured:
        (P/'measured-analysis.json').write_text(json.dumps(analyze(args.measured),indent=2),'utf8')
    print(json.dumps(summary,indent=2))

# Original educational figures

Run `python draw_figures.py` with Pillow installed. The script redraws the six PNG files beside it. It uses an installed Segoe UI or DejaVu Sans font and does not distribute font files. English technical labels keep identifiers legible; Persian captions and alt text are in figures-metadata.json.

All figures are original explanatory diagrams or explicitly labeled analytical models. They are not screenshots, physical captures, proof of hardware execution, or copies of official artwork. Sources, limitations, placement and image hashes are recorded in figures-metadata.json. Compare exact kernel/project versions before adapting a figure.

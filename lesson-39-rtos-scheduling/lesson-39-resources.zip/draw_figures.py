"""Original flat technical diagrams. Requires Pillow; no AI image synthesis.
Rebuild with Python. Images are explanatory models, never lab screenshots.
Font fallback: Segoe UI on Windows, DejaVu Sans on Linux. Fonts not bundled.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json,hashlib,zipfile,ast,shutil
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f5f8fa';LINE='#ccdbe3';PALE='#dceef0';WHITE='#ffffff'
ROOT=Path(__file__).resolve().parents[1]
FOLDERS={37:'lesson37-architecture',38:'lesson38-tasks',39:'lesson39-scheduling'}
def font(n=44,b=False):
    paths=[f'C:/Windows/Fonts/segoeui{"b" if b else ""}.ttf',f'/usr/share/fonts/truetype/dejavu/DejaVuSans{"-Bold" if b else ""}.ttf']
    for p in paths:
        if Path(p).exists():return ImageFont.truetype(p,n)
    raise FileNotFoundError('Set an installed sans-serif font path in font().')
def tx(d,x,y,s,n=44,c=INK,b=False):
    box=d.textbbox((x,y),s,font=font(n,b))
    assert box[2]<=W-30 and box[3]<=H-15,(s,box)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1050,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        new=(line+' '+word).strip()
        if line and d.textlength(new,font=font(n,b))>width:lines.append(line);line=word
        else:line=new
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,60,35,title,1080,54,b=True)
    y=para(d,60,y+12,subtitle,1080,40,MUTED)
    assert y<=240,(title,y)
    d.line((60,250,1140,250),fill=LINE,width=3)
    return im,d
def foot(d,s='Original diagram; no physical measurement supplied.'):
    d.line((60,1640,1140,1640),fill=LINE,width=3)
    y=para(d,60,1670,s,1080,38,MUTED)
    assert y<=1790
def arrow(d,points,c=TEAL,w=7):
    d.line(points,fill=c,width=w);x,y=points[-1];px,py=points[-2];a=math.atan2(y-py,x-px)
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,p0,p1,c=ORANGE):
    x0,y0=p0;x1,y1=p1;dist=math.hypot(x1-x0,y1-y0)
    for a in range(0,int(dist),30):
        b=min(a+14,dist);d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=4)
def box(d,x,y,w,h,title,lines=(),c=TEAL,n=44):
    d.rounded_rectangle((x,y,x+w,y+h),16,fill=WHITE,outline=c,width=3)
    yy=para(d,x+22,y+15,title,w-44,n,c,True)
    for line in lines:yy=para(d,x+22,yy+10,line,w-44,n-2)
    assert yy+10<=y+h,(title,yy,y+h)
def axis(d,x,y,w,start,end,label,ticks):
    arrow(d,[(x,y),(x+w,y)],INK,4)
    for t in ticks:
        xx=x+(t-start)/(end-start)*w;d.line((xx,y-12,xx,y+12),fill=INK,width=3)
        tx(d,max(40,xx-25),y+20,str(t),38,MUTED)
    tx(d,x,y+83,label,40,MUTED)
def rect(d,x,y,w,h,label,c=TEAL,n=42):
    d.rectangle((x,y,x+w,y+h),fill=c)
    if label:tx(d,x+14,y+10,label,n,WHITE,True)
def save(im,n,k):
    im.save(Path(__file__).resolve().parent/f'lesson{n}-figure{k}.png',optimize=True)



def fig39_1():
    im,d=begin('One tick is not one full millisecond wait','Ideal tick-phase model at 1000 Hz; Ready is different from actually Running')
    axis(d,120,600,900,0,3,'Time (ms)',[0,1,2,3])
    for t in [0,1,2,3]:
        x=120+t*300;d.line((x,420,x,590),fill=TEAL,width=4)
    xcall=120+.4*300;d.line((xcall,410,xcall,590),fill=ORANGE,width=6)
    tx(d,100,310,'Call vTaskDelay(1) at 0.4 ms',44,ORANGE,True)
    arrow(d,[(xcall,820),(420,820)],ORANGE)
    tx(d,130,880,'Ideal blocked interval = 0.6 ms',44,ORANGE,True)
    box(d,90,1020,1020,235,'At the next tick: task becomes Ready',['Actual CPU execution may start later.','Interrupts and scheduling can delay the start.'],n=42)
    box(d,90,1360,1020,220,'Tick resolution is 1 ms in this project',['It does not prove a 1 ms response deadline.'],n=44)
    foot(d,'Diagram is a numerical example, not a target timestamp capture.');save(im,39,1)

def fig39_2():
    im,d=begin('Relative waiting adds work time','Isolated ideal worker: 20 ms work + 100 ms delay, with no interference or overhead')
    tx(d,90,300,'vTaskDelay starts after the work',44,TEAL,True)
    for k in range(3):
        yy=440+k*150;x=120+k*240
        rect(d,x,yy,40,80,'',ORANGE);rect(d,x+40,yy,200,80,'Wait 100',TEAL,38)
        tx(d,95,yy+85,f'Start {k}: {k*120} ms',40,MUTED)
    axis(d,120,950,900,0,450,'Model time (ms)',[0,100,200,300,400])
    tx(d,90,1120,'Start[k]=120k; phase error = 20k ms',44,TEAL,True)
    for k,(a,b) in enumerate([('Start 0','0 ms / phase 0 ms'),('Start 50','6000 ms / phase 1000 ms'),('Start 499','59880 ms / phase 9980 ms')]):
        yy=1240+k*110;tx(d,90,yy,a,42,ORANGE,True);tx(d,390,yy,b,42)
    foot(d,'500 starts in [0,60000) ms in this isolated model, not firmware data.');save(im,39,2)

def fig39_3():
    im,d=begin('Advance the absolute reference','Isolated ideal worker; actual task starts can be late despite a fixed release reference')
    tx(d,90,310,'next reference = old reference + 100 ticks',44,TEAL,True)
    for k in range(4):
        yy=440+k*150;x=120+k*200
        rect(d,x,yy,40,80,'',ORANGE);rect(d,x+40,yy,160,80,'Wait',TEAL,38)
        tx(d,90,yy+85,f'Start {k}: {k*100} ms',40,MUTED)
    axis(d,120,1110,900,0,450,'Model time (ms)',[0,100,200,300,400])
    box(d,90,1320,1020,275,'Model phase error: 0 ms',['600 starts in [0,60000) ms; last start 59900 ms.','Zero model phase error is not measured zero jitter.'],n=42)
    foot(d,'Work = 20 ms, ideal wait = 80 ms; no competing task or interrupt.');save(im,39,3)

def fig39_4():
    im,d=begin('No delay does not reset the reference','Illustrative late-work example: period 50 ticks; first work ends at tick 120')
    axis(d,120,500,900,0,150,'Kernel time (ticks)',[0,50,100,120,150])
    rect(d,120,350,720,80,'One long work interval: 120 ticks',ORANGE,42)
    tx(d,90,750,'Assume no extra work between these calls',42,MUTED)
    rows=[('Call 1 at 120','ref 0 -> 50','pdFALSE: no block'),('Call 2 at 120','ref 50 -> 100','pdFALSE: no block'),('Call 3 at 120','ref 100 -> 150','pdTRUE: block to 150')]
    for k,(a,b,c) in enumerate(rows):
        yy=850+k*235;box(d,90,yy,1020,190,a,[b+'; '+c],n=42)
    para(d,95,1550,'Reference advances; it does not reset to now.',1020,40,c=ORANGE)
    foot(d,'Counter of pdFALSE returns is not a count of missed periods.');save(im,39,4)

def fig39_5():
    im,d=begin('Capture valid samples','Measurement procedure only; no physical capture or instrument screenshot exists here')
    box(d,90,300,1020,235,'GB100ST outputs -> analyzer inputs',['PB6 / header 28 -> CH0: Relative','PB7 / header 31 -> CH1: Absolute; shared GND'],n=42)
    steps=[('1. Reset and run','No breakpoints during capture.'),('2. Nominal 60000 ticks','Window sets g_test_done=1 after suspending both.'),('3. Halt and export populated rows','Use each count; capacity 601 is not sample count.'),('4. Analyze tick data / inspect edges','Tick data is 1 ms; finer jitter needs an instrument.')]
    for k,(a,b) in enumerate(steps):
        yy=610+k*245;box(d,90,yy,1020,200,a,[b],n=42)
        if k<3:arrow(d,[(600,yy+205),(600,yy+235)])
    foot(d,'Use 3.3 V-compatible inputs; analyzer must not drive MCU outputs.');save(im,39,5)

def fig39_6():
    im,d=begin('Choose the timing mechanism','Counter resolution, ISR latency and physical edge jitter are different quantities')
    rows=[('Periodic task / xTaskDelayUntil',['This project: 1000 Hz tick -> 1 ms time grid.','Actual start also depends on scheduler and ISRs.']),('Hardware timer interrupt',['Counter step depends on timer clock and prescaler.','Executing the ISR still has processor latency.']),('Hardware output compare / PWM',['Configured edges do not need per-edge CPU code.','Clock quality and configuration still affect timing.'])]
    for k,(a,lines) in enumerate(rows):box(d,90,300+k*355,1020,290,a,lines,n=42)
    box(d,90,1390,1020,205,'Example counter step, not measured jitter',['72 MHz, PSC=0: 1/72000000 s = 13.9 ns nominal'],n=42)
    foot(d,'No universal jitter value or zero-CPU system claim is made.');save(im,39,6)

if __name__=="__main__":
    for k in range(1,7):globals()[f"fig39_{k}"]()

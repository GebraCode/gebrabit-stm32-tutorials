"""Editable original educational diagrams. Requires Pillow and Windows Segoe UI.
All timelines and waveforms are models, never captured hardware results.
Regenerates only this lesson's PNGs and image-metadata.json beside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, json, textwrap
OUT=Path(__file__).resolve().parent
LESSON=13
W,H=1200,1800
INK='#16354b';TEAL='#087f8c';ORANGE='#ac5c18';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c7d7e1';PALE='#e3f1f2';WHITE='#ffffff'
def font(n=43,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if bold else '')+'.ttf',n)
def tx(d,x,y,s,n=43,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1060,n=43,c=INK,b=False,gap=12):
    words=s.split();lines=[];line=''
    for word in words:
        test=(line+' '+word).strip()
        if d.textlength(test,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,sub='Original diagram / synthetic model'):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,38,title,1090,52,b=True)
    para(d,55,y+10,sub,1090,38,c=MUTED)
    d.line((55,185,1145,185),fill=LINE,width=3)
    return im,d
def footer(d,s='STM32F303CBT6 | Official manuals + exact F3 HAL'):
    d.line((55,H-165,1145,H-165),fill=LINE,width=3)
    para(d,55,H-140,s,1090,33,c=MUTED,gap=6)
    tx(d,55,H-50,'Original model. No board measurement or GUI capture.',32,MUTED)
def arrow(d,pts,c=TEAL,width=7):
    d.line(pts,fill=c,width=width)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+13,s,w-48,42)
    assert yy-18<=y+h+5,(title,yy,y+h)
def note(d,y,s,c=INK):return para(d,65,y,s,1070,43,c)
def save(im,i):im.save(OUT/f'lesson{LESSON}-figure{i}.png',optimize=True)
def axis(d,x0=160,y0=1150,x1=1110,y1=340,xlabel='Time ->',ylabel=None):
    arrow(d,[(x0,y0),(x1,y0)],INK,4);arrow(d,[(x0,y0),(x0,y1)],INK,4)
    tx(d,x1-230,y0+95,xlabel,39)
    if ylabel:tx(d,65,y1-70,ylabel,42,b=True)
def dots(d,x,y,count,active=None,step=70):
    for k in range(count):
        color=TEAL if active is None or k in active else LINE
        d.rounded_rectangle((x+k*step,y,x+k*step+step-9,y+70),8,fill=color)
def step(d,events,xmap,yhi,ylo,c=TEAL,width=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,yhi if last else ylo),(x,yhi if v else ylo)]);last=v
    d.line(pts,fill=c,width=width)
def ring(d,cx,cy,r=310,n=16,start=3,end=11):
    # Sectors represent groups of bytes, not a false256-cell screenshot.
    for k in range(n):
        d.pieslice((cx-r,cy-r,cx+r,cy+r),k*360/n-90,(k+1)*360/n-90,fill=TEAL if start<=k<end else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+100,cy-r+100,cx+r-100,cy+r-100),fill=BG)
def lineplot(d,points,x0,y0,xscale,yscale,c=TEAL):
    d.line([(x0+x*xscale,y0-y*yscale) for x,y in points],fill=c,width=7)

def lesson13():
    im,d=begin('Byte deadlines do not disappear','115200 baud, 8N1 | Conceptual service timeline')
    tx(d,65,235,'Each full frame: 10 /115200 = 86.8056us',46,b=True)
    for base,label,service in [(410,'A: RDR not serviced before next byte',False),(880,'B: ISR reads RDR before next byte',True)]:
        tx(d,65,base-80,label,43,b=True)
        x=lambda t:140+t/200*950
        d.line((140,base+130,1090,base+130),fill=INK,width=4)
        for t in [0,86.8056,173.6112]:
            xx=x(t);d.line((xx,base,xx,base+130),fill=LINE,width=3)
            tx(d,xx-20,base+155,str(round(t,1)),38)
        tx(d,65,base-10,'RDR',40,b=True)
        d.rectangle((x(0),base+45,x(86.8056),base+95),fill=TEAL)
        if service:
            d.rectangle((x(45),base+44,x(86.8056),base+96),fill=BG)
            arrow(d,[(x(45),base-35),(x(45),base+35)],ORANGE)
            tx(d,300,base-25,'Read (example order)',40,ORANGE)
            d.rectangle((x(86.8056),base+45,x(125),base+95),fill=TEAL)
            tx(d,550,base+240,'No fixed ISR latency claimed.',42,TEAL)
        else:
            d.rectangle((x(86.8056),base+45,x(130),base+95),fill=RED)
            tx(d,610,base+240,'Next completion: ORE risk',42,RED)
    tx(d,890,1295,'Time (us)',41,b=True)
    note(d,1410,'Interrupt reception still needs timely ISR service, prompt rearming and enough software buffer space.')
    footer(d,'RDR / ORE: RM0316 USART; timing is a model.');save(im,1)

    im,d=begin('USART IRQ dispatch: success and error')
    panel(d,70,230,1060,195,'USART1 request -> NVIC',['USART1_IRQHandler()','HAL_UART_IRQHandler(&huart1)'])
    arrow(d,[(600,435),(600,500)])
    d.polygon([(600,500),(980,610),(600,720),(220,610)],fill=WHITE,outline=INK,width=4)
    tx(d,370,575,'Status + enable bits',44,b=True)
    arrow(d,[(235,615),(160,615),(160,810)],TEAL)
    arrow(d,[(965,615),(1040,615),(1040,810)],RED)
    panel(d,65,820,520,330,'RX byte path',['HAL reads rx_byte','Check ErrorCode first','Enqueue; safe rearm'],TEAL)
    panel(d,615,820,520,330,'Error path',['Capture ErrorCode','ErrorCallback','mark recovery pending'],RED)
    arrow(d,[(325,1160),(325,1275),(600,1275)])
    arrow(d,[(875,1160),(875,1275),(600,1275)],RED)
    panel(d,70,1310,1060,230,'Application decisions',['Error and RX conditions can coexist.','Check pending recovery before rearming.'])
    footer(d,'Exact HAL order matters; this is a simplified dispatch map.');save(im,2)

    im,d=begin('One producer, one consumer','256-byte SPSC ring | One empty slot distinguishes Full')
    ring(d,600,610,start=3,end=11)
    tx(d,470,555,'255 usable',48,TEAL,True);tx(d,450,625,'not 256 bytes',43)
    arrow(d,[(1020,320),(875,420)],TEAL);tx(d,845,245,'head / ISR',42,TEAL,True)
    arrow(d,[(190,915),(335,810)],ORANGE);tx(d,65,955,'tail / main',42,ORANGE,True)
    tx(d,70,1100,'next = (head + 1) & 0xFF',47,b=True)
    tx(d,70,1190,'Empty: head == tail',45,TEAL,True)
    tx(d,70,1280,'Full: next == tail',45,ORANGE,True)
    note(d,1400,'ISR writes head; main writes tail. Publish data before the index; volatile alone is not a general synchronization guarantee.')
    footer(d,'Ring sectors are grouped visually; exact project uses256 slots.');save(im,3)

    im,d=begin('Recover once, then rearm','Error handling model | Match the delivered application')
    stages=[('Receiving','UART ISR moves bytes to software ring.'),('Error recorded','Save error bits; block ordinary RX rearm.'),('Recovery requested','Main aborts/stops the affected receive path.'),('State restored','Clear flags; flush ring; discard to line end.'),('Rearm checked','Start RX once; verify HAL_OK or count failure.')]
    for k,(a,b) in enumerate(stages):
        y=230+k*247;panel(d,85,y,1030,180,a,[b],RED if k==1 else TEAL)
        if k<4:arrow(d,[(600,y+185),(600,y+235)],RED if k==1 else TEAL)
    footer(d,'ORE / FE / NE / PE must be counted, not silently called lossless.');save(im,4)

    im,d=begin('Buffer capacity buys finite time','Model: continuous115200 8N1; consumer temporarily stopped')
    x0,y0=175,1150;xs=900/30;ys=700/300
    axis(d,x0,y0,1120,335,'Delay (ms)','Queued bytes')
    for t in [0,5,10,15,20,25,30]:
        x=x0+t*xs;d.line((x,y0,x,390),fill=LINE,width=2);tx(d,x-17,y0+25,str(t),38)
    for b in [0,64,128,192,255]:
        y=y0-b*ys;tx(d,65,y-25,str(b),38);d.line((x0,y,1095,y),fill=LINE,width=2)
    lineplot(d,[(0,0),(255/11.52,255)],x0,y0,xs,ys)
    d.line((x0,y0-255*ys,1090,y0-255*ys),fill=RED,width=5)
    xx=x0+(255/11.52)*xs;d.line((xx,390,xx,y0),fill=RED,width=4)
    tx(d,340,315,'Capacity limit:255 bytes',44,RED,True)
    tx(d,70,1295,'255 /11520 = 22.1354ms (ideal empty start)',44,b=True)
    note(d,1390,'A100ms blocking TX in main can overflow this ring during unpaced continuous input. ISR reception is not a lossless guarantee.',RED)
    footer(d,'Rate =11520 bytes/s; backlog and scheduling reduce free budget.');save(im,5)

    im,d=begin('IDLE is an event, not a packet checksum','Synthetic receive stream | Sender pacing is not guaranteed')
    tx(d,70,240,'RX frames and gaps',48,b=True)
    for j,(x,w,label) in enumerate([(95,190,'byte1'),(320,190,'byte2'),(760,190,'byte3')]):
        d.rectangle((x,385,x+w,495),fill=TEAL);tx(d,x+30,410,label,39,'white',True)
    arrow(d,[(95,540),(1110,540)],INK,3)
    arrow(d,[(540,600),(735,600)],ORANGE);tx(d,490,660,'Idle gap -> IDLE event',43,ORANGE,True)
    tx(d,65,820,'A PC can insert a gap inside one logical line.',43)
    tx(d,65,925,'Application framing is separate:',46,b=True)
    fields=[('SEQ',180),('DATA',260),('SUM8',220),('LF',140)]
    x=100
    for label,w in fields:
        d.rectangle((x,1060,x+w,1180),outline=INK,width=4,fill=WHITE);tx(d,x+22,1095,label,43,b=True);x+=w
    arrow(d,[(100,1250),(1030,1250)],INK,4)
    tx(d,70,1340,'Main: find LF; validate sequence and checksum.',43,TEAL,True)
    note(d,1440,'ReceiveToIdle_IT is a separate variant; its timeout or gap events do not by themselves prove a full valid application frame.')
    footer(d,'Model labels show logical fields, not a captured serial trace.');save(im,6)






def run():
    globals()[f'lesson{LESSON}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')



METADATA=[{'id': 1, 'filename': 'lesson13-figure1.png', 'alt': 'مهلت سرویس رجیستر دریافت UART', 'caption': 'نمودار زمانی تألیفی و مدل در نرخ 115200 و قالب 8N1؛ فاصلهٔ اسمی پایان فریم\u200cها 86.8056us است. وقفه مهلت خواندن RDR را حذف نمی\u200cکند؛ هیچ تأخیر 3us یا مشاهدهٔ ORE روی برد ادعا نمی\u200cشود.', 'purpose': 'چرا مهلت خواندن RDR با استفاده از وقفه حذف نمی\u200cشود؟', 'placement': 'بخش: چرا دریافت مسدودکننده (Blocking) بایت از دست میدهد؟', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 2, 'filename': 'lesson13-figure2.png', 'alt': 'انشعاب دریافت و خطای USART1 در HAL', 'caption': 'نقشهٔ تألیفی ساده\u200cشدهٔ مسیر USART1 تا HAL و callback؛ شرط خطا و دریافت می\u200cتوانند هم\u200cزمان برقرار باشند. در کد واقعی پیش از کپی و راه\u200cاندازی مجدد، HAL_UART_GetError بررسی می\u200cشود تا خطای بیرونی HAL پاک نشود.', 'purpose': 'مسیر دریافت و خطای USART1 چگونه به callback و تصمیم بازیابی می\u200cرسد؟', 'placement': 'بخش: معماری وقفه USART1 و تسلیح بایت\u200cبه\u200cبایت با HAL_UART_Receive_IT', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 3, 'filename': 'lesson13-figure3.png', 'alt': 'بافر حلقوی 256 بایتی و شاخص\u200cهای تولیدکننده و مصرف\u200cکننده', 'caption': 'مدل تألیفی SPSC با ظرفیت قابل استفادهٔ 255 بایت؛ ISR تنها نویسندهٔ head و main تنها نویسندهٔ tail است. داده با DMB پیش از انتشار شاخص مرتب می\u200cشود؛ volatile به\u200cتنهایی تضمین هم\u200cزمانی عمومی نیست. قطعه\u200cهای حلقه نمایش گروهی هستند، نه 256 خانهٔ مجزا.', 'purpose': 'چرا رینگ 256 خانه\u200cای ظرفیت 255 بایت دارد و مالک شاخص\u200cها کیست؟', 'placement': 'بخش: بافر حلقوی SPSC: ساختار، شاخصها و دسترسی امن بین ISR و حلقه اصلی', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 4, 'filename': 'lesson13-figure4.png', 'alt': 'ترتیب بازیابی خطای دریافت و راه\u200cاندازی دوباره', 'caption': 'ماشین حالت تألیفی مطابق سیاست پروژه: ثبت خطا در ISR، جلوگیری از rearm عادی، AbortReceive در main، پاک\u200cسازی وضعیت و تخلیهٔ دادهٔ ناقص و همگام\u200cسازی تا انتهای خط، سپس بررسی نتیجهٔ دریافت مجدد. داده\u200cهای قربانی\u200cشده برای همگام\u200cسازی شمرده می\u200cشوند.', 'purpose': 'برنامه پس از خطای دریافت چگونه یک\u200cبار همگام\u200cسازی و دریافت را راه\u200cاندازی می\u200cکند؟', 'placement': 'بخش: خطاهای سخت\u200cافزاری دریافت (ORE, FE, NE, PE) و راهبرد بازیابی', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 5, 'filename': 'lesson13-figure5.png', 'alt': 'بودجهٔ زمانی بافر 255 بایتی در دریافت پیوسته', 'caption': 'نمودار محاسباتی تألیفی با بافر ابتدا خالی و main موقتاً متوقف؛ در نرخ 11520bytes/s ظرفیت 255 بایتی تقریباً 22.1354ms فرصت می\u200cدهد. ارسال مسدودکنندهٔ ACK با timeout برابر 100ms در main می\u200cتواند با ورودی بدون کنترل جریان بافر را سرریز کند؛ نمودار اندازه\u200cگیری نیست.', 'purpose': 'بافر ابتداخالی 255 بایتی در دریافت پیوسته چه بودجهٔ انباشت محدودی دارد؟', 'placement': 'بخش: تجزیه فرمانهای خطی در حلقه اصلی و راستی\u200cآزمایی پروتکل', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 6, 'filename': 'lesson13-figure6.png', 'alt': 'تفاوت رخداد IDLE با مرز و اعتبار پیام', 'caption': 'مدل تألیفی جریان بایت\u200cها: مکث فرستنده می\u200cتواند داخل پیام رخ دهد. نسخهٔ واقعی ReceiveToIdle_IT با دستهٔ حداکثر 32 بایت نیز DMA نیست؛ پروتکل خطی S,seq,hex,sum8 با پایان خط و checksum و شمارهٔ توالی در main اعتبارسنجی می\u200cشود.', 'purpose': 'چرا IDLE به\u200cتنهایی مرز و صحت پیام را تعیین نمی\u200cکند؟', 'placement': 'بخش: دریافت تا خط بیکار (ReceiveToIdle) و تفکیک مرز بسته', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}]
if __name__=='__main__':run()

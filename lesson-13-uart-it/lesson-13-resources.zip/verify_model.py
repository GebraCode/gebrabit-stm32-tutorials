import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json
from protocol_model import Parser,Ring,frame,validate
p=Parser();stream=b''.join(frame(i,bytes(range(i%33)),b'\r\n') for i in range(100))
for byte in stream:p.feed(bytes([byte]))
assert len(p.accepted)==100 and p.discontinuities==p.invalid==p.overflows==0
idle=Parser()
for i in range(0,len(stream),32):idle.feed(stream[i:i+32])
assert idle.accepted==p.accepted
assert validate(frame(0xffffffff,b'')[:-1])[0]==0xffffffff
wrap=Parser();wrap.feed(frame(0xffffffff)+frame(0));assert wrap.discontinuities==0
bad=bytearray(frame(1,b'ab'));bad[4]^=1;assert validate(bytes(bad[:-1])) is None
q=Parser();q.feed(b'X'*96+b'\n'+frame(2));assert q.overflows==1 and len(q.accepted)==1
q=Parser();q.feed(frame(3)[:-1]+b'\0trash\n'+frame(4));assert q.invalid==1 and q.accepted[0][0]==4
q=Parser();q.feed(frame(5)[:5]);q.resync();q.feed(frame(5)[5:]+frame(6));assert [x[0] for x in q.accepted]==[6]
r=Ring();assert all(r.push(i&255) for i in range(255));assert not r.push(1) and r.drops==1
assert [r.pop() for _ in range(255)]==list(range(255));assert r.pop() is None
for i in range(1000):assert r.push(i&255) and r.pop()==(i&255)
q=Parser();q.feed(frame(1)+frame(3));assert q.discontinuities==1
assert validate(b'S,4294967296,,00') is None and validate(b'S,1,F,00') is None
# Error-before-rearm ordering regression: arming clears ErrorCode, so never arm an errored completion.
def completion(error):return {'save_error':error,'rearm':error==0,'copy':error==0,'recover':error!=0}
assert completion(8)==dict(save_error=8,rearm=False,copy=False,recover=True)
result={'scope':'Pure protocol/ring arithmetic and callback-order decision model; not hardware or interrupt timing','checks_passed':['100 frames streamed byte by byte','32byte-IDLE chunk equivalence','sequence uint32 wrap','sum8 corruption detection example','line overflow discard','NUL/nonprintable rejection','recovery discard toEOL','ring255 capacity','ring wrap1000','sequence discontinuity detection','malformed bounds','error-before-rearm guard'],'model_frames_accepted':len(p.accepted),'ring_size':256,'usable_capacity':255,'line_buffer_size':96,'payload_max_bytes':32,'checksum':'sum8 ASCII prefix; not CRC or collision-free integrity guarantee'}
(Path(__file__).parent/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

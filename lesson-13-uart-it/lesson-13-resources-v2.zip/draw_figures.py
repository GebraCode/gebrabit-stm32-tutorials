"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=13
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Interrupt reception still has limits','Qualitative scheduling model; incoming 115200 / 8N1 frames are nominal 86.8 us')
 tx(d,75,300,'Incoming byte frames',46,TEAL,True)
 for k in range(4):panel(d,75+k*270,430,245,150,f'Byte {k+1}',())
 tx(d,75,720,'Polling main can be busy elsewhere',46,ORANGE,True)
 d.rounded_rectangle((75,850,1125,1050),15,fill=WHITE,outline=ORANGE,width=4)
 tx(d,110,900,'TX / printf / other work -> delayed RDR read',42)
 tx(d,75,1180,'IT reception moves byte service into IRQ handling',44,TEAL,True)
 for k in range(4):
  x=75+k*270;d.rectangle((x,1300,x+100,1410),fill=TEAL);tx(d,x+15,1440,'IRQ',40,TEAL,True)
 tx(d,75,1560,'IRQ latency, re-arm gaps and full queues still impose limits.',40)
 foot(d,'No 2 us service claim or exact hardware-overrun time is implied.');save(im,1)
def figure2():
 im,d=begin('Check error evidence before any re-arm','Actual single-byte IT receive path, shortened to its ordering essentials')
 steps=[('USART1 IRQ -> HAL_UART_IRQHandler','RXNE service reads RDR into the 1-byte buffer.'),('Completion: check ErrorCode first','Error? Request recovery and return.'),('Clean byte -> Ring_Push','ISR publishes data before advancing head.'),('Checked Start_Rx -> Receive_IT again','Re-arm failure requests deferred recovery.'),('Main consumes and parses later','No parsing, printf or TX in this callback.')]
 for k,(a,b)in enumerate(steps):
  y=290+k*255;panel(d,75,y,1050,195,a,[b])
  if k<4:arrow(d,[(600,y+205),(600,y+245)])
 foot(d,'A new start clears HAL ErrorCode; the guard must precede it.');save(im,2)
def figure3():
 im,d=begin('Separate producer and consumer ownership','A schematic 256-slot ring; the highlighted occupancy is only an example')
 center=(600,820);r=300
 for k in range(16):
  a=math.radians(k*22.5-90);b=math.radians((k+1)*22.5-90)
  pts=[center,(600+r*math.cos(a),820+r*math.sin(a)),(600+r*math.cos(b),820+r*math.sin(b))]
  d.polygon(pts,fill=PALE if k<4 or k>=14 else WHITE,outline=LINE,width=3)
 d.ellipse((435,655,765,985),fill=BG,outline=LINE,width=3)
 tx(d,460,740,'256 slots',46,TEAL,True);tx(d,460,825,'255 usable',44,TEAL,True)
 arrow(d,[(1040,820),(920,820)]);tx(d,850,955,'Head: ISR',42,TEAL,True)
 arrow(d,[(210,430),(350,600)],ORANGE);tx(d,75,350,'Tail: main',44,ORANGE,True)
 tx(d,75,1190,'Empty: head == tail',45,TEAL,True)
 tx(d,75,1290,'Full: ((head + 1) & 255) == tail',45,TEAL,True)
 tx(d,75,1420,'Initially empty budget: 255 / 11520 = 22.1354 ms',42)
 tx(d,75,1520,'DMB orders data/head and read/tail on this single core.',40)
 foot(d,'The budget is not a guaranteed maximum processing latency.');save(im,3)
def figure4():
 im,d=begin('IDLE is inactivity, not a packet delimiter','Actual alternative uses ReceiveToIdle_IT with a 32-byte batch; no DMA')
 tx(d,75,300,'Short batch ends on an IDLE event',46,TEAL,True)
 for k in range(3):panel(d,75+k*240,420,210,150,f'Byte {k+1}',())
 d.line((820,495,1120,495),fill=ORANGE,width=7);tx(d,820,590,'Idle gap',42,ORANGE,True)
 arrow(d,[(950,670),(950,780)],ORANGE)
 tx(d,75,820,'Event callback receives Size in 1..32, then re-arms.',42)
 tx(d,75,1020,'A full 32-byte batch also ends the request',46,TEAL,True)
 for k in range(8):d.rectangle((75+k*130,1150,190+k*130,1260),fill=TEAL)
 tx(d,75,1310,'32 bytes received -> Size=32, even without an IDLE gap',40)
 panel(d,75,1440,1050,170,'Application framing stays in main',['CR / LF protocol rules define complete commands.'])
 foot(d,'No immediate callback or protocol packet boundary is promised.');save(im,4)
def figure5():
 im,d=begin('Defer recovery and discard uncertain data','Actual conservative policy; notified errors are not all identical in HAL')
 steps=[('ISR detects or is notified of error','Aggregate flags / counters; set recovery_pending.'),('Main Service_Recovery','Save PRIMASK and briefly mask configurable IRQs.'),('AbortReceive and flush stale data','Discard ring and partial line; resynchronize to EOL.'),('Checked restart, then restore saved mask','A restarted receiver does not recover discarded bytes.')]
 for k,(a,b)in enumerate(steps):
  y=300+k*310;panel(d,75,y,1050,225,a,[b])
  if k<3:arrow(d,[(600,y+240),(600,y+300)])
 tx(d,75,1570,'ORE can block IT; other errors may notify while continuing.',40)
 foot(d,'Parity errors are not physically tested with parity disabled.');save(im,5)
def figure6():
 im,d=begin('Separate parser bounds and receive losses','The parser runs in main; neither queue overflow nor error recovery is lossless')
 panel(d,75,300,1050,285,'96-byte line buffer: 95 chars + NUL',['Printable input; CR / LF / CRLF ends the line.','Protocol: S,seq,hexpayload,sum8; then ACK on a valid line.'])
 panel(d,75,680,490,420,'Software queue full',['Ring drops new byte.','loss_epoch changes.','Flush queue / partial line; discard to EOL.'])
 panel(d,650,680,480,370,'Hardware ORE',['RDR not serviced.','Defer error recovery.','Main delay != ORE.'])
 panel(d,75,1220,1050,360,'Proposed tests, not board observations',['Delayed main -> software ring overflow.','Mask USART1 IRQ only -> investigate ORE.','Keep SysTick active; declare host rate and window.'])
 foot(d,'sum8 and sequence checks do not prove detection of every loss.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson13-refresh-figure1.png', 'alt': 'فاصلهٔ سرویس\u200cدهی در polling و دریافت وقفه\u200cای', 'caption': 'مدل کیفی تألیفی فریم\u200cهای ورودی اسمی 86.8 us در 115200 و 8N1 و فاصلهٔ رسیدگی main هنگام TX و کار دیگر. دریافت IT سرویس بایت را به IRQ می\u200cبرد اما تأخیر وقفه و فاصلهٔ re-arm و صف پر همچنان محدودیت دارند. عرض بخش\u200cهای IRQ زمان واقعی نیست و سرویس 2 us یا لحظهٔ دقیق ORE ادعا نشده است.', 'purpose': 'فاصلهٔ سرویس\u200cدهی در polling و دریافت وقفه\u200cای', 'placement': 'بخش آسیب\u200cشناسی دریافت مسدودکننده (Polling) در سیستم\u200cهای بلادرنگ', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson13twoITv2sources', 'scope': 'HALIRQcompletion/error/rearm, IDLEIT, sourcequeue/parser/deferredrecovery'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'USARTRDR/RXNE/ORE/IDLEconcepts'}, {'url': 'local:calculate_budget.py and verify_model.py', 'version': 'Fresh3budgetassertions and12modelgroups', 'scope': '255usablebuffer/nominalbudget andboundedprotocol; notboardtiming'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Qualitativeframes/servicegaps, no2usCPUtime or173.6usOREdeadline orzeroLossguarantee.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson13-refresh-figure2.png', 'alt': 'ترتیب بررسی خطا و صف و re-arm تک\u200cبایتی', 'caption': 'نمودار تألیفی ترتیب مسیر واقعی: HAL داده را از RDR می\u200cگیرد؛ completion callback ابتدا ErrorCode را بررسی می\u200cکند و فقط بایت سالم را در صف منتشر و دریافت را دوباره آماده می\u200cکند. Start جدید ErrorCode را پاک می\u200cکند، بنابراین بررسی خطا باید پیش از copy و re-arm باشد. شکست re-arm به بازیابی main ارجاع می\u200cشود.', 'purpose': 'ترتیب بررسی خطا و صف و re-arm تک\u200cبایتی', 'placement': 'بخش دریافت وقفه\u200cای تک\u200cبایتی و زنجیرهٔ آماده\u200cسازی مجدد (Re-arm)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson13twoITv2sources', 'scope': 'HALIRQcompletion/error/rearm, IDLEIT, sourcequeue/parser/deferredrecovery'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'USARTRDR/RXNE/ORE/IDLEconcepts'}, {'url': 'local:calculate_budget.py and verify_model.py', 'version': 'Fresh3budgetassertions and12modelgroups', 'scope': '255usablebuffer/nominalbudget andboundedprotocol; notboardtiming'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualonebyteIT/errorguardbeforecopy+rearm, checkedStart_Rx, ISRnocallbackparsing/TXprintf.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson13-refresh-figure3.png', 'alt': 'مالکیت شاخص\u200cها و ظرفیت بافر حلقوی', 'caption': 'مدل شماتیک تألیفی حلقهٔ 256 خانه\u200cای با 255 بایت ظرفیت قابل استفاده؛ بخش رنگی فقط مثال occupancy است و هر قطاع یک بایت نیست. ISR تولیدکنندهٔ head و main مصرف\u200cکنندهٔ tail است و DMB ترتیب انتشار را در الگوی تک\u200cهسته\u200cای واقعی حفظ می\u200cکند. بودجهٔ حدود 22.1354 ms تنها برای backlog ایدئال صفِ ابتدا خالی است و حد تضمین\u200cشدهٔ تأخیر نیست.', 'purpose': 'مالکیت شاخص\u200cها و ظرفیت بافر حلقوی', 'placement': 'بخش ساختار بافر حلقوی (Ring Buffer) تک\u200cنویسنده تک\u200cخواننده (SPSC)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson13twoITv2sources', 'scope': 'HALIRQcompletion/error/rearm, IDLEIT, sourcequeue/parser/deferredrecovery'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'USARTRDR/RXNE/ORE/IDLEconcepts'}, {'url': 'local:calculate_budget.py and verify_model.py', 'version': 'Fresh3budgetassertions and12modelgroups', 'scope': '255usablebuffer/nominalbudget andboundedprotocol; notboardtiming'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actualalignedvolatileuint32head/tail SPSC+DMB, notgeneralC11lockfreeclaim. Oneunusedslot256/255, emptyideal255/11520=22.1354ms; occupancy/IRQs/rearmmatter.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson13-refresh-figure4.png', 'alt': 'پایان batch با IDLE یا پرشدن 32 بایت', 'caption': 'نمودار تألیفی نوع دوم واقعی ReceiveToIdle_IT با batch برابر 32 بایت و بدون DMA. IDLE نشانهٔ بیکاری است، نه مرز قطعی بسته؛ بافر پر هم رویداد می\u200cدهد و Size در 1..32 بررسی و سپس دریافت دوباره آماده می\u200cشود. callback فوری یا بدون فاصله تضمین نشده و framing پروتکل در main باقی می\u200cماند.', 'purpose': 'پایان batch با IDLE یا پرشدن 32 بایت', 'placement': 'بخش دریافت بسته با طول متغیر به کمک تشخیص خط بیکار (ReceiveToIdle)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson13twoITv2sources', 'scope': 'HALIRQcompletion/error/rearm, IDLEIT, sourcequeue/parser/deferredrecovery'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'USARTRDR/RXNE/ORE/IDLEconcepts'}, {'url': 'local:calculate_budget.py and verify_model.py', 'version': 'Fresh3budgetassertions and12modelgroups', 'scope': '255usablebuffer/nominalbudget andboundedprotocol; notboardtiming'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual32byteIDLE_ITnotDMA, bothfull/IDLEcompletion, rearmgap; eventSize1..32, IDLEnotpacketdelimiter.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson13-refresh-figure5.png', 'alt': 'بازیابی تعویقی و کنارگذاشتن دادهٔ نامطمئن', 'caption': 'روندنمای تألیفی سیاست محافظه\u200cکارانهٔ واقعی: callback خطا فقط شاهدها و درخواست بازیابی را ثبت می\u200cکند؛ main با ذخیره و بازگرداندن PRIMASK دریافت را abort و دادهٔ مانده و صف و خط ناقص را دور می\u200cریزد و restart بررسی\u200cشده انجام می\u200cدهد. همهٔ خطاها در HAL یکسان متوقف\u200cکننده نیستند و بازیابی داده\u200cهای حذف\u200cشده را برنمی\u200cگرداند.', 'purpose': 'بازیابی تعویقی و کنارگذاشتن دادهٔ نامطمئن', 'placement': 'بخش خطاهای دریافت سخت\u200cافزاری و الگوی بازیابی بدون قفل (Lock-free Recovery)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson13twoITv2sources', 'scope': 'HALIRQcompletion/error/rearm, IDLEIT, sourcequeue/parser/deferredrecovery'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'USARTRDR/RXNE/ORE/IDLEconcepts'}, {'url': 'local:calculate_budget.py and verify_model.py', 'version': 'Fresh3budgetassertions and12modelgroups', 'scope': '255usablebuffer/nominalbudget andboundedprotocol; notboardtiming'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'OREcanblockIT; FE/NE/PEcancontinuenotify, actualallnotifiederrorsdeferrecovery. Noalwaysautohardwarestop/errorguaranteedrecovery; parityoffnophysicalPEtest.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson13-refresh-figure6.png', 'alt': 'مرز خط فرمان و تفاوت سرریز صف و ORE', 'caption': 'نمودار تألیفی parser محدود 96 بایتی با 95 کاراکتر و NUL و پایان CR/LF/CRLF. پرشدن صف نرم\u200cافزاری loss_epoch و resync ایجاد می\u200cکند و الزاماً ORE سخت\u200cافزاری نیست؛ ORE به سرویس\u200cنشدن RDR مربوط است. تأخیر مصرف main و ماسک\u200cکردن فقط IRQ UART دو پیشنهاد آزمون جدا هستند و روی برد انجام نشده\u200cاند. sum8 و sequence تضمین تشخیص همهٔ خطاها یا اتلاف\u200cها نیستند.', 'purpose': 'مرز خط فرمان و تفاوت سرریز صف و ORE', 'placement': 'بخش تجزیهٔ فرمان\u200cهای متنی (Parser) در حلقهٔ اصلی و سناریوهای آزمایشی', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson13twoITv2sources', 'scope': 'HALIRQcompletion/error/rearm, IDLEIT, sourcequeue/parser/deferredrecovery'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'USARTRDR/RXNE/ORE/IDLEconcepts'}, {'url': 'local:calculate_budget.py and verify_model.py', 'version': 'Fresh3budgetassertions and12modelgroups', 'scope': '255usablebuffer/nominalbudget andboundedprotocol; notboardtiming'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualboundedASCIIprotocol/95chars+NUL, loss_epochflush+discardtoEOL. ProposedUSART1IRQmaskOREtestnotcompiledhookclaim, notmain-taildelay==ORE; no hardwaretest.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

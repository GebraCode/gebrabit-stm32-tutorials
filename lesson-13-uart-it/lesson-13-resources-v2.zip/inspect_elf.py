"""Inspect real ELF32 ARM symbols and debug-section presence offline, using stdlib.

Reads lesson-13-build-artifacts-v2.zip beside this script. This does not execute the
firmware or connect to a debugger/board. It does not decode variable locations
from DWARF or promise that a live debugger can display an optimized local.
"""
from pathlib import Path
import struct,json,zipfile

def cstr(data,offset):
    end=data.find(b'\0',offset)
    return data[offset:end].decode('utf8',errors='replace')

def inspect(data):
    assert data[:6]==b'\x7fELF\x01\x01','Expected ELF32 little-endian'
    h=struct.unpack_from('<16sHHIIIIIHHHHHH',data)
    assert h[2]==40,'Expected ARM machine'
    shoff,shentsize,shnum,shstrndx=h[6],h[11],h[12],h[13]
    sections=[struct.unpack_from('<IIIIIIIIII',data,shoff+i*shentsize) for i in range(shnum)]
    names_header=sections[shstrndx]
    names=data[names_header[4]:names_header[4]+names_header[5]]
    named=[(cstr(names,s[0]),s) for s in sections]
    debug={name:s[5] for name,s in named if name.startswith('.debug_')}
    symbols={}
    keep={'rx_head','rx_tail','rx_ring','ring_drops','uart_errors','main'}
    for name,s in named:
        if s[1]!=2:continue
        strheader=sections[s[6]]
        strings=data[strheader[4]:strheader[4]+strheader[5]]
        for off in range(s[4],s[4]+s[5],s[9]):
            stname,value,size,info,other,index=struct.unpack_from('<IIIBBH',data,off)
            sym=cstr(strings,stname)
            if sym in keep:symbols[sym]={'address':f'0x{value:08X}','size_bytes':size,'section_index':index}
    assert all(k in symbols for k in ['rx_head','rx_tail','rx_ring','ring_drops','uart_errors','main'])
    assert '.debug_info' in debug and '.debug_line' in debug
    return {'machine':'ARM ELF32 little-endian','entry_address':f'0x{h[4]:08X}','debug_section_sizes':debug,'selected_symbols':symbols,'validation':'offline metadata inspection only; no board execution or target debugger observations'}

if __name__=='__main__':
    root=Path(__file__).resolve().parent
    with zipfile.ZipFile(root/'lesson-13-build-artifacts-v2.zip') as z:
        result={name:inspect(z.read(name)) for name in z.namelist() if name.endswith('.elf')}
    assert len(result)==2
    (root/'elf-inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result,indent=2))

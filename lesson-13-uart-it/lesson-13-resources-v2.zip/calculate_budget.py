"""Ideal wire/queue arithmetic only; not interrupt latency or no-loss verification."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json
from protocol_model import frame

baud=115200
bits_per_frame=10
byte_rate=baud/bits_per_frame
ring_capacity=255
backlog_ms=ring_capacity/byte_rate*1000
assert byte_rate==11520 and abs(backlog_ms-22.135416666666668)<1e-12
longest=frame(0xffffffff,bytes(range(32)),b'\r\n')
assert len(longest)==82 and len(longest)-2==80
ack=b'A,4294967295,FF\r\n'
assert len(ack)==17 and len(ack)<32
result={
 'scope':'Ideal8N1 wire arithmetic with initially empty queue. No real timing, board throughput, or zero-loss guarantee.',
 'baud':baud,'bits_per_frame':bits_per_frame,'ideal_byte_period_us':1e6/byte_rate,
 'ideal_one_direction_bytes_per_second':byte_rate,'ring_usable_capacity':ring_capacity,
 'empty_ring_ideal_backlog_ms':backlog_ms,'configured_main_TX_timeout_ms':100,
 'largest_protocol_line_without_EOL_bytes':80,'largest_frame_CRLF_bytes':len(longest),
 'largest_ACK_bytes':len(ack),'largest_ACK_ideal_wire_ms':len(ack)/byte_rate*1000,
 'warning':'Actual queue occupancy, IRQ masking/service/rearm gaps, parser/TX work and sender bursts limit behavior. Sum8 and sequence checks do not detect all corruption or quantify every lost byte.'
}
(Path(__file__).parent/'budget-calculations.json').write_text(json.dumps(result,indent=2)+'\n','utf8')
print(json.dumps(result,indent=2))

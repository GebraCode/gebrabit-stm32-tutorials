"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent

LESSON=30
def save(im,n):im.save(OUT/f'lesson30-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Choose what must survive sleep','Functional retention map for STM32F303CB; no current comparison is measured')
 rows=[('Sleep','CPU clock stopped','Enabled peripherals can keep clocks','SRAM and execution context kept'),('Stop','HSI / HSE / PLL stopped','LSE / LSI RTC can remain enabled','32 KiB main + 8 KiB CCM retained'),('Standby','1.8 V domain powered down','SRAM and CPU context lost','Backup survives only with supply')]
 for k,(a,b,c,e)in enumerate(rows):
  yy=290+k*410;panel(d,75,yy,1050,330,a,[b,c,e])
  if k<2:arrow(d,[(600,yy+340),(600,yy+395)])
 foot(d,'Stop resumes code; Standby wakes through a reset-style boot.');save(im,1)
def figure2():
 im,d=begin('Restore the clock after Stop','Actual source order; hardware returns with HSI, not the previous 72 MHz PLL')
 steps=[('Suspend tick; saved PRIMASK check','Short protected event check -> Stop WFI'),('Restore interrupt mask on return','SystemCoreClockUpdate -> record HSI HCLK'),('Rebuild the time base at HSI','HAL_InitTick -> HAL_ResumeTick'),('Restore generated 72 MHz clock','SystemClock_Config with working tick / IRQs'),('Check the requested event','Spurious return: suspend tick and wait again')]
 for k,(a,b)in enumerate(steps):
  yy=285+k*260;panel(d,75,yy,1050,215,a,[b])
  if k<4:arrow(d,[(600,yy+220),(600,yy+250)])
 foot(d,'ResumeTick alone does not recalculate a stale SysTick reload.');save(im,2)
def figure3():
 im,d=begin('Standby wakes through the reset path','Actual wake sources: RTC wakeup timer and PA0 WKUP1 rising edge')
 panel(d,75,290,1050,220,'Prepare the wake sources',['Disable retained Alarm A/B; configure own RTC WUT.','Clear required RTC / EXTI / NVIC / PWR flags.'])
 arrow(d,[(600,525),(600,590)])
 panel(d,75,610,1050,220,'PA0 must begin LOW',['External 10 kOhm to GND is required for this setup.','Firmware refuses entry while PA0 is HIGH.'])
 arrow(d,[(600,850),(600,930),(300,930),(300,1010)]);arrow(d,[(600,930),(900,930),(900,1010)])
 panel(d,65,1030,470,240,'PA0 rising',['WKUP1 event','PA3 is not WKUP1'])
 panel(d,665,1030,470,240,'RTC WUT',['Reload 9 / 1 Hz','Nominal 10 s'])
 arrow(d,[(300,1290),(300,1380),(600,1380),(600,1430)]);arrow(d,[(900,1290),(900,1380),(600,1380)])
 panel(d,75,1450,1050,150,'Reset boot: inspect saved SBF / WUF / RCC flags',())
 foot(d,'WUF alone does not identify the exact wake cause.');save(im,3)
def figure4():
 im,d=begin('Avoid a floating digital input','Conceptual input-buffer model; the firmware does not set every pin to analog')
 tx(d,75,300,'Digital input left without a defined level',44,ORANGE,True)
 d.line((130,600,470,600),fill=ORANGE,width=6)
 pts=[(130+k*8,600+70*__import__('math').sin(k*.25))for k in range(40)]
 d.line(pts,fill=ORANGE,width=5)
 d.polygon([(500,470),(500,730),(700,600)],outline=INK,width=5)
 arrow(d,[(700,600),(1090,600)]);tx(d,770,680,'May toggle',42,ORANGE)
 tx(d,75,860,'Analog mode: digital input buffer disabled',44,TEAL,True)
 d.line((130,1100,470,1100),fill=MUTED,width=5)
 d.polygon([(500,970),(500,1230),(700,1100)],outline=MUTED,width=5)
 d.line((480,950,720,1250),fill=RED,width=9)
 tx(d,770,1060,'No digital',40,TEAL);tx(d,770,1120,'buffer path',40,TEAL)
 panel(d,75,1380,1050,240,'Select unused pins carefully',['Keep SWD, wake, crystals and board-driven nets.','Analog mode does not mean zero leakage.'])
 foot(d,'Configure real pin roles; never blanket-change every GPIO.');save(im,4)
def figure5():
 im,d=begin('Finish the UART frame before gating clocks','Conceptual USART pipeline; blocking HAL transmit waits for TC on HAL_OK')
 panel(d,75,300,1050,180,'CPU writes TDR',())
 arrow(d,[(600,500),(600,570)])
 panel(d,75,590,1050,240,'Shift register sends the frame',['TXE: transmit data register is empty.','The last frame can still be on the wire.'])
 tx(d,75,930,'Model TX line: start / 8 data / stop',44,TEAL,True)
 bits=[1,0,1,0,1,0,0,1,0,1,1];pts=[]
 for k,b in enumerate(bits):
  x=95+k*92;y=1100 if b else 1200
  if pts:pts.append((x,y))
  pts.extend([(x,y),(x+92,y)])
 d.line(pts,fill=TEAL,width=6)
 dashed(d,1107,1000,1107,1290);tx(d,1050,1300,'TC',44,ORANGE,True)
 panel(d,75,1410,1050,195,'TC: transmission complete',['Check with working tick before Stop / Standby.'])
 foot(d,'Sleep does not automatically gate the USART clock.');save(im,5)
def figure6():
 im,d=begin('Measure the whole board at the right rail','Symbolic current budget; there are no invented mA or uA measurements')
 tx(d,75,300,'5 V input current includes board overhead',46,TEAL,True)
 arrow(d,[(600,400),(600,510),(300,510),(300,580)]);arrow(d,[(600,510),(900,510),(900,580)])
 panel(d,65,600,470,265,'AMS1117',['Regulator overhead','Depends on load'])
 panel(d,665,600,470,265,'Power LED',['3V3 -> R13=560 Ohm','Red LED -> GND'])
 arrow(d,[(600,860),(600,970)])
 panel(d,75,990,1050,290,'Total: MCU + regulator + LED + external',['Turn PB6 LED off; account for probes and back-power.','5 V board current is not a 3V3 MCU-only result.'])
 panel(d,75,1360,1050,245,'Stock backup rail has no battery',['VBAT pin 1 -> R11=0 Ohm -> 3V3; C4=1 uF.','Full board power loss removes backup power too.'])
 foot(d,'Record voltage, mode, temperature and external connections.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson30-refresh-figure1.png', 'alt': 'حفظ کلاک و حافظه در سه حالت توان', 'caption': 'نمودار عملکردی تألیفی Sleep، Stop و Standby برای STM32F303CB: حافظهٔ اصلی 32 KiB و CCM برابر 8 KiB است. Stop زمینهٔ اجرا را نگه می\u200cدارد و Standby مسیر بوت شبیه reset دارد؛ نگهداری backup وابسته به تغذیه است. نمودار جریان اندازه\u200cگیری\u200cشده یا جدول مصرف عددی نیست.', 'purpose': 'حفظ کلاک و حافظه در سه حالت توان', 'placement': 'FIGURE_1', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 2, 'filename': 'lesson30-refresh-figure2.png', 'alt': 'ترتیب واقعی بازیابی پس از Stop', 'caption': 'روندنمای تألیفی منطبق با کد نهایی: تعلیق tick و بررسی کوتاه محافظت\u200cشده، WFI، بازگرداندن PRIMASK، SystemCoreClockUpdate، HAL_InitTick و HAL_ResumeTick در HSI، سپس SystemClock_Config برای 72 MHz. بازگشت بدون رویداد معتبر دوباره وارد انتظار می\u200cشود. ResumeTick به\u200cتنهایی reload قدیمی را اصلاح نمی\u200cکند؛ اجرا روی برد مشاهده نشده است.', 'purpose': 'ترتیب واقعی بازیابی پس از Stop', 'placement': 'FIGURE_2', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 3, 'filename': 'lesson30-refresh-figure3.png', 'alt': 'ورود و بیداری Standby با PA0 و RTC', 'caption': 'روندنمای تألیفی بیداری Standby با WKUP1 روی لبهٔ بالاروندهٔ PA0 و WUT اسمی 10 s. مقاومت خارجی 10 kOhm به GND برای این اتصال لازم است؛ pull-down اولیهٔ GPIO تضمین وضعیت Standby نیست. برنامه ورود با PA0 بالا را رد و Alarm A/B باقی\u200cمانده را غیرفعال می\u200cکند. PA3 کلید EXTI است، نه WKUP1؛ WUF به\u200cتنهایی علت دقیق را اثبات نمی\u200cکند.', 'purpose': 'ورود و بیداری Standby با PA0 و RTC', 'placement': 'FIGURE_3', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 4, 'filename': 'lesson30-refresh-figure4.png', 'alt': 'ورودی شناور در برابر بافر دیجیتال غیرفعال', 'caption': 'مدل مفهومی تألیفی ورودی دیجیتال بدون سطح تعریف\u200cشده و غیرفعال\u200cشدن بافر دیجیتال در analog mode. شکل مدار داخلی واقعی یا جریان اندازه\u200cگیری\u200cشده نیست؛ analog به معنی نشتی صفر نیست. کد همهٔ پین\u200cها را analog نمی\u200cکند و نقش\u200cهای SWD، wake، کریستال و مدارهای برد باید حفظ شوند.', 'purpose': 'ورودی شناور در برابر بافر دیجیتال غیرفعال', 'placement': 'FIGURE_4', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 5, 'filename': 'lesson30-refresh-figure5.png', 'alt': 'تفاوت TXE و TC پیش از توقف کلاک', 'caption': 'نمودار تألیفی خط لولهٔ USART و فریم مصنوعی: TXE فقط خالی\u200cبودن رجیستر داده و TC پایان ارسال را نشان می\u200cدهد. HAL_UART_Transmit مسدودکننده در مسیر موفق HAL_OK منتظر TC می\u200cماند؛ انتظار اضافی الزامی فرض نشده است. برنامهٔ نمونه uart_status را ثبت می\u200cکند ولی ورود به Stop یا Standby را به موفقیت UART مشروط نمی\u200cکند؛ بنابراین timeout ممکن است چاپ ناقص باقی بگذارد. اگر پایان چاپ لازم است، ورود باید به موفقیت ارسال مشروط شود. timeoutها پیش از تعلیق tick باید کار کنند. Sleep لزوماً کلاک USART را قطع نمی\u200cکند؛ این موج ثبت ابزار نیست.', 'purpose': 'تفاوت TXE و TC پیش از توقف کلاک', 'placement': 'FIGURE_5', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 6, 'filename': 'lesson30-refresh-figure6.png', 'alt': 'بودجهٔ نمادین جریان کل برد', 'caption': 'نمودار تألیفی بودجهٔ نمادین MCU، رگولاتور AMS1117، LED تغذیه با R13 برابر 560 Ohm و بارهای خارجی. جریان ورودی 5 V برد با جریان تنها MCU روی 3V3 یکی نیست؛ هیچ مقدار mA یا uA اندازه\u200cگیری\u200cشده جعل نشده است. اتصال VBAT از R11 برابر 0 Ohm به 3V3 و C4 برابر 1 uF، باتری مستقل ایجاد نمی\u200cکند.', 'purpose': 'بودجهٔ نمادین جریان کل برد', 'placement': 'FIGURE_6', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}]
if __name__=='__main__':run()

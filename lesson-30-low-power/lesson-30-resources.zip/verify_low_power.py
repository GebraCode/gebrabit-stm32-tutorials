"""Offline arithmetic/static checks; no simulated current or hardware wake results."""
from pathlib import Path
import json,zipfile,hashlib
P=Path(__file__).resolve().parent;checks=[]
def check(n,c):
 assert c,n
 checks.append(n)
check('HSI8MHz1msSysTickreload7999',8000000//1000-1==7999)
check('PLL72MHz1msSysTickreload71999',72000000//1000-1==71999)
check('WUT32768div128div256reload9nominal10s',(9+1)/(32768/128/256)==10)
check('RAM32KiBplusCCM8KiBtotal40KiB',32*1024+8*1024==40960)
check('wrapsafe2000msdelay',((0x000007C0-0xFFFFFFF0)&0xFFFFFFFF)==2000)
for kind in ['projects','build-artifacts']:
 with zipfile.ZipFile(P/f'lesson-30-{kind}.zip')as z:
  check(kind+' CRC',z.testzip() is None)
  manifest=json.loads((P/(kind+'-manifest.json')).read_text());check(kind+' hashes',all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items()))
  if kind=='projects':
   for mode in ['sleep','stop','standby']:
    root='gebrabit_lesson30_'+mode+'/';s=z.read(root+'Core/Src/main.c').decode();ioc=z.read(root+'gebrabit_lesson30_'+mode+'.ioc').decode()
    check(mode+' priorlessonalarmsdeactivated','HAL_RTC_DeactivateAlarm(&hrtc, RTC_ALARM_A)' in s and 'HAL_RTC_DeactivateAlarm(&hrtc, RTC_ALARM_B)' in s)
    check(mode+' retainsSWD','PA13.Signal=SYS_JTMS-SWDIO' in ioc and 'PA14.Signal=SYS_JTCK-SWCLK' in ioc)
    check(mode+' earlyresetpowercaptures',s.index('power_flags_raw = PWR->CSR;')<s.index('  HAL_Init();'))
    if mode in ['sleep','stop']:
     check(mode+' savedmaskrestore','__set_PRIMASK(saved_mask);' in s)
     check(mode+' fallingPA3','PA3.GPIO_Mode=GPIO_MODE_IT_FALLING' in ioc)
     begin=s.index('static void WaitForWake');end=s.index('/* USER CODE END 0 */',begin);wait=s[begin:end]
     check(mode+' noHALDelaywhileticksuspended','HAL_Delay(' not in wait)
     if mode=='stop':
      sequence=['HAL_PWR_EnterSTOPMode(','__set_PRIMASK(saved_mask);','SystemCoreClockUpdate();','HAL_InitTick(TICK_INT_PRIORITY)','HAL_ResumeTick();','SystemClock_Config();']
      cursor=0
      for token in sequence:cursor=wait.index(token,cursor)+len(token)
      check('Stoprestoreorderbeforeclocktimeouts',True)
    else:
     check('StandbyPA0initialpulldown','PA0.GPIO_PuPd=GPIO_PULLDOWN' in ioc)
     check('StandbyrequiresPA0low','WKUP_EXTERNAL_Pin) == GPIO_PIN_RESET' in s)
     standby=s[s.index('static void EnterStandby'):s.index('/* USER CODE END 0 */')]
     sequence=['HAL_PWR_DisableWakeUpPin(','HAL_RTCEx_DeactivateWakeUpTimer(','__HAL_RTC_WAKEUPTIMER_CLEAR_FLAG(','__HAL_PWR_CLEAR_FLAG(PWR_FLAG_WU)','HAL_RTCEx_SetWakeUpTimer_IT(','HAL_PWR_EnableWakeUpPin(','HAL_PWR_EnterSTANDBYMode(']
     cursor=0
     for token in sequence:cursor=standby.index(token,cursor)+len(token)
     check('Standbydisable-clear-reenable-order',True)
r={'scope':'Static source/archive checks and nominal arithmetic only; no current, wake latency, retention or UART measurements','checks_passed':len(checks),'checks':checks,'SysTick_reload_nominal_HSI8':7999,'SysTick_reload_nominal_PLL72':71999,'WUT_nominal_seconds':10,'power_model':'I_board_input includes regulator, MCU, board LEDs and external loads; no invented measured numbers','limitations':['RTC trim CALR is retained, nominal10s assumes untrimmed32768Hz','PA0 requires an external10k pull-down for reliable Standby input; GPIO initialpull is not a Standby guarantee','Wakeflags coalesce; counters countcallbacks, notallphysicaledges','HALtick does not account for suspended/sleep time','Actual clocks/current/wake behavior require boardmeasurement']}
(P/'low-power-model-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

"""Integer/rational timer calculations, not oscilloscope measurements."""
from fractions import Fraction
import json
F=72_000_000
def period(psc,arr):
    if not 0<=psc<=65535 or not 1<=arr<=65535:raise ValueError('TIM6 requires a16bit PSC and nonzero16bit ARR for this exercise')
    return Fraction((psc+1)*(arr+1),F)
def best_pair(target):
    counts=target*F;best=None
    for psc in range(65536):
        ideal=counts/(psc+1);floor=ideal.numerator//ideal.denominator
        for c in {max(2,min(65536,floor)),max(2,min(65536,floor+1))}:
            error=abs(Fraction((psc+1)*c,F)-target)
            key=(error,psc)
            if best is None or key<best[0]:best=(key,psc,c-1)
    return {'PSC':best[1],'ARR':best[2],'period_s':float(period(best[1],best[2])),'absolute_error_s':float(best[0][0]),'relative_error_ppm':float(best[0][0]/target*1_000_000)}
assert period(71,999)==Fraction(1,1000)
assert period(7199,4999)==Fraction(1,2)
try:period(71,0)
except ValueError:pass
else:raise AssertionError('ARR0 not rejected')
rows=[]
for p,a in [(71,999),(7199,4999)]:
    t=period(p,a);rows.append({'PSC':p,'ARR':a,'update_period_ms':float(t*1000),'update_hz':float(1/t),'toggle_output_hz':float(1/(2*t))})
print(json.dumps({'assumptions':'TIM6 upcounting, APB1 prescaler2 => timer72MHz, nonzeroARR; idealhardwareclock. SoftwareISR latency and GPIO edge jitter NOT modelled.','examples':rows,'rounding_search_1234Hz':best_pair(Fraction(1,1234)),'priority_group':'GROUP4: 4preemptionbits,0subprioritybits','software_counter_wrap_days_at1kHz':2**32/1000/86400,'main_delay_ms':500,'pending_after_exact500ms_ideal_interrupts':500,'measured_frequency_hz':None,'measured_ISR_us':None},indent=2))

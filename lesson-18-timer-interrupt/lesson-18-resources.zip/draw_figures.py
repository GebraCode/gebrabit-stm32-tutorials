"""Editable original educational diagrams. Requires Pillow and Windows Segoe UI.
All timelines and waveforms are models, never captured hardware results.
Regenerates only this lesson's PNGs and image-metadata.json beside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, json, textwrap
OUT=Path(__file__).resolve().parent
LESSON=18
W,H=1200,1800
INK='#16354b';TEAL='#087f8c';ORANGE='#ac5c18';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c7d7e1';PALE='#e3f1f2';WHITE='#ffffff'
def font(n=43,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if bold else '')+'.ttf',n)
def tx(d,x,y,s,n=43,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1060,n=43,c=INK,b=False,gap=12):
    words=s.split();lines=[];line=''
    for word in words:
        test=(line+' '+word).strip()
        if d.textlength(test,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,sub='Original diagram / synthetic model'):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,38,title,1090,52,b=True)
    para(d,55,y+10,sub,1090,38,c=MUTED)
    d.line((55,185,1145,185),fill=LINE,width=3)
    return im,d
def footer(d,s='STM32F303CBT6 | Official manuals + exact F3 HAL'):
    d.line((55,H-165,1145,H-165),fill=LINE,width=3)
    para(d,55,H-140,s,1090,33,c=MUTED,gap=6)
    tx(d,55,H-50,'Original model. No board measurement or GUI capture.',32,MUTED)
def arrow(d,pts,c=TEAL,width=7):
    d.line(pts,fill=c,width=width)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+13,s,w-48,42)
    assert yy-18<=y+h+5,(title,yy,y+h)
def note(d,y,s,c=INK):return para(d,65,y,s,1070,43,c)
def save(im,i):im.save(OUT/f'lesson{LESSON}-figure{i}.png',optimize=True)
def axis(d,x0=160,y0=1150,x1=1110,y1=340,xlabel='Time ->',ylabel=None):
    arrow(d,[(x0,y0),(x1,y0)],INK,4);arrow(d,[(x0,y0),(x0,y1)],INK,4)
    tx(d,x1-230,y0+95,xlabel,39)
    if ylabel:tx(d,65,y1-70,ylabel,42,b=True)
def dots(d,x,y,count,active=None,step=70):
    for k in range(count):
        color=TEAL if active is None or k in active else LINE
        d.rounded_rectangle((x+k*step,y,x+k*step+step-9,y+70),8,fill=color)
def step(d,events,xmap,yhi,ylo,c=TEAL,width=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,yhi if last else ylo),(x,yhi if v else ylo)]);last=v
    d.line(pts,fill=c,width=width)
def ring(d,cx,cy,r=310,n=16,start=3,end=11):
    # Sectors represent groups of bytes, not a false256-cell screenshot.
    for k in range(n):
        d.pieslice((cx-r,cy-r,cx+r,cy+r),k*360/n-90,(k+1)*360/n-90,fill=TEAL if (start<=k<end or end>n and k<end-n) else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+100,cy-r+100,cx+r-100,cy+r-100),fill=BG)
def lineplot(d,points,x0,y0,xscale,yscale,c=TEAL):
    d.line([(x0+x*xscale,y0-y*yscale) for x,y in points],fill=c,width=7)






def lesson18():
    im,d=begin('An update flag is gated into an IRQ','TIM6 example | UIF is a status bit, not an event counter')
    panel(d,70,230,1060,225,'Counter reaches its update boundary',['Up-count model:0..ARR then reload','Allowed update sets TIM6_SR.UIF.'])
    arrow(d,[(330,475),(330,650)])
    panel(d,65,675,480,155,'UIF status',['TIM6_SR bit0'])
    panel(d,655,675,480,155,'UIE enable',['TIM6_DIER bit0'],ORANGE)
    arrow(d,[(305,850),(305,1000),(550,1000)]);arrow(d,[(895,850),(895,1000),(650,1000)],ORANGE)
    d.ellipse((520,925,680,1085),fill=WHITE,outline=INK,width=5);tx(d,550,970,'AND',42,b=True)
    arrow(d,[(600,1100),(600,1220)])
    panel(d,70,1240,1060,210,'NVIC: TIM6_DAC_IRQn',['External IRQn54, vector-table index70','Shared vector: dispatch only configured sources.'])
    footer(d,'NVIC enables, priority and masks still control exception entry.');save(im,1)

    im,d=begin('1000 count ticks make one update','Course clock model | Nominal frequency, not an observed trace')
    chain=[('HCLK72MHz -> APB1 /2','PCLK1 =36MHz'),('APB divider is not1 -> timer x2','TIM6 input =72MHz'),('PSC71 divides by72','CNT tick =1MHz =1us'),('ARR999 gives1000 ticks','Update period =1ms; update rate =1000Hz')]
    for k,(a,b) in enumerate(chain):
        y=240+k*285;panel(d,70,y,1060,205,a,[b])
        if k<3:arrow(d,[(600,y+220),(600,y+270)])
    tx(d,70,1480,'T = (PSC +1)(ARR +1) /f_TIM',48,TEAL,True)
    footer(d,'Actual TIM6 project:ARPE enabled, no timer output channel.');save(im,2)

    im,d=begin('The HAL callback follows flag handling','Actual shared TIM6/DAC handler dispatch sequence')
    stages=[('TIM6_DAC_IRQHandler','First filter: TIM6 UIF and UIE both set.'),('PB7 marker goes High','Marker starts after the source filter.'),('HAL_TIM_IRQHandler(&htim6)','Checks update flag and interrupt enable.'),('Clear handled update flag','Then call PeriodElapsedCallback(htim6).'),('User callback, then PB7 Low','Check Instance==TIM6; toggle PB6; count ticks.')]
    for k,(a,b) in enumerate(stages):
        y=230+k*250;panel(d,75,y,1050,185,a,[b])
        if k<4:arrow(d,[(600,y+193),(600,y+235)])
    footer(d,'Actual marker excludes exception entry/return and the pre-marker filter.');save(im,3)

    im,d=begin('Clear the initialization update flag','An early pending flag is different from a new timed period')
    for k,(a,b,c) in enumerate([('INIT','Base_Init issues UG to load settings.','UIF may already be1 before the start.'),('PREPARE','Set CNT=0; clear UIF.','Clear NVIC pending for the configured IRQ.'),('START','HAL_TIM_Base_Start_IT enables UIE + CEN.','Check return value; do not restart every loop.')]):
        y=240+k*365;panel(d,75,y,1050,260,a,[b,c],ORANGE if k==1 else TEAL)
        if k<2:arrow(d,[(600,y+280),(600,y+345)])
    note(d,1430,'Clearing stale UIF avoids an immediate stale-flag callback. It does not guarantee an exactly1ms software callback latency.',ORANGE)
    footer(d,'Pinned HAL953955a: TIM_Base_SetConfig / Base_Start_IT.');save(im,4)

    im,d=begin('Toggle every1ms -> a500Hz square wave','Idealized timing model; actual ISR latency is unmeasured')
    x=lambda t:170+t*230
    for t in range(5):
        xx=x(t);d.line((xx,300,xx,1190),fill=LINE,width=3);tx(d,xx-15,1230,str(t),42)
    tx(d,65,225,'Update events',46,TEAL,True)
    for t in [1,2,3,4]:arrow(d,[(x(t),325),(x(t),470)],TEAL)
    tx(d,65,570,'PB6: toggled in callback',46,TEAL,True)
    step(d,[(0,0),(1,1),(2,0),(3,1),(4,0)],x,690,850)
    tx(d,65,950,'PB7: marker around HAL dispatch + callback',42,ORANGE,True)
    ev=[(0,0)]
    for t in [1,2,3,4]:ev.extend([(t,1),(t+.12,0)])
    step(d,ev,x,1060,1160,ORANGE)
    tx(d,890,1325,'Time (ms)',42,b=True)
    tx(d,65,1420,'Full PB6 period:2ms ->500Hz',48,TEAL,True)
    note(d,1510,'PB7 widths are illustrative, not ISR latency measurements.',ORANGE)
    footer(d,'Marker excludes exception stacking/unstacking and source filter.');save(im,5)

    im,d=begin('Volatile does not protect read-and-reset','Actual pending tick handoff: saved PRIMASK critical section')
    tx(d,70,240,'UNPROTECTED: one increment can be lost',43,RED,True)
    for k,(a,b) in enumerate([('Main reads','pending =5'),('ISR increments','pending =6'),('Main resets','pending =0; copied count stays5')]):
        y=350+k*150;d.rectangle((80,y,400,y+105),fill=RED if k==1 else TEAL);tx(d,100,y+25,a,42,'white',True);para(d,450,y+18,b,660,42)
    tx(d,70,880,'PROTECTED: short atomic handoff',46,TEAL,True)
    labels=['Save old PRIMASK','Disable IRQs','Copy pending; reset to0','DMB; restore old PRIMASK']
    for k,t in enumerate(labels):
        yy=985+k*135;d.rounded_rectangle((150,yy,1050,yy+95),15,fill=WHITE,outline=TEAL,width=3);tx(d,180,yy+18,t,43,TEAL,True)
        if k<3:arrow(d,[(600,yy+102),(600,yy+127)])
    footer(d,'Single UIF bit can merge events while masked; software counters can wrap.');save(im,6)

def run():
    globals()[f'lesson{LESSON}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')



METADATA=[{'id': 1, 'filename': 'lesson18-figure1.png', 'alt': 'گیت UIF و UIE تا وقفهٔ مشترک TIM6', 'caption': 'نمودار تألیفی مسیر Update تا فلگ UIF و مجوز UIE و NVIC؛ TIM6_DAC_IRQn برابر IRQ خارجی 54 و اندیس جدول بردار 70 است. UIF یک بیت است و چند رخداد عقب\u200cافتاده را نمی\u200cشمارد؛ فعال\u200cبودن NVIC و ماسک\u200cها و اولویت نیز مؤثرند.', 'purpose': 'UIF و UIE چگونه درخواست وقفهٔ مشترک TIM6 را شکل می\u200cدهند؟', 'placement': "زیربخش 'تفاوت بنیادین رخداد سخت\u200cافزاری به\u200cروزرسانی (UEV) و درخواست وقفه (UIE و UIF)'", 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 2, 'filename': 'lesson18-figure2.png', 'alt': 'محاسبهٔ دورهٔ 1ms با PSC و ARR', 'caption': 'نمودار محاسباتی تألیفی برای TIM6 با کلاک 72MHz، PSC=71 و ARR=999؛ تیک CNT برابر 1us و 1000 تیک برابر Update اسمی 1ms است. این عدد فرکانس تنظیمات است و نمودار اندازه\u200cگیری خروجی نیست.', 'purpose': 'PSC و ARR پروژه چگونه Update اسمی 1ms می\u200cسازند؟', 'placement': "زیربخش 'کلاک واقعی تایمر در گذرگاه APB1 و تحلیل قاعدهٔ ضریب 2 (f_TIM = 72 MHz)'", 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 3, 'filename': 'lesson18-figure3.png', 'alt': 'مسیر واقعی HAL و محدودهٔ نشانگر PB7', 'caption': 'نمودار توالی تألیفی مطابق ISR پروژه: پس از شرط UIF و UIE، PB7 بالا می\u200cرود، HAL فلگ را پاک و callback را اجرا می\u200cکند و PB7 پایین می\u200cآید. نشانگر شامل entry و return استثنا یا شرط پیش از نشانگر نیست و عرض آن کل تأخیر ورود به وقفه را نشان نمی\u200cدهد.', 'purpose': 'فلگ و callback در HAL چه ترتیبی دارند و PB7 کدام بخش را می\u200cپوشاند؟', 'placement': "زیربخش 'سلسله\u200cمراتب فراخوانی: از بردار سخت\u200cافزاری تا تابع HAL_TIM_PeriodElapsedCallback'", 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 4, 'filename': 'lesson18-figure4.png', 'alt': 'پاک\u200cکردن فلگ Update حاصل از راه\u200cاندازی اولیه', 'caption': 'نمودار تألیفی Init، آماده\u200cسازی CNT و UIF و NVICpending و Start_IT؛ پاک\u200cکردن UIF قدیمی از callback فوری ناشی از فلگ قدیمی جلوگیری می\u200cکند، اما رسیدن نرم\u200cافزار به callback دقیقاً پس از 1ms یا بی\u200cJitterبودن تضمین نمی\u200cشود.', 'purpose': 'پاک\u200cکردن UIF قدیمی پیش از Start_IT چه مشکلی را رفع می\u200cکند و چه تضمینی نمی\u200cدهد؟', 'placement': "زیربخش 'تحلیل اثر جانبی بیت UG در Init و لزوم پاکسازی پیش\u200cدستانه پرچم UIF'", 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 5, 'filename': 'lesson18-figure5.png', 'alt': 'فرکانس 500Hz خروجی با Toggle در هر 1ms', 'caption': 'شکل موج مدل و تألیفی با محور ms؛ معکوس\u200cکردن PB6 در هر وقفهٔ اسمی 1ms دورهٔ کامل 2ms و فرکانس اسمی 500Hz می\u200cسازد. پالس\u200cهای PB7 فقط پوشش مفهومی HAL و callback هستند و عرض ساختگی آن\u200cها اندازه\u200cگیری تأخیر یا زمان اجرا نیست.', 'purpose': 'چرا Toggle در Updateهای 1ms موج اسمی 500Hz می\u200cدهد؟', 'placement': "زیربخش 'آزمایش 1: نوسان پایه\u200cای PB6 با دوره 1 ms و اثبات فرکانس خروجی 500 Hz روی اسیلوسکوپ'", 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 6, 'filename': 'lesson18-figure6.png', 'alt': 'ناحیهٔ بحرانی برای خواندن و صفرکردن شمارندهٔ مشترک', 'caption': 'نمودار تألیفی مثال گم\u200cشدن increment میان خواندن و صفرکردن main و راه\u200cحل واقعی ذخیرهٔ PRIMASK، غیرفعال\u200cسازی کوتاه، کپی و صفر و DMB و بازیابی PRIMASK قبلی؛ volatile عملیات مرکب را اتمیک نمی\u200cکند. توقف طولانی وقفه می\u200cتواند رخدادهای تک\u200cبیتی UIF را ادغام کند.', 'purpose': 'چرا volatile برای خواندن و صفرکردن شمارنده کافی نیست و PRIMASK چگونه حفظ می\u200cشود؟', 'placement': "زیربخش 'مدیریت متغیرهای مشترک: محدودیت volatile و حفاظت اتمیک RMW با PRIMASK'", 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}]
if __name__=='__main__':run()

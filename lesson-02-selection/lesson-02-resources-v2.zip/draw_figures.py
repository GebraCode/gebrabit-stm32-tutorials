"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=2
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
    im,d=begin('Start from the job, not a family ranking','Illustrative groups overlap; examples are not an exhaustive catalog')
    groups=[(65,340,'Basic control','C0 / G0'),(635,340,'Analog control','F3 / G4'),(65,780,'More processing','H7 / N6'),(635,780,'Low-power focus','L0 / U0 / U3 / U5'),(350,1220,'Wireless focus','WB / WL / WBA')]
    for x,y,a,b in groups:
        d.rounded_rectangle((x,y,x+500,y+265),55,fill=WHITE,outline=TEAL,width=4)
        para(d,x+28,y+40,a,444,46,TEAL,True);para(d,x+28,y+145,b,444,43)
    for x,y in [(565,470),(565,910)]:d.line((x,y,x+70,y),fill=LINE,width=7)
    tx(d,65,1550,'Family labels do not guarantee every feature or power result.',41)
    foot(d,'Examples are candidates for a search, not purchase advice.');save(im,1)

def figure2():
    im,d=begin('Read this exact part number in meaningful fields','STM32F303CBT6 | Use the ordering table for this device line')
    parts=[('STM32','ST microcontroller product name'),('F303','The device product line'),('C','48 physical package pins'),('B','128 KiB Flash'),('T','LQFP package'),('6','Ambient range: -40 to +85 degC')]
    for k,(a,b) in enumerate(parts):
        y=310+k*205;d.rounded_rectangle((65,y,340,y+130),15,fill=TEAL)
        tx(d,90,y+35,a,48,'white',True);arrow(d,[(365,y+65),(450,y+65)])
        para(d,485,y+32,b,650,43,b=True)
    tx(d,65,1570,'F is not a universal code meaning "general-purpose".',41,ORANGE)
    foot(d,'A part-number field is not a complete feature checklist.');save(im,2)

def figure3():
    im,d=begin('Budget signal roles before counting spare pins','A six-signal example, not the complete 4-ADC project allocation')
    roles=[('ADC1_IN2','PA1'),('ADC1_IN3','PA2'),('TIM3_CH1','PA6'),('TIM3_CH2','PA7'),('SWDIO','PA13'),('SWCLK','PA14')]
    for k,(role,pin) in enumerate(roles):
        yy=310+k*155;tx(d,90,yy,role,47,TEAL,True);arrow(d,[(495,yy+35),(735,yy+35)])
        tx(d,815,yy,pin,47,b=True)
    panel(d,70,1295,1060,175,'Conflict example: TIM3_CH1 + SPI1_MISO',['Both request PA6; one pad cannot serve both at once.'],RED)
    tx(d,65,1540,'Power, clocks, reset and board circuits still need review.',42,ORANGE)
    foot(d,'No unsupported count of "free GPIOs" is inferred.');save(im,3)

def figure4():
    im,d=begin('Check the memory region a buffer actually needs','Hypothetical worksheet budgets; not compiled RAM usage')
    tx(d,65,295,'Main SRAM capacity: 32768 bytes',47,TEAL,True)
    rows=[('Controller',4608,'2 x 256 x 1 + 4096 other bytes'),('Logger',10240,'2 x 1024 x 2 + 6144 other bytes'),('Analog example',24576,'2 x 4096 x 2 + 8192 other bytes')]
    for k,(title,n,formula) in enumerate(rows):
        yy=430+k*300;tx(d,65,yy,f'{title}: {n} bytes',45,b=True)
        d.rectangle((110,yy+105,1090,yy+180),fill='#dce7ed')
        d.rectangle((110,yy+105,110+n/32768*980,yy+180),fill=TEAL)
        tx(d,65,yy+210,formula,40)
    panel(d,70,1390,1060,185,'CCM is a separate 8192-byte region',['Do not add it to the main-SRAM DMA-buffer budget.'],ORANGE)
    foot(d,'Buffer sizes and safety margins are design assumptions.');save(im,4)

def figure5():
    im,d=begin('Build a documented shortlist','Requirements, documents and prototypes narrow the candidates')
    levels=[(65,310,1070,'1  Write the required job and interfaces'),(115,565,970,'2  Budget pins, memory and power'),(165,820,870,'3  Search official selector tools'),(215,1075,770,'4  Check datasheet, errata and supply'),(300,1330,600,'5  Prototype and measure')]
    for x,y,w,a in levels:
        d.polygon([(x,y),(x+w,y),(x+w-35,y+170),(x+35,y+170)],fill=WHITE,outline=TEAL,width=4)
        para(d,x+40,y+40,a,w-80,43,TEAL,True)
        if y<1330:arrow(d,[(600,y+185),(600,y+235)])
    foot(d,'Price and availability must be checked when selecting a part.');save(im,5)

def figure6():
    im,d=begin('Let requirements shape the shortlist','Illustrative family candidates; no exact part has been qualified')
    scenarios=[('Wired controller','Interfaces, pin budget and total cost','C0 / G0'),('Battery logger','Sleep conditions and wake-up behavior','L0 / U0 / U3 / U5'),('Analog control','ADC, timer and signal-processing needs','F3 / G4')]
    for k,(a,b,c) in enumerate(scenarios):
        yy=320+k*405;tx(d,65,yy,a,48,TEAL,True);tx(d,65,yy+100,b,42)
        arrow(d,[(150,yy+220),(470,yy+220)])
        panel(d,505,yy+155,625,145,c,())
    tx(d,65,1560,'Compare exact devices and prototypes before a final choice.',41,ORANGE)
    foot(d,'No guessed SKU, fixed price or measured power is shown.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson02-refresh-figure1.png', 'alt': 'گروه\u200cهای کاربردی خانواده\u200cهای STM32', 'caption': 'نقشهٔ تألیفی و کیفی چند گروه نمونه از خانواده\u200cهای STM32. گروه\u200cها هم\u200cپوشانی دارند؛ این شکل فهرست جامع، نمودار اندازه\u200cگیری مصرف یا تضمین قابلیت همهٔ اعضای یک خانواده نیست.', 'purpose': 'گروه\u200cهای کاربردی خانواده\u200cهای STM32', 'placement': 'در بخش نقشه خانواده\u200cهای میکروکنترلرهای STM32', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Ordering, pin functions and memory capacities'}, {'url': 'https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html', 'version': 'Portfolio examples checked for this course, not exhaustive', 'scope': 'Qualitative family examples'}, {'url': 'local:selection-worksheet.csv', 'version': 'Lesson02 fresh public worksheet and 17 model checks', 'scope': 'Explicit hypothetical RAM budgets and six-role pin subset'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Qualitative overlapping examples; no energy/performance axes or absolute hierarchy.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson02-refresh-figure2.png', 'alt': 'خواندن کد سفارش STM32F303CBT6', 'caption': 'تجزیهٔ تألیفی کد سفارش STM32F303CBT6 طبق DS9118: C نشان\u200cدهندهٔ 48 پایه، B حافظهٔ Flash برابر 128 KiB، T بستهٔ LQFP و 6 بازهٔ دمای محیط -40 تا +85 درجه است. F به\u200cتنهایی به معنی همه\u200cمنظوره نیست.', 'purpose': 'خواندن کد سفارش STM32F303CBT6', 'placement': 'در بخش کالبدشکافی شماره قطعه STM32F303CBT6', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Ordering, pin functions and memory capacities'}, {'url': 'https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html', 'version': 'Portfolio examples checked for this course, not exhaustive', 'scope': 'Qualitative family examples'}, {'url': 'local:selection-worksheet.csv', 'version': 'Lesson02 fresh public worksheet and 17 model checks', 'scope': 'Explicit hypothetical RAM budgets and six-role pin subset'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Decode STM32/F303/C/B/T/6; no universal F category claim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson02-refresh-figure3.png', 'alt': 'نمونهٔ تخصیص شش نقش پایه و تشخیص تداخل', 'caption': 'نقشهٔ تألیفی نمونهٔ واقعی کاربرگ: 2 ورودی ADC، 2 خروجی تایمر و 2 سیگنال SWD. این نمونه تخصیص کامل سناریوی 4 ورودی نیست. TIM3_CH1 و SPI1_MISO هر دو به PA6 نیاز دارند و در این انتخاب هم\u200cزمان قابل تخصیص نیستند. تعداد پایهٔ آزاد ادعا نشده است.', 'purpose': 'نمونهٔ تخصیص شش نقش پایه و تشخیص تداخل', 'placement': 'در زیربخش بودجه\u200cبندی پایه\u200cهای فیزیکی LQFP48', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Ordering, pin functions and memory capacities'}, {'url': 'https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html', 'version': 'Portfolio examples checked for this course, not exhaustive', 'scope': 'Qualitative family examples'}, {'url': 'local:selection-worksheet.csv', 'version': 'Lesson02 fresh public worksheet and 17 model checks', 'scope': 'Explicit hypothetical RAM budgets and six-role pin subset'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Six-role subset PA1 PA2 PA6 PA7 PA13 PA14, not a complete four-ADC design. Check power/clocks/reset/board loading separately.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson02-refresh-figure4.png', 'alt': 'سه بودجهٔ فرضی RAM در برابر SRAM اصلی', 'caption': 'نمودار تألیفی مدل کاربرگ با فرض\u200cهای صریح: کنترلر 4608، ثبت\u200cکننده 10240 و کنترل آنالوگ 24576 بایت. مرجع 32768 بایت SRAM اصلی است؛ CCM برابر 8192 بایت ناحیه\u200cای جداست و برای DMA منظور نمی\u200cشود. این اعداد مصرف اندازه\u200cگیری\u200cشده یا قانون حاشیهٔ 30 درصد نیستند.', 'purpose': 'سه بودجهٔ فرضی RAM در برابر SRAM اصلی', 'placement': 'در بخش ارزیابی منابع حافظه: تمایز Flash، Main SRAM و CCM SRAM', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Ordering, pin functions and memory capacities'}, {'url': 'https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html', 'version': 'Portfolio examples checked for this course, not exhaustive', 'scope': 'Qualitative family examples'}, {'url': 'local:selection-worksheet.csv', 'version': 'Lesson02 fresh public worksheet and 17 model checks', 'scope': 'Explicit hypothetical RAM budgets and six-role pin subset'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Hypothetical formulas 2*256*1+4096; 2*1024*2+6144; 2*4096*2+8192; main SRAM32768, CCM8192 separate, no DMA CCM.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson02-refresh-figure5.png', 'alt': 'مسیر محدود کردن گزینه\u200cهای انتخاب میکروکنترلر', 'caption': 'نمودار تألیفی تصمیم\u200cگیری از نیازمندی و بودجه تا انتخابگر، بررسی دیتاشیت و خطاهای شناخته\u200cشده و نمونه\u200cسازی. نتیجهٔ انتخابگر به\u200cتنهایی تأیید طراحی یا موجودی بازار نیست.', 'purpose': 'مسیر محدود کردن گزینه\u200cهای انتخاب میکروکنترلر', 'placement': 'در بخش ابزارهای رسمی گزینش تراشه و روش اعتبارسنجی', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Ordering, pin functions and memory capacities'}, {'url': 'https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html', 'version': 'Portfolio examples checked for this course, not exhaustive', 'scope': 'Qualitative family examples'}, {'url': 'local:selection-worksheet.csv', 'version': 'Lesson02 fresh public worksheet and 17 model checks', 'scope': 'Explicit hypothetical RAM budgets and six-role pin subset'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Documented gates, not fixed margin law or unverified availability/prices.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson02-refresh-figure6.png', 'alt': 'نیازمندی سه کاربرد و خانواده\u200cهای نامزد', 'caption': 'نمودار تألیفی سه کاربرد فرضی و چند خانوادهٔ نامزد برای بررسی. نام خانواده پیشنهاد اولیه است؛ قطعهٔ نهایی به قابلیت عضو دقیق، مدار، بودجه و آزمون نمونه وابسته است. هیچ قیمت یا مصرف واقعی اندازه\u200cگیری نشده است.', 'purpose': 'نیازمندی سه کاربرد و خانواده\u200cهای نامزد', 'placement': 'در بخش کارگاه عملی و تمرین: بررسی سه سناریوی پروژه فرضی', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Ordering, pin functions and memory capacities'}, {'url': 'https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html', 'version': 'Portfolio examples checked for this course, not exhaustive', 'scope': 'Qualitative family examples'}, {'url': 'local:selection-worksheet.csv', 'version': 'Lesson02 fresh public worksheet and 17 model checks', 'scope': 'Explicit hypothetical RAM budgets and six-role pin subset'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Candidates only, no guessed SKU or qualified device guarantee.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

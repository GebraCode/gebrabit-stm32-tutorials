"""Hypothetical resource accounting, not selection certification or a measurement."""
from pathlib import Path
import json, math
P=Path(__file__).resolve().parent
d=json.loads((P/'selection-cases.json').read_text(encoding='utf-8')); checks=[]
def check(name,condition):
    if not condition: raise AssertionError(name)
    checks.append(name)
results=[]
for c in d['cases']:
    raw=c['buffer_samples']*c['bytes_per_sample']*c['buffers']
    used=raw+c['other_main_sram_bytes']
    results.append({'case':c['id'],'raw_buffer_bytes':raw,'other_main_sram_bytes':c['other_main_sram_bytes'],'total_budget_bytes':used,'remaining_against_reference_32KiB':32768-used,'distinct_signal_pins_lower_bound':sum(c['signal_pins'].values()),'exact_MPN_selection':'pending'})
    check(c['id']+' positive and within reference only',0<used<=32768)
    check(c['id']+' no fabricated exact MPN',c['exact_mpn'] is None)
check('wired 4608 bytes',results[0]['total_budget_bytes']==4608)
check('logger 10240 bytes',results[1]['total_budget_bytes']==10240)
check('analog 24576 bytes',results[2]['total_budget_bytes']==24576)
check('signal pin lower bounds', [r['distinct_signal_pins_lower_bound'] for r in results]==[12,6,8])
def conflicts(assignments):
    by_pin={}
    for a in assignments: by_pin.setdefault(a['pin'],[]).append(a['signal'])
    return {p:s for p,s in by_pin.items() if len(s)>1}
pins=d['pin_examples']
check('nonconflicting example only',conflicts(pins['valid_logical_assignment'])=={})
check('PA6 overlap deliberately caught',conflicts(pins['invalid_assignment'])=={'PA6':['TIM3_CH1','SPI1_MISO']})
check('board button loading separately recorded',pins['board_loaded_pin']=='PA3')
b=d['battery_model']; duty=b['active_ms_per_cycle']/b['cycle_ms']
check('duty bounded',0<=duty<=1)
avg_ua=b['active_current_ma']*1000*duty+b['sleep_current_ua']*(1-duty)+b['always_on_board_current_ua']
ideal_hours=b['nominal_capacity_mah']/(avg_ua/1000)
check('weighted mean 129.9uA',math.isclose(avg_ua,129.9))
check('board consumption not omitted',avg_ua>109.9)
check('not measured',b['measured'] is False)
report={'kind':'hypothetical arithmetic and collision checks','checks_passed':len(checks),'checks':checks,'resource_budgets':results,'battery_example':{'duty_fraction':duty,'average_current_ua':avg_ua,'ideal_capacity_over_current_hours':ideal_hours,'limits':'Not a runtime guarantee. Excludes regulator conversion/losses beyond the explicit assumed board current, battery self-discharge, temperature, usable capacity and sensor transients. No measured currents.'},'limits':'Signal counts exclude supply/reset/boot and are not a package GPIO count. No candidate exact MPN, AF electrical compatibility, power limits, timing or commercial status is certified. Analog input circuitry and PA3 button load need separate review. SRAM reservations are assumptions, not linker measurements; CCM excluded from DMA budgets.'}
(P/'selection-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

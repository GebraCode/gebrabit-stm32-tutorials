"""Offline calculations and archive/source checks; no target or electrical execution."""
from pathlib import Path
import hashlib,json,math,struct,sys,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'toolchain-and-validation.json').read_text(encoding='utf-8'))
name=meta['project'];lesson=meta['lesson'];checks=[];values={}
def check(label,condition):
    if not condition: raise AssertionError(label)
    checks.append(label)
with zipfile.ZipFile(ROOT/f'lesson-{lesson}-projects.zip') as z:
    check('source archive CRC',z.testzip() is None)
    manifest=json.loads((ROOT/'source-manifest.json').read_text())
    check('all source hashes',all(hashlib.sha256(z.read(name+'/'+k)).hexdigest()==v for k,v in manifest.items()))
    check('three component licenses',all(name+'/'+x in z.namelist() for x in meta['component_licenses']))
    main=z.read(name+'/Core/Src/main.c').decode()
    ioc=z.read(name+'/'+name+'.ioc').decode()
    init=z.read(name+'/Core/Src/'+('i2c.c' if lesson==26 else 'spi.c')).decode()
    check('baseline PLL9 and Flash2 actual source',all(x in main for x in ['RCC_PLL_MUL9','RCC_HSE_PREDIV_DIV1','RCC_HCLK_DIV2','FLASH_LATENCY_2']))
with zipfile.ZipFile(ROOT/f'lesson-{lesson}-build-artifacts.zip') as z:
    check('artifact archive CRC',z.testzip() is None)
    elf=z.read(name+'/'+name+'.elf')
    check('ELF artifact hash',hashlib.sha256(elf).hexdigest()==meta['ELF_SHA256'])
    check('ARM32 little endian executable',elf[:6]==b'\x7fELF\x01\x01' and struct.unpack_from('<HH',elf,16)==(2,40))
    shoff=struct.unpack_from('<I',elf,32)[0];entsize,shnum,shstr=struct.unpack_from('<HHH',elf,46)
    sections=[struct.unpack_from('<IIIIIIIIII',elf,shoff+i*entsize) for i in range(shnum)]
    strings=sections[shstr];names=elf[strings[4]:strings[4]+strings[5]]
    labels=[names[h[0]:].split(b'\0',1)[0].decode() for h in sections]
    check('actual debug info and vector section',all(s in labels for s in ['.debug_info','.debug_line','.isr_vector']))
    check('RAM section accounting',sum([meta['data_bytes'],meta['actual_BSS_bytes'],meta['heap_stack_section_bytes']])==meta['RAM_linked_reserved_bytes'])
check('actual Debug warning flags',all(x in meta['main_compile_command'] for x in ['-O0','-g3','-Wall','-Werror']))

check('generated SYSCLK72 I2C1 source', 'PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_SYSCLK;' in main and 'RCC.I2C1Freq_Value=72000000' in ioc)
word=int(meta['TIMINGR'],16)
fields={'PRESC':(word>>28)&15,'SCLDEL':(word>>20)&15,'SDADEL':(word>>16)&15,'SCLH':(word>>8)&255,'SCLL':word&255}
check('TIMING fields match actual generated init',fields==meta['timing_fields'] and 'hi2c1.Init.Timing = 0x8041242A;' in init)
tick=1e9/72000000;tp=(fields['PRESC']+1)*tick
low=(fields['SCLL']+1)*tp;high=(fields['SCLH']+1)*tp
rise=300.0;fall=100.0;afmin=50.0;afmax=260.0;dnf=0
syncmin=afmin+dnf*tick+2*tick;syncmax=afmax+dnf*tick+3*tick
period_fastest=low+high+2*syncmin # zero external edges: conservative upperfrequency bound
period_with_assumed_edges_min=period_fastest+rise+fall
period_with_assumed_edges_max=low+high+2*syncmax+rise+fall
check('Standard mode high and low minima across assumed filters',low+syncmin>=4700 and high+syncmin>=4000)
check('zero-edge shortest period does not exceed100kHz',period_fastest>=10000)
setup=(fields['SCLDEL']+1)*tp
hold=fields['SDADEL']*tp
hold_min=max(0,fall-afmin-3*tick)
hold_max=3450-rise-afmax-4*tick
check('SCLDEL setup bound at maximum assumed rise',setup>=rise+250)
check('SDADEL hold bounds at selected edge/filter ranges',hold_min<=hold<=hold_max)
check('I2C kernel period below target100ns setup',tick<100)
r_on=10000.0;r_ext=4700.0;effective=1/(1/r_on+1/r_ext);cb=100e-12
tr=0.8473*effective*cb*1e9;r_min=(3.3-0.4)/0.003
check('parallel pullup meets example sink and assumed rise',effective>=r_min and tr<=rise)
check('onboard10k example not Fast mode300ns',0.8473*r_on*cb*1e9>300)
check('address shifting and identity register are distinct',(0x68<<1)==0xD0 and (0x69<<1)==0xD2 and 'WHO_AM_I_REG 0x75U' in main and 'WHO_AM_I_EXPECTED 0x12U' in main)
check('scan and finite receive API source',(all(s in main for s in ['address = 0x08U','address <= 0x77U','I2C_TRANSFER_TIMEOUT_MS 20U','HAL_I2C_Master_Transmit','HAL_I2C_Mem_Read','I2C_MEMADD_SIZE_8BIT'])))
check('bounded open drain recovery source',all(s in main for s in ['GPIO_MODE_OUTPUT_OD','recovery_pulses < 9U','guard < 200000U','__HAL_RCC_GPIOB_CLK_ENABLE','Restore_I2C()']))
# A conceptual single-controller line-release model, not execution of the C firmware.
def clear_model(release_after=0,scl_can_rise=True):
    if not scl_can_rise:return 1,0
    pulses=0
    while pulses<9 and pulses<release_after:pulses+=1
    return (0 if release_after<=9 else 2),pulses
check('conceptual line release cases',all(clear_model(i)==(0,i) for i in range(10)) and clear_model(10)==(2,9) and clear_model(0,False)==(1,0))
values={'TIMINGR':meta['TIMINGR'],'fields':fields,'kernel_period_ns':tick,'prescaler_period_ns':tp,'register_low_ns':low,'register_high_ns':high,'minimum_low_ns':low+syncmin,'minimum_high_ns':high+syncmin,'SCLDEL_setup_ns':setup,'SDADEL_hold_ns':hold,'SDADEL_lower_bound_ns':hold_min,'SDADEL_upper_bound_ns':hold_max,'zero_edge_min_period_us':period_fastest/1000,'zero_edge_upper_frequency_hz':1e9/period_fastest,'assumed_rise_fall_ns':[rise,fall],'assumed_edges_period_range_us':[period_with_assumed_edges_min/1000,period_with_assumed_edges_max/1000],'assumed_edges_frequency_range_hz':[1e9/period_with_assumed_edges_max,1e9/period_with_assumed_edges_min],'pullup_example':{'onboard_ohm':r_on,'external_ohm':r_ext,'parallel_ohm':effective,'assumed_capacitance_pF':100,'rise_ns':tr,'example_Rmin_ohm':r_min},'WHO_read_expected_SCL_cycles':36,'pointer_only_write_SCL_cycles':18,'bus_clear_max_clock_pulses':9,'DWT_delay_requested_us':5,'DWT_SCL_wait_requested_ms':2,'iteration_guard':200000}

result={'scope':'Offline calculation/source/archive/ELF checks; not an MCU run, C simulator, bus electrical measurement, or proof of reliable communication. Edge capacitance/filter assumptions must be verified on actual wiring.','passed':len(checks),'checks':checks,'values':values}
(ROOT/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))

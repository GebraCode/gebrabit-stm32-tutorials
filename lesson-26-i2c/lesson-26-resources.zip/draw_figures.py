"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=26
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)
def ground(d,x,y):
 d.line((x,y,x,y+15),fill=INK,width=4)
 for yy,ww in [(y+15,25),(y+28,17),(y+41,8)]:d.line((x-ww,yy,x+ww,yy),fill=INK,width=4)
def figure1():
 im,d=begin('Release the line to let a pull-up raise it','Original open-drain example; the rise curves assume 100 pF, not a measurement')
 tx(d,480,285,'3V3',44,TEAL,True);d.line((350,360,750,360),fill=INK,width=5)
 for x,label in [(350,'10 kOhm'),(750,'4.7 kOhm')]:
  d.line((x,360,x,420),fill=INK,width=5);d.rectangle((x-20,420,x+20,510),fill=WHITE,outline=INK,width=4);d.line((x,510,x,590),fill=INK,width=5)
  tx(d,75 if x==350 else 800,430,label,40,TEAL,True)
 d.line((150,590,1050,590),fill=TEAL,width=6)
 for x in [180,1010]:d.line((x,590,x,650),fill=INK,width=5);d.line((x,650,x+45,700),fill=ORANGE,width=5);d.line((x,715,x,745),fill=INK,width=4);ground(d,x,745)
 tx(d,75,840,'One line shown; use the same pull-up logic on SCL.',40)
 x0,y0=150,1310;pw,ph=950,350
 d.line((x0,920,x0,y0,x0+pw,y0),fill=INK,width=4)
 for v in [0.3,0.7,1.0]:
  yy=y0-v*ph;d.line((x0,yy,x0+pw,yy),fill=LINE,width=2);tx(d,65,yy-25,str(v),40)
 for R,c in [(10000,ORANGE),(1/(1/10000+1/4700),TEAL)]:
  pts=[]
  for k in range(301):
   ns=k*5;v=1-math.exp(-(ns*1e-9)/(R*100e-12));pts.append((x0+ns/1500*pw,y0-v*ph))
  d.line(pts,fill=c,width=7)
 for ns in [0,500,1000,1500]:tx(d,x0+ns/1500*pw-28,1330,str(ns),40)
 tx(d,820,1400,'Time (ns)',40);tx(d,170,900,'V / VDD',40,TEAL,True)
 tx(d,75,1480,'10 kOhm: 30%-70% rise 847.3 ns',42,ORANGE,True)
 tx(d,75,1560,'10 k || 4.7 k = 3197.28 Ohm: rise 270.91 ns',42,TEAL,True)
 foot(d,'Active LOW sinks current; released HIGH is not push-pull drive.');save(im,1)
def clock_bits(d,y,bits,owner,title):
 tx(d,75,y,title,44,TEAL,True);width=105;start=120;d.line((75,y+170,1100,y+170),fill=LINE,width=2)
 pts=[(start,y+170)]
 for k,b in enumerate(bits):
  x=start+k*width;pts.extend([(x,y+170),(x+width/2,y+170),(x+width/2,y+100),(x+width,y+100),(x+width,y+170)])
  tx(d,x+30,y+45,str(b),40,ORANGE if k==8 else INK,True)
 d.line(pts,fill=TEAL,width=5);tx(d,35,y+100,'SCL',38,MUTED);tx(d,75,y+205,owner,40,ORANGE)
def figure2():
 im,d=begin('Follow a one-byte I2C register read','Expected WHO_AM_I transaction; schematic clock groups, not a logic-analyzer capture')
 clock_bits(d,285,[1,1,0,1,0,0,0,0,0],'Target drives ACK=0','START -> 0xD0: address 0x68 + Write')
 clock_bits(d,610,[0,1,1,1,0,1,0,1,0],'Target drives ACK=0','Register 0x75')
 clock_bits(d,935,[1,1,0,1,0,0,0,1,0],'Target drives ACK=0','Repeated START -> 0xD1: Read')
 clock_bits(d,1260,[0,0,0,1,0,0,1,0,1],'Master drives NACK=1, then STOP','Expected data 0x12 from target')
 foot(d,'SDA changes at SCL LOW, except START / STOP conditions.');save(im,2)
def figure3():
 im,d=begin('Use the selected I2C kernel clock','Actual I2C1: SYSCLK 72 MHz; analog filter ON, DNF=0')
 panel(d,75,290,1050,195,'Kernel source -> prescaled timing tick',['tPRESC=(PRESC+1)/72 MHz'])
 fields=[('PRESC','31:28',8),('SCL DEL','23:20',4),('SDA DEL','19:16',1),('SCLH','15:8',35),('SCLL','7:0',39)]
 for k,(a,b,v)in enumerate(fields):
  x=65+k*220;panel(d,x,620,205,300,a,[b])
 tx(d,75,960,'SCL low base: (SCLL+1) x tPRESC',44,TEAL,True)
 tx(d,75,1060,'SCL high base: (SCLH+1) x tPRESC',44,TEAL,True)
 panel(d,75,1220,1050,380,'Counts alone are not the wire period',['Select a word that matches the generated project.','Calculated -> IOC entry -> CubeMX-generated C.','Edge / filter / synchronization delays still matter.'])
 foot(d,'No simple low+high sum is claimed to be the exact wire period.');save(im,3)
def figure4():
 im,d=begin('Wire nets and inspect module selectors','Original interconnect diagram; no copied board layout or assumed header orientation')
 tx(d,75,300,'GB100ST V2.0',46,TEAL,True);tx(d,735,300,'GB304IM V2.0',46,TEAL,True)
 rows=[('PB8 / SCL','SCL'),('PB9 / SDA','SDA'),('3V3 rail','3V3 supply'),('GND','GND')]
 for k,(a,b)in enumerate(rows):
  yy=470+k*180;tx(d,75,yy,a,42,TEAL,True);tx(d,780,yy,b,42,TEAL,True);d.line((450,yy+40,730,yy+40),fill=TEAL if k<2 else INK,width=6)
 panel(d,75,1240,1050,350,'Check selectors by their net labels',['VDD SEL=3V3 and VDIO SEL=3V3; protocol routes=I2C','CS tied to VDDIO; AD0=GND selects 7-bit 0x68','Onboard pull-ups: 10 kOhm; PB6 LED is separate.'])
 foot(d,'Both rails 3.3 V; the module is not a 5 V level converter.');save(im,4)
def figure5():
 im,d=begin('Separate bus addresses and register data','HAL address parameter is shifted; the controller supplies the direction bit')
 tx(d,75,300,'7-bit address 0x68 -> HAL parameter 0xD0',46,TEAL,True)
 panel(d,75,470,1050,355,'Mem_Read uses a repeated START',['START D0 W -> 75 -> repeated START D1 R -> 12 -> STOP','Register 0x75 is not the bus address.','Expected 0x12 is identity data, not an observed reply.'])
 panel(d,75,990,1050,310,'Separate transfers can include STOP',['Pointer write -> STOP; later receive -> START','This can be legitimate if the target permits it.','Target behavior decides whether this is compatible.'])
 tx(d,75,1450,'AD0 HIGH alternative: 0x69 -> HAL parameter 0xD2',44,ORANGE,True)
 foot(d,'Wire read-address 0xD1 is not the HAL address parameter.');save(im,5)
def figure6():
 im,d=begin('Release a stuck I2C bus safely','Single-master owned bus only; no active IT/DMA transfer during recovery')
 steps=[('Deinit I2C; release SDA and SCL as open-drain','Read actual levels, not only output commands.'),('SCL remains LOW?','Wait within a bound; fail and report if not released.'),('SDA LOW while SCL can rise?','Try at most 9 clock pulses; check every released SCL HIGH.'),('Attempt STOP only when possible','Restore AF4, init, filters and verify both lines idle.'),('Retry within a declared bound','A held external fault may need safely isolated target reset.')]
 for k,(a,b)in enumerate(steps):
  yy=290+k*255;panel(d,75,yy,1050,215,a,[b])
  if k<4:arrow(d,[(600,yy+220),(600,yy+245)])
 foot(d,'Recovery is not guaranteed; never force SCL push-pull HIGH.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson26-refresh-figure1.png', 'alt': 'مدار Open-drain و مدل زمان بالاروی', 'caption': 'شماتیک و مدل RC تألیفی یک خط؛ همین منطق برای SCL و SDA است. با ظرفیت فرضی 100 pF، مقاومت 10 kOhm به\u200cتنهایی زمان بالاروی 30 تا 70 درصد برابر 847.3 ns می\u200cدهد؛ 4.7 kOhm موازی آن مقاومت مؤثر حدود 3197.28 Ohm و زمان 270.91 ns می\u200cسازد. ظرفیت و زمان\u200cها اندازه\u200cگیری نشده\u200cاند.', 'purpose': 'مدار Open-drain و مدل زمان بالاروی', 'placement': 'بخش 1: باس دوسیمه، خروجی Open-drain و محاسبه مقاومت Pull-up', 'type': 'original explanatory schematic / calculated model', 'references': [{'url': 'https://cache.nxp.com/docs/en/user-guide/UM10204.pdf', 'version': 'UM10204 Rev7 October2021', 'scope': 'I2Copen-drain/framing and boundedbusclearconcept'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessed revision', 'scope': 'F3TIMINGRfields and I2Ckernel/source concepts'}, {'url': 'https://www.st.com/resource/en/application_note/an4235-i2c-timing-configuration-tool-for-stm32f3xxxx-and-stm32f0xxxx-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4235 Rev2 August2013', 'scope': 'Timingformulas anddelayterms, not obsolete toolinstructions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rails/selectors/pullups; newdiagramlayoutnotcopied'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Address/WHO_AM_I andinterfacefacts'}], 'rights': 'Original new geometry; no official figure or photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual generated project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Open-drain sinksLOW/releasesHIGH, no pushpullhigh. Cbassumed100pF, twoRCcurvescomputedV/VDD; onboard10k||external4.7k eachline.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 2, 'filename': 'lesson26-refresh-figure2.png', 'alt': 'ترتیب خواندن تک\u200cبایتی شناسه با I2C', 'caption': 'نمودار تألیفی گروه\u200cهای کلاک تراکنش مورد انتظار: START و 0xD0 برای Write، ACK هدف، رجیستر 0x75 و ACK هدف، repeated START و 0xD1 برای Read و ACK هدف، سپس دادهٔ مورد انتظار 0x12 و NACK از master و STOP. بیت نهم در هر ردیف مالک متفاوت دارد؛ این تصویر ثبت آنالایزر نیست.', 'purpose': 'ترتیب خواندن تک\u200cبایتی شناسه با I2C', 'placement': 'بخش 2: START، STOP، آدرس 7 بیتی، ACK و NACK', 'type': 'original explanatory schematic / calculated model', 'references': [{'url': 'https://cache.nxp.com/docs/en/user-guide/UM10204.pdf', 'version': 'UM10204 Rev7 October2021', 'scope': 'I2Copen-drain/framing and boundedbusclearconcept'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessed revision', 'scope': 'F3TIMINGRfields and I2Ckernel/source concepts'}, {'url': 'https://www.st.com/resource/en/application_note/an4235-i2c-timing-configuration-tool-for-stm32f3xxxx-and-stm32f0xxxx-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4235 Rev2 August2013', 'scope': 'Timingformulas anddelayterms, not obsolete toolinstructions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rails/selectors/pullups; newdiagramlayoutnotcopied'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Address/WHO_AM_I andinterfacefacts'}], 'rights': 'Original new geometry; no official figure or photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual generated project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ExpectedMem_Readframe, targetACKwritesandreadaddress, masterNACKlastdata. 0x68addressnotWHO0x12. SDAchangesSCLlowexceptSTART/STOP.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 3, 'filename': 'lesson26-refresh-figure3.png', 'alt': 'فیلدهای TIMINGR و کلاک ورودی I2C1', 'caption': 'نمودار ساختاری تألیفی I2C1 با انتخاب SYSCLK برابر 72 MHz و فیلتر آنالوگ فعال و DNF برابر 0. فیلدهای PRESC و SCLDEL و SDADEL و SCLH و SCLL با جای بیت درست نشان داده شده\u200cاند. مقدار TIMING با محاسبه انتخاب و در IOC وارد و سپس با CubeMX تولید می\u200cشود؛ اجرای محاسبه\u200cگر GUI ادعا نشده است. جمع سادهٔ شمارنده\u200cها دورهٔ دقیق سیم نیست و لبه\u200cها و فیلتر و همگام\u200cسازی باید در مدل منظور شوند. پروژهٔ نهایی از SYSCLK برابر 72 MHz و TIMINGR برابر 0x8041242A استفاده می\u200cکند؛ این مقدار محاسبه و در IOC وارد و سپس در C تولید شده است، نه حاصل اجرای محاسبه\u200cگر GUI یا اندازه\u200cگیری. با فرض rise برابر 300 ns و fall برابر 100 ns، مدل بازهٔ حدود 90.882 تا 94.737 kHz را می\u200cدهد؛ سقف Standard-mode برابر 100 kHz است.', 'purpose': 'فیلدهای TIMINGR و کلاک ورودی I2C1', 'placement': 'بخش 3: رجیستر TIMING در F303 و محاسبه آن در CubeMX', 'type': 'original explanatory schematic / calculated model', 'references': [{'url': 'https://cache.nxp.com/docs/en/user-guide/UM10204.pdf', 'version': 'UM10204 Rev7 October2021', 'scope': 'I2Copen-drain/framing and boundedbusclearconcept'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessed revision', 'scope': 'F3TIMINGRfields and I2Ckernel/source concepts'}, {'url': 'https://www.st.com/resource/en/application_note/an4235-i2c-timing-configuration-tool-for-stm32f3xxxx-and-stm32f0xxxx-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4235 Rev2 August2013', 'scope': 'Timingformulas anddelayterms, not obsolete toolinstructions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rails/selectors/pullups; newdiagramlayoutnotcopied'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Address/WHO_AM_I andinterfacefacts'}], 'rights': 'Original new geometry; no official figure or photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual generated project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ConfirmedSYSCLK72/AFonDNF0. Fieldsonly, exactwordownedbyfinalgeneratedproject. TimingcalculatedthenIOCthenCubeMXC, notGUIcalculator; no exactperiodfromcounterssum.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 4, 'filename': 'lesson26-refresh-figure4.png', 'alt': 'اتصال منطقی ماژول ICM20602 و انتخاب ریل\u200cها', 'caption': 'نمودار تألیفی اتصال PB8/SCL و PB9/SDA با AF4 و تغذیهٔ 3V3 و زمین مشترک به GB304IM V2.0. هر دو انتخابگر VDD و VDIO روی 3V3 و مسیرهای پروتکل روی I2C بررسی می\u200cشوند؛ CS به VDDIO و AD0 به GND برای آدرس 0x68 می\u200cرود. جهت هدر یا سازگاری چیدمان فرض نشده و ماژول مبدل خودکار 5 V نیست.', 'purpose': 'اتصال منطقی ماژول ICM20602 و انتخاب ریل\u200cها', 'placement': 'بخش 4: سیم\u200cبندی برد GB100ST و ماژول GebraBit ICM20602', 'type': 'original explanatory schematic / calculated model', 'references': [{'url': 'https://cache.nxp.com/docs/en/user-guide/UM10204.pdf', 'version': 'UM10204 Rev7 October2021', 'scope': 'I2Copen-drain/framing and boundedbusclearconcept'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessed revision', 'scope': 'F3TIMINGRfields and I2Ckernel/source concepts'}, {'url': 'https://www.st.com/resource/en/application_note/an4235-i2c-timing-configuration-tool-for-stm32f3xxxx-and-stm32f0xxxx-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4235 Rev2 August2013', 'scope': 'Timingformulas anddelayterms, not obsolete toolinstructions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rails/selectors/pullups; newdiagramlayoutnotcopied'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Address/WHO_AM_I andinterfacefacts'}], 'rights': 'Original new geometry; no official figure or photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual generated project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Logicalnets notcopiedlayout/headerpositions. Bothrails3V3, P1/P2/P4/P5I2Croutes/AD0GND, PB6onboardLEDseparate.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 5, 'filename': 'lesson26-refresh-figure5.png', 'alt': 'تفاوت repeated START و تراکنش\u200cهای جدا', 'caption': 'نمودار مقایسه\u200cای تألیفی: پارامتر HAL برای آدرس 7 بیتی 0x68 برابر 0xD0 است و سخت\u200cافزار جهت را اعمال می\u200cکند. Mem_Read از repeated START استفاده می\u200cکند؛ pointer-write با STOP و سپس Receive جدا، در صورت پشتیبانی هدف می\u200cتواند معتبر باشد و ذاتاً خراب یا همان تراکنش اول نیست. رجیستر 0x75 و مقدار شناسهٔ 0x12 آدرس باس نیستند.', 'purpose': 'تفاوت repeated START و تراکنش\u200cهای جدا', 'placement': 'بخش 5: HAL_I2C_Mem_Read و HAL_I2C_Master_Transmit', 'type': 'original explanatory schematic / calculated model', 'references': [{'url': 'https://cache.nxp.com/docs/en/user-guide/UM10204.pdf', 'version': 'UM10204 Rev7 October2021', 'scope': 'I2Copen-drain/framing and boundedbusclearconcept'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessed revision', 'scope': 'F3TIMINGRfields and I2Ckernel/source concepts'}, {'url': 'https://www.st.com/resource/en/application_note/an4235-i2c-timing-configuration-tool-for-stm32f3xxxx-and-stm32f0xxxx-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4235 Rev2 August2013', 'scope': 'Timingformulas anddelayterms, not obsolete toolinstructions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rails/selectors/pullups; newdiagramlayoutnotcopied'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Address/WHO_AM_I andinterfacefacts'}], 'rights': 'Original new geometry; no official figure or photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual generated project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'BothAPIshapescanbelegitimate targetdependent, not atomicunsafe framing. HAL0x68<<1D0, alternative69D2, wireD1read notHALparam.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 6, 'filename': 'lesson26-refresh-figure6.png', 'alt': 'روند محدود بازیابی باس قفل\u200cشده', 'caption': 'روندنمای تألیفی برای باس تک\u200cmaster متعلق به برنامه و بدون انتقال فعال: رهاکردن open-drain و خواندن واقعی سطح، توقف با خطای محدود اگر SCL بالا نرود، حداکثر 9 پالس هنگام SDA پایین، STOP در صورت امکان و بازگرداندن AF و init و فیلترها و بررسی idle. بازیابی تضمین نشده و SCL نباید push-pull بالا رانده شود.', 'purpose': 'روند محدود بازیابی باس قفل\u200cشده', 'placement': 'بخش 6: اسکن باس، مدیریت خطا و بازیابی باس قفل\u200cشده', 'type': 'original explanatory schematic / calculated model', 'references': [{'url': 'https://cache.nxp.com/docs/en/user-guide/UM10204.pdf', 'version': 'UM10204 Rev7 October2021', 'scope': 'I2Copen-drain/framing and boundedbusclearconcept'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessed revision', 'scope': 'F3TIMINGRfields and I2Ckernel/source concepts'}, {'url': 'https://www.st.com/resource/en/application_note/an4235-i2c-timing-configuration-tool-for-stm32f3xxxx-and-stm32f0xxxx-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4235 Rev2 August2013', 'scope': 'Timingformulas anddelayterms, not obsolete toolinstructions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rails/selectors/pullups; newdiagramlayoutnotcopied'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Address/WHO_AM_I andinterfacefacts'}], 'rights': 'Original new geometry; no official figure or photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual generated project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Boundedsinglemasterbusclear; no inventedpulsewidthuntilactualcode, noforcedSCLhigh/guaranteedrecovery.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}]
if __name__=='__main__':run()

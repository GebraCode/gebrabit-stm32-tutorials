"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=27
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Wire four SPI signals and hold CS inactive','Logical 3.3 V interconnect; selectors must match the actual GB304IM revision')
 tx(d,75,290,'STM32F303 / SPI1',44,TEAL,True);tx(d,760,290,'ICM20602 module',44,TEAL,True)
 rows=[('PA5 / SCK','SCLK',True),('PA7 / MOSI','SDI',True),('PA6 / MISO','SDO',False),('PA4 / GPIO CS','CS',True)]
 for k,(a,b,forward)in enumerate(rows):
  yy=440+k*175;tx(d,75,yy,a,42,TEAL,True);tx(d,820,yy,b,42,TEAL,True);arrow(d,[(470 if forward else 770,yy+35),(770 if forward else 470,yy+35)])
 panel(d,75,1200,1050,410,'Check power, selectors and shared ground',['Both VDD / VDIO selectors=3V3; never 5 V direct logic','SPI routes: P1 / P2 / P4 / P5; P3 must not load SDO.','External 10 kOhm CS pull-up to 3V3 holds CS HIGH at reset.'])
 foot(d,'PA6 is MISO here, not PWM; no header positions assumed.');save(im,1)
def register_row(d,y,label,bits,c=TEAL):
 tx(d,75,y,label,46,c,True)
 for k,b in enumerate(bits):
  x=75+k*135;d.rectangle((x,y+115,x+120,y+245),fill=WHITE,outline=c,width=4);tx(d,x+40,y+150,str(b),46,c,True)
def figure2():
 im,d=begin('Shift a bit in while another bit shifts out','Abstract 8-bit shift registers; the first received byte is not identity data')
 register_row(d,300,'Master transmits command 0xF5',[1,1,1,1,0,1,0,1])
 arrow(d,[(150,740),(1080,740)]);tx(d,75,650,'MOSI: master -> target',44,TEAL,True)
 arrow(d,[(1080,950),(150,950)],ORANGE);tx(d,75,850,'MISO: target -> master at the same clocks',44,ORANGE,True)
 register_row(d,1050,'Target first-byte contents: unspecified',['?']*8,ORANGE)
 panel(d,75,1430,1050,180,'Dummy 0x00 provides 8 reply clocks',['Use the second received byte as the identity reply.'])
 foot(d,'Full duplex does not mean the first response byte is meaningful.');save(im,2)
def mode_clock(d,y,mode,cpol,cpha):
 tx(d,75,y,f'Mode {mode}',44,TEAL if mode==3 else INK,True);tx(d,75,y+70,f'{cpol} / {cpha}',40)
 hi=y+30;lo=y+110;idle=hi if cpol else lo;active=lo if cpol else hi;pts=[(300,idle),(400,idle)]
 for k in range(3):
  x=400+k*200;pts.extend([(x,active),(x+100,active),(x+100,idle),(x+200,idle)])
 d.line(pts,fill=TEAL,width=6)
 for k in range(3):
  x=400+k*200+(100 if cpha else 0);dashed(d,x,y+5,x,y+140,ORANGE,w=3,dash=12);d.polygon([(x-10,y-2),(x+10,y-2),(x,y+13)],fill=ORANGE)
 sample='rising'if (cpol==cpha)else'falling';tx(d,300,y+165,'Sample '+sample+' edge; orange strobes',40,ORANGE)
def figure3():
 im,d=begin('Choose idle level and sample edge','Four generic modes; only Mode 3 is selected for the delivered exercise')
 tx(d,75,270,'CPOL / CPHA',40,MUTED)
 for k,(pol,pha)in enumerate([(0,0),(0,1),(1,0),(1,1)]):mode_clock(d,350+k*300,k,pol,pha)
 tx(d,75,1570,'Check target setup/hold requirements; these are mode models.',38)
 foot(d,'Mode 3: idle HIGH, sample rising; not a captured bus waveform.');save(im,3)
def fifo_row(d,y,n):
 for k in range(4):
  x=75+k*155;d.rectangle((x,y,x+140,y+150),fill=PALE if k<n else WHITE,outline=TEAL,width=4)
  if k<n:tx(d,x+35,y+45,'B'+str(k),42,TEAL,True)
def figure4():
 im,d=begin('Match RX threshold to access width','F3 TX/RX FIFOs each hold 32 bits; this view shows the RX FIFO')
 tx(d,75,300,'FRXTH=1:quarter threshold, 8 bits',45,TEAL,True)
 fifo_row(d,440,1);tx(d,770,480,'RXNE with 1 byte',40,TEAL,True)
 tx(d,75,760,'FRXTH=0:half threshold, 16 bits',45,TEAL,True)
 fifo_row(d,900,2);tx(d,770,940,'RXNE with 2 bytes',40,TEAL,True)
 panel(d,75,1260,1050,335,'HAL manages packed accesses',['Size >1: packed 16-bit DR, half threshold.','Odd tail: 8-bit DR, quarter threshold.','Do not change FRXTH behind an active HAL call.'])
 foot(d,'Actual identity read uses 2 frames; no universal streaming claim.');save(im,4)
def data_wave(d,bits,x,y,w=60,c=TEAL):
 pts=[]
 for k,b in enumerate(bits):
  xx=x+k*w;yy=y if b else y+75
  if pts:pts.append((xx,pts[-1][1]))
  pts.extend([(xx,yy),(xx+w,yy)])
 d.line(pts,fill=c,width=6)
def figure5():
 im,d=begin('Predict the 16-clock identity transaction','Mode 3, 72 MHz / 64 = 1.125 MHz; prediction only, not a scope capture')
 tx(d,75,290,'CS LOW across command and dummy byte',44,TEAL,True)
 d.line([(75,390),(120,390),(120,465),(1140,465),(1140,390)],fill=ORANGE,width=6);tx(d,75,510,'CS',40,ORANGE,True)
 pts=[(75,630),(150,630)]
 for k in range(16):
  x=150+k*60;pts.extend([(x,705),(x+30,705),(x+30,630),(x+60,630)])
 d.line(pts,fill=TEAL,width=5);tx(d,75,755,'SCK idle HIGH; sample rising edges',42,TEAL,True)
 tx(d,75,880,'MOSI: 0xF5 command, then 0x00 dummy',44,TEAL,True)
 data_wave(d,[1,1,1,1,0,1,0,1]+[0]*8,150,980)
 tx(d,75,1150,'MISO: first 8 bits ignored; next 8 expected 0x12',42,ORANGE,True)
 d.rounded_rectangle((150,1260,630,1380),12,outline=ORANGE,width=3);tx(d,210,1290,'Unspecified',42,ORANGE,True)
 data_wave(d,[0,0,0,1,0,0,1,0],630,1260,c=ORANGE)
 arrow(d,[(150,1480),(1110,1480)])
 tx(d,75,1560,'16 / 1.125 MHz = 14.222 us nominal wire time',43,TEAL,True)
 foot(d,'Wire time excludes software setup / CS margins / error handling.');save(im,5)
def figure6():
 im,d=begin('Check completion and identity separately','Actual source startup and checked transfer; no physical sensor test is claimed')
 steps=[('CS HIGH during reset and power-up','Wait chosen 3 ms margin; both module rails are 3V3.'),('Select SPI-only mode','Write 0x40 to 0x70; verify bit 6 before WHO read.'),('CS LOW: command F5, then dummy 00','Hold CS for both bytes; custom GPIO is your responsibility.'),('Always release GPIO CS after HAL returns','HAL_OK is not a sensor ACK; SPI has no ACK.'),('Compare Rx[1] with expected 0x12','Record HAL error; apply bounded recovery.')]
 for k,(a,b)in enumerate(steps):
  yy=290+k*255;panel(d,75,yy,1050,215,a,[b])
  if k<4:arrow(d,[(600,yy+220),(600,yy+245)])
 foot(d,'Changing back to I2C needs protocol selectors and target reset.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson27-refresh-figure1.png', 'alt': 'اتصال منطقی SPI و نگه\u200cداشتن CS در حالت غیرفعال', 'caption': 'نمودار تألیفی اتصال SPI1 روی PA5/SCK و PA7/MOSI و PA6/MISO با AF5 و PA4 به\u200cعنوان CS نرم\u200cافزاری. هر دو ریل ماژول GB304IM روی 3V3 و مسیرهای P1 و P2 و P4 و P5 روی SPI بررسی می\u200cشوند و P3 نباید SDO را بارگذاری کند. pull-up خارجی 10 kOhm روی CS برای زمان reset پیشنهاد شده؛ وجود آن روی خود ماژول فرض نشده و شمارهٔ هدر بازسازی نشده است.', 'purpose': 'اتصال منطقی SPI و نگه\u200cداشتن CS در حالت غیرفعال', 'placement': 'زیربخش سیم\u200cبندی سخت\u200cافزاری ماژول GB304IM و مدیریت CS', 'type': 'original explanatory diagram / synthetic protocol model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'PA5/PA6/PA7AF5 logicalpins and electricalconditions'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessedrevision', 'scope': 'SPI4..16bitdata/FIFO/FRXTH/flags'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Identityread/startup/register70bit6 andSPIprotocol'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rail/protocolselectors; newlayoutnotcopied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualSPIprojectfacts', 'scope': 'PackedDRaccess/thresholdchanges/endtransaction andcheckedGPIOCSownership'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing from accepted Antigravity plan and generated-project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Logical3V3/GND, no5Vlogic/headerposition/copiedlayout; PA6notPWM; externalCSpullupnotonboardclaim.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 2, 'filename': 'lesson27-refresh-figure2.png', 'alt': 'مدل شیفت هم\u200cزمان داده و نقش بایت dummy', 'caption': 'مدل تألیفی دو مسیر هم\u200cزمان MOSI و MISO برای یک جفت رجیستر شیفت انتزاعی 8 بیتی. فرمان نمونه 0xF5 ارسال می\u200cشود و مقدار اولین بایت دریافتی نامشخص و نادیده گرفته می\u200cشود؛ بایت dummy برابر 0x00 هشت کلاک بعدی را برای دریافت شناسه فراهم می\u200cکند. این مدل معماری داخلی قطعه یا ثبت واقعی باس نیست.', 'purpose': 'مدل شیفت هم\u200cزمان داده و نقش بایت dummy', 'placement': 'سناریوی کاربردی و مدل ذهنی گذرگاه SPI', 'type': 'original explanatory diagram / synthetic protocol model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'PA5/PA6/PA7AF5 logicalpins and electricalconditions'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessedrevision', 'scope': 'SPI4..16bitdata/FIFO/FRXTH/flags'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Identityread/startup/register70bit6 andSPIprotocol'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rail/protocolselectors; newlayoutnotcopied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualSPIprojectfacts', 'scope': 'PackedDRaccess/thresholdchanges/endtransaction andcheckedGPIOCSownership'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing from accepted Antigravity plan and generated-project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Abstractfull-duplex8bitshiftmodel; ignorefirstRxunspecified, dummyclocksecondreply; nohighZ/00firstbyteinvented.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 3, 'filename': 'lesson27-refresh-figure3.png', 'alt': 'چهار حالت عمومی CPOL و CPHA', 'caption': 'مدل تألیفی چهار حالت عمومی SPI و لبهٔ نمونه\u200cبرداری با strobe نارنجی. فقط Mode 3 با idle بالا و sample در لبهٔ rising برای پروژه انتخاب شده است؛ setup و hold هدف باید از سند آن خوانده شود و حالت\u200cها نتیجهٔ آزمایش روی قطعه نیستند.', 'purpose': 'چهار حالت عمومی CPOL و CPHA', 'placement': 'حالت\u200cهای کاری SPI (CPOL و CPHA) و استخراج زمان\u200cبندی از دیتاشیت', 'type': 'original explanatory diagram / synthetic protocol model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'PA5/PA6/PA7AF5 logicalpins and electricalconditions'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessedrevision', 'scope': 'SPI4..16bitdata/FIFO/FRXTH/flags'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Identityread/startup/register70bit6 andSPIprotocol'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rail/protocolselectors; newlayoutnotcopied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualSPIprojectfacts', 'scope': 'PackedDRaccess/thresholdchanges/endtransaction andcheckedGPIOCSownership'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing from accepted Antigravity plan and generated-project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Generic4modes, actualMode3CPOL1CPHA1sampleRising/changeFalling; nosecondtestedMode0claim.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 4, 'filename': 'lesson27-refresh-figure4.png', 'alt': 'ظرفیت FIFO و اثر FRXTH و بسته\u200cبندی HAL', 'caption': 'نمودار تألیفی RX FIFO با ظرفیت 32 بیت و آستانهٔ یک بایت یا دو بایت. در HAL دقیق F3، انتقال 8 بیتی با Size بزرگ\u200cتر از 1 می\u200cتواند دسترسی packed شانزده\u200cبیتی و آستانهٔ نصف و برای tail فرد دسترسی 8 بیتی و آستانهٔ یک\u200cچهارم به کار ببرد. FRXTH همیشه 1 نیست و تغییر آن پشت سر HAL توصیه نشده است.', 'purpose': 'ظرفیت FIFO و اثر FRXTH و بسته\u200cبندی HAL', 'placement': 'معماری بافر FIFO و آستانه دریافت (FRXTH) در STM32F3', 'type': 'original explanatory diagram / synthetic protocol model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'PA5/PA6/PA7AF5 logicalpins and electricalconditions'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessedrevision', 'scope': 'SPI4..16bitdata/FIFO/FRXTH/flags'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Identityread/startup/register70bit6 andSPIprotocol'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rail/protocolselectors; newlayoutnotcopied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualSPIprojectfacts', 'scope': 'PackedDRaccess/thresholdchanges/endtransaction andcheckedGPIOCSownership'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing from accepted Antigravity plan and generated-project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': '32bitTX/RXFIFO, FRXTH1quarter8/0half16, actualHALpackedSize>1 andoddtail; noallstreamingerratumapproval.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 5, 'filename': 'lesson27-refresh-figure5.png', 'alt': 'تراکنش پیش\u200cبینی\u200cشدهٔ 16 کلاکی شناسه', 'caption': 'مدل تألیفی Mode 3 با SCK اسمی 1.125 MHz از 72 MHz تقسیم بر 64. CS در تمام فرمان 0xF5 و dummy برابر 0x00 پایین می\u200cماند؛ هشت بیت اول MISO نامشخص و هشت بیت بعد مقدار مورد انتظار 0x12 هستند. 16 کلاک حدود 14.222 us زمان سیم اسمی است و زمان HAL و حاشیهٔ CS و خطا را شامل نمی\u200cشود؛ تصویر اسیلوسکوپ نیست.', 'purpose': 'تراکنش پیش\u200cبینی\u200cشدهٔ 16 کلاکی شناسه', 'placement': 'آزمایش پیش\u200cبینی\u200cشده: خواندن رجیستر WHO_AM_I', 'type': 'original explanatory diagram / synthetic protocol model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'PA5/PA6/PA7AF5 logicalpins and electricalconditions'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessedrevision', 'scope': 'SPI4..16bitdata/FIFO/FRXTH/flags'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Identityread/startup/register70bit6 andSPIprotocol'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rail/protocolselectors; newlayoutnotcopied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualSPIprojectfacts', 'scope': 'PackedDRaccess/thresholdchanges/endtransaction andcheckedGPIOCSownership'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing from accepted Antigravity plan and generated-project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': '16cycles32edges, continuousCS, MSBF5+00 expectedsecond12, firstunspecifiedignored, noactualcapture/observedidentity.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 6, 'filename': 'lesson27-refresh-figure6.png', 'alt': 'توالی startup و کنترل وضعیت انتقال و شناسه', 'caption': 'روندنمای تألیفی منطبق با کد نهایی: انتظار انتخاب\u200cشدهٔ 3 ms پس از تغذیه، نوشتن 0x40 در رجیستر 0x70 و بررسی bit 6، خواندن WHO_AM_I با F5 و بایت dummy، رهاکردن CS در همهٔ مسیرهای خروج و مقایسهٔ بایت دوم با 0x12. این مراحل واقعاً در کد وجود دارند؛ اجرای فیزیکی روی حسگر و اندازه\u200cگیری زمان انجام نشده است.', 'purpose': 'توالی startup و کنترل وضعیت انتقال و شناسه', 'placement': 'عیب\u200cیابی، تله\u200cهای رایج و تحلیل مسیر خطاهای بازگشتی HAL', 'type': 'original explanatory diagram / synthetic protocol model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'PA5/PA6/PA7AF5 logicalpins and electricalconditions'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no guessedrevision', 'scope': 'SPI4..16bitdata/FIFO/FRXTH/flags'}, {'url': 'https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000176-icm-20602-v1.1.pdf', 'version': 'DS-000176 Rev1.1', 'scope': 'Identityread/startup/register70bit6 andSPIprotocol'}, {'url': 'https://gebrabit.com/wp-content/uploads/2025/07/GebraBit-ICM20602-Schematic-V2.0.pdf', 'version': 'GB304IM V2.0', 'scope': 'Module rail/protocolselectors; newlayoutnotcopied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualSPIprojectfacts', 'scope': 'PackedDRaccess/thresholdchanges/endtransaction andcheckedGPIOCSownership'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing from accepted Antigravity plan and generated-project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actualchosenstartup3ms/write70=40/readbackbit6 thenWHO; compareidentityseparateHALstatus, CSdeassertonallreturns; actualcompiledorderbindingrequired.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}]
if __name__=='__main__':run()

"""Offline calculations and archive/source checks; no target or electrical execution."""
from pathlib import Path
import hashlib,json,math,struct,sys,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'toolchain-and-validation.json').read_text(encoding='utf-8'))
name=meta['project'];lesson=meta['lesson'];checks=[];values={}
def check(label,condition):
    if not condition: raise AssertionError(label)
    checks.append(label)
with zipfile.ZipFile(ROOT/f'lesson-{lesson}-projects.zip') as z:
    check('source archive CRC',z.testzip() is None)
    manifest=json.loads((ROOT/'source-manifest.json').read_text())
    check('all source hashes',all(hashlib.sha256(z.read(name+'/'+k)).hexdigest()==v for k,v in manifest.items()))
    check('three component licenses',all(name+'/'+x in z.namelist() for x in meta['component_licenses']))
    main=z.read(name+'/Core/Src/main.c').decode()
    ioc=z.read(name+'/'+name+'.ioc').decode()
    init=z.read(name+'/Core/Src/'+('i2c.c' if lesson==26 else 'spi.c')).decode()
    check('baseline PLL9 and Flash2 actual source',all(x in main for x in ['RCC_PLL_MUL9','RCC_HSE_PREDIV_DIV1','RCC_HCLK_DIV2','FLASH_LATENCY_2']))
with zipfile.ZipFile(ROOT/f'lesson-{lesson}-build-artifacts.zip') as z:
    check('artifact archive CRC',z.testzip() is None)
    elf=z.read(name+'/'+name+'.elf')
    check('ELF artifact hash',hashlib.sha256(elf).hexdigest()==meta['ELF_SHA256'])
    check('ARM32 little endian executable',elf[:6]==b'\x7fELF\x01\x01' and struct.unpack_from('<HH',elf,16)==(2,40))
    shoff=struct.unpack_from('<I',elf,32)[0];entsize,shnum,shstr=struct.unpack_from('<HHH',elf,46)
    sections=[struct.unpack_from('<IIIIIIIIII',elf,shoff+i*entsize) for i in range(shnum)]
    strings=sections[shstr];names=elf[strings[4]:strings[4]+strings[5]]
    labels=[names[h[0]:].split(b'\0',1)[0].decode() for h in sections]
    check('actual debug info and vector section',all(s in labels for s in ['.debug_info','.debug_line','.isr_vector']))
    check('RAM section accounting',sum([meta['data_bytes'],meta['actual_BSS_bytes'],meta['heap_stack_section_bytes']])==meta['RAM_linked_reserved_bytes'])
check('actual Debug warning flags',all(x in meta['main_compile_command'] for x in ['-O0','-g3','-Wall','-Werror']))

check('generated Mode3 actual source', 'SPI_POLARITY_HIGH' in init and 'SPI_PHASE_2EDGE' in init)
check('generated64prescaler8bitsoftwareNSS',all(s in init for s in ['SPI_BAUDRATEPRESCALER_64','SPI_DATASIZE_8BIT','SPI_NSS_SOFT','SPI_NSS_PULSE_DISABLE','GPIO_AF5_SPI1','GPIO_SPEED_FREQ_HIGH']))
sck=72000000/64;wire=16/sck*1e6
check('clock arithmetic and sensor limit',sck==1125000 and 72000000/8<=10000000 and 72000000/4>10000000)
check('WHO command and second receivebyte',0x75|0x80==0xF5 and all(x in main for x in ['WHO_AM_I_REG 0x75U','WHO_AM_I_EXPECTED 0x12U','*value = rx[1]','HAL_SPI_TransmitReceive(&hspi1, tx, rx, 2U']))
check('startup SPIonly configure plus readback',all(s in main for s in ['HAL_Delay(3U)','I2C_IF_REG 0x70U','I2C_IF_DIS_BIT 0x40U','Sensor_Write(I2C_IF_REG, I2C_IF_DIS_BIT)','Sensor_Read(I2C_IF_REG, &value)']))
check('guards and unconditional CSrelease source',all(s in main for s in ['Delay_Us(1U)','guard < 200000U','Always release CS','SENSOR_CS_Pin, GPIO_PIN_SET','SPI_TRANSFER_TIMEOUT_MS 20U']))
with zipfile.ZipFile(ROOT/f'lesson-{lesson}-projects.zip') as z:
    driver=z.read(name+'/Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_spi.c').decode()
check('pinned HAL2bytepacking and threshold behavior',all(s in driver for s in ['initial_RxXferCount > 1U','CLEAR_BIT(hspi->Instance->CR2, SPI_RXFIFO_THRESHOLD)','hspi->RxXferCount -= 2U','SET_BIT(hspi->Instance->CR2, SPI_RXFIFO_THRESHOLD)']))
check('transfer completion drains FIFOs and BSY',all(x in driver for x in ['SPI_EndRxTxTransaction(hspi, Timeout, tickstart)','SPI_FTLVL_EMPTY','SPI_FRLVL_EMPTY','SPI_FLAG_BSY, RESET']))
values={'PCLK2_hz':72000000,'prescaler':64,'SCK_nominal_hz':sck,'sensor_limit_hz':10000000,'read_transfer_clock_cycles':16,'wiretime_without_CSguards_or_HALgaps_us':wire,'requested_nominal_CS_setup_us':1,'requested_nominal_CS_hold_us':1,'powerup_HAL_delay_ms':3,'datasheet_register_startup_max_ms':2,'write_SPIonly_hex':['70','40'],'read_WHO_hex':['F5','00'],'expected_second_rx_hex':'12','SPI_HAL_has_no_sensor_ACK':True}

result={'scope':'Offline calculation/source/archive/ELF checks; not an MCU run, C simulator, bus electrical measurement, or proof of reliable communication. Edge capacitance/filter assumptions must be verified on actual wiring.','passed':len(checks),'checks':checks,'values':values}
(ROOT/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))

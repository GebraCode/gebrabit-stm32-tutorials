"""Bounded ASCII protocol model matching the lesson firmware; not CPU execution."""
def frame(seq,payload=b'',ending=b'\n'):
    if not 0<=seq<=0xffffffff or len(payload)>32:raise ValueError('frame range')
    prefix=f'S,{seq},{payload.hex().upper()}'.encode('ascii')
    return prefix+b','+f'{sum(prefix)&255:02X}'.encode()+ending

def validate(line):
    try:
        text=line.decode('ascii');parts=text.split(',')
        if len(parts)!=4 or parts[0]!='S' or not parts[1] or not all('0'<=c<='9' for c in parts[1]):return None
        seq=int(parts[1]);payload=parts[2];check=parts[3]
        if seq>0xffffffff or len(payload)>64 or len(payload)%2 or len(check)!=2:return None
        if any(c not in '0123456789abcdefABCDEF' for c in payload+check):return None
        if int(check,16)!=(sum(line[:line.rfind(b',')])&255):return None
        return seq,int(check,16)
    except (UnicodeError,ValueError):return None

class Parser:
    def __init__(self):self.line=bytearray();self.discard=False;self.ignore_lf=False;self.accepted=[];self.invalid=0;self.overflows=0;self.expected=None;self.discontinuities=0
    def resync(self):self.line.clear();self.discard=True;self.ignore_lf=False
    def feed(self,data):
        for b in data:
            if b in (10,13):
                if b==10 and self.ignore_lf:self.ignore_lf=False;continue
                self.ignore_lf=b==13
                if self.discard:self.discard=False;self.line.clear();continue
                if self.line:
                    result=validate(bytes(self.line))
                    if result is None:self.invalid+=1
                    else:
                        seq,check=result
                        if self.expected is not None and seq!=self.expected:self.discontinuities+=1
                        self.expected=(seq+1)&0xffffffff;self.accepted.append(result)
                self.line.clear();continue
            self.ignore_lf=False
            if b<32 or b>126:self.invalid+=1;self.line.clear();self.discard=True;continue
            if self.discard:continue
            if len(self.line)<95:self.line.append(b)
            else:self.overflows+=1;self.line.clear();self.discard=True

class Ring:
    def __init__(self,n=256):self.buf=bytearray(n);self.n=n;self.head=self.tail=self.drops=0
    def push(self,b):
        nxt=(self.head+1)&(self.n-1)
        if nxt==self.tail:self.drops+=1;return False
        self.buf[self.head]=b;self.head=nxt;return True
    def pop(self):
        if self.head==self.tail:return None
        b=self.buf[self.tail];self.tail=(self.tail+1)&(self.n-1);return b

"""Current-NDTR cursor model plus bounded stream/ownership and actual ELF proof."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,struct,zipfile
from protocol_model import Parser,Ring,frame
class Cursor:
    def __init__(self):self.memory=[None]*64;self.absolute=0;self.old=0;self.output=[];self.no_progress=0
    def write(self,count):
        for _ in range(count):self.memory[self.absolute%64]=self.absolute;self.absolute+=1
    def event(self,size,event):
        assert 1<=size<=64
        remaining=64-(self.absolute%64);position=(64-remaining)&63
        if position==self.old:self.no_progress+=1;return []
        result=[]
        while self.old!=position:
            result.append(self.memory[self.old]);self.old=(self.old+1)&63
        self.output.extend(result);return result
c=Cursor();c.write(40);assert c.event(40,'IDLE')==list(range(40));assert c.event(32,'staleHT')==[]
c.write(24);assert c.event(64,'TC')==list(range(40,64));assert c.event(64,'duplicateTC')==[]
c.write(6);assert c.event(6,'IDLE')==list(range(64,70));assert c.event(64,'staleTC')==[]
assert c.output==list(range(70))
c=Cursor()
for i in range(1000):
    c.write(1)
    if c.absolute%32==0:c.event(32 if c.absolute%64 else 64,'HTorTC')
    if c.absolute%27==0:c.event(c.absolute%64 or 64,'IDLE')
c.event(c.absolute%64 or 64,'IDLE');assert c.output==list(range(1000))
ambiguous=Cursor();ambiguous.write(64);assert ambiguous.event(64,'TC')==[]
# Exact whole revolution has same cursor as a duplicate; never invent an extra64 copied bytes.
r=Ring(512);assert all(r.push(i&255) for i in range(511));assert not r.push(1)
assert [r.pop() for _ in range(511)]==[i&255 for i in range(511)]
p=Parser();wire=b''.join(frame(i,bytes(range(i%33)),b'\r\n') for i in range(100))
for i in range(0,len(wire),32):p.feed(wire[i:i+32])
assert len(p.accepted)==100 and p.invalid==0 and p.discontinuities==0
q=Parser();q.feed(frame(1)[:5]);q.resync();q.feed(frame(1)[5:]+frame(2));assert [x[0] for x in q.accepted]==[2]
class TxOwner:
    def __init__(self):self.busy=False;self.data=b''
    def start(self,data):
        if self.busy:return False
        self.data=data;self.busy=True;return True
    def complete_or_abort(self):self.busy=False
t=TxOwner();assert t.start(b'first');assert not t.start(b'overwrite') and t.data==b'first';t.complete_or_abort();assert t.start(b'next')
def inspect(data):
    h=struct.unpack_from('<16sHHIIIIIHHHHHH',data);assert h[0][:6]==b'\x7fELF\x01\x01' and h[2]==40
    sections=[struct.unpack_from('<IIIIIIIIII',data,h[6]+i*h[11]) for i in range(h[12])];result={};wanted={'dma_rx':64,'rx_ring':512,'tx_buffer':32}
    for s in sections:
        if s[1]!=2:continue
        st=sections[s[6]];ss=data[st[4]:st[4]+st[5]]
        for o in range(s[4],s[4]+s[5],s[9]):
            n,a,z,info,other,index=struct.unpack_from('<IIIBBH',data,o);name=ss[n:ss.find(b'\0',n)].decode()
            if name in wanted:
                assert z==wanted[name] and 0x20000000<=a and a+z<=0x20008000
                result[name]={'address':hex(a),'bytes':z,'main_SRAM_not_CCM':True}
    assert len(result)==3;return result
root=Path(__file__).parent
with zipfile.ZipFile(root/'lesson-15-build-artifacts.zip') as z:elf={n:inspect(z.read(n)) for n in z.namelist() if n.endswith('.elf')}
with zipfile.ZipFile(root/'lesson-15-projects.zip') as z:
    u=z.read('gebrabit_lesson15_uart_dma/Core/Src/usart.c').decode();irq=z.read('gebrabit_lesson15_uart_dma/Core/Src/stm32f3xx_it.c').decode()
    assert all(s in u for s in ['hdma_usart1_rx.Instance = DMA1_Channel5','hdma_usart1_rx.Init.Mode = DMA_CIRCULAR','hdma_usart1_tx.Instance = DMA1_Channel4','hdma_usart1_tx.Init.Mode = DMA_NORMAL'])
    assert all(s in irq for s in ['void DMA1_Channel4_IRQHandler','void DMA1_Channel5_IRQHandler','void USART1_IRQHandler'])
result={'scope':'Synthetic cursor/protocol/ownership arithmetic and actual offline source/ELF inspection; no hardware throughput or CPU-load measurement','RX_DMA_bytes':64,'software_ring_bytes':512,'usable_ring_bytes':511,'TX_owned_buffer_bytes':32,'ideal_baud':115200,'ideal_character_us':1e6*10/115200,'ideal_half_buffer_ms':1000*32*10/115200,'ideal_full_buffer_ms':1000*64*10/115200,'ideal_aux_backlog_ms':1000*511*10/115200,'continuous_RX_IT_byte_callbacks_per_second':11520,'continuous_DMA_HT_TC_callbacks_per_second':360,'CPU_load_percent':None,'whole_unobserved_revolution':'undetectable from modulo cursor alone; deadline violation can lose data; never fabricate64new bytes','checks_passed':['IDLE then staleHT no duplicate','normal wrap','duplicateTC no copy','staleTC no backwards wrap','1000bytes ordered within service bound','unseen full-revolution ambiguity','511usable ring bound','100protocol frames across chunks','recovery discard toEOL','TXownership before complete/abort','actual ELF SRAM buffers','actual generatedDMAchannels and3IRQroutes'],'ELF':elf}
(root/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

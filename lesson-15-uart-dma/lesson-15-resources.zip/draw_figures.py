"""Editable original educational diagrams. Requires Pillow and Windows Segoe UI.
All timelines and waveforms are models, never captured hardware results.
Regenerates only this lesson's PNGs and image-metadata.json beside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, json, textwrap
OUT=Path(__file__).resolve().parent
LESSON=15
W,H=1200,1800
INK='#16354b';TEAL='#087f8c';ORANGE='#ac5c18';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c7d7e1';PALE='#e3f1f2';WHITE='#ffffff'
def font(n=43,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if bold else '')+'.ttf',n)
def tx(d,x,y,s,n=43,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1060,n=43,c=INK,b=False,gap=12):
    words=s.split();lines=[];line=''
    for word in words:
        test=(line+' '+word).strip()
        if d.textlength(test,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,sub='Original diagram / synthetic model'):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,38,title,1090,52,b=True)
    para(d,55,y+10,sub,1090,38,c=MUTED)
    d.line((55,185,1145,185),fill=LINE,width=3)
    return im,d
def footer(d,s='STM32F303CBT6 | Official manuals + exact F3 HAL'):
    d.line((55,H-165,1145,H-165),fill=LINE,width=3)
    para(d,55,H-140,s,1090,33,c=MUTED,gap=6)
    tx(d,55,H-50,'Original model. No board measurement or GUI capture.',32,MUTED)
def arrow(d,pts,c=TEAL,width=7):
    d.line(pts,fill=c,width=width)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+13,s,w-48,42)
    assert yy-18<=y+h+5,(title,yy,y+h)
def note(d,y,s,c=INK):return para(d,65,y,s,1070,43,c)
def save(im,i):im.save(OUT/f'lesson{LESSON}-figure{i}.png',optimize=True)
def axis(d,x0=160,y0=1150,x1=1110,y1=340,xlabel='Time ->',ylabel=None):
    arrow(d,[(x0,y0),(x1,y0)],INK,4);arrow(d,[(x0,y0),(x0,y1)],INK,4)
    tx(d,x1-230,y0+95,xlabel,39)
    if ylabel:tx(d,65,y1-70,ylabel,42,b=True)
def dots(d,x,y,count,active=None,step=70):
    for k in range(count):
        color=TEAL if active is None or k in active else LINE
        d.rounded_rectangle((x+k*step,y,x+k*step+step-9,y+70),8,fill=color)
def step(d,events,xmap,yhi,ylo,c=TEAL,width=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,yhi if last else ylo),(x,yhi if v else ylo)]);last=v
    d.line(pts,fill=c,width=width)
def ring(d,cx,cy,r=310,n=16,start=3,end=11):
    # Sectors represent groups of bytes, not a false256-cell screenshot.
    for k in range(n):
        d.pieslice((cx-r,cy-r,cx+r,cy+r),k*360/n-90,(k+1)*360/n-90,fill=TEAL if (start<=k<end or end>n and k<end-n) else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+100,cy-r+100,cx+r-100,cy+r-100),fill=BG)
def lineplot(d,points,x0,y0,xscale,yscale,c=TEAL):
    d.line([(x0+x*xscale,y0-y*yscale) for x,y in points],fill=c,width=7)



def lesson15():
    im,d=begin('USART1 has fixed DMA channel routes','STM32F303CBT6 | Logical connections, not header positions')
    panel(d,70,230,1060,225,'USART1 / APB2',['PA9 TX / AF7 / LQFP48 pin30','PA10 RX / AF7 / LQFP48 pin31'])
    arrow(d,[(300,475),(300,620)],ORANGE);arrow(d,[(900,620),(900,475)],TEAL)
    tx(d,70,505,'TX: data to UART',41,ORANGE,True);tx(d,700,505,'RX: UART to RAM',41,TEAL,True)
    panel(d,65,645,520,230,'DMA1 Channel4',['TX Normal','App buffer -> TDR'],ORANGE)
    panel(d,615,645,520,230,'DMA1 Channel5',['RX Circular','RDR ->64-byte ring'])
    arrow(d,[(300,895),(300,1060)],ORANGE);arrow(d,[(900,1060),(900,895)],TEAL)
    panel(d,70,1080,1060,230,'Main SRAM: DMA buffers',['Supported SRAM region starts at0x20000000.','CCM RAM0x10000000 is not a DMA buffer.'])
    note(d,1425,'For the USB-TTL adapter: cross TX/RX, share GND, verify3.3V logic, and keep board supply independent.')
    footer(d,'DS9118 pinout + RM0316 fixed DMA mapping; no DMAMUX here.');save(im,1)

    im,d=begin('TX ownership ends at UART completion','Actual Normal DMA TX path | Timeline is not to scale')
    x=[130,390,720,1080]
    for base,title,c in [(300,'Application buffer',TEAL),(690,'DMA / memory',ORANGE),(1080,'UART line / HAL',INK)]:
        tx(d,65,base,title,46,c,True);d.line((100,base+180,1120,base+180),fill=LINE,width=4)
    d.rectangle((x[0],405,x[3],495),fill=TEAL);tx(d,220,425,'Do not edit / reuse bytes while TX is busy',41,'white',True)
    d.rectangle((x[0],795,x[2],885),fill=ORANGE);tx(d,190,815,'DMA supplies TDR',42,'white',True)
    d.rectangle((x[0],1185,x[3],1275),fill=INK);tx(d,185,1205,'UART shifts final byte, then UART_TC',41,'white',True)
    for xx,label,yy,c in [(x[0],'HAL_OK',560,TEAL),(x[2],'DMA_TC',950,ORANGE),(x[3],'UART_TC',1350,INK)]:
        d.line((xx,yy-65,xx,yy+15),fill=c,width=5);tx(d,max(70,xx-160),yy+30,label,42,c,True)
    note(d,1450,'Release on TxCpltCallback, or after AbortTransmit completes. DMA_TC alone does not release the buffer; a new start may return HAL_BUSY.')
    footer(d,'Pinned stm32f3xx_hal_uart.c DMA-TX -> UART-TC path.');save(im,2)

    im,d=begin('Size is a position, not a byte delta','Actual RX bufferN=64 | Current DMA cursor avoids stale events')
    ring(d,600,580,r=280,n=16,start=12,end=20)
    tx(d,490,500,'N =64',52,TEAL,True);tx(d,420,580,'index0..63',43)
    tx(d,75,235,'HT: Size32',43,ORANGE,True);tx(d,760,235,'TC: Size64',43,TEAL,True)
    tx(d,65,925,'API Size: first free position in1..64',46,b=True)
    tx(d,65,1025,'Actual cursor = (64 - NDTR) %64',46,TEAL,True)
    panel(d,70,1140,1060,210,'Wrap example: old48 -> cursor16',['Copy [48..63], then [0..15]:32 new bytes.','Callback Size may be stale; read current NDTR.'])
    note(d,1440,'Same position can mean no bytes or a missed full revolution. Cursor comparison cannot reconstruct overwritten data.',RED)
    footer(d,'HT/TC/IDLE require timely service; UART and DMA use equal preempt priority.');save(im,3)

    im,d=begin('Move bounded data; parse in main','Actual producer/consumer boundaries | This is not zero-copy')
    d.rounded_rectangle((55,225,1145,935),20,fill='#e5f2f3',outline=TEAL,width=3)
    tx(d,85,245,'HARDWARE + ISR CONTEXT',46,TEAL,True)
    panel(d,100,350,1000,150,'USART RX ->64-byte Circular DMA',())
    arrow(d,[(600,515),(600,590)])
    panel(d,100,610,1000,210,'RxEvent / DMA interrupt handling',['Read NDTR cursor; copy only new range.','Count overflow / error; no blocking TX here.'])
    arrow(d,[(600,835),(600,1015)])
    panel(d,100,1035,1000,170,'Auxiliary SPSC ring:512 slots',['511 usable bytes; finite backlog.'])
    arrow(d,[(600,1220),(600,1305)])
    panel(d,100,1325,1000,220,'MAIN: deferred frame parser',['Validate framing, sequence and checksum.','Prepare response only in an owned TX buffer.'])
    footer(d,'USART/DMA ISR producer is serialized; main owns ring consumption.');save(im,4)

    im,d=begin('DMA errors need controlled recovery','Recovery policy model | Lost data cannot be restored')
    stages=[('Active Circular RX','HT / TC / IDLE events drain current cursor.'),('Error recorded','ORE or DMA transfer error marks recovery.'),('MAIN: abort RX + TX once','Keep ordinary callbacks from restarting RX.'),('Discard partial state','Flush stale ring/cursor and partial frame.'),('Restart RX; check HAL_OK','Count failures; resynchronize incoming frames.')]
    for k,(a,b) in enumerate(stages):
        y=230+k*250;panel(d,80,y,1040,180,a,[b],RED if k==1 else TEAL)
        if k<4:arrow(d,[(600,y+190),(600,y+235)])
    footer(d,'Use the delivered error/abort path; do not assume a hardware auto-restart.');save(im,5)

    im,d=begin('Different buffers protect different deadlines','115200 8N1 model | CPU utilization has not been measured')
    tx(d,70,235,'Wire rate:11520 bytes/s',47,b=True)
    for base,title,n,time,c in [(380,'One-byte UART service',1,'86.8056us',ORANGE),(710,'DMA half-buffer service',32,'2.7778ms',TEAL),(1040,'Auxiliary ring capacity',511,'44.3576ms',INK)]:
        tx(d,70,base,title,46,c,True)
        # Equal-length marks show classes, not misleading measured benchmark bars.
        for j in range(8):
            xx=100+j*130;d.rectangle((xx,base+100,xx+105,base+155),fill=c)
        tx(d,100,base+200,f"{n} {'byte' if n==1 else 'bytes'} /11520 = {time}",43,c,True)
    note(d,1425,'A full64-byte DMA revolution takes5.5556ms. The511-byte ring budget does not extend the DMA ISR service deadline.',RED)
    footer(d,'Empty-start ideal budgets; scheduling and existing backlog reduce headroom.');save(im,6)




def run():
    globals()[f'lesson{LESSON}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')



METADATA=[{'id': 1, 'filename': 'lesson15-figure1.png', 'alt': 'USART1 و کانال\u200cهای ثابت DMA1', 'caption': 'نمودار تألیفی مسیر DMA1 Channel4 برای TX و Channel5 برای RX؛ پایه\u200cهای PA9 و PA10 با AF7 و شمارهٔ فیزیکی بستهٔ LQFP48 مشخص\u200cاند، نه شمارهٔ هدر. بافر واقعی RX برابر 64 بایت در SRAM اصلی است؛ CCM مسیر DMA ندارد.', 'purpose': 'کدام کانال\u200cهای ثابت DMA1 به USART1 مربوط\u200cاند و بافر کجا قرار می\u200cگیرد؟', 'placement': 'زیربخش: نگاشت سخت\u200cافزاری کانال\u200cهای DMA1 برای USART1 و محدودیت دسترسی به CCM RAM', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 2, 'filename': 'lesson15-figure2.png', 'alt': 'مالکیت بافر TX تا تکمیل UART', 'caption': 'نمودار توالی تألیفی بدون مقیاس زمانی واقعی: DMA_TC به معنی خروج آخرین بیت از خط نیست. در حالت Normal، مسیر HAL پس از UART_TC به TxCpltCallback می\u200cرسد و بافر طبق سیاست برنامه آزاد می\u200cشود؛ شروع هم\u200cزمان ممکن است HAL_BUSY بدهد.', 'purpose': 'چرا مالکیت بافر TX با DMA_TC پایان نمی\u200cیابد؟', 'placement': 'زیربخش: حفاظت از یکپارچگی داده و آزادسازی حافظه در تابع بازخوانی HAL_UART_TxCpltCallback', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 3, 'filename': 'lesson15-figure3.png', 'alt': 'تفاوت Size و موقعیت فعلی DMA با محاسبهٔ پیچش', 'caption': 'مدل تألیفی با N=64: Size جایگاه نخستین محل آزاد در 1..64 است، نه تعداد بایت تازه. پروژه برای جلوگیری از عقب\u200cرفتن بر اثر callback دیرهنگام از cursor=(64-NDTR)%64 استفاده می\u200cکند. مثال old=48 و cursor=16 برابر 32 بایت تازه است؛ موقعیت برابر به\u200cتنهایی دور کامل ازدست\u200cرفته را کشف نمی\u200cکند.', 'purpose': 'Size و cursor فعلی DMA چه تفاوتی با دلتای داده دارند و wrap چگونه شمرده می\u200cشود؟', 'placement': 'زیربخش: الگوریتم محاسبه دلتای موقعیت داده و مدیریت شرایط پیچش بافر (Wrap-around)', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 4, 'filename': 'lesson15-figure4.png', 'alt': 'جداسازی دریافت DMA از پردازش پیام در main', 'caption': 'نمودار جریان تألیفی مطابق پروژه: بافر DMA برابر 64 بایت و SPSC برابر 512 خانه با ظرفیت 511 بایت است. ISR فقط محدودهٔ تازه را کپی می\u200cکند؛ main پیام متنی S,seq,hex,sum8 با payload حداکثر 32 بایت و پایان خط را بررسی می\u200cکند. این مسیر zero-copy نیست.', 'purpose': 'کدام بخش دریافت در ISR انجام می\u200cشود و کدام بخش پردازش به main می\u200cرود؟', 'placement': 'زیربخش: جداسازی زمینه وقفه از پردازش سنگین با استفاده از بافر کمکی SPSC', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 5, 'filename': 'lesson15-figure5.png', 'alt': 'ترتیب توقف و بازیابی دریافت DMA', 'caption': 'ماشین حالت تألیفی مطابق سیاست پروژه: خطا ثبت می\u200cشود؛ main یک\u200cبار AbortReceive می\u200cکند، فلگ\u200cها و ورودی باقی\u200cمانده را با مسیر HAL و ICR/RQR پاک و صف و cursor و خط ناقص را تخلیه می\u200cکند و دریافت را مجدداً با بررسی HAL_OK راه می\u200cاندازد. بازیابی به معنای بازگرداندن بایت ازدست\u200cرفته نیست.', 'purpose': 'برنامه با خطای UART یا DMA چگونه دریافت را متوقف و دوباره راه\u200cاندازی می\u200cکند؟', 'placement': 'زیربخش: رویه پاک\u200cسازی ثبات\u200cهای وضعیت، سقط دریافت و راه\u200cاندازی مجدد ReceiveToIdle', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 6, 'filename': 'lesson15-figure6.png', 'alt': 'بودجهٔ سرویس DMA در برابر ظرفیت صف نرم\u200cافزاری', 'caption': 'مدل محاسباتی تألیفی برای 115200 و 8N1: هر بایت 86.8056us، نیمهٔ بافر 32 بایتی 2.7778ms و دور کامل 64 بایتی 5.5556ms است. ظرفیت 511 بایتی صف اصلی در شروع خالی حدود 44.3576ms است و مهلت سرویس وقفهٔ DMA را افزایش نمی\u200cدهد؛ هیچ درصد بار CPU اندازه\u200cگیری نشده است.', 'purpose': 'مهلت سرویس نیمهٔ DMA با بودجهٔ انباشت صف نرم\u200cافزار چه تفاوتی دارد؟', 'placement': 'زیربخش: مقایسه مفهومی بار پردازنده و مهلت پاسخ (Latency Budget) در روش\u200cهای Polling، وقفه و DMA', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}]
if __name__=='__main__':run()

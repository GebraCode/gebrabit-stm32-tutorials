"""Optional PC hardware verifier; pyserial is required only for --port. No automatic install."""
import argparse,json,random,time,sys
sys.dont_write_bytecode=True
from protocol_model import frame
def main():
    a=argparse.ArgumentParser();a.add_argument('--port');a.add_argument('--count',type=int,default=100);a.add_argument('--window',type=int,default=1);a.add_argument('--seed',type=int,default=13);a.add_argument('--timeout',type=float,default=3);a.add_argument('--report',default='serial-report.json');a.add_argument('--self-test',action='store_true');args=a.parse_args()
    if args.self_test:
        assert frame(1,b'AB').startswith(b'S,1,4142,');print('Host frame self-test passed; no serial port opened.');return
    if not args.port:a.error('--port is required for a real hardware run')
    if args.count<1 or args.window<1:a.error('count/window must be positive')
    try:import serial
    except ImportError:raise SystemExit('Install pyserial in your chosen environment before hardware use; it was not installed or used by this package build.')
    rng=random.Random(args.seed);received=[];bad=[];missing=[];duplicates=[]
    with serial.Serial(args.port,115200,timeout=0.1,write_timeout=2) as port:
        time.sleep(0.2);port.reset_input_buffer()
        for first in range(0,args.count,args.window):
            expected={};packet=bytearray()
            for seq in range(first,min(first+args.window,args.count)):
                payload=bytes(rng.randrange(256) for _ in range(rng.randrange(33)));wire=frame(seq,payload);packet.extend(wire);expected[seq]=int(wire[-3:-1],16)
            if port.write(packet)!=len(packet):raise RuntimeError('Short host write')
            got=set();deadline=time.monotonic()+args.timeout
            while len(got)<len(expected) and time.monotonic()<deadline:
                line=port.readline().strip()
                if not line:continue
                try:
                    marker,seq,check=line.decode('ascii').split(',');seq=int(seq);check=int(check,16)
                    if marker!='A' or seq not in expected or check!=expected[seq]:bad.append(line.hex());continue
                    if seq in got:duplicates.append(seq)
                    got.add(seq);received.append(seq)
                except (ValueError,UnicodeError):bad.append(line.hex())
            missing.extend(sorted(set(expected)-got))
    result={'scope':'Actual PC serial run requested by operator','port':args.port,'count':args.count,'window':args.window,'seed':args.seed,'received_acknowledgements':received,'missing_sequences':missing,'duplicate_sequences':duplicates,'invalid_responses_hex':bad,'passed':not(missing or duplicates or bad)}
    with open(args.report,'w',encoding='utf8') as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='received_acknowledgements'},indent=2))
if __name__=='__main__':main()

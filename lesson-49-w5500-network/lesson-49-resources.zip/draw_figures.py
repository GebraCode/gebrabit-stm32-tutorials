"""Original educational diagrams; not screenshots, captured signals or measurements.
Rebuild with Python+Pillow on Windows (Segoe UI), or set GEBRA_FONT_DIR to a folder
containing segoeui.ttf/segoeuib.ttf. No font files are redistributed.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import os,json,math,sys
P=Path(__file__).resolve().parent
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';MUTED='#526d7e';LINE='#ccdbe3';ORANGE='#a95a1d'
def font(n,bold=False):return ImageFont.truetype(str(Path(os.environ.get('GEBRA_FONT_DIR','C:/Windows/Fonts'))/('segoeuib.ttf' if bold else 'segoeui.ttf')),n)
def text(d,x,y,s,width=1040,n=42,color=INK,bold=False):
 lines=[];line=''
 for word in s.split():
  new=(line+' '+word).strip()
  if line and d.textlength(new,font=font(n,bold))>width:lines.append(line);line=word
  else:line=new
 if line:lines.append(line)
 for line in lines:
  box=d.textbbox((x,y),line,font=font(n,bold));assert box[2]<W-22 and box[3]<H-22,(line,box)
  d.text((x,y),line,font=font(n,bold),fill=color);y+=n+14
 return y
def card(d,y,title,body,h=245,color=TEAL):
 d.rounded_rectangle((65,y,1135,y+h),18,fill='white',outline=color,width=4)
 yy=text(d,90,y+18,title,1020,46,color,True)
 for sentence in body:yy=text(d,90,yy+8,sentence,1020,42)
 assert yy<y+h-3,(title,yy,y+h)
def arrow(d,x,y,x2,y2):
 d.line((x,y,x2,y2),fill=TEAL,width=7);a=math.atan2(y2-y,x2-x)
 d.polygon([(x2,y2),(x2-24*math.cos(a-.5),y2-24*math.sin(a-.5)),(x2-24*math.cos(a+.5),y2-24*math.sin(a+.5))],fill=TEAL)
FAT='https://elm-chan.org/fsw/ff/doc/appnote.html'
SD='https://elm-chan.org/docs/mmc/mmc_e.html'
WIZ='https://docs.wiznet.io/img/products/w5500/W5500_ds_v110e.pdf'
IO='https://github.com/Wiznet/ioLibrary_Driver/tree/069a81350e8ea0da2d210ab01db97895bba20399'
SPECS={47:[
 {'title':'SD card through SPI1','subtitle':'Actual project pins. STM32F303CB has no SDIO peripheral.','kind':'wires','signals':[('PA5 / SCK','CLK',1),('PA7 / MOSI','DI / CMD',1),('PA6 / MISO','DO / DAT0',-1),('PA4 / CS','CS / DAT3',1)],'note':['Use a 3.3 V-compatible socket or module.','Common GND; stable supply and local decoupling.','CS pull-up; check unused DAT1 / DAT2 pull-ups.'],'source':SD,'caption':'نمودار سیم‌بندی تألیفی مطابق پروژه: کارت با SPI1 روی PA5، PA6 و PA7 و انتخاب تراشهٔ PA4 متصل می‌شود. F303 رابط SDIO ندارد؛ تغذیه و سطح منطقی کارت باید مطابق ماژول و در محدودهٔ مجاز باشد.'},
 {'title':'Start slowly, then change clock','subtitle':'These are command steps in the supplied driver, not a logic-analyzer trace.','cards':[['281.25 kHz: power and idle','CS high, MOSI high, at least 74 clocks.','CMD0 enters idle; CMD8 checks the SD v2 response.'],['CMD55 + ACMD41','Repeat until ready, with a bounded timeout.','Set HCS for SD v2; retain legacy SDSC handling.'],['CMD58: read OCR / CCS','CCS chooses block or byte addressing.','SDSC additionally uses CMD16 for 512-byte blocks.'],['Then use 4.5 MHz SPI','Only after successful initialization.','72 MHz / 16; this is not measured file throughput.']],'source':SD,'caption':'فلوچارت تألیفی راه‌اندازی: کلاک اولیه 281.25 کیلوهرتز است. پس از CMD0، CMD8 و حلقهٔ CMD55/ACMD41، پاسخ CMD58 نوع نشانی‌دهی را مشخص می‌کند؛ تنها پس از آماده‌شدن، کلاک به 4.5 مگاهرتز می‌رسد.'},
 {'title':'The same sector, different argument','subtitle':'The disk interface counts 512-byte sectors; the SD command argument depends on CCS.','cards':[['Example: sector index N = 2','Payload length: 512 bytes.','This is an address calculation, not recorded card data.'],['SDSC: byte address','Command argument = N x 512 = 1024.','Set block length 512 with CMD16.'],['SDHC: block address','Command argument = N = 2.','Do not multiply this sector number by 512.'],['Check format separately','The example accepts an already formatted FAT32 volume.','Capacity class and filesystem format are different.']],'source':SD,'caption':'نمودار تألیفی نشانی‌دهی: برای سکتور 2، آرگومان فرمان در SDSC برابر 1024 و در حالت بلوکی SDHC برابر 2 است. نوع کارت و قالب فایل‌سیستم دو موضوع جدا هستند.'},
 {'title':'From a CSV line to a sector','subtitle':'FatFs R0.16 is manually integrated; this is not a CubeMX GUI screenshot.','cards':[['Application','f_mount / f_open / f_write / f_sync / f_close.','Check FRESULT and the number of bytes written.'],['FatFs: files, directories and FAT','Official R0.16 core; 8.3 names, no exFAT here.','No firmware formatting function is enabled.'],['User disk I/O layer','disk_initialize / read / write / ioctl.','CTRL_SYNC waits for the card to leave busy state.'],['HAL SPI1 and SD card','Mode 0, 8 bits, software chip select.','Read CMD17 / write CMD24, one sector at a time.']],'source':FAT,'caption':'بلوک‌دیاگرام تألیفی لایه‌ها: برنامه از API فایل استفاده می‌کند؛ FatFs به diskio و درایور کاربر به HAL SPI متصل است. این پروژه ادغام دستی R0.16 است و قالب‌بندی کارت در آن فعال نیست.'},
 {'title':'Sync reduces risk, not all risk','subtitle':'A power-loss explanation, not a destructive card experiment.','cards':[['Before sync','Some data and metadata may still be dirty in RAM.','A successful f_write alone is not a power-loss guarantee.'],['f_sync + CTRL_SYNC','Flush the FatFs file cache and wait for card ready.','Check the returned status; do not ignore errors.'],['Inside the card','Its controller and Flash translation remain involved.','Power loss can still damage data or metadata.'],['Finish the logging session','Check f_sync and f_close, then remove safely.','Never claim that a file update is power-fail atomic.']],'source':'https://elm-chan.org/fsw/ff/doc/sync.html','caption':'نمودار تألیفی محدودیت f_sync: همگام‌سازی پنجرهٔ داده‌های نانوشته را کوچک می‌کند، اما نوشتن اتمی در برابر قطع برق یا سلامت قطعی کنترلر داخلی کارت را تضمین نمی‌کند.'},
 {'title':'The supplied CSV logger','subtitle':'No recording has been performed on a physical card during preparation.','cards':[['User starts logging','Set g_start_request = 1, then resume execution.','Mount FAT32; create an unused ADC000..999.CSV.'],['Sample about once per second','PA1 ADC: raw code and estimated mV.','Timestamp is uptime_ms; VDDA is assumed 3300 mV.'],['Write and check','Check FRESULT AND written byte count.','Sync the header and after every 10 valid rows.'],['Stop and close','100 valid rows, or g_stop_request = 1.','Check both sync and close; copy the actual CSV to a PC.']],'source':FAT,'caption':'فلوچارت تألیفی کد همراه: ثبت فقط با فرمان کاربر آغاز می‌شود؛ فایل تازه بدون بازنویسی فایل قبلی ساخته می‌شود. نمونه‌برداری تقریباً هر 1 ثانیه، همگام‌سازی هر 10 ردیف و پایان پس از 100 ردیف معتبر است؛ CSV واقعی هنوز ثبت نشده است.'}
],49:[
 {'title':'W5500 module through SPI1','subtitle':'Actual project pins; polling is used, so INTn is not connected by this example.','kind':'wires','signals':[('PA5 / SCK','SCLK',1),('PA7 / MOSI','MOSI',1),('PA6 / MISO','MISO',-1),('PA4 / CS','SCSn',1),('PB0','RSTn',1)],'note':['Use a documented module with RJ45 magnetics.','Common GND and adequate 3.3 V supply.','Reset: low 2 ms, then wait 100 ms.'],'source':WIZ,'caption':'نمودار سیم‌بندی تألیفی مطابق کد: W5500 از SPI1 و CS روی PA4 استفاده می‌کند و ریست آن به PB0 وصل است. INTn در این مثال استفاده نمی‌شود؛ قطعهٔ خارجی باید تغذیه، کلاک و رابط شبکهٔ مناسب داشته باشد.'},
 {'title':'Where the network work happens','subtitle':'STM32F303CB has no integrated Ethernet MAC. An external controller supplies this path.','cards':[['STM32 application','ADC sample, application buffers and socket state.','MCU RAM is still required; protocol offload is not zero RAM.'],['SPI1 transfer','Commands and payload cross the SPI bus.','This project uses 4.5 MHz, not 80 MHz.'],['W5500 hardware','IPv4 / TCP / UDP plus Ethernet MAC and PHY.','8 sockets; internal TX 16 KiB and RX 16 KiB.'],['External module and LAN','RJ45 / magnetics and module clock are required.','No LwIP stack is integrated in this example.']],'source':WIZ,'caption':'بلوک‌دیاگرام تألیفی تقسیم کار: W5500 پشتهٔ سخت‌افزاری TCP/IP، MAC و PHY دارد. میکروکنترلر همچنان برای برنامه و بافرها RAM مصرف می‌کند؛ آف‌لود شبکه به معنی مصرف صفر حافظهٔ MCU نیست.'},
 {'title':'Choose the actual bus clock','subtitle':'A chip headline rate is not the rate of the complete board or application.','cards':[['SPI1 source clock: 72 MHz','APB2 clock in this project.','Configured prescaler: 16.'],['Actual configured SCK: 4.5 MHz','72 MHz / 16 = 4.5 MHz.','Mode 0; 8-bit transfers; software CS.'],['W5500 interface constraints','Datasheet headline: 80 MHz theoretical SPI.','Guaranteed timing, host limits and wiring still matter.'],['Ethernet link is not payload rate','10 / 100 Mbit/s describes the Ethernet PHY link.','SPI, framing and firmware affect useful throughput.']],'source':WIZ,'caption':'نمودار تألیفی کلاک: کد همراه از SPI1 با 72/16 یعنی 4.5 مگاهرتز استفاده می‌کند. عدد تبلیغی 80 مگاهرتز تراشه یا لینک 100 مگابیتی Ethernet، سرعت واقعی انتقال برنامه را تعیین نمی‌کند.'},
 {'title':'Bind the driver to the hardware','subtitle':'Pinned ioLibrary v3.1.3, with documented local patches and retained license notices.','cards':[['Application socket calls','socket / listen / recv / send.','One main-context owner; no network calls from ISR.'],['ioLibrary + W5500 driver','Register CS and byte-SPI callbacks.','Use _WIZCHIP_ = 5500 explicitly.'],['HAL callbacks','CS low / high through GPIO PA4.','HAL_SPI_TransmitReceive on SPI1.'],['Check and stop on faults','VERSIONR must be 0x04; SPI failure is recorded.','A bounded guard needs a live HAL tick.']],'source':IO,'caption':'بلوک‌دیاگرام تألیفی اتصال ioLibrary به HAL: توابع بازخوانی انتخاب تراشه و تبادل بایت ثبت می‌شوند. همهٔ عملیات شبکه در حلقهٔ اصلی یک مالک دارند؛ وقفه فقط شمارندهٔ زمان DHCP را پیش می‌برد.'},
 {'title':'A small TCP server loop','subtitle':'Socket 0 echoes on port 5000; socket 1 serves the ADC page on port 8080.','cards':[['CLOSED -> INIT -> LISTEN','socket(..., SF_IO_NONBLOCK), then listen().','Wait for an incoming connection.'],['ESTABLISHED: receive and buffer','TCP is a stream; request fragments may arrive separately.','Keep pending bytes in a persistent buffer.'],['Send and track progress','Positive result advances the offset; 0 means busy.','Retry later; handle errors and wait for SENDOK.'],['Close and reopen','HTTP closes after response acknowledgement.','Idle / close-state timeout prevents an endless session.']],'source':IO,'caption':'نمودار تألیفی ماشین حالت برنامهٔ سرور: اتصال TCP به صورت جریان بایت پردازش می‌شود. ارسال ناقص، وضعیت Busy، طول عمر بافر و بستن اتصال پس از پاسخ در کد بررسی می‌شوند؛ این نمودار ردگیری شبکهٔ واقعی نیست.'},
 {'title':'Static IP or a DHCP lease','subtitle':'These are two separate compiled presets; no DHCP lease has been observed on a board.','cards':[['Debug: example static settings','Adapt IP, subnet and a unique locally administered MAC.','Do not copy the example onto an unrelated LAN.'],['DHCP preset: socket 7','DHCP_init(), then keep calling DHCP_run().','Assignment / update callbacks apply the lease.'],['A real 1-second time source','SysTick user code calls App_Tick1ms().','Every 1000 ticks: DHCP_time_handler(), no SPI in ISR.'],['Failure and renewal','Keep running DHCP while the lease is valid.','Initial timeout or failure stops service; no silent fallback.']],'source':IO,'caption':'فلوچارت تألیفی تنظیم شبکه: نسخهٔ IP ثابت و DHCP جدا کامپایل می‌شوند. شمارندهٔ 1 ثانیه‌ای DHCP از SysTick تغذیه می‌شود و در وقفه هیچ فرمان SPI اجرا نمی‌شود. شکست دریافت آدرس به تغییر پنهان به IP ثابت منجر نمی‌شود.'}
]}
def draw(n,outdir):
 outdir.mkdir(parents=True,exist_ok=True);qa=outdir.parent/'visual-qa';qa.mkdir(exist_ok=True);meta=[]
 for idx,s in enumerate(SPECS[n],1):
  im=Image.new('RGB',(W,H),'#f5f8fa');d=ImageDraw.Draw(im)
  y=text(d,65,32,s['title'],1070,56,INK,True);text(d,65,y+10,s['subtitle'],1070,40,MUTED)
  d.line((65,250,1135,250),fill=LINE,width=3)
  if s.get('kind')=='wires':
   text(d,80,300,'STM32F303CB',500,48,TEAL,True);text(d,760,300,'SD card' if n==47 else 'W5500',360,48,TEAL,True)
   for j,(left,right,direction) in enumerate(s['signals']):
    y=430+j*145;text(d,80,y,left,470,43,INK,True);text(d,770,y,right,350,43,INK,True)
    if direction>0:arrow(d,555,y+35,735,y+35)
    else:arrow(d,735,y+35,555,y+35)
   card(d,1250,'Power and wiring checks',s['note'],330,ORANGE)
  else:
   for j,row in enumerate(s['cards']):
    y=300+j*315;card(d,y,row[0],row[1:],270)
    if idx in ([2,4,6] if n==47 else [2,4,5,6]) and j<3:arrow(d,600,y+278,600,y+305)
  d.line((65,1640,1135,1640),fill=LINE,width=3);text(d,65,1660,'Original diagram; not a board measurement or captured trace.',1070,37,MUTED)
  filename=f'lesson{n}-figure{idx}.png';im.save(outdir/filename,optimize=True)
  for size in [390,600]:im.resize((size,H*size//W),Image.Resampling.LANCZOS).save(qa/f'fig{idx}-{size}.png')
  meta.append({'id':f'fig{idx:02d}','filename':filename,'width':W,'height':H,'caption':s['caption'],'alt':s['caption'],'source':s['source'],'license':'Original GEBRA ENG diagram and drawing code CC BY 4.0; sources cited, no copied figure.','kind':'original conceptual or wiring diagram','pixels_reviewed':False})
 (outdir/'image-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
 sheet=Image.new('RGB',(1170,1170),'white')
 for i in range(1,7):sheet.paste(Image.open(qa/f'fig{i}-390.png'),(((i-1)%3)*390,((i-1)//3)*585))
 sheet.save(qa/'contact-sheet.png');print(n,'6images drawn')
if __name__=='__main__':
 if (P/'config.json').exists():
  config=json.loads((P/'config.json').read_text())
  for c in config:
   if c['n'] in SPECS:draw(c['n'],P.parent/c['local']/'public')
 else:
  # Portable copy inside a public download: python draw_figures.py 47 (or49).
  for n in map(int,sys.argv[1:] or ['47','49']):draw(n,P/f'redrawn-{n}')

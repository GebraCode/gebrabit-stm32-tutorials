"""User-run LAN test client. No network requests until explicit --host is supplied.
Tests the educational firmware endpoints, not Internet security or throughput.
"""
import argparse,socket,http.client,json
p=argparse.ArgumentParser();p.add_argument('--host',required=True,help='IP read from your board g_network.ip; do not use an unrelated host');p.add_argument('--timeout',type=float,default=5.0);a=p.parse_args()
payload=b'GebraBit echo\x00\x01\xff\r\n'
results={}
with socket.create_connection((a.host,5000),a.timeout) as s:
 s.settimeout(a.timeout);s.sendall(payload);received=b''
 while len(received)<len(payload):
  chunk=s.recv(len(payload)-len(received))
  if not chunk:break
  received+=chunk
 results['tcp_echo_exact']=received==payload
with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
 s.settimeout(a.timeout);s.sendto(payload,(a.host,5001));data,peer=s.recvfrom(1024);results['udp_echo_exact']=data==payload;results['udp_peer']=peer
c=http.client.HTTPConnection(a.host,8080,timeout=a.timeout);c.request('GET','/');r=c.getresponse();body=r.read();results['http_status']=r.status;results['http_contains_adc']=b'raw=' in body and b'valid=' in body;c.close()
print(json.dumps(results,indent=2))

"""Configuration/address arithmetic only; no card or network measurement."""
import json
values={'spi_init_hz':72000000//256,'spi_run_hz':72000000//16,'sector2_SDSC_argument':2*512,'sector2_SDHC_argument':2,'adc0_estimated_mv':0,'adc4095_estimated_mv':(4095*3300+2047)//4095,'classification':'Arithmetic model, not measured hardware data'}
print(json.dumps(values,indent=2))

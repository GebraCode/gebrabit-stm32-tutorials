"""Portable rebuild helper. Requires Arm GNU GCC13.2.1, CMake and Ninja on PATH.
Run from the extracted download root. Does not execute target firmware.
"""
from pathlib import Path
import subprocess,os,json,hashlib,re
base=Path(__file__).resolve().parent
projects=list(base.glob('gebrabit_lesson*'))
if len(projects)!=1:raise SystemExit('Extract project-and-build.zip beside this script first.')
project=projects[0]
presets=['Debug','DHCP'] if '49_' in project.name else ['Debug']
for preset in presets:
    lines=[]
    def run(args):
        done=subprocess.run(args,cwd=project,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        lines.append('$ '+' '.join(args)+'\n'+done.stdout)
        if done.returncode:
            print(done.stdout);raise SystemExit(done.returncode)
        return done.stdout
    version=run(['arm-none-eabi-gcc','--version']).splitlines()[0]
    run(['cmake','--preset',preset]);run(['cmake','--build','--preset',preset,'--clean-first'])
    out=project/'build'/preset;elf=out/(project.name+'.elf')
    for fmt,suffix in [('binary','.bin'),('ihex','.hex')]:
        run(['arm-none-eabi-objcopy','-O',fmt,str(elf),str(elf.with_suffix(suffix))])
    size=run(['arm-none-eabi-size',str(elf)])
    commands=json.loads((out/'compile_commands.json').read_text())
    c=[x for x in commands if x['file'].endswith('.c')]
    if not all(all(flag in x['command'] for flag in ['-O0','-g3','-Wall','-Werror']) for x in c):raise SystemExit('Compiler flags differ from reviewed debug setup.')
    warnings=re.findall(r'^.*warning:.*$','\n'.join(lines),re.M)
    if warnings:raise SystemExit('Warning found: '+str(warnings))
    (base/f'local-{preset}-build.log').write_text('\n'.join(lines),encoding='utf8')
    report={'preset':preset,'compiler':version,'C_compile_commands':len(c),'warnings':warnings,'size':size,'ELF_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'hardware_execution':False}
    (base/f'local-{preset}-build.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report,indent=2))

"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent


LESSON=34
def save(im,n):im.save(OUT/f'lesson34-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Wire the ROM USART1 route','Logical connections only; no assumed header orientation or live programming test')
 tx(d,75,290,'3.3 V USB-UART',46,TEAL,True);tx(d,745,290,'GB100ST V2.0',46,TEAL,True)
 for yy,a,b in [(480,'TX output','PA10 / RX'),(690,'RX input','PA9 / TX'),(900,'GND','GND')]:
  tx(d,75,yy,a,44);tx(d,810,yy,b,44)
  arrow(d,[(400,yy+35),(760,yy+35)]if a=='TX output'else[(760,yy+35),(400,yy+35)],TEAL if a!='GND'else INK)
 panel(d,75,1110,1050,285,'BOOT SEL: normal boot = GND',['3V3 side -> R3=10 kOhm -> BOOT0; select before reset.','ROM pattern: BOOT0=1 AND nBoot1 option=1.'])
 panel(d,75,1420,1050,190,'Separate board supply',['Shared GND; do not join unknown power rails.'])
 foot(d,'PA9 / PA10 are logical pins; package pins are 30 / 31.');save(im,1)
def figure2():
 im,d=begin('Boot mapping selects the reset vectors','Physical addresses stay distinct; the selected memory is aliased at address zero')
 items=[('Main Flash','0x08000000','128 KiB'),('System ROM','0x1FFFD800','8 KiB block'),('Main SRAM','0x20000000','32 KiB')]
 for k,(a,b,c)in enumerate(items):panel(d,65+k*370,300,350,260,a,[b,c])
 for x in [240,610,980]:d.line((x,580,x,680),fill=TEAL,width=6)
 d.line((240,680,980,680),fill=TEAL,width=6);arrow(d,[(610,680),(610,780)])
 panel(d,75,800,1050,200,'Boot selection / address alias',['BOOT0 and nBoot1 determine the boot memory.'])
 arrow(d,[(600,1020),(600,1110)])
 panel(d,75,1130,1050,310,'Alias base: 0x00000000',['Offset +0x00: initial main stack pointer (MSP)','Offset +0x04: reset vector / Thumb entry','ROM boot and user Flash are different programs.'])
 tx(d,75,1530,'VTOR later selects the exception-vector base.',44,ORANGE,True)
 foot(d,'The System ROM base is specific to this target.');save(im,2)
def figure3():
 im,d=begin('Read the USART boot protocol','Synthetic AN3155 byte/frame examples; no serial capture or target ACK was observed')
 tx(d,75,285,'8E1: idle / start / 8 data / even parity / stop',42,TEAL,True)
 bits=[1,0,1,1,1,1,1,1,1,0,1,1]
 pts=[]
 for k,b in enumerate(bits):
  x=75+k*88;y=450 if b else 550
  if pts:pts.append((x,y))
  pts.extend([(x,y),(x+88,y)])
 d.line(pts,fill=TEAL,width=6)
 labels=['idle','start','1','1','1','1','1','1','1','0','P=1','stop']
 for k,a in enumerate(labels):tx(d,75+k*88,590,a,38)
 tx(d,75,685,'0x7F LSB first; 7 ones -> parity bit 1',43,TEAL,True)
 panel(d,75,800,1050,220,'Host sync 0x7F -> target ACK 0x79',['NACK = 0x1F; discover supported commands with Get.'])
 panel(d,75,1090,1050,200,'Command example: Get = 0x00, 0xFF',['Command XOR complement = 0xFF.'])
 panel(d,75,1380,1050,225,'Data blocks: XOR checksum',['Command complement is a different rule.','Application: 8N1; ROM programming: 8E1.'])
 foot(d,'Waveform is a bit model, not a measured voltage or timing trace.');save(im,3)
def figure4():
 im,d=begin('Program, verify, then return to Flash','Procedure diagram only; CubeProgrammer GUI and target programming were not run')
 stages=[('1. Inspect the physical setup','3.3 V UART logic / TX-RX crossing / shared GND'),('2. Select ROM boot and reset','BOOT0 HIGH; read-only check nBoot1 option=1'),('3. Connect using UART / 8E1','Get supported commands; inspect actual responses'),('4. Program the reviewed application','HEX carries addresses; BIN needs base 0x08000000'),('5. Verify, then select normal boot','BOOT0 LOW -> reset -> application terminal 8N1')]
 for k,(a,b)in enumerate(stages):
  yy=285+k*260;panel(d,75,yy,1050,215,a,[b])
  if k<4:arrow(d,[(600,yy+220),(600,yy+250)])
 foot(d,'A relocated image requires its matching address and vector setup.');save(im,4)
def figure5():
 im,d=begin('Relocating vectors is only one step','Conceptual handoff checklist; this course project does not implement a bootloader')
 panel(d,75,285,1050,240,'Validate image and vectors',['MSP: valid RAM, top allowed, 8-byte aligned.','Thumb reset entry must be inside allowed Flash.'])
 arrow(d,[(600,545),(600,610)])
 panel(d,75,630,1050,215,'Quiesce interrupt and DMA sources',['SysTick / peripheral IRQs / DMA / NVIC state.'])
 arrow(d,[(600,865),(600,930)])
 panel(d,75,950,1050,240,'VTOR selects the exception table',['Match linker, alignment and SystemInit behavior.','VTOR does not set MSP / PC or initialize C.'])
 arrow(d,[(600,1210),(600,1290)])
 panel(d,75,1310,1050,295,'Complete the processor handoff',['Assembly transfer after changing MSP.','Do not continue C using the old stack.','No executable jump or universal safe recipe shown.'])
 foot(d,'Example main SRAM interval: 0x20000000 .. 0x20008000 top.');save(im,5)
def figure6():
 im,d=begin('Diagnose a missing bootloader response','Read-only inspection first; no automatic protection removal or erase recommendation')
 nodes=[('No ACK to sync 0x7F?','Check BOOT selection and reset; inspect nBoot1.'),('Still silent?','Check 3.3 V logic, GND, TX/RX and UART even parity.'),('Connected, command rejected?','Read Get response; confirm supported command and framing.'),('Erase / write or verify rejected?','Inspect exact status, image address, RDP / WRP read-only.')]
 for k,(a,b)in enumerate(nodes):
  yy=290+k*300;panel(d,75,yy,1050,240,a,[b])
  if k<3:arrow(d,[(600,yy+250),(600,yy+290)])
 panel(d,75,1510,1050,105,'Do not infer a wiring fault from every NACK.',())
 foot(d,'No destructive unprotect / mass-erase step is part of this flow.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson34-refresh-figure1.png', 'alt': 'اتصال منطقی USART1 و انتخاب Boot', 'caption': 'نمودار تألیفی اتصال TX مبدل به PA10 و RX به PA9 با منطق 3.3 V و زمین مشترک؛ شماره\u200cهای 30 و 31 فقط شمارهٔ پین فیزیکی MCU هستند، نه هدر برد. در BOOT SEL، مسیر 3V3 از R3 برابر 10 kOhm می\u200cگذرد و انتخاب معمول GND است؛ مقاومت pull-down اختراع نشده است. ورود ROM در Pattern 2 به BOOT0=1 و nBoot1=1 وابسته است. اتصال یا پروگرام واقعی انجام نشده است.', 'purpose': 'اتصال منطقی USART1 و انتخاب Boot', 'placement': 'در بخش دوم پس از جدول حالت\u200cهای بوت', 'references': [{'url': 'https://www.st.com/resource/en/application_note/cd00167594-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf', 'version': 'AN2606 Rev70 February2026, section26 / Tables57-58', 'scope': 'Exact F303xB/C ROM address, boot pattern and interfaces; no chip observation'}, {'url': 'https://www.st.com/resource/en/application_note/an3155-how-to-use-usart-protocol-in-bootloader-on-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN3155 Rev22 September2026', 'scope': 'USART8E1 / sync / ACK / command complement / data checksum'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'BOOT SEL R3 pull-up-side / USART logical nets'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'CB memory and pin package resources'}, {'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 core concepts; no revision or full-read claim', 'scope': 'Vector table and core handoff concepts; no implemented bootloader'}], 'type': 'original functional diagram / explicitly synthetic protocol model', 'source': 'Original Codex Pillow geometry based on accepted Antigravity questions and verified source facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 2, 'filename': 'lesson34-refresh-figure2.png', 'alt': 'نگاشت بوت و بردارهای آغاز', 'caption': 'نقشهٔ عملکردی تألیفی: Flash در 0x08000000، بلاک ROM این تراشه از 0x1FFFD800 با اندازهٔ 8 KiB و SRAM اصلی از 0x20000000. حافظهٔ انتخاب\u200cشده در آدرس صفر alias می\u200cشود؛ آدرس\u200cهای فیزیکی جابه\u200cجا نمی\u200cشوند. دو واژهٔ نخست بردار آغاز، MSP و reset vector هستند. آدرس ROM از AN2606 فعلیِ مخصوص F303xB/C گرفته شده است.', 'purpose': 'نگاشت بوت و بردارهای آغاز', 'placement': 'در انتهای بخش دوم کنار توضیح نگاشت آدرس', 'references': [{'url': 'https://www.st.com/resource/en/application_note/cd00167594-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf', 'version': 'AN2606 Rev70 February2026, section26 / Tables57-58', 'scope': 'Exact F303xB/C ROM address, boot pattern and interfaces; no chip observation'}, {'url': 'https://www.st.com/resource/en/application_note/an3155-how-to-use-usart-protocol-in-bootloader-on-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN3155 Rev22 September2026', 'scope': 'USART8E1 / sync / ACK / command complement / data checksum'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'BOOT SEL R3 pull-up-side / USART logical nets'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'CB memory and pin package resources'}, {'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 core concepts; no revision or full-read claim', 'scope': 'Vector table and core handoff concepts; no implemented bootloader'}], 'type': 'original functional diagram / explicitly synthetic protocol model', 'source': 'Original Codex Pillow geometry based on accepted Antigravity questions and verified source facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 3, 'filename': 'lesson34-refresh-figure3.png', 'alt': 'مدل فریم 8E1 و پیام\u200cهای AN3155', 'caption': 'مدل مصنوعی تألیفی بایت sync برابر 0x7F با ترتیب LSB-first، 7 بیت یک و parity زوج برابر 1، ACK برابر 0x79 و NACK برابر 0x1F. برای دستور Get دو بایت 0x00 و 0xFF متمم هم\u200cاند؛ checksum بلوک داده قاعدهٔ جدا دارد. موج یا پاسخ واقعی دستگاه ثبت نشده است. قالب ROM برابر 8E1 و ترمینال برنامه برابر 8N1 است.', 'purpose': 'مدل فریم 8E1 و پیام\u200cهای AN3155', 'placement': 'در بخش سوم پس از معرفی بایت\u200cهای همگام\u200cسازی', 'references': [{'url': 'https://www.st.com/resource/en/application_note/cd00167594-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf', 'version': 'AN2606 Rev70 February2026, section26 / Tables57-58', 'scope': 'Exact F303xB/C ROM address, boot pattern and interfaces; no chip observation'}, {'url': 'https://www.st.com/resource/en/application_note/an3155-how-to-use-usart-protocol-in-bootloader-on-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN3155 Rev22 September2026', 'scope': 'USART8E1 / sync / ACK / command complement / data checksum'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'BOOT SEL R3 pull-up-side / USART logical nets'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'CB memory and pin package resources'}, {'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 core concepts; no revision or full-read claim', 'scope': 'Vector table and core handoff concepts; no implemented bootloader'}], 'type': 'original functional diagram / explicitly synthetic protocol model', 'source': 'Original Codex Pillow geometry based on accepted Antigravity questions and verified source facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 4, 'filename': 'lesson34-refresh-figure4.png', 'alt': 'روند پروگرام و بازگشت به برنامه', 'caption': 'روندنمای آموزشی تألیفی برای تنظیم Boot، اتصال USART، بررسی فرمان\u200cهای پشتیبانی\u200cشده، پروگرام فایل بازبینی\u200cشده، verify و بازگرداندن BOOT0 به Low پیش از reset. HEX آدرس دارد و BIN برنامهٔ عادی به آدرس 0x08000000 نیاز دارد؛ تصویر relocated به آدرس و VTOR متناظر نیاز دارد. این راهنما شاهد اجرای GUI یا پروگرام واقعی نیست.', 'purpose': 'روند پروگرام و بازگشت به برنامه', 'placement': 'در بخش چهارم کنار مراحل اتصال نرم\u200cافزار', 'references': [{'url': 'https://www.st.com/resource/en/application_note/cd00167594-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf', 'version': 'AN2606 Rev70 February2026, section26 / Tables57-58', 'scope': 'Exact F303xB/C ROM address, boot pattern and interfaces; no chip observation'}, {'url': 'https://www.st.com/resource/en/application_note/an3155-how-to-use-usart-protocol-in-bootloader-on-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN3155 Rev22 September2026', 'scope': 'USART8E1 / sync / ACK / command complement / data checksum'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'BOOT SEL R3 pull-up-side / USART logical nets'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'CB memory and pin package resources'}, {'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 core concepts; no revision or full-read claim', 'scope': 'Vector table and core handoff concepts; no implemented bootloader'}], 'type': 'original functional diagram / explicitly synthetic protocol model', 'source': 'Original Codex Pillow geometry based on accepted Antigravity questions and verified source facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 5, 'filename': 'lesson34-refresh-figure5.png', 'alt': 'انتقال مفهومی کنترل و محدودیت VTOR', 'caption': 'نمودار مفهومی تألیفی شرایط انتقال کنترل، نه bootloader پیاده\u200cسازی\u200cشده: اعتبارسنجی آدرس و هم\u200cترازی MSP، reset vector با Thumb bit و بازهٔ Flash، توقف منابع وقفه، تطبیق VTOR با linker و SystemInit و انتقال اسمبلی پس از عوض\u200cکردن MSP. رأس مجاز اولیهٔ SRAM اصلی 0x20008000 است؛ ماسک کلی ناامن برای اعتبارسنجی استفاده نشده است. VTOR به\u200cتنهایی MSP یا PC و محیط C را تنظیم نمی\u200cکند. برنامهٔ ساخته\u200cشده فقط VTOR را به FLASH_BASE تنظیم و بردارها را ثبت می\u200cکند؛ MSP را عوض نمی\u200cکند و ROM jump یا relocation برنامه پیاده نشده است.', 'purpose': 'انتقال مفهومی کنترل و محدودیت VTOR', 'placement': 'در بخش پنجم کنار کد آموزشی پرش', 'references': [{'url': 'https://www.st.com/resource/en/application_note/cd00167594-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf', 'version': 'AN2606 Rev70 February2026, section26 / Tables57-58', 'scope': 'Exact F303xB/C ROM address, boot pattern and interfaces; no chip observation'}, {'url': 'https://www.st.com/resource/en/application_note/an3155-how-to-use-usart-protocol-in-bootloader-on-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN3155 Rev22 September2026', 'scope': 'USART8E1 / sync / ACK / command complement / data checksum'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'BOOT SEL R3 pull-up-side / USART logical nets'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'CB memory and pin package resources'}, {'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 core concepts; no revision or full-read claim', 'scope': 'Vector table and core handoff concepts; no implemented bootloader'}], 'type': 'original functional diagram / explicitly synthetic protocol model', 'source': 'Original Codex Pillow geometry based on accepted Antigravity questions and verified source facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 6, 'filename': 'lesson34-refresh-figure6.png', 'alt': 'روند عیب\u200cیابی بدون تغییر حفاظت', 'caption': 'روندنمای تألیفی عیب\u200cیابی انتخاب Boot، reset، سیم\u200cبندی، منطق و parity، فهرست فرمان\u200cهای واقعی و بررسی فقط\u200cخواندنی RDP یا WRP. پاسخ NACK همیشه خطای سیم\u200cبندی را ثابت نمی\u200cکند؛ هیچ mass erase یا readout unprotect خودکار توصیه نشده است. این شکل به\u200cعنوان لاگ تجربهٔ سخت\u200cافزاری ارائه نشده است.', 'purpose': 'روند عیب\u200cیابی بدون تغییر حفاظت', 'placement': 'در بخش ششم در ابتدای بخش عیب\u200cیابی', 'references': [{'url': 'https://www.st.com/resource/en/application_note/cd00167594-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf', 'version': 'AN2606 Rev70 February2026, section26 / Tables57-58', 'scope': 'Exact F303xB/C ROM address, boot pattern and interfaces; no chip observation'}, {'url': 'https://www.st.com/resource/en/application_note/an3155-how-to-use-usart-protocol-in-bootloader-on-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN3155 Rev22 September2026', 'scope': 'USART8E1 / sync / ACK / command complement / data checksum'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'BOOT SEL R3 pull-up-side / USART logical nets'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'CB memory and pin package resources'}, {'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 core concepts; no revision or full-read claim', 'scope': 'Vector table and core handoff concepts; no implemented bootloader'}], 'type': 'original functional diagram / explicitly synthetic protocol model', 'source': 'Original Codex Pillow geometry based on accepted Antigravity questions and verified source facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}]
if __name__=='__main__':run()

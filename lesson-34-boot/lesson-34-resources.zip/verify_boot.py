"""Offline vector/image and AN3155 framing examples; never opens a serial port."""
from pathlib import Path
import json,zipfile,hashlib
from elf_audit import inspect_elf,inspect_hex
P=Path(__file__).resolve().parent;checks=[]
def check(n,c):
 assert c,n
 checks.append(n)
sync=0x7F;bits=[0]+[(sync>>i)&1 for i in range(8)]+[sync.bit_count()%2]+[1]
check('sync8E1has11bits',len(bits)==11)
check('syncLSBfirst',bits[1:9]==[1,1,1,1,1,1,1,0])
check('evenparitybit1',(sum(bits[1:9])+bits[9])%2==0 and bits[9]==1)
for name,command in [('Get',0),('GetID',2),('ReadMemory',0x11),('WriteMemory',0x31)]:check(name+'commandcomplementXORFF',(command^(command^0xFF))==0xFF)
address=(0x08000000).to_bytes(4,'big');checksum=0
for b in address:checksum^=b
check('addresspacketXOR00',(checksum^address[0]^address[1]^address[2]^address[3])==0)
for kind in ['projects','build-artifacts']:
 z=zipfile.ZipFile(P/f'lesson-34-{kind}.zip');check(kind+'CRC',z.testzip()is None)
 manifest=json.loads((P/(kind+'-manifest.json')).read_text());check(kind+'SHA',all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items()))
 if kind=='projects':
  main=z.read('gebrabit_lesson34_boot_app/Core/Src/main.c').decode()
  check('VTORbeforeHAL_Init',main.index('SCB->VTOR = FLASH_BASE;')<main.index('  HAL_Init();'))
  check('noROMjumporoptionwrites',all(x not in main for x in ['__set_MSP','HAL_FLASH_OB_','0x1FFFD800','JumpTo']))
  check('boundedapplicationUART','HAL_UART_Transmit(&huart1' in main and '(uint16_t)n, 20U)'in main)
 else:
  root='gebrabit_lesson34_boot_app/gebrabit_lesson34_boot_app';e=inspect_elf(z.read(root+'.elf'));binary=z.read(root+'.bin');hexmem=inspect_hex(z.read(root+'.hex').decode())
  check('realBINequalsELFloadimage',binary==e['image'])
  check('realHEXequalsBIN',all(e['image_start']<=a<e['image_end']and binary[a-e['image_start']]==b for a,b in hexmem.items()))
  check('vectorsatnormalFlash',e['sections']['.isr_vector'][3]==0x08000000)
  check('initialMSPinmainSRAMincludingtop',0x20000000<e['initial_msp']<=0x20008000 and e['initial_msp']%8==0)
  check('resetThumbbitandFlashrange',(e['reset_vector']&1)==1 and 0x08000000<=(e['reset_vector']&~1)<0x08020000)
  check('entrymatchesReset_Handler',(e['entry']|1)==(e['reset_vector']|1))
  image={'Flash_start':hex(e['image_start']),'image_end_exclusive':hex(e['image_end']),'bytes':len(binary),'initial_MSP':hex(e['initial_msp']),'reset_vector':hex(e['reset_vector']),'ELF_entry':hex(e['entry']),'BIN_SHA256':hashlib.sha256(binary).hexdigest(),'VTOR_application_assignment':'0x08000000 beforeHAL_Init, no relocation/jump'}
  (P/'application-image-manifest.json').write_text(json.dumps(image,indent=2)+'\n')
r={'scope':'Offlinefile/vector/framing checks only; no adapter/ROMsync/GetID/programming or targetobservations','checks_passed':len(checks),'checks':checks,'sync_7F_8E1_line_bits_start_dataLSBfirst_parity_stop':bits,'frame_bits':11,'nominal_frame_us_at115200':11/115200*1e6,'ACK':'79','NACK':'1F','Get_request':'00 FF','GetID_request':'02 FD','exampleaddresspacket':'08 00 00 00 08','examplepackets_not_transmitted':True,'ROM_GetID_response':'NOT OBSERVED; no fabricated deviceID','image_manifest':image}
(P/'boot-model-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

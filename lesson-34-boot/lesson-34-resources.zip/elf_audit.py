"""Small read-only ELF32 and Intel HEX checks; not a target emulator."""
import struct
def inspect_elf(data):
 h=struct.unpack_from('<16sHHIIIIIHHHHHH',data)
 assert h[0][:6]==b'\x7fELF\x01\x01' and h[2]==40
 sh=[struct.unpack_from('<IIIIIIIIII',data,h[6]+i*h[11])for i in range(h[12])]
 names=data[sh[h[13]][4]:sh[h[13]][4]+sh[h[13]][5]]
 sections={names[x[0]:].split(b'\0')[0].decode():x for x in sh}
 symbols={}
 for x in sh:
  if x[1]!=2:continue
  strings=sh[x[6]];table=data[strings[4]:strings[4]+strings[5]]
  for offset in range(x[4],x[4]+x[5],x[9]):
   symbol=struct.unpack_from('<IIIBBH',data,offset);name=table[symbol[0]:].split(b'\0')[0].decode()
   if name:symbols[name]=symbol[1]
 segments=[struct.unpack_from('<IIIIIIII',data,h[5]+i*h[9])for i in range(h[10])]
 # objcopy serializes allocated sections, not padding bytes inside ELF segments.
 loads=[]
 for section in sh:
  if not(section[2]&2)or section[1]==8 or section[5]==0:continue
  for segment in segments:
   if segment[0]==1 and segment[2]<=section[3] and section[3]+section[5]<=segment[2]+segment[4]:
    lma=segment[3]+section[3]-segment[2]
    if 0x08000000<=lma<0x08020000:loads.append((lma,data[section[4]:section[4]+section[5]]))
    break
 start=min(a for a,b in loads);end=max(a+len(b)for a,b in loads);image=bytearray(b'\xff'*(end-start))
 for address,payload in loads:image[address-start:address-start+len(payload)]=payload
 v=sections['.isr_vector'];vectors=struct.unpack_from('<II',data,v[4])
 return {'entry':h[4],'symbols':symbols,'sections':sections,'image_start':start,'image_end':end,'image':bytes(image),'initial_msp':vectors[0],'reset_vector':vectors[1]}
def inspect_hex(text):
 upper=0;memory={};eof=False
 for line in text.splitlines():
  assert line.startswith(':');b=bytes.fromhex(line[1:]);assert sum(b)%256==0
  n=b[0];addr=int.from_bytes(b[1:3],'big');kind=b[3];payload=b[4:4+n];assert len(b)==n+5
  if kind==0:
   for i,v in enumerate(payload):memory[upper+addr+i]=v
  elif kind==4:upper=int.from_bytes(payload,'big')<<16
  elif kind==2:upper=int.from_bytes(payload,'big')<<4
  elif kind==1:eof=True
  elif kind in [3,5]:pass
  else:raise AssertionError(kind)
 assert eof
 return memory

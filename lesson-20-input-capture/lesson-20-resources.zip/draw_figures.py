"""Six original course teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson{LESSON}-course-figure{n}.png',optimize=True)

LESSON=20

def figure1():
    im,d=begin('Capture time in hardware, notify later','TIM2 free-running 32-bit counter at 1 MHz | PA0 / AF1 / TI1')
    panel(d,70,255,1060,150,'PA0 -> TI1 input path',['ICF =0: no digital glitch filtering.'])
    arrow(d,[(350,425),(350,540)]);arrow(d,[(900,425),(900,540)],ORANGE)
    panel(d,65,560,520,245,'CH1 direct TI1',['Rising edge','ICPSC DIV1'])
    panel(d,615,560,520,245,'CH2 indirect TI1',['Falling edge','USER CODE 2'],ORANGE)
    arrow(d,[(325,825),(325,1000)]);arrow(d,[(875,825),(875,1000)],ORANGE)
    panel(d,65,1020,520,180,'CNT -> CCR1',['Latch on rising edge'])
    panel(d,615,1020,520,180,'CNT -> CCR2',['Latch on falling edge'],ORANGE)
    arrow(d,[(325,1220),(325,1320),(545,1320)],INK);arrow(d,[(875,1220),(875,1320),(655,1320)],INK)
    d.ellipse((545,1275,655,1365),fill=WHITE,outline=INK,width=3);tx(d,565,1290,'IRQ',38,INK,True)
    tx(d,65,1390,'CCxIF -> IRQ -> callback reads saved CCR value',43,b=True)
    para(d,65,1490,'ISR latency is not the timestamp. It still limits whether captures can be serviced before more edges arrive.',1070,43,ORANGE)
    foot(d,'Hardware latches first; software reads later.');save(im,1)

def figure2():
    im,d=begin('One input, two captured edge types','Model: rising CCR1, falling CCR2; period and High width')
    x=lambda t:170+t*.7
    wave(d,[(0,1),(250,0),(1000,1),(1250,0)],x,470,700)
    for t,label,col in [(0,'rise1',TEAL),(250,'fall',ORANGE),(1000,'rise2',TEAL)]:
        dashed(d,x(t),350,x(t),1000,col,4);tx(d,max(65,x(t)-45),280,label,44,col,True)
    for t in [0,250,500,750,1000,1250]:tx(d,x(t)-18,750,str(t),38)
    tx(d,790,840,'Elapsed ticks',40,b=True)
    arrow(d,[(x(0),940),(x(250),940)],ORANGE,5)
    tx(d,65,1010,'High =4250 -4000 =250 ticks',46,ORANGE,True)
    arrow(d,[(x(0),1120),(x(1000),1120)],TEAL,5)
    tx(d,65,1190,'Period =5000 -4000 =1000 ticks',46,TEAL,True)
    tx(d,65,1310,'Raw CCR examples:4000 ->4250 ->5000',43)
    tx(d,65,1420,'f =1 MHz /1000 =1 kHz',47,b=True)
    tx(d,65,1510,'Duty =250 /1000 x100 =25%',47,b=True)
    foot(d,'Free-running capture, not Slave Reset mode.');save(im,2)

def figure3():
    im,d=begin('Unsigned time difference crosses a wrap','One-wrap arithmetic model; not the application timeout range')
    cx,cy,r=600,670,320
    for k in range(24):d.pieslice((cx-r,cy-r,cx+r,cy+r),k*15-90,(k+1)*15-90,fill=TEAL if k in [23,0] else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+95,cy-r+95,cx+r-95,cy+r-95),fill=BG)
    tx(d,420,610,'Modulo2^32',49,TEAL,True)
    arrow(d,[(200,450),(390,360)],ORANGE);tx(d,65,275,'Old:0xFFFFFF80',44,ORANGE,True)
    arrow(d,[(1040,460),(850,370)]);tx(d,650,1100,'New:0x00000050',44,TEAL,True)
    tx(d,65,1240,'(uint32_t)(new - old) =0xD0 =208',45,b=True)
    tx(d,65,1350,'At 1 MHz:208 ticks =208 us',47,TEAL,True)
    para(d,65,1450,'Valid only if elapsed time is less than2^32 ticks. A missed full turn cannot be reconstructed from two samples.',1070,43,ORANGE)
    foot(d,'Wrap math only:4294.967296s per full turn.');save(im,3)

def figure4():
    im,d=begin('Loop back a known PWM on the same board','Logical signal wiring | Package pins are not header positions')
    panel(d,70,255,1060,150,'GB100ST V2.0 | Verified board power',['Nominal 5 V input -> internal 3V3 logic.'])
    panel(d,65,560,520,250,'PWM OUTPUT',['PA6 / physical 16','AF2 / TIM3_CH1'])
    panel(d,615,560,520,250,'CAPTURE INPUT',['PA0 / physical 10','AF1 / TIM2_TI1'],ORANGE)
    arrow(d,[(325,830),(325,1030),(875,1030),(875,830)])
    tx(d,285,1110,'One jumper: PA6 -> PA0',48,TEAL,True)
    d.line((180,1250,1020,1250),fill=INK,width=7)
    tx(d,65,1320,'Same board: GND is already common.',44,b=True)
    para(d,65,1425,'External source: share GND and respect PA0 electrical limits. Do not assume unrestricted 5 V tolerance.',1070,43,ORANGE)
    foot(d,'Shared-clock loopback is not clock calibration.');save(im,4)

def figure5():
    im,d=begin('One tick is a larger fraction of a short period','Illustrative quantization fractions, not accuracy or bandwidth')
    x=lambda f:220+math.log10(f/100)*400
    y=lambda e:950-math.log10(e/.01)*280
    tx(d,65,255,'1 us /period x100 (%)',46,b=True)
    arrow(d,[(220,1000),(220,335)],INK,4);arrow(d,[(220,950),(1120,950)],INK,4)
    for e,label in [(.01,'0.01'),(.1,'0.1'),(1,'1')]:
        yy=y(e);d.line((220,yy,1090,yy),fill=LINE,width=3);tx(d,65,yy-25,label,39)
    for f,e in [(100,.01),(1000,.1),(10000,1)]:
        xx=x(f);yy=y(e);d.ellipse((xx-10,yy-10,xx+10,yy+10),fill=TEAL)
        tx(d,xx-30,1020,str(f),39);tx(d,max(280,xx-120),yy-90,str(e)+'%',44,TEAL,True)
    tx(d,740,1120,'Frequency (Hz)',42,b=True)
    tx(d,65,1240,'Both axes use logarithmic spacing.',43,MUTED)
    para(d,65,1340,'App accepts periods 2..200000 ticks: lower frequency 5 Hz. Period 2 is not a proven 500 kHz input capability.',1070,43,ORANGE)
    tx(d,65,1530,'Maximum sustainable IRQ rate is not measured.',43,RED,True)
    foot(d,'Tick fraction is not total measurement accuracy.');save(im,5)

def figure6():
    im,d=begin('Validity is separate from frequency','Main loop stays responsive when edges disappear')
    panel(d,75,250,1050,185,'WAIT / pair timestamps',['Need a rising-falling-rising sequence.'])
    arrow(d,[(600,455),(600,560)])
    panel(d,75,580,1050,230,'Validate the sample',['Period 2..200000; width strictly between 0 and period.','No overcapture or ambiguous queued edge order.'])
    arrow(d,[(600,830),(600,935)])
    panel(d,75,955,1050,185,'VALID sample',['Publish period, High width and valid flag.'])
    arrow(d,[(105,1160),(105,1265)],ORANGE);tx(d,175,1180,'Timeout or detected capture fault',42,ORANGE,True)
    panel(d,75,1285,1050,220,'INVALID / no signal',['More than 250 ms without callback -> invalidate.','Detected OF / both pending edges -> discard.'],ORANGE)
    tx(d,65,1550,'A zero display means invalid, not a measured 0 Hz.',42,RED,True)
    foot(d,'Loss flags cannot count every lost input edge.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson20-course-figure1.png', 'alt': 'مسیر ثبت سخت\u200cافزاری لبه تا CCR', 'caption': 'نمودار تألیفی مطابق پروژه: PA0/TI1 با AF1 به CH1 مستقیمِ بالارونده و CH2 غیرمستقیمِ پایین\u200cرونده وصل است. کانال2 در USER CODE 2 تنظیم می\u200cشود؛ ICF=0 و ICPSC=DIV1 است. مقدار CNT در لبه ذخیره می\u200cشود و callback بعداً مقدار ذخیره\u200cشده را می\u200cخواند؛ تأخیر IRQ همچنان بر سرویس\u200cدهی مؤثر است.', 'purpose': 'لبهٔ ورودی چگونه پیش از اجرای callback برچسب زمانی می\u200cگیرد؟', 'placement': 'ذیل بخش ساختار کانال\u200cهای ورودی و فیلتر دیجیتال', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry based on exact lesson code and official facts; not a copied layout', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision/page asserted', 'scope': 'TIM2/TIM3/TIM4 input capture, CCR and status flags'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'LQFP48 PA0/PA6 pinout and alternate functions'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'HAL_TIM_IRQHandler and input capture callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board signals and power'}], 'rights': 'Original drawing; no copied official figure or assumed CC license. System font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'PA0 TI1 AF1 -> ICF0/DIV1; CH1 direct rising and CH2 indirect falling share input; CNT32 free-run1MHz latched into CCR1/CCR2; CCxIF notifies software. CH2 configured in USER CODE 2.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 2, 'filename': 'lesson20-course-figure2.png', 'alt': 'استخراج دوره و عرض High با دو نوع لبه', 'caption': 'مدل زمانی تألیفی: ثبت\u200cهای نمونهٔ 4000 و 4250 و 5000 تیک، عرض High برابر 250 و دوره برابر 1000 تیک می\u200cدهند؛ در تیک1 us، فرکانس اسمی1 kHz و Duty برابر25% است. این روش شمارندهٔ آزاد است و با PWM Input همراه Slave Reset یکی نیست.', 'purpose': 'از کدام سه برچسب زمانی دوره و عرض مثبت به دست می\u200cآید؟', 'placement': 'ذیل بخش روش\u200cهای اندازه\u200cگیری پهنای پالس و نسبت دوره کاری', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry based on exact lesson code and official facts; not a copied layout', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision/page asserted', 'scope': 'TIM2/TIM3/TIM4 input capture, CCR and status flags'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'LQFP48 PA0/PA6 pinout and alternate functions'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'HAL_TIM_IRQHandler and input capture callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board signals and power'}], 'rights': 'Original drawing; no copied official figure or assumed CC license. System font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Model risingCCR1old4000, fallingCCR24250, risingCCR1new5000. Period1000ticks, High250ticks,1 MHz=>1kHz25%. No hardware timing trace.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 3, 'filename': 'lesson20-course-figure3.png', 'alt': 'تفریق پیمانه\u200cای یک\u200cبار عبور از شمارندهٔ32بیتی', 'caption': 'مدل ریاضی تألیفی: تفاضل uint32 از 0xFFFFFF80 تا 0x00000050 برابر208 تیک است. شرط صحت، بازهٔ کمتر از یک دور کامل4294.967296s در1 MHz است؛ این فقط حد ریاضی است و دامنهٔ کاربرد واقعی با دوره\u200cهای2..200000 تیک و timeout250ms محدودتر می\u200cشود.', 'purpose': 'تفاضل بدون علامت در عبور از یک wrap چه شرطی دارد؟', 'placement': 'ذیل بخش تفاضل پیمانه\u200cای با متغیر uint32_t', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry based on exact lesson code and official facts; not a copied layout', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision/page asserted', 'scope': 'TIM2/TIM3/TIM4 input capture, CCR and status flags'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'LQFP48 PA0/PA6 pinout and alternate functions'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'HAL_TIM_IRQHandler and input capture callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board signals and power'}], 'rights': 'Original drawing; no copied official figure or assumed CC license. System font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'uint32 modulo2^32 difference0x50-0xFFFFFF80=0xD0=208ticks=208 us. Less than fullwrap4294.967296s; app limits separate, no multiwrap recovery.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 4, 'filename': 'lesson20-course-figure4.png', 'alt': 'سیم\u200cبندی منطقی PA6 به PA0 روی همان برد', 'caption': 'شماتیک تألیفی: PA6/TIM3_CH1/AF2 با پایهٔ فیزیکی16 به PA0/TIM2_TI1/AF1 با پایهٔ فیزیکی10 متصل می\u200cشود. شماره\u200cها مربوط به LQFP48 هستند، نه هدر. زمین روی همان برد مشترک است؛ برای منبع خارجی سطح مجاز ورودی و زمین رعایت شود. حذف خطای کلاک مشترک در نسبت لوپ\u200cبک، کالیبراسیون مستقل نیست.', 'purpose': 'آزمایش لوپ\u200cبک روی همان برد چه اتصالی لازم دارد؟', 'placement': 'ذیل بخش آزمایش عملی حلقه بازخورد', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry based on exact lesson code and official facts; not a copied layout', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision/page asserted', 'scope': 'TIM2/TIM3/TIM4 input capture, CCR and status flags'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'LQFP48 PA0/PA6 pinout and alternate functions'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'HAL_TIM_IRQHandler and input capture callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board signals and power'}], 'rights': 'Original drawing; no copied official figure or assumed CC license. System font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'One jumperPA6physical 16AF2->PA0physical 10AF1; sameboardGNDcommon; nominal5Vboardinput/internal 3V3logic; externalPA0limitsnotunrestricted 5 V. No boardphoto or headerposition claim.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 5, 'filename': 'lesson20-course-figure5.png', 'alt': 'سهم یک تیک از دوره در سه فرکانس نمونه', 'caption': 'نمودار محاسباتی تألیفی برای تیک1 us: سهم یک تیک در دورهٔ100 Hz برابر0.01%، در1 kHz برابر0.1% و در10 kHz برابر1% است. این مقدار دقت کل، کالیبراسیون یا نرخ قابل پشتیبانی IRQ نیست. حد پایین دورهٔ مجاز کاربرد5 Hz است؛ نرخ بالای عملی باید اندازه\u200cگیری شود.', 'purpose': 'چرا یک تیک در دورهٔ کوتاه سهم نسبی بیشتری دارد؟', 'placement': 'ذیل بخش تفکیک زمانی یک تیک و خطای کوانتیزاسیون', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry based on exact lesson code and official facts; not a copied layout', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision/page asserted', 'scope': 'TIM2/TIM3/TIM4 input capture, CCR and status flags'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'LQFP48 PA0/PA6 pinout and alternate functions'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'HAL_TIM_IRQHandler and input capture callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board signals and power'}], 'rights': 'Original drawing; no copied official figure or assumed CC license. System font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Log-spaced illustrative points100Hz0.01%,1kHz0.1%,10kHz1% for1usperiodquantization; no safe range zone, no accuracy label, no500kHzthroughput claim. App2..200000ticks lower5Hz and unknown practicalupperIRQlimit.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 6, 'filename': 'lesson20-course-figure6.png', 'alt': 'اعتبار نمونه و قطع سیگنال با timeout', 'caption': 'مدل وضعیت تألیفی: نمونه فقط با ترتیب لبه و دوره و عرض مجاز معتبر است. بیش از250 ms بدون callback آن را نامعتبر می\u200cکند؛ CCxOF یا هم\u200cزمانی دو پرچم لبه پیش از HAL محافظه\u200cکارانه باعث دورریختن نمونه می\u200cشود. نمایش عدد0 در این وضعیت اندازه\u200cگیری0 Hz نیست و شمارندهٔ خطا همهٔ لبه\u200cهای ازدست\u200cرفته را نمی\u200cشمارد.', 'purpose': 'برنامه چگونه نمونهٔ معتبر را از قطع ورودی و ازدحام Capture جدا می\u200cکند؟', 'placement': 'ذیل بخش مدیریت شرایط غیرعادی و خطاهای سیستماتیک', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry based on exact lesson code and official facts; not a copied layout', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; no unverified revision/page asserted', 'scope': 'TIM2/TIM3/TIM4 input capture, CCR and status flags'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'LQFP48 PA0/PA6 pinout and alternate functions'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'HAL_TIM_IRQHandler and input capture callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board signals and power'}], 'rights': 'Original drawing; no copied official figure or assumed CC license. System font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Maincontinues; signal_present0after>250 ms, displayzerosinvalidnot0Hz, oldrawvaluesstale. PreHALOF/bothCCIFdrop and callbackOFrecheck conservative; cannot detect every lostedge. Period 2..200000,widthstrictly0<width<period.', 'status': 'prepared-for-Codex-final-visual-review'}]
if __name__=='__main__':run()

"""Logical capture and arithmetic tests; no hardware execution."""
import json
checks=0
def check(x):
 global checks
 assert x
 checks+=1
def delta(a,b): return (a-b)&0xffffffff
def sample(rise,fall,next_rise):
 period=delta(next_rise,rise); high=delta(fall,rise)
 return (period,high) if 1<period<=200000 and 0<high<period else None
check(sample(100,350,1100)==(1000,250))
check(sample(0xffffff00,0xfffffffa,0x2e8)==(1000,250))
check(sample(0,0,1000) is None)
check(sample(0,1000,1000) is None)
check(sample(0,100,200001) is None)
check(sample(0,100000,200000)==(200000,100000))
check(delta(10,0xfffffff0)==26)
check(delta(251,0)>250)
check(not(delta(250,0)>250))
check(72000000//(71+1)==1000000)
check(1000000000//1000==1000000)
check(250*1000//1000==250)
check(1000000/200000==5)
# Modulo cannot distinguish no elapsed time from one complete32-bit wrap.
check(delta(0,0)==delta(2**32,0))
# Delayed ISR with both flags is conservatively rejected by the real prehook.
for over,both,reject in [(0,0,False),(1,0,True),(0,1,True),(1,1,True)]:
 check(bool(over or both)==reject)
# Same-clock loopback ratio cancels a common clock-scale error, unlike external input.
for scale in [0.9999,1,1.0001]:
 check(abs((1000000*scale)/(1000*scale)-1000)<1e-9)
print(json.dumps({'checks_passed':checks,'hardware':'NOT TESTED','timer_tick_us':1,
 'hardware_wrap_seconds':2**32/1000000,
 'hardware_strict_lower_frequency_Hz':1000000/2**32,
 'firmware_max_period_ticks':200000,'firmware_lower_frequency_Hz':5,
 'signal_timeout_ms_condition':'>250',
 'period_quantization_relative_one_tick':{'1kHz':1/1000,'10kHz':1/100},
 'ISR_rate_for_1kHz_two_edges':2000,
 'throughput_upper_limit':'Requires measured worst-case ISR latency; not established by build',
 'notes':['Logical endpoint rejection means constantLOW/HIGH cannot be measured as0/100percent duty.',
 'No overflow IRQ is used; intervals must be shorter than one complete32-bit wrap.',
 'Counter resolution is not the physical accuracy of an external signal measurement.']},indent=2))

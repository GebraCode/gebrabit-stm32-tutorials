"""Deterministic arithmetic models, NOT board or oscilloscope measurements."""
from math import ceil, log2, isclose
import json

checks = 0
def check(condition):
    global checks
    assert condition
    checks += 1

def frequency(psc, arr):
    if not (0 <= psc <= 65535 and 0 <= arr <= 65535):
        raise ValueError('TIM3 PSC and ARR must fit16 bits')
    return 72_000_000 / ((psc + 1) * (arr + 1))

def high_ticks(arr, ccr, mode=1, polarity_high=True):
    if not (0 <= arr <= 65535 and 0 <= ccr <= 65535):
        raise ValueError('16-bit register range')
    active = sum(cnt < ccr for cnt in range(arr + 1))
    if mode == 2:
        active = arr + 1 - active
    elif mode != 1:
        raise ValueError('Only PWM1/2 modeled')
    return active if polarity_high else arr + 1 - active

check(36_000_000 * 2 == 72_000_000)
check(frequency(71, 999) == 1000)
rows = []
for ccr in [0, 250, 500, 750, 1000]:
    high = high_ticks(999, ccr)
    check(high == ccr)
    for mode in [1, 2]:
        check(high_ticks(999, ccr, mode, True) + high_ticks(999, ccr, mode, False) == 1000)
    check(high_ticks(999, ccr, 1) + high_ticks(999, ccr, 2) == 1000)
    rows.append({'CCR': ccr, 'duty_percent': high / 10,
                 'TON_ms_nominal': high / 1000,
                 'mean_V_ideal_3V3': 3.3 * high / 1000})
check(high_ticks(65535, 65535) == 65535)
try:
    high_ticks(65535, 65536)
except ValueError:
    checks += 1
else:
    raise AssertionError('CCR65536 must be rejected')
try:
    frequency(0, 71999)
except ValueError:
    checks += 1
else:
    raise AssertionError('ARR71999 must be rejected')

solutions = []
for target in [1000, 20000]:
    clocks = 72_000_000 // target
    divider = ceil(clocks / 65536)
    while clocks % divider:
        divider += 1
    arr = clocks // divider - 1
    check(frequency(divider - 1, arr) == target)
    check(arr <= 65535)
    solutions.append({'frequency_Hz': target, 'PSC': divider - 1,
                      'ARR': arr, 'time_quanta': arr + 1,
                      'effective_resolution_bits': log2(arr + 1)})
check(solutions[0]['PSC'] == 1 and solutions[0]['ARR'] == 35999)
check(solutions[1]['PSC'] == 0 and solutions[1]['ARR'] == 3599)

# Illustrative comparator-only model, not a validated hardware state machine.
# Ideal exact write at CNT500; real firmware polls >=500 and has instruction latency.
# Continuous PWM without OC1PE is deliberately outside the recommended configuration;
# this computed500-tick illustration is NOT a guaranteed hardware pulse width.
old_ccr, new_ccr, write_at = 750, 250, 500
preload_on = [int(c < old_ccr) for c in range(1000)]
preload_off = [int(c < (old_ccr if c < write_at else new_ccr)) for c in range(1000)]
check(sum(preload_on) == 750)
check(sum(preload_off) == 500)
check(high_ticks(999, new_ccr) == 250)
# Concept-only UG resets the current count, shortening the preceding interval.
check(write_at / 1_000_000 == 0.0005)
# Unsigned tick subtraction survives wrap for bounded intervals.
check(((10 - 0xfffffff0) & 0xffffffff) == 26)
print(json.dumps({'checks_passed': checks, 'measurements': 'NOT PERFORMED',
 'baseline_time_quanta': 1000, 'baseline_resolution_bits': log2(1000),
 'PWM1_high_rows': rows, 'optimal_exact_frequency_solutions': solutions,
 'ideal_preload_write_CNT': write_at,
 'illustrative_comparator_only_high_ticks_OCPE_on_off': [sum(preload_on), sum(preload_off)],
 'next_period_high_ticks': 250,
 'notes': ['Mean voltage assumes ideal0V/3.3V levels and suitable averaging; not a motor drive voltage guarantee.',
 'Center-aligned up/down counter has a different period; this model uses edge-aligned upcount only.',
 'Default firmware changes duty in steps, not a brightness fade.',
 'OCPE-off500-tick model output is only illustrative; continuous PWM without preload is not a guaranteed hardware operating configuration.',
 'Endpoint CCR1000 mapping applies only to fixedARR999.']}, indent=2))

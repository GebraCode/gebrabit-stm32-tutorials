"""Seven original PWM teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson19-refresh-figure{n}.png',optimize=True)

def figure1():
    im,d=begin('Same voltage levels, different ON times','Ideal 1kHz PWM | T =1000us | High3.3V, Low0V')
    x=lambda us:165+us*.9
    for k,(duty,ton,avg) in enumerate([(25,250,'0.825'),(50,500,'1.65'),(75,750,'2.475')]):
        top=260+k*420;hi=top+100;lo=top+260
        tx(d,65,top,f'{duty}% | T_ON {ton}us | T_OFF {1000-ton}us',44,TEAL,True)
        tx(d,65,hi-25,'3.3V',38);tx(d,90,lo-25,'0V',38)
        d.line((x(0),hi-10,x(0),lo+35),fill=INK,width=3)
        d.line((x(0),lo+35,x(1000)+25,lo+35),fill=INK,width=3)
        avg_y=lo-(lo-hi)*duty/100
        dashed(d,x(0),avg_y,x(1000),avg_y,ORANGE)
        wave(d,[(0,1),(ton,0),(1000,1)],x,hi,lo)
        for us in [0,500,1000]:tx(d,x(us)-15,lo+45,str(us),38)
        tx(d,65,top+340,f'Ideal V_avg = {avg}V',43,ORANGE,True)
    tx(d,825,1555,'Time (us)',42,b=True)
    foot(d,'Ideal average is not a regulated DC output.');save(im,1)

def figure2():
    im,d=begin('CNT compared with CCR1 makes PWM','Up-count, PWM Mode 1, active High | N =1000, CCR1 =250')
    x=lambda tick:180+tick*.9;y=lambda cnt:760-cnt*.4
    tx(d,65,255,'CNT value (selected discrete samples)',44,b=True)
    d.line((180,300,180,805,1115,805),fill=INK,width=4)
    for cnt in [0,250,500,999]:
        yy=y(cnt);tx(d,65,yy-25,str(cnt),38);dashed(d,180,yy,1080,yy,LINE,2)
    dashed(d,180,y(250),1080,y(250),ORANGE,5)
    for tick in sorted(set(range(0,1000,32))|{249,250,999}):
        xx=x(tick);yy=y(tick);d.ellipse((xx-6,yy-6,xx+6,yy+6),fill=TEAL if tick<250 else MUTED)
    d.ellipse((x(1000)-7,y(0)-7,x(1000)+7,y(0)+7),fill=RED)
    tx(d,650,570,'CCR1 =250',44,ORANGE,True)
    for tick in [0,250,500,750,1000]:tx(d,x(tick)-22,830,str(tick),38)
    tx(d,65,930,'CNT increments by1; dots do not show every tick.',42)
    tx(d,65,1020,'Output High only for CNT =0..249',47,TEAL,True)
    wave(d,[(0,1),(250,0),(1000,1)],x,1145,1265)
    dashed(d,x(250),1090,x(250),1310,ORANGE,4)
    tx(d,65,1335,'Around the compare boundary:',43,b=True)
    for k,cnt in enumerate([248,249,250,251,252]):
        xx=120+k*195;active=cnt<250
        d.rectangle((xx,1430,xx+180,1515),fill=TEAL if active else '#dce6ed')
        tx(d,xx+34,1448,str(cnt),43,'white' if active else INK,True)
        tx(d,xx+25,1530,'HIGH' if active else 'LOW',38,TEAL if active else MUTED,True)
    foot(d,'ARR 999: update after1000 count ticks.');save(im,2)

def figure3():
    im,d=begin('Frequency alone does not fix resolution','Three discrete choices at a nominal timer clock of72MHz')
    x=lambda f:210+f*42;y=lambda n:850-n*.0125
    tx(d,65,250,'Available count slots N = ARR +1',44,b=True)
    arrow(d,[(210,880),(210,335)],INK,4);arrow(d,[(210,850),(1120,850)],INK,4)
    for n in [0,10000,20000,30000,40000]:
        yy=y(n);d.line((210,yy,1090,yy),fill=LINE,width=2);tx(d,60,yy-24,str(n),38)
    for f in [1,5,10,15,20]:
        xx=x(f);d.line((xx,850,xx,870),fill=INK,width=3);tx(d,xx-12,890,str(f),38)
    for f,n,label,c,dx,dy in [(1,1000,'A',TEAL,25,-80),(1,36000,'B',ORANGE,25,-30),(20,3600,'C',INK,-55,-95)]:
        xx=x(f);yy=y(n);d.ellipse((xx-11,yy-11,xx+11,yy+11),fill=c);tx(d,xx+dx,yy+dy,label,49,c,True)
    tx(d,820,955,'f_PWM (kHz)',41,b=True)
    configs=[('A  1kHz: PSC 71, ARR 999','N 1000 | step 0.1 percentage point'),('B  1kHz: PSC 1, ARR 35999','N 36000 | step 0.00277778 percentage point'),('C  20kHz: PSC 0, ARR 3599','N 3600 | step 0.0277778 percentage point')]
    for k,(a,b) in enumerate(configs):
        yy=1030+k*155;tx(d,65,yy,a,43,TEAL if k==0 else ORANGE if k==1 else INK,True);tx(d,65,yy+65,b,38)
    tx(d,65,1515,'PSC 0 at 1kHz needs ARR 71999: invalid for TIM3.',41,RED,True)
    tx(d,65,1580,'N max 65536; log2(N) is a count measure, not ENOB.',40)
    foot(d,'Computed settings, not measured accuracy.');save(im,3)

def figure4():
    im,d=begin('Preload separates writes from active timing','Buffered values transfer on an allowed update event')
    cols=[(65,'PSC','Always buffered','71'),(445,'ARR','ARPE =1','999'),(825,'CCR1','OC1PE =1','250')]
    tx(d,65,260,'CPU writes the preload value',47,b=True)
    for xx,name,control,value in cols:
        tx(d,xx+20,370,name,48,TEAL,True)
        para(d,xx+10,450,control,320,38,ORANGE,True)
        panel(d,xx,565,310,180,'Preload',[value])
        arrow(d,[(xx+155,770),(xx+155,1000)])
        panel(d,xx,1030,310,205,'Active',[value])
    d.rounded_rectangle((75,835,1125,940),15,fill=TEAL)
    tx(d,200,860,'UEV transfers buffered settings',46,'white',True)
    tx(d,65,1320,'PSC divides; ARR sets period; CCR1 sets compare.',43,b=True)
    para(d,65,1420,'ARPE =0 or OC1PE =0 bypasses that buffer. PSC stays buffered. UG can also change the counter phase.',1070,43,ORANGE)
    foot(d,'Buffering is not a universal no-glitch guarantee.');save(im,4)

def figure5():
    im,d=begin('PWM mode and polarity both matter','Up-count N =1000, CCR1 =250 | Output channel enabled')
    x=lambda t:180+t*.9
    rows=[('Mode 1 | CC1P =0 | High 25%',True),('Mode 1 | CC1P =1 | High 75%',False),('Mode 2 | CC1P =0 | High 75%',False),('Mode 2 | CC1P =1 | High 25%',True)]
    tx(d,145,260,'CNT < CCR',39,TEAL,True);tx(d,620,260,'CNT >= CCR',39,ORANGE,True)
    for k,(title,early) in enumerate(rows):
        top=350+k*290;hi=top+95;lo=top+205
        tx(d,65,top,title,44,b=True)
        tx(d,80,hi-25,'1',38);tx(d,80,lo-25,'0',38)
        d.line((x(0),lo+25,x(1000)+25,lo+25),fill=LINE,width=3)
        wave(d,[(0,int(early)),(250,int(not early)),(1000,int(early))],x,hi,lo,TEAL if early else ORANGE)
        dashed(d,x(250),hi-15,x(250),lo+30,MUTED,3)
    tx(d,65,1555,'CC1P =0: not inverted; CC1P =1: inverted.',42)
    foot(d,'Physical High time differs from active time.');save(im,5)

def figure6():
    im,d=begin('Probe PA6, not the onboard LED','Logical wiring plan | No header-position numbers implied')
    panel(d,70,265,1060,150,'Verified 5V board INPUT -> internal 3V3',())
    arrow(d,[(600,430),(600,495)])
    d.rounded_rectangle((70,515,1130,955),20,fill=WHITE,outline=LINE,width=4)
    tx(d,100,540,'GB100ST V2.0 / STM32F303CBT6',46,TEAL,True)
    tx(d,100,650,'PB6 / physical 42 -> NPN -> USER LED',42,ORANGE,True)
    d.line((100,730,1100,730),fill=LINE,width=3)
    tx(d,100,765,'PA6 / AF2 / TIM3_CH1',42,TEAL,True)
    tx(d,100,835,'LQFP48 physical pin 16',40)
    tx(d,875,790,'GND',44,b=True)
    for xx in [350,940]:d.ellipse((xx-15,940,xx+15,970),fill=TEAL if xx==350 else INK)
    arrow(d,[(350,985),(350,1215)])
    d.line((940,985,940,1215),fill=INK,width=7)
    tx(d,85,1060,'Probe tip',43,TEAL,True);tx(d,745,1110,'Ground clip',42,b=True)
    panel(d,70,1240,1060,240,'Scope CH1: 10x, high-impedance input',['Probe tip to PA6; ground to board GND.','3V3 is internal logic power, not the 5V input.'])
    tx(d,65,1555,'PA6 is a logic output, not a motor power driver.',42,RED,True)
    foot(d,'DS9118 Rev14; board schematic V2.0.');save(im,6)

def figure7():
    im,d=begin('Preload and a mid-period write','Abstract logic model | Time in count ticks | N =1000')
    x=lambda t:165+t*.6
    rows=[(275,'A: OC1PE =0 | CCR 750 ->250 at tick 500',[(0,1),(500,0),(1000,1),(1250,0),(1500,0)],'Model:500-tick High. NOT a hardware prediction.'),
          (700,'B: OC1PE =1 | same write at tick 500',[(0,1),(750,0),(1000,1),(1250,0),(1500,0)],'Old 750-tick pulse ends; next pulse uses 250.'),
          (1125,'C: separate UG case | CCR stays 250',[(0,1),(250,0),(500,1),(750,0),(1500,1)],'UG at 500 resets phase: a new rise arrives early.')]
    for top,title,events,note in rows:
        tx(d,65,top,title,42,TEAL if top!=1125 else ORANGE,True)
        hi=top+115;lo=top+235
        d.line((x(0),lo+25,x(1500)+35,lo+25),fill=LINE,width=3)
        dashed(d,x(500),top+75,x(500),lo+55,ORANGE,4)
        dashed(d,x(1000),top+75,x(1000),lo+55,MUTED,3)
        wave(d,events,x,hi,lo,TEAL if top!=1125 else ORANGE)
        for t in [0,500,1000,1500]:tx(d,x(t)-15,lo+50,str(t),38)
        tx(d,65,top+335,note,40)
    tx(d,65,1570,'OC1PE =0: continuous PWM behavior is NOT guaranteed.',40,RED,True)
    foot(d,'Comparator illustration, not a board prediction.');save(im,7)

def run():
    for n in range(1,8):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')

METADATA=[{'id': 1, 'filename': 'lesson19-refresh-figure1.png', 'alt': 'مقایسهٔ زمان روشن و خاموش PWM با دامنهٔ ثابت', 'caption': 'مدل تألیفی ایدئال PWM با دورهٔ 1000us و سطح\u200cهای 0V و 3.3V؛ زمان\u200cهای روشن و خاموش برای 25% و 50% و 75% و میانگین\u200cهای 0.825V و 1.65V و 2.475V نشان داده شده\u200cاند. خط میانگین به معنی خروجی DC تنظیم\u200cشده یا ولتاژ اندازه\u200cگیری\u200cشدهٔ بار نیست.', 'purpose': 'با ثابت\u200cبودن سطح ولتاژ، تغییر سهم زمان روشن چه اثری بر میانگین ایدئال دارد؟', 'placement': 'بخش مفهوم پایه سیگنال PWM، پس از بند توضیح نسبت وظیفه و ولتاژ میانگین', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'sections': 'TIM2/TIM3/TIM4 PWM mode, polarity, counter and preload; TIMx_CCMR1 OC1PE caveat'}, {'url': 'https://www.st.com/resource/en/application_note/an4776-generalpurpose-timer-cookbook-for-stm32-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4776 Rev5 October2026', 'sections': '1.4.2 preload description; printed pages15 and17 inspected as text, layout not copied'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'voltage_levels_ideal_V': [0, 3.3], 'period_us': 1000, 'duty_percent': [25, 50, 75], 'voltage_average_measured': False}, 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 2, 'filename': 'lesson19-refresh-figure2.png', 'alt': 'نمونه\u200cهای گسستهٔ شمارنده و مقایسه با CCR1 برابر 250', 'caption': 'مدل تألیفی شمارش صعودی، PWM Mode1 و قطبیت High با ARR=999 و CCR1=250؛ خروجی برای CNT از 0 تا 249 در سطح High و از 250 به بعد Low است. نقطه\u200cها فقط نمونه\u200cهای منتخب\u200cاند؛ شمارنده پله\u200cهای تک\u200cتیک دارد و رمپ پیوستهٔ آنالوگ نیست.', 'purpose': 'چگونه 250 تیک High از 1000 تیک یک دوره ساخته می\u200cشود؟', 'placement': 'بخش معماری سخت افزار تایمر، بعد از توضیح شمارنده CNT و رجیستر CCR', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'sections': 'TIM2/TIM3/TIM4 PWM mode, polarity, counter and preload; TIMx_CCMR1 OC1PE caveat'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d', 'sections': 'stm32f3xx_hal_tim.c PWM configuration/start/stop and compare/preload macros'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'counter_direction': 'up', 'PWM_mode': 1, 'CC1P': 0, 'N': 1000, 'ARR': 999, 'CCR1': 250, 'selected_discrete_samples_not_continuous_ramp': True}, 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 3, 'filename': 'lesson19-refresh-figure3.png', 'alt': 'سه انتخاب گسستهٔ PSC و ARR با تفکیک\u200cپذیری متفاوت', 'caption': 'نمودار محاسباتی تألیفی با کلاک اسمی 72MHz؛ دو تنظیم 1kHz با N برابر 1000 و 36000 و یک تنظیم 20kHz با N برابر 3600 مقایسه می\u200cشوند. نقطه\u200cها به هم وصل نشده\u200cاند؛ نمودار مرز پیوسته یا رابطهٔ یکنواخت مستقل از PSC را ادعا نمی\u200cکند. N بیشینه 65536 است و log2(N) معادل شمارشی است، نه ENOB اندازه\u200cگیری\u200cشده.', 'purpose': 'چرا دو تنظیم هم\u200cفرکانس می\u200cتوانند گام\u200cهای Duty متفاوت داشته باشند؟', 'placement': 'بخش روابط ریاضی و تفکیک پذیری، پس از محاسبه فرکانس 1 kHz و محدودیت ARR', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'sections': 'TIM3 width and LQFP48 pinout / alternate functions'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'sections': 'TIM2/TIM3/TIM4 PWM mode, polarity, counter and preload; TIMx_CCMR1 OC1PE caveat'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'timer_clock_assumed_Hz': 72000000, 'counter_bits': 16, 'N_max': 65536, 'settings': [{'PSC': 71, 'ARR': 999, 'frequency_Hz': 1000, 'N': 1000, 'step_percentage_point': 0.1}, {'PSC': 1, 'ARR': 35999, 'frequency_Hz': 1000, 'N': 36000, 'step_percentage_point': 0.002777777777777778}, {'PSC': 0, 'ARR': 3599, 'frequency_Hz': 20000, 'N': 3600, 'step_percentage_point': 0.027777777777777776}], 'invalid_1kHz_PSC0_ARR': 71999, 'not_a_measured_ENOB': True}, 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 4, 'filename': 'lesson19-refresh-figure4.png', 'alt': 'مسیر نوشتن پیش\u200cبارگذاری تا مقدار فعال تایمر', 'caption': 'معماری تألیفی PSC و ARR و CCR1؛ با ARPE=1 و OC1PE=1، نوشتن پردازنده مقدار فعال را همان لحظه عوض نمی\u200cکند و انتقال با Update مجاز انجام می\u200cشود. PSC همواره بافر دارد. این شکل شرط\u200cهای دقیق تایمر را حذف نمی\u200cکند و تضمین عمومی حذف همهٔ ناپایداری\u200cها نیست.', 'purpose': 'پیش\u200cبارگذاری چگونه نوشتن CPU را از مقدار فعال زمان\u200cبندی جدا می\u200cکند؟', 'placement': 'بخش رجیسترهای پیش بارگذاری و رخداد بروزرسانی، پس از توضیح بیتهای ARPE و OC1PE', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'sections': 'TIM2/TIM3/TIM4 PWM mode, polarity, counter and preload; TIMx_CCMR1 OC1PE caveat'}, {'url': 'https://www.st.com/resource/en/application_note/an4776-generalpurpose-timer-cookbook-for-stm32-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4776 Rev5 October2026', 'sections': '1.4.2 preload description; printed pages15 and17 inspected as text, layout not copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d', 'sections': 'stm32f3xx_hal_tim.c PWM configuration/start/stop and compare/preload macros'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'ARPE': 1, 'OC1PE': 1, 'PSC_always_buffered': True, 'transfer_on_allowed_update': True, 'no_universal_jitter_or_glitch_guarantee': True}, 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 5, 'filename': 'lesson19-refresh-figure5.png', 'alt': 'چهار ترکیب PWM Mode و قطبیت CC1P', 'caption': 'جدول شکل\u200cموج تألیفی برای شمارش صعودی، N=1000 و CCR1=250 و کانال فعال؛ سهم سطح فیزیکی High برای Mode1/CC1P0، Mode1/CC1P1، Mode2/CC1P0 و Mode2/CC1P1 به\u200cترتیب 25% و 75% و 75% و 25% است. این مقایسهٔ منطقی ادعای آزمایش چهار پیکربندی روی برد نیست.', 'purpose': 'حالت PWM و معکوس\u200cکردن قطبیت چگونه سهم سطح High را تغییر می\u200cدهند؟', 'placement': 'بخش حالت های کاری و جهت شمارش، پس از بند مقایسه مدها و قطبیت', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'sections': 'TIM2/TIM3/TIM4 PWM mode, polarity, counter and preload; TIMx_CCMR1 OC1PE caveat'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'counter_direction': 'up', 'N': 1000, 'CCR1': 250, 'channel_enabled': True, 'physical_high_percent': [25, 75, 75, 25], 'all_four_modes_hardware_tested': False}, 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 6, 'filename': 'lesson19-refresh-figure6.png', 'alt': 'اتصال منطقی پراب به PA6 و زمین مشترک برد', 'caption': 'شماتیک تألیفی اتصال PA6 با AF2 و TIM3_CH1، پایهٔ فیزیکی 16 در LQFP48، به نوک پراب 10x با ورودی امپدانس\u200cبالا و اتصال گیره به GND برد. PB6 و LED کاربر مسیر جدا دارند. ورودی اسمی برد 5V و منطق داخلی 3V3 است؛ شکل پیشنهاد تغذیهٔ برد از پایهٔ 3V3 یا شماره\u200cگذاری هدرها نیست.', 'purpose': 'برای مشاهدهٔ PWM کدام سیگنال و زمین باید به اسیلوسکوپ متصل شوند؟', 'placement': 'بخش پیکربندی سخت افزار GebraBit و آزمایش عملی', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'sections': 'TIM3 width and LQFP48 pinout / alternate functions'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'sections': '5V input regulator, signal headers, PB6 USER LED'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'board': 'GB100ST V2.0', 'part': 'STM32F303CBT6', 'pin': 'PA6', 'physical_LQFP48_pin': 16, 'AF': 2, 'signal': 'TIM3_CH1', 'onboard_LED_separate_PB6_pin42': True, 'nominal_board_input_V': 5, 'internal_logic_nominal_V': 3.3, 'probe': '10x high impedance', 'header_positions_not_claimed': True}, 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 7, 'filename': 'lesson19-refresh-figure7.png', 'alt': 'مدل انتزاعی تغییر CCR و اثر مستقل UG بر فاز', 'caption': 'مدل مقایسه\u200cگر تألیفی، نه پیش\u200cبینی قطعی برد: برای تصویرسازی، CCR از 750 به 250 در تیک ایدئال 500 تغییر می\u200cکند. شاخهٔ OC1PE=0 فقط مدل منطقی است؛ RM0316 استفاده از PWM بدون پیش\u200cبارگذاری را جز در One-pulse تضمین نمی\u200cکند و رفتار PWM پیوستهٔ آن تضمین\u200cشده نیست. با پیش\u200cبارگذاری، مدل دورهٔ قبلی را کامل می\u200cکند. شاخهٔ مستقل UG با CCR ثابت 250، شروع زودتر چرخه را نمایش می\u200cدهد؛ این شاخه حالت آزمایش کامپایل\u200cشده نیست و کد واقعی نوشتن را پس از CNT>=500 انجام می\u200cدهد.', 'purpose': 'تغییر مقدار فعال، انتقال در Update و UG چه تفاوتی دارند و محدودیت تضمین رفتار کجاست؟', 'placement': 'کنار بخش Preload و UG', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex-authored original Pillow geometry, based on official facts and actual lesson code; no official illustration layout reproduced', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'sections': 'TIM2/TIM3/TIM4 PWM mode, polarity, counter and preload; TIMx_CCMR1 OC1PE caveat'}, {'url': 'https://www.st.com/resource/en/application_note/an4776-generalpurpose-timer-cookbook-for-stm32-microcontrollers-stmicroelectronics.pdf', 'version': 'AN4776 Rev5 October2026', 'sections': '1.4.2 preload description; printed pages15 and17 inspected as text, layout not copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d', 'sections': 'stm32f3xx_hal_tim.c PWM configuration/start/stop and compare/preload macros'}], 'technical_basis': 'DS9118 Rev14; RM0316 F3-specific timer facts; AN4776 Rev5 where relevant; pinned F3 HAL953955a; actual generated TIM3 lesson19 project', 'rights': 'Original drawing. No third-party illustration copied and no assumed CC license assigned. System Segoe UI font is not redistributed.', 'provenance': 'Programmatic original drawing, not image-generation output, GUI screenshot, board photo or measurement.', 'physical_measurement': False, 'AI_generated_image': False, 'model_assumptions': {'abstract_comparator_model_only': True, 'not_board_prediction': True, 'N': 1000, 'CCR_old': 750, 'CCR_new': 250, 'ideal_write_tick': 500, 'actual_software_poll_phase': 'CNT>=500; timing not guaranteed exact500', 'OC1PE0_continuous_PWM_behavior_guaranteed': False, 'RM_caveat': 'PWM without preload requires One-pulse for guaranteed behavior; otherwise behavior not guaranteed', 'separate_UG_case_CCR': 250, 'separate_UG_case_tick': 500, 'midrun_UG_test_mode_delivered': False}, 'status': 'prepared-for-Codex-final-visual-review'}]
if __name__=='__main__':run()

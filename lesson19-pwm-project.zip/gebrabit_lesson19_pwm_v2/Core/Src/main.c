/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint32_t lesson_mode = 0U;
volatile uint32_t lesson_hal_error = 0U;
static uint32_t previous_mode = 0U;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void PWM_StopLow(void);
static void PWM_RestoreOutput(void);
static void PWM_PreloadTrial(uint32_t enabled);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1) != HAL_OK)
  {
    lesson_hal_error = 1U;
    Error_Handler();
  }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    uint32_t mode = lesson_mode;
    if (mode != previous_mode)
    {
      if (previous_mode == 3U)
      {
        PWM_RestoreOutput();
      }
      SET_BIT(TIM3->CCMR1, TIM_CCMR1_OC1PE);
      if (mode == 3U)
      {
        PWM_StopLow();
      }
      previous_mode = mode;
    }

    switch (mode)
    {
      case 0U:
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 250U);
        HAL_Delay(1000U);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 500U);
        HAL_Delay(1000U);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 750U);
        HAL_Delay(1000U);
        break;
      case 1U:
        PWM_PreloadTrial(1U);
        break;
      case 2U:
        PWM_PreloadTrial(0U);
        break;
      case 3U:
        HAL_Delay(10U);
        break;
      default:
        lesson_hal_error = 3U;
        Error_Handler();
        break;
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
static void PWM_StopLow(void)
{
  GPIO_InitTypeDef pin = {0};
  if (HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1) != HAL_OK)
  {
    lesson_hal_error = 2U;
    Error_Handler();
  }
  HAL_GPIO_WritePin(PWM_OUT_GPIO_Port, PWM_OUT_Pin, GPIO_PIN_RESET);
  pin.Pin = PWM_OUT_Pin;
  pin.Mode = GPIO_MODE_OUTPUT_PP;
  pin.Pull = GPIO_NOPULL;
  pin.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(PWM_OUT_GPIO_Port, &pin);
}

static void PWM_RestoreOutput(void)
{
  GPIO_InitTypeDef pin = {0};
  pin.Pin = PWM_OUT_Pin;
  pin.Mode = GPIO_MODE_AF_PP;
  pin.Pull = GPIO_NOPULL;
  pin.Speed = GPIO_SPEED_FREQ_LOW;
  pin.Alternate = GPIO_AF2_TIM3;
  HAL_GPIO_Init(PWM_OUT_GPIO_Port, &pin);
  SET_BIT(TIM3->CCMR1, TIM_CCMR1_OC1PE);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 250U);
  __HAL_TIM_SET_COUNTER(&htim3, 0U);
  /* Timer is stopped here: latch the buffered values before restarting. */
  TIM3->EGR = TIM_EGR_UG;
  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_UPDATE);
  if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1) != HAL_OK)
  {
    lesson_hal_error = 1U;
    Error_Handler();
  }
}

static void PWM_PreloadTrial(uint32_t enabled)
{
  /* Establish the same baseline at a complete period boundary. */
  SET_BIT(TIM3->CCMR1, TIM_CCMR1_OC1PE);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 750U);
  while (__HAL_TIM_GET_COUNTER(&htim3) < 900U) {}
  while (__HAL_TIM_GET_COUNTER(&htim3) > 100U) {}

  if (enabled == 0U)
  {
    CLEAR_BIT(TIM3->CCMR1, TIM_CCMR1_OC1PE);
  }
  while (__HAL_TIM_GET_COUNTER(&htim3) < 500U) {}
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 250U);
  HAL_Delay(10U);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

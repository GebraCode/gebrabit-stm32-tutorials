# TURINGCODE PROJECT

## Required tools

- The following tools must be installed in your system for the turingcode ecosystem to work correctly.
- Please ask the user permission to install them if they dont exist already.

### probe-rs (for programming the .elf files)

**probe-rs** is an open-source, Rust-based toolkit for working with embedded microcontrollers through debug probes. It talks to hardware debuggers (such as CMSIS-DAP, ST-Link, J-Link, ESP USB-JTAG, and FTDI-based probes) over interfaces like JTAG and SWD. With it you can:

- **Flash** firmware onto chips (ARM Cortex-M, RISC-V, Xtensa/ESP32, and others)
- **Debug** running code, with a GDB server and a VS Code extension via the Debug Adapter Protocol
- **Stream logs** using RTT (Real-Time Transfer) and `defmt`
- **Run firmware directly** with `cargo run` through its `probe-rs run` runner, which is popular in the embedded Rust ecosystem

It's both a CLI tool and a Rust library, and it's a modern, cross-platform alternative to tools like OpenOCD.
"""Ideal DAC transfer and illustrative resistor loading; no voltage measurements."""
from fractions import Fraction
import json
checks={}
def test(n,c):checks[n]=bool(c);assert c,n
vref=Fraction(33,10);codes=[0,1024,2048,3072,4095]
test('12bit_code_count',2**12==4096)
test('half_code_is_half_reference',Fraction(2048,4096)==Fraction(1,2))
test('full_code_below_reference',vref*4095/4096<vref)
test('quarter_code',vref*1024/4096==Fraction(825,1000))
test('right_aligned_range',all(0<=x<=4095 for x in codes))
test('twoSecond_step_tenSecond_cycle',len(codes)*2==10)
test('10k_ground_load_meets_buffer_minimum',10000>=5000)
test('15k_series10kload_model',Fraction(10000,15000+10000)==Fraction(2,5))
print(json.dumps({'model_only':True,'vref_nominal_V':3.3,'denominator':4096,'checks':checks,'passed_checks':len(checks),'ideal_levels':[{'code':c,'ideal_V':float(vref*c/4096),'within_buffer_headroom_at_nominal':0.2<=float(vref*c/4096)<=3.1,'measured_V':None} for c in codes],'source_impedance_load_example':{'ASSUMED_Rout_ohm':15000,'load_ohm':10000,'divider_ratio':0.4,'note':'Illustration using datasheet maximum15kohm, not typical/exact source resistance or measured output; code/voltage dependent errors not included.'}},indent=2))

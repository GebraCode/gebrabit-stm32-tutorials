"""Six original course teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson{LESSON}-course-figure{n}.png',optimize=True)

LESSON=24

def figure1():
    im,d=begin('A DAC code sets an ideal voltage target','Selected codes | Vref assumed 3.3 V; actual output not measured')
    x=lambda code:180+code/4096*900;y=lambda v:1080-v/3.3*650
    tx(d,65,270,'Ideal voltage (V)',46,b=True)
    d.line((180,350,180,1130,1120,1130),fill=INK,width=4)
    for v in [0,.825,1.65,2.475,3.3]:
        yy=y(v);d.line((180,yy,1090,yy),fill=LINE,width=2);tx(d,65,yy-24,str(v),38)
    dashed(d,x(0),y(0),x(4095),y(3.3*4095/4096),MUTED,4)
    for code in [0,1024,2048,3072,4095]:
        xx=x(code);yy=y(3.3*code/4096);d.ellipse((xx-10,yy-10,xx+10,yy+10),fill=TEAL);tx(d,xx-22,1170,str(code),38)
    tx(d,900,1260,'Code',42,b=True)
    tx(d,65,1370,'V_ideal = Vref x DOR /4096',47,TEAL,True)
    tx(d,65,1470,'Code4095 gives3.29919 V, not exactly3.3 V.',43)
    tx(d,65,1565,'No real buffer clamp curve is drawn.',43,ORANGE,True)
    foot(d,'Ideal formula is not a guarantee of loaded pin voltage.');save(im,1)

def figure2():
    im,d=begin('Alignment selects where the data bits sit','Lower 16bits shown | Upper 16bits omitted from these diagrams')
    for top,name,lo,hi in [(300,'DHR12R1: right-aligned 12-bit',0,11),(740,'DHR12L1: left-aligned 12-bit',4,15),(1180,'DHR8R1: right-aligned 8-bit',0,7)]:
        tx(d,65,top,name,46,TEAL,True)
        for k in range(16):
            bit=15-k;xx=105+k*63;active=lo<=bit<=hi
            tx(d,xx+8,top+100,str(bit),38)
            d.rectangle((xx,top+180,xx+57,top+280),fill=TEAL if active else '#dce7ee')
        tx(d,65,top+325,f'Highlighted data field: bits {hi}..{lo}',42)
    foot(d,'Field maps, not a captured register window.');save(im,2)

def figure3():
    im,d=begin('DHR and DOR serve different jobs','Trigger control selects when the output code updates')
    stages=[('Software writes DHR','The selected alignment maps the input data.'),('Update / trigger logic','No trigger or selected trigger determines transfer.'),('DOR output register','The conversion block uses this output code.'),('Analog conversion block','Reference voltage defines the ideal scale.'),('Output buffer path','BOFF selection and electrical load matter.'),('PA4 / DAC1_OUT1','LQFP48 physical pin 14; voltage must be measured.')]
    for k,(a,b) in enumerate(stages):
        y=245+k*225;panel(d,75,y,1050,165,a,[b])
        if k<5:arrow(d,[(600,y+180),(600,y+210)])
    foot(d,'Actual project:trigger NONE, set DHR before Start.');save(im,3)

def figure4():
    im,d=begin('Buffer mode changes load behavior','Qualitative equivalent circuits | DS9118 Table 75 conditions')
    tx(d,65,365,'Resistance values are in kOhm.',38,MUTED)
    for cx,title,c in [(325,'BUFFER ON',TEAL),(875,'BUFFER OFF',ORANGE)]:
        tx(d,cx-210,275,title,47,c,True)
        d.ellipse((cx-70,450,cx+70,590),outline=c,width=5);tx(d,cx-30,485,'V',43,c,True)
        d.line((cx,590,cx,665),fill=INK,width=6);d.rectangle((cx-65,665,cx+65,820),outline=INK,width=5)
        tx(d,cx-205,715,'R_out',43,c,True)
        d.line((cx,820,cx,990),fill=INK,width=6);d.rectangle((cx-65,990,cx+65,1130),outline=INK,width=5)
        tx(d,cx-180,1025,'R_L',42,b=True);d.line((cx,1130,cx,1185),fill=INK,width=6)
        for j,w in enumerate([100,70,35]):d.line((cx-w/2,1185+j*20,cx+w/2,1185+j*20),fill=INK,width=5)
    tx(d,65,1300,'ON: R_L >=5k to GND',42,TEAL,True)
    tx(d,65,1370,'R_L >=25k to VDDA',42,TEAL,True)
    tx(d,65,1440,'C_load <=50 pF',42,TEAL,True)
    tx(d,660,1300,'OFF: R_out <=15k MAX',42,ORANGE,True)
    tx(d,660,1370,'Not a fixed 15k value',41,ORANGE)
    tx(d,660,1440,'Full rails not promised',41,ORANGE)
    tx(d,65,1550,'ON range under table conditions:0.2 V..VDDA-0.2 V',41)
    foot(d,'Conditions are not a measured full-range clamp curve.');save(im,4)

def figure5():
    im,d=begin('Measure PA4 with a high-Z voltmeter','Logical wiring plan | Board power is separate from signal leads')
    panel(d,70,260,1060,280,'GB100ST V2.0 / STM32F303CBT6',['PA4 / DAC1_OUT1 / physical pin 14','PA5 / physical pin 15 is the other channel.'])
    tx(d,185,610,'PA4',46,TEAL,True);tx(d,900,610,'GND',46,b=True)
    d.line((300,685,300,1240),fill=RED,width=7);d.line((970,685,970,1240),fill=INK,width=7)
    d.line((300,790,610,790,610,870),fill=ORANGE,width=5)
    d.rectangle((555,870,665,1050),outline=ORANGE,width=5)
    d.line((610,1050,610,1140,970,1140),fill=ORANGE,width=5)
    d.ellipse((288,778,312,802),fill=RED);d.ellipse((958,1128,982,1152),fill=INK)
    tx(d,680,900,'Optional 10k',40,ORANGE,True);tx(d,680,970,'load to GND',40,ORANGE)
    panel(d,70,1260,1060,220,'DMM: DC voltage mode',['RED / V lead -> PA4; BLACK / COM -> GND.','No voltage reading is fabricated in this diagram.'])
    tx(d,65,1550,'Physical pin 14 is not header position 14.',43,b=True)
    foot(d,'Nominal 5 V board input; internal 3V3 is not that input.');save(im,5)

def figure6():
    im,d=begin('Define a band before measuring settling','Normalized step model, not physical F303 timing')
    x=lambda t:190+t*105;y=lambda v:1120-v*600
    tx(d,65,275,'Output fraction of a step',46,b=True)
    d.line((190,350,190,1180,1120,1180),fill=INK,width=4)
    d.rectangle((190,y(1.02),1100,y(.98)),fill='#d9ecee')
    for v in [0,.5,1]:tx(d,65,y(v)-25,str(v),38)
    dashed(d,190,y(1),1100,y(1),MUTED,3)
    d.line([(x(i/100),y(1-math.exp(-i/100))) for i in range(801)],fill=TEAL,width=7)
    t=-math.log(.02);dashed(d,x(t),350,x(t),1210,ORANGE,4)
    tx(d,500,370,'Illustrative 2% error band',43,ORANGE,True)
    for t in [0,2,4,6,8]:tx(d,x(t)-12,1230,str(t),38)
    tx(d,820,1330,'Time / tau',42,b=True)
    para(d,65,1440,'This curve is not a full-rail DAC test. Real settling depends on the defined error band, load and datasheet conditions.',1070,43)
    foot(d,'Normalized example; real timing uses datasheet conditions.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson24-course-figure1.png', 'alt': 'کد DAC و هدف ولتاژ ایدئال', 'caption': 'نمودار محاسباتی تألیفی کدهای منتخب با فرض مرجع 3.3 V و رابطهٔ رسمی Vref×DOR/4096؛ کد4095 حدود3.29919 V ایدئال می\u200cدهد، نه دقیقاً3.3 V. هیچ منحنی واقعی clamp یا نتیجهٔ ولتاژ بار رسم نشده است.', 'purpose': 'کد DAC و هدف ولتاژ ایدئال چگونه تفسیر می\u200cشود؟', 'placement': 'بخش دوم: فرمول محاسبه ولتاژ خروجی و مدل ذهنی تبدیل کُد به ولتاژ', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'DACideal/4096 perRM0316§16.5.3/AN3126Rev6eq1,notWord/4095; selectedidealpoints0,1024,2048,3072,4095,notmeasuredclamporaccuracy.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 2, 'filename': 'lesson24-course-figure2.png', 'alt': 'جایگاه بیت\u200cهای داده در سه چینش DHR', 'caption': 'نمای تألیفی 16 بیت پایین رجیستر: DHR12R1 داده را در11..0، DHR12L1 در15..4 و DHR8R1 در7..0 می\u200cگیرد. رنگِ بدون داده توصیهٔ نوشتن در بیت رزروشده نیست و تصویر پنجرهٔ واقعی رجیستر نیست.', 'purpose': 'جایگاه بیت\u200cهای داده در سه چینش DHR چگونه تفسیر می\u200cشود؟', 'placement': 'بخش سوم: رجیسترهای نگه\u200cدارنده (DHR) و چینش\u200cهای 12 بیتی و 8 بیتی', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualDHR12Rbits0..11,DHR12L4..15,DHR8R0..7;lower16display,upper16omitted;notGUI/notreservedbitwriteadvice.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 3, 'filename': 'lesson24-course-figure3.png', 'alt': 'نقش DHR و تریگر و DOR', 'caption': 'بلوک\u200cدیاگرام تألیفی مسیر داده تا خروجی آنالوگ و بافر؛ هستهٔ تبدیل فقط به\u200cصورت یک بلوک نشان داده شده و معماری فیزیکی R-2R ادعا نمی\u200cشود. پروژهٔ واقعی Trigger=None دارد و پیش از Start مقدار DHR را می\u200cگذارد؛ حالت تریگردار با این مسیر یکی نیست.', 'purpose': 'نقش DHR و تریگر و DOR چگونه تفسیر می\u200cشود؟', 'placement': 'بخش سوم: انتقال داده به رجیستر خروجی (DOR) و مقایسه تریگر نرم\u200cافزاری و سخت\u200cافزاری', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'DHR/update-triggerlogic/DOR/analogconversion/outputbuffer/PA4;noR2Rsiliconclaim;actualtriggerNONE/setDHRthenStart;noinventedAPBtiming.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 4, 'filename': 'lesson24-course-figure4.png', 'alt': 'اثر بافر و بار بر خروجی DAC', 'caption': 'مدار معادل تألیفی و کیفی؛ تحت شروط Table 75، بافر روشن بار مقاومتی به GND حداقل5kOhm، به VDDA حداقل25kOhm و بار خازنی حداکثر50 pF دارد و بازهٔ خروجی شرط\u200cدار0.2 V تا VDDA−0.2 V است. امپدانس بافرخاموش حداکثر15kOhm است، نه مقدار ثابت؛ رسیدن کامل به ریل\u200cها تضمین نشده است.', 'purpose': 'اثر بافر و بار بر خروجی DAC چگونه تفسیر می\u200cشود؟', 'placement': 'بخش چهارم: بافر خروجی آنالوگ (Output Buffer) و رفتار بار', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'QualitativeRoutnotfewOhm;DS9118Table 75DACVDDA2.4..3.6,ONRLtoGND>=5k/toVDDA>=25k/CL<=50 pF,conditionalrange.2..VDDA-.2;OFFRoutMAX15knottyp/fixed,nofullrailsclaim.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 5, 'filename': 'lesson24-course-figure5.png', 'alt': 'اندازه\u200cگیری منطقی PA4 با مولتی\u200cمتر', 'caption': 'شماتیک تألیفی PA4/DAC1_OUT1 با پایهٔ فیزیکی14 به ورودی V مولتی\u200cمتر امپدانس\u200cبالا در حالت DC و GND به COM؛ بار10kOhm به زمین اختیاری است. PA5 با پایهٔ فیزیکی15 کانال دیگر است؛ شمارهٔ بسته شمارهٔ هدر نیست و نمایشگر ولتاژ واقعی ساخته نشده است.', 'purpose': 'اندازه\u200cگیری منطقی PA4 با مولتی\u200cمتر چگونه تفسیر می\u200cشود؟', 'placement': 'بخش ششم: آزمایش عملی و طرح آزمون ولتاژ پله\u200cای با مولتی\u200cمتر', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'PA4phys14OUT1DMMDCred/blackGND;optional10kGNDload;PA5phys15otherchannel;nom5Vboardinput/internal 3V3separate;norealDMMreading.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 6, 'filename': 'lesson24-course-figure6.png', 'alt': 'مفهوم زمان نشست با باند خطای تعریف\u200cشده', 'caption': 'منحنی تألیفی یک پاسخ پلهٔ نرمال\u200cشده با باند فرضی2%؛ زمان برحسب tau است و این باند و منحنی، مشخصهٔ واقعی DAC یا زمان3.5..6 us نیست. دادهٔ واقعی نشست باید با خطای مجاز و بار و شرایط دیتاشیت سنجیده شود.', 'purpose': 'مفهوم زمان نشست با باند خطای تعریف\u200cشده چگونه تفسیر می\u200cشود؟', 'placement': 'بخش چهارم: پایداری خروجی، زمان نشست (Settling Time) و بار خازنی/مقاومتی', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Assumednormalized1-exp(-t/tau)stepwithillustrative2%bandnotDS±1LSB;nofullrailphysicalstep/fake3.5..6 us/actualslewratecurve.', 'status': 'prepared-awaiting-final-visual-review'}]
if __name__=='__main__':run()

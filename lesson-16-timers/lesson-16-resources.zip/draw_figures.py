"""Editable original educational diagrams. Requires Pillow and Windows Segoe UI.
All timelines and waveforms are models, never captured hardware results.
Regenerates only this lesson's PNGs and image-metadata.json beside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, json, textwrap
OUT=Path(__file__).resolve().parent
LESSON=16
W,H=1200,1800
INK='#16354b';TEAL='#087f8c';ORANGE='#ac5c18';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c7d7e1';PALE='#e3f1f2';WHITE='#ffffff'
def font(n=43,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if bold else '')+'.ttf',n)
def tx(d,x,y,s,n=43,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1060,n=43,c=INK,b=False,gap=12):
    words=s.split();lines=[];line=''
    for word in words:
        test=(line+' '+word).strip()
        if d.textlength(test,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,sub='Original diagram / synthetic model'):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,38,title,1090,52,b=True)
    para(d,55,y+10,sub,1090,38,c=MUTED)
    d.line((55,185,1145,185),fill=LINE,width=3)
    return im,d
def footer(d,s='STM32F303CBT6 | Official manuals + exact F3 HAL'):
    d.line((55,H-165,1145,H-165),fill=LINE,width=3)
    para(d,55,H-140,s,1090,33,c=MUTED,gap=6)
    tx(d,55,H-50,'Original model. No board measurement or GUI capture.',32,MUTED)
def arrow(d,pts,c=TEAL,width=7):
    d.line(pts,fill=c,width=width)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+13,s,w-48,42)
    assert yy-18<=y+h+5,(title,yy,y+h)
def note(d,y,s,c=INK):return para(d,65,y,s,1070,43,c)
def save(im,i):im.save(OUT/f'lesson{LESSON}-figure{i}.png',optimize=True)
def axis(d,x0=160,y0=1150,x1=1110,y1=340,xlabel='Time ->',ylabel=None):
    arrow(d,[(x0,y0),(x1,y0)],INK,4);arrow(d,[(x0,y0),(x0,y1)],INK,4)
    tx(d,x1-230,y0+95,xlabel,39)
    if ylabel:tx(d,65,y1-70,ylabel,42,b=True)
def dots(d,x,y,count,active=None,step=70):
    for k in range(count):
        color=TEAL if active is None or k in active else LINE
        d.rounded_rectangle((x+k*step,y,x+k*step+step-9,y+70),8,fill=color)
def step(d,events,xmap,yhi,ylo,c=TEAL,width=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,yhi if last else ylo),(x,yhi if v else ylo)]);last=v
    d.line(pts,fill=c,width=width)
def ring(d,cx,cy,r=310,n=16,start=3,end=11):
    # Sectors represent groups of bytes, not a false256-cell screenshot.
    for k in range(n):
        d.pieslice((cx-r,cy-r,cx+r,cy+r),k*360/n-90,(k+1)*360/n-90,fill=TEAL if (start<=k<end or end>n and k<end-n) else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+100,cy-r+100,cx+r-100,cy+r-100),fill=BG)
def lineplot(d,points,x0,y0,xscale,yscale,c=TEAL):
    d.line([(x0+x*xscale,y0-y*yscale) for x,y in points],fill=c,width=7)




def lesson16():
    im,d=begin('Timer capabilities are not all the same','Exact STM32F303CBT6 | Bonded channel pins vary by package')
    headers=[(65,'Timers'),(425,'Bus'),(650,'CNT'),(900,'CC')]
    for x,t in headers:tx(d,x,245,t,44,b=True)
    rows=[('TIM1 / TIM8','APB2','16-bit','4'),('TIM2','APB1','32-bit','4'),('TIM3 / TIM4','APB1','16-bit','4'),('TIM15','APB2','16-bit','2'),('TIM16 / TIM17','APB2','16-bit','1'),('TIM6 / TIM7','APB1','16-bit','0')]
    for k,row in enumerate(rows):
        y=360+k*145;d.rectangle((55,y-10,1145,y+100),fill=WHITE if k%2==0 else PALE)
        for (x,_),t in zip(headers,row):tx(d,x,y+10,t,43,TEAL if x==65 else INK,x==65)
    note(d,1290,'TIM2 has a32-bit CNT, but its PSC is16-bit. TIM1 and TIM8 are advanced16-bit timers.')
    note(d,1430,'Up/down/center modes are not universal: TIM6/7 and reduced timers have different capabilities.',ORANGE)
    footer(d,'DS9118 Rev14 Table5; CC = capture/compare channel count.');save(im,1)

    im,d=begin('Prescaler, counter and reload')
    panel(d,70,230,1060,150,'Timer input clock',['Actual TIM2 project:72MHz internal clock'])
    arrow(d,[(600,395),(600,460)])
    panel(d,70,480,1060,210,'PSC -> prescaler active value',['f_CNT = f_TIM /(PSC +1)','PSC transfer is buffered; update loads it.'])
    arrow(d,[(600,705),(600,770)])
    panel(d,70,790,1060,150,'CNT increments on count ticks',['TIM2 counter range:0..0xFFFFFFFF'])
    arrow(d,[(600,960),(600,1030)])
    panel(d,70,1050,1060,235,'ARR active value sets the boundary',['ARPE=1: ARR preload waits for update.','An allowed update transfers buffered settings.'])
    arrow(d,[(600,1300),(600,1370)])
    tx(d,120,1400,'Update event -> UIF (subject to controls)',45,TEAL,True)
    footer(d,'Actual variants PSC71/7199, ARR0xFFFFFFFF and ARPE enabled.');save(im,2)

    im,d=begin('Three counter shapes, where supported','Conceptual count shapes; not a capture or a clock-exact trace')
    x0=200;xx=lambda t:x0+t*100
    for base,title,pts in [(315,'UP',[(0,0),(3,1),(3,0),(6,1),(6,0),(9,1)]),(755,'DOWN',[(0,1),(3,0),(3,1),(6,0),(6,1),(9,0)]),(1195,'CENTER',[(0,0),(3,1),(6,0),(9,1)])]:
        tx(d,65,base-75,title,46,TEAL,True)
        d.line((x0,base+210,1110,base+210),fill=INK,width=3)
        tx(d,75,base-5,'ARR',40);tx(d,95,base+170,'0',40)
        d.line([(xx(t),base+200-v*190) for t,v in pts],fill=TEAL,width=7)
        for t in [3,6]:d.line((xx(t),base-15,xx(t),base+245),fill=LINE,width=3)
    tx(d,905,1490,'Time ->',41,b=True)
    note(d,1550,'CMS selects compare flags, not update gating.',ORANGE)
    footer(d,'Update behavior also depends on UDIS/URS and repetition settings.');save(im,3)

    im,d=begin('APB division and timer clock doubling','Actual course clock tree | Both timer buses reach72MHz')
    panel(d,70,230,1060,150,'HCLK =72MHz',['AHB prescaler /1'])
    arrow(d,[(350,400),(350,540)]);arrow(d,[(850,400),(850,540)],ORANGE)
    panel(d,65,560,520,240,'APB1 /2',['PCLK1 =36MHz','TIM2/3/4/6/7'],TEAL)
    panel(d,615,560,520,240,'APB2 /1',['PCLK2 =72MHz','TIM1/8/15/16/17'],ORANGE)
    arrow(d,[(325,820),(325,975)]);arrow(d,[(875,820),(875,975)],ORANGE)
    panel(d,65,995,520,240,'Timer clock x2',['Divider is not1.','f_TIM =72MHz'],TEAL)
    panel(d,615,995,520,240,'Timer clock x1',['Divider is1.','f_TIM =72MHz'],ORANGE)
    note(d,1390,'Do not use PCLK1=36MHz directly as the TIM2 input in this project. The timer rule depends on the bus prescaler.')
    footer(d,'RM0316 RCC clock tree; fixed course configuration, not universal.');save(im,4)

    im,d=begin('ARR preload delays the active change','Conceptual up-count example | ARPE does not remove all jitter')
    for base,title,on in [(265,'ARPE=0: active ARR changes immediately',False),(900,'ARPE=1: active ARR waits for update',True)]:
        tx(d,65,base,title,43,TEAL if on else ORANGE,True)
        x0=160;y0=base+370
        d.line((x0,y0,1100,y0),fill=INK,width=3)
        d.line((x0,y0-270,1100,y0-270),fill=LINE,width=4)
        d.line((x0,y0-110,1100,y0-110),fill=ORANGE,width=5)
        tx(d,65,base+60,'old ARR',39,MUTED);tx(d,65,y0-90,'new',39,ORANGE)
        pts=[(160,y0),(650,y0-210)]
        if on:pts.extend([(790,y0-270),(790,y0),(1020,y0-110),(1020,y0),(1100,y0-35)])
        else:pts.extend([(1100,y0-360)])
        d.line(pts,fill=TEAL,width=7)
        arrow(d,[(650,base+460),(650,base+300)],ORANGE)
        tx(d,500,base+490,'Write new ARR below current CNT',40,ORANGE,True)
        if on:tx(d,65,base+560,'Update transfers the buffered value.',42)
        else:tx(d,65,base+560,'The current compare may be missed.',42)
    footer(d,'This shape models a consequence, not a measured output waveform.');save(im,5)

    im,d=begin('A timer can trigger another timer','Logical master/slave routing; no second timer configured here')
    panel(d,75,250,1050,245,'MASTER timer',['Choose a supported event, e.g. update.','CR2.MMS selects the TRGO source.'])
    arrow(d,[(600,520),(600,730)])
    tx(d,690,595,'TRGO',50,TEAL,True)
    d.rounded_rectangle((230,750,970,910),20,fill=TEAL)
    tx(d,290,800,'Internal trigger routing',46,'white',True)
    arrow(d,[(600,935),(600,1135)])
    tx(d,700,1010,'ITRx -> TS',47,TEAL,True)
    panel(d,75,1155,1050,270,'SLAVE timer',['SMCR.TS selects the supported input route.','SMCR.SMS selects reset / gated / trigger mode.'])
    note(d,1490,'Verify the exact timer-pair ITR table; TRGO is not automatically routed to every other timer.',ORANGE)
    footer(d,'RM0316 timer synchronization; actual lesson16 uses only TIM2.');save(im,6)



def run():
    globals()[f'lesson{LESSON}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')



METADATA=[{'id': 1, 'filename': 'lesson16-figure1.png', 'alt': 'ویژگی\u200cهای متفاوت تایمرهای STM32F303CBT6', 'caption': 'جدول تألیفی بر پایهٔ DS9118 Rev14 Table5: TIM1 و TIM8 هر دو موجود و پیشرفتهٔ 16 بیتی\u200cاند؛ TIM2 شمارندهٔ 32 بیتی با PSC شانزده\u200cبیتی دارد. شمار کانال\u200cها به معنی موجودبودن همهٔ پایه\u200cهای کانال در LQFP48 نیست و همهٔ تایمرها حالت\u200cهای شمارش یکسان ندارند.', 'purpose': 'تایمرهای موجود این تراشه در باس و عرض شمارنده و کانال چه تفاوتی دارند؟', 'placement': 'بخش ماتریس تایمرهای موجود در پکیج 48 پین LQFP بر اساس DS9118', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 2, 'filename': 'lesson16-figure2.png', 'alt': 'مسیر کلاک و پیش\u200cبارگذاری PSC و ARR', 'caption': 'مدل تألیفی هستهٔ زمان\u200cبندی تایمر: PSC با رخداد مجاز Update بارگذاری می\u200cشود؛ ARR با ARPE=1 پیش\u200cبارگذاری دارد. پروژهٔ واقعی TIM2 از PSC برابر 71 یا 7199 و ARR برابر 0xFFFFFFFF استفاده می\u200cکند؛ رخداد Update و ثبت UIF تابع کنترل\u200cهای تایمرند.', 'purpose': 'PSC و CNT و ARR و پیش\u200cبارگذاری چگونه به هم مربوط\u200cاند؟', 'placement': 'بخش رجیسترهای اصلی و سازوکار عملکرد', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 3, 'filename': 'lesson16-figure3.png', 'alt': 'شکل مفهومی شمارش صعودی و نزولی و مرکزی', 'caption': 'نمودار تألیفی شکل CNT در سه حالت، فقط برای تایمرهای پشتیبان آن حالت\u200cها؛ نمودار ردگیری دقیق سیکل\u200cها یا نتیجهٔ برد نیست. CMS رفتار پرچم مقایسه را انتخاب می\u200cکند؛ شرایط Update از UDIS و URS و در تایمرهای مربوط از تکرار نیز اثر می\u200cپذیرد.', 'purpose': 'شکل شمارش صعودی و نزولی و مرکزی در تایمر پشتیبان چگونه متفاوت است؟', 'placement': 'بخش حالت\u200cهای شمارش در تایمرهای چندمنظوره', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 4, 'filename': 'lesson16-figure4.png', 'alt': 'اثر تقسیم APB و دوبرابرشدن کلاک تایمر', 'caption': 'نمودار محاسباتی تألیفی پیکربندی مشترک دوره: HCLK=72MHz و APB1/2 به PCLK1=36MHz و کلاک تایمر APB1=72MHz می\u200cرسد؛ APB2/1 کلاک تایمر 72MHz دارد. این قاعده برای تنظیم همین پروژه است و به همهٔ تنظیمات تعمیم داده نمی\u200cشود.', 'purpose': 'چرا با APB1 برابر 36MHz کلاک تایمر این پروژه برابر 72MHz است؟', 'placement': 'بخش درخت کلاک و سازوکار فرکانس 72 مگاهرتز تایمرها', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 5, 'filename': 'lesson16-figure5.png', 'alt': 'تفاوت زمان اثر نوشتن ARR با ARPE', 'caption': 'مدل تألیفی شمارش رو به بالا: با ARPE=0 نوشتن ARR کوچک\u200cتر از CNT جاری ممکن است مقایسهٔ جاری را از دست بدهد؛ با ARPE=1 مقدار تازه تا Update در پیش\u200cبارگذاری منتظر می\u200cماند. نمودار اندازه\u200cگیری نیست و پیش\u200cبارگذاری تضمین حذف همهٔ Jitterها نیست.', 'purpose': 'ARPE زمان اثر مقدار تازهٔ ARR را چگونه تغییر می\u200cدهد؟', 'placement': 'بخش بیت کنترلی ARPE و تولید رخداد به\u200cروزرسانی', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 6, 'filename': 'lesson16-figure6.png', 'alt': 'مسیر منطقی TRGO تا ورودی ITR تایمر پیرو', 'caption': 'نمودار تألیفی همگام\u200cسازی: MMS منبع TRGO و TS مسیر ورودی و SMS حالت پیرو را تعیین می\u200cکنند. نگاشت هر زوج تایمر باید از جدول ITR همان تراشه بررسی شود؛ این شکل ادعای پروژهٔ عملی تایمر دوم نیست و پروژهٔ درس فقط TIM2 دارد.', 'purpose': 'TRGO و ITR و انتخاب\u200cهای MMS و TS و SMS چه ارتباطی دارند؟', 'placement': 'بخش ارتباط داخلی تایمرها از طریق سیگنال TRGO و خطوط تریگر داخلی ITR', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}]
if __name__=='__main__':run()

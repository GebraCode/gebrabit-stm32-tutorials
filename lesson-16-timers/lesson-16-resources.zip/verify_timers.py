"""Ideal expected values only, not observations of the physical board."""
import json
f=72_000_000
rows=[]
for psc in [71,7199]:
    tick=f/(psc+1)
    rows.append({'PSC':psc,'ARR':0xffffffff,'tick_hz':tick,'tick_us':1e6/tick,'wrap_seconds':2**32/tick,'ideal_ticks_in_100ms':tick/10})
assert rows[0]['tick_hz']==1_000_000 and rows[1]['tick_hz']==10_000
assert rows[0]['wrap_seconds']==4294.967296
print(json.dumps({'assumptions':'72MHz timer, upcounting full 32-bit range, ideal clock; HAL_Delay and debugger timing are not precise 100ms measurements','expected':rows},indent=2))

"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=29
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Follow power into the backup domain','Original functional power diagram; stock VBAT is tied to 3V3, not a battery holder')
 panel(d,75,290,1050,180,'5 V input -> AMS1117-3V3 -> 3V3 rail',())
 arrow(d,[(600,490),(600,570),(300,570),(300,650)]);arrow(d,[(600,570),(900,570),(900,650)])
 panel(d,65,670,470,230,'VDD / VDDA',['Normal MCU supply'])
 panel(d,665,670,470,230,'VBAT pin 1',['R11=0 Ohm from 3V3','C4=1 uF to GND'])
 arrow(d,[(900,920),(900,1030)])
 panel(d,665,1050,470,250,'Backup domain',['RTC + 64 B registers','LSE PC14 / PC15'])
 panel(d,65,1050,470,250,'Protected writes',['Enable PWR clock','DBP grants access'])
 panel(d,75,1410,1050,185,'Retention requires backup power',['Full board power loss does not preserve stock RTC.'])
 foot(d,'Do not attach a battery directly to the tied 3V3 node.');save(im,1)
def figure2():
 im,d=begin('Divide clocks and read the calendar','Nominal LSE 32768 Hz; no frequency or wall-clock accuracy was measured')
 stages=[('RTCCLK 32768 Hz','LSE source'),('PREDIV_A=127 -> divide 128','ck_apre=256 Hz'),('PREDIV_S=255 -> divide 256','Nominal 1 Hz calendar; SSR counts synchronous ticks')]
 for k,(a,b)in enumerate(stages):
  yy=290+k*310;panel(d,75,yy,1050,225,a,[b])
  if k<2:arrow(d,[(600,yy+235),(600,yy+ 300)])
 panel(d,75,1300,1050,300,'Calendar shadow access: GetTime -> GetDate',['Read the date even when you only display the time.','BIN 23 -> hardware BCD 0x23; these are different representations.'])
 foot(d,'Register values 127/255 -> actual divisors 128/256.');save(im,2)
def figure3():
 im,d=begin('Separate RTC alarm and wakeup paths','Actual source flags are handled separately; calendar alarms are match conditions')
 panel(d,65,300,470,240,'Alarm A',['ALRMAR / ALRMASSR'])
 panel(d,665,300,470,240,'Alarm B',['ALRMBR / ALRMBSSR'])
 arrow(d,[(300,560),(300,650),(600,650),(600,740)]);arrow(d,[(900,560),(900,650),(600,650)])
 panel(d,75,760,1050,225,'EXTI17 -> shared RTC Alarm IRQ',['HAL checks A and B flags and dispatches their callbacks.'])
 panel(d,65,1140,470,280,'WUTR=9 / 1 Hz',['Nominal 10 s period'])
 arrow(d,[(550,1270),(650,1270)])
 panel(d,665,1140,470,280,'EXTI20 / RTC WKUP',['Separate wakeup callback'])
 tx(d,75,1520,'Callbacks set flags; main reports and re-arms alarms.',40)
 foot(d,'Hardware periods still have interrupt/software service costs.');save(im,3)
def figure4():
 im,d=begin('A seconds match is not a 10 s period','Synthetic scheduling examples; the actual program re-arms alarms from main')
 tx(d,75,300,'Fixed seconds=10, minutes masked',46,TEAL,True)
 for k,a in enumerate(['00:10','01:10','02:10']):
  panel(d,75+k*365,430,330,150,a,())
  if k<2:arrow(d,[(415+k*365,505),(430+k*365,505)])
 tx(d,75,650,'Matches once per minute, not every 10 seconds.',43,ORANGE,True)
 panel(d,75,800,1050,360,'Dynamic targets use current time',['A: now + 10 s; B: now + 30 s; date masked','23:59:55 + 10 s -> 00:00:05','Main latency shifts cadence; no phase anchor.'])
 tx(d,75,1250,'WUT: 1 Hz clock, reload 9 -> 10 s nominal',44,TEAL,True)
 d.line((150,1450,1110,1450),fill=INK,width=4)
 for k in range(4):
  x=150+k*300;d.line((x,1450,x,1360),fill=TEAL,width=7);tx(d,x-20,1490,str(k*10),40)
 tx(d,75,1570,'WUT time axis in seconds; model pulses, not a capture.',40)
 foot(d,'Neither dynamic alarms nor WUT mean zero CPU overhead.');save(im,4)
def figure5():
 im,d=begin('Preserve the calendar across reset','Actual guard uses backup marker 0x32F2 plus INITS; no live RTC reading is claimed')
 panel(d,75,300,1050,185,'Configure LSE / backup-domain access',())
 arrow(d,[(600,505),(600,610)])
 panel(d,75,610,1050,250,'Snapshot marker 0x32F2 + INITS',['Then HAL_RTC_Init and verify PRER.','A marker does not prove correct wall-clock time.'])
 arrow(d,[(600,860),(600,950),(300,950),(300,1010)]);arrow(d,[(600,950),(900,950),(900,1010)])
 panel(d,65,1030,470,290,'Guard valid',['Preserve the calendar.','Do not SetTime/Date again.'])
 panel(d,665,1030,470,290,'Guard invalid',['Set demo Time/Date.','Then write backup marker.'])
 panel(d,75,1450,1050,155,'Cold epoch 2026-01-01 00:00:00 is a demo value',())
 foot(d,'Backup reset, source changes or power loss can break retention.');save(im,5)
def figure6():
 im,d=begin('Measure drift before calibration','Assumed +15 ppm model below; no drift or trim improvement was measured')
 tx(d,75,290,'32 s x 32768 Hz = 2^20 RTCCLK cycles',46,TEAL,True)
 tx(d,75,390,'Approximate step: 1e6 / 2^20 = 0.953674 ppm',44,TEAL,True)
 tx(d,75,490,'Pulse balance: 512 x CALP - CALM',44)
 x0=160;y0=1130;ww=900;hh=430;d.line((x0,630,x0,y0,x0+ww,y0),fill=INK,width=4)
 for h in [0,6,12,18,24]:
  x=x0+h/24*ww;tx(d,x-20,1160,str(h),40)
 for val in [0,.648,1.296]:
  yy=y0-val/1.296*hh;d.line((x0,yy,x0+ww,yy),fill=LINE,width=2);tx(d,50,yy-25,str(val),38)
 d.line((x0,y0,x0+ww,y0-hh),fill=ORANGE,width=8)
 tx(d,200,620,'Offset (s)',42,ORANGE,True);tx(d,750,1240,'Reference time (h)',40)
 panel(d,75,1380,1050,225,'Assumed +1.296 s/day',['Use a trusted reference; record temperature.','Default calibration stays unchanged.'])
 foot(d,'Calibration windows count RTCCLK cycles, not ck_apre cycles.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson29-refresh-figure1.png', 'alt': 'ناحیهٔ پشتیبان و تغذیهٔ واقعی برد', 'caption': 'نمودار عملکردی تألیفی تغذیه: VBAT پین 1 از R11 برابر 0 Ohm به 3V3 وصل است و C4 برابر 1 uF دارد. RTC و 16 رجیستر 32 بیتی پشتیبان فقط با تداوم تغذیه حفظ می\u200cشوند؛ برد استاندارد باتری مستقل ندارد. این تصویر بازترسیم شماتیک رسمی یا عکس برد نیست.', 'purpose': 'ناحیهٔ پشتیبان و تغذیهٔ واقعی برد', 'placement': 'FIGURE_1', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 2, 'filename': 'lesson29-refresh-figure2.png', 'alt': 'تقسیم کلاک RTC و خواندن shadow', 'caption': 'نمودار تألیفی LSE اسمی 32768 Hz با PREDIV_A=127 و PREDIV_S=255، یعنی تقسیم\u200cهای واقعی 128 و 256 و تقویم اسمی 1 Hz. ترتیب GetTime سپس GetDate برای آزادکردن shadow نشان داده شده است. BIN برابر 23 و نمایش BCD برابر 0x23 دو نمایش متفاوت\u200cاند؛ دقت زمانی اندازه\u200cگیری نشده است.', 'purpose': 'تقسیم کلاک RTC و خواندن shadow', 'placement': 'FIGURE_2', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 3, 'filename': 'lesson29-refresh-figure3.png', 'alt': 'مسیرهای مستقل Alarm و Wakeup', 'caption': 'نمودار تألیفی Alarm A و B در مسیر مشترک EXTI17 و RTC Alarm IRQ، در برابر WUT با EXTI20 و IRQ مستقل. مقدار reload برابر 9 با کلاک اسمی 1 Hz دورهٔ اسمی 10 s می\u200cدهد. callbackها فقط شمارنده و پرچم را ثبت می\u200cکنند؛ پردازش main و هزینهٔ وقفه حذف نمی\u200cشوند.', 'purpose': 'مسیرهای مستقل Alarm و Wakeup', 'placement': 'FIGURE_3', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 4, 'filename': 'lesson29-refresh-figure4.png', 'alt': 'تفاوت تطبیق ثانیه و زمان\u200cبندی دوره\u200cای', 'caption': 'مثال مصنوعی تطبیق seconds=10 با minutes masked فقط یک بار در هر دقیقه رخ می\u200cدهد. کد واقعی Alarm A را از زمان جاری به\u200cاضافهٔ 10 s و B را به\u200cاضافهٔ 30 s دوباره تنظیم می\u200cکند؛ rollover روز رعایت می\u200cشود و تأخیر main آهنگ بعدی را جابه\u200cجا می\u200cکند. پالس\u200cهای WUT مدل\u200cاند، نه ثبت ابزار.', 'purpose': 'تفاوت تطبیق ثانیه و زمان\u200cبندی دوره\u200cای', 'placement': 'FIGURE_4', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 5, 'filename': 'lesson29-refresh-figure5.png', 'alt': 'حفظ تقویم با marker و INITS', 'caption': 'روندنمای تألیفی منطبق با ترتیب واقعی کد: پس از دسترسی به LSE و backup domain، مقدار marker برابر 0x32F2 و INITS پیش از HAL_RTC_Init ذخیره می\u200cشوند؛ سپس init و بررسی PRER انجام می\u200cشود. در مسیر معتبر تقویم دوباره نوشته نمی\u200cشود؛ در مسیر marker نامعتبر یا مفقود، حتی با RTC روشن، زمان و تاریخ نمونه تنظیم و marker ثبت می\u200cشود. مقدار 2026-01-01 ساعت 00:00:00 نمونه است، نه زمان جاری یا خواندن واقعی برد.', 'purpose': 'حفظ تقویم با marker و INITS', 'placement': 'FIGURE_5', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}, {'id': 6, 'filename': 'lesson29-refresh-figure6.png', 'alt': 'مدل drift و گام smooth calibration', 'caption': 'نمودار محاسباتی تألیفی با فرض خطای مثبت 15 ppm، معادل 1.296 s در روز؛ این خطا اندازه\u200cگیری نشده است. پنجرهٔ 32 s شامل 2^20 سیکل RTCCLK است، نه سیکل ck_apre. گام حدود 0.953674 ppm و توازن پالس 512×CALP−CALM مدل مقدماتی\u200cاند؛ ضریب دقیق اصلاح 2^20/(2^20+CALM−512×CALP) است. کالیبراسیون پیش\u200cفرض تغییر نمی\u200cکند.', 'purpose': 'مدل drift و گام smooth calibration', 'placement': 'FIGURE_6', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'F303CB resources and conditioned characteristics'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316', 'scope': 'RTC / PWR / GPIO / USART register concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Actual board power and logical signal nets'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'Pinned HAL 953955a plus actual generated lesson source', 'scope': 'Source-bound sequence, not board observation'}], 'type': 'original explanatory diagram / explicitly labelled calculated model', 'source': 'Original Codex Pillow geometry based on root-accepted Antigravity plan and actual project facts.', 'rights': 'Original layout; no official figure copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final; source-bound; Codex and root visual reviews completed; no physical measurement'}]
if __name__=='__main__':run()

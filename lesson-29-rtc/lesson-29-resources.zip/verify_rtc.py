"""RTC arithmetic, rollover, archive/source checks; no calendar hardware simulation."""
from pathlib import Path
import json,zipfile,hashlib,math
P=Path(__file__).resolve().parent;checks=[]
def check(n,c):
 assert c,n
 checks.append(n)
def target(h,m,s,delta):
 t=(h*3600+m*60+s+delta)%86400
 return t//3600,t//60%60,t%60
check('LSE prescalers give1Hz',32768/(127+1)/(255+1)==1)
check('WUTreload9gives10seconds',(9+1)/1==10)
for initial,delta,expected in [((12,0,5),10,(12,0,15)),((12,59,55),10,(13,0,5)),((23,59,55),10,(0,0,5)),((23,59,50),30,(0,0,20))]:check('rollover '+str(initial),target(*initial,delta)==expected)
check('fixedseconds10everyminute',[t for t in range(0,121)if t%60==10]==[10,70])
check('BCD23is0x23',((23//10)<<4)|(23%10)==0x23)
N=2**20
def factor(p,m):return N/(N+m-512*p)
extrema={'minimum_ppm':(factor(0,511)-1)*1e6,'maximum_ppm':(factor(1,0)-1)*1e6}
check('zero trim unchanged',factor(0,0)==1)
check('remove pulses slows calendar',factor(0,16)<1)
check('add pulses speeds calendar',factor(1,0)>1)
check('15ppmfast1.296seconds/day',math.isclose(15e-6*86400,1.296))
residual=((1+15e-6)*factor(0,16)-1)*1e6
check('16removedreduces15ppmexample',abs(residual)<1)
check('approxstep0.953674ppm',math.isclose(1e6/N,.95367431640625))
for kind in ['projects','build-artifacts']:
 with zipfile.ZipFile(P/f'lesson-29-{kind}.zip')as z:
  check(kind+' CRC',z.testzip() is None)
  manifest=json.loads((P/(kind+'-manifest.json')).read_text());check(kind+' hashes',all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items()))
  if kind=='projects':
   root='gebrabit_lesson29_rtc/';main=z.read(root+'Core/Src/main.c').decode();rtc=z.read(root+'Core/Src/rtc.c').decode();it=z.read(root+'Core/Src/stm32f3xx_it.c').decode()
   check('marker+INITS beforeInit',rtc.index('RTC->BKP0R == 0x32F2U')<rtc.index('HAL_RTC_Init(') and 'RTC_ISR_INITS' in rtc)
   check('conditional initialcalendar',rtc.index('if (valid_calendar == 0U)')<rtc.index('HAL_RTC_SetTime('))
   check('time beforedate',main.index('HAL_RTC_GetTime(')<main.index('HAL_RTC_GetDate('))
   callbacks=main[main.index('/* USER CODE BEGIN 4 */'):main.index('/* USER CODE END 4 */')]
   check('callbacks short noformat orrearm',all(x not in callbacks for x in ['snprintf','HAL_UART_Transmit','HAL_RTC_SetAlarm_IT','HAL_Delay']))
   check('AlarmAandBsharedhandler/WUTseparate','HAL_RTC_AlarmIRQHandler(&hrtc)' in it and 'HAL_RTCEx_WakeUpTimerIRQHandler(&hrtc)' in it)
r={'scope':'Arithmetic predictions and static archive/source checks; no board calendar/alarms/drift/calibration observations','checks_passed':len(checks),'checks':checks,'RTCCLK_Hz_nominal':32768,'calendar_Hz_nominal':1,'WUT_seconds_nominal':10,'calibration_window_RTCCLK_cycles':N,'exact_frequency_factor':'2^20/(2^20+CALM-512*CALP)','factor_domain':'32s window, CALM0..511,CALP0or1; factorrelative to untrimmed clock, not whole oscillator accuracy','exact_correction_extrema_ppm':extrema,'approx_step_ppm':1e6/N,'hypothetical_fast15ppm_seconds_per_day':1.296,'hypothetical_CALP0_CALM16_residual_ppm':residual}
(P/'rtc-model-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

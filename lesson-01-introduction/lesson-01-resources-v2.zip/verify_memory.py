"""Arithmetic/model checks only. No connection to a microcontroller."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
f=json.loads((P/'device-facts.json').read_text(encoding='utf-8'))
checks=[]
def check(name,condition):
    if not condition: raise AssertionError(name)
    checks.append(name)
check('exact part', f['part']=='STM32F303CBT6')
check('exact CB capacities', (f['flash_kib'],f['main_sram_kib'],f['ccm_kib'])==(128,32,8))
flash,main,ccm=(f[k]*1024 for k in ('flash_kib','main_sram_kib','ccm_kib'))
check('binary KiB', (flash,main,ccm)==(131072,32768,8192))
check('RAM sum not main SRAM', main+ccm==40960 and main!=40960)
def budget(count,width,copies,other):
    if any(type(v) is not int or v<0 for v in (count,width,copies,other)) or width==0 or copies==0:
        raise ValueError('nonnegative integer counts and positive width/copies required')
    raw=count*width*copies
    return {'buffer_bytes':raw,'other_reserved_bytes':other,'remaining_main_sram_bytes':main-raw-other,'fits_main_sram':raw+other<=main}
cases={'single_32bit':budget(1024,4,1,0), 'double_16bit':budget(1024,2,2,6144), 'oversized':budget(20000,2,1,0)}
check('single buffer 4096',cases['single_32bit']['buffer_bytes']==4096)
check('single remainder theoretical',cases['single_32bit']['remaining_main_sram_bytes']==28672)
check('double buffer reserves both copies',cases['double_16bit']['buffer_bytes']==4096)
check('explicit other allocations',cases['double_16bit']['remaining_main_sram_bytes']==22528)
check('oversized buffer rejected despite total RAM',not cases['oversized']['fits_main_sram'] and cases['oversized']['buffer_bytes']<main+ccm)
for args in [(-1,2,1,0),(1,0,1,0),(1,2,0,0),(1.5,2,1,0)]:
    try: budget(*args)
    except ValueError: checks.append('reject invalid input '+str(args))
    else: raise AssertionError('invalid input accepted')
report={'kind':'arithmetic model, not measured free RAM','checks_passed':len(checks),'checks':checks,'capacities_bytes':{'flash':flash,'main_sram':main,'ccm':ccm,'total_ram':main+ccm},'cases':cases,'limits':'Other reservations are illustrative. Linker placement, stack peaks, heap, alignment and all actual globals need a real build/runtime analysis. CCM is separate, not a DMA buffer extension. No MCU firmware or hardware test.'}
(P/'memory-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

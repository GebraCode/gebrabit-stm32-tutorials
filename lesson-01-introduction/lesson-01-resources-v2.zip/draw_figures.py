"""Original novice-oriented course drawings; standalone generator.
Uses only Pillow, standard library and the system Segoe UI font.
No official illustration, GUI screenshot or hardware photo is reproduced.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=1
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
    im,d=begin('Integrated control or a larger application?','Two illustrative architectures; individual devices can differ')
    tx(d,65,295,'MCU example: many resources in one chip',46,TEAL,True)
    d.rounded_rectangle((100,420,1100,810),25,fill=WHITE,outline=TEAL,width=5)
    for x,y,a in [(150,465,'CPU core'),(650,465,'Flash'),(150,640,'SRAM'),(650,640,'Peripherals')]:panel(d,x,y,400,120,a,())
    tx(d,65,950,'Application MPU example: external resources',46,ORANGE,True)
    chip(d,95,1100,420,250,'Processor','Application core',ORANGE)
    panel(d,735,1040,380,175,'External RAM',(),ORANGE)
    panel(d,735,1300,380,175,'Storage',(),ORANGE)
    arrow(d,[(550,1185),(715,1130)],ORANGE);arrow(d,[(550,1280),(715,1375)],ORANGE)
    tx(d,65,1540,'These are tendencies, not rules about all MCUs or MPUs.',41)
    foot(d);save(im,1)

def figure2():
    im,d=begin('Cortex-M names describe different core options','A qualitative feature map, not an energy or speed benchmark')
    rows=[('M0 / M0+','Compact control; Thumb instruction subset'),('M3','General control with Thumb-2'),('M4','DSP extensions; optional single-precision FPU'),('M7','Different implementation options and capabilities')]
    for k,(a,b) in enumerate(rows):
        yy=300+k*255;d.rounded_rectangle((65,yy,1135,yy+190),18,fill=WHITE,outline=LINE,width=3)
        tx(d,95,yy+35,a,49,TEAL,True);para(d,420,yy+30,b,670,43)
    panel(d,70,1370,1060,225,'This course: STM32F303CBT6',['Cortex-M4 with single-precision FPU and DSP.','This exact part has no D-cache.'])
    foot(d,'Core features do not alone choose the best MCU.');save(im,2)

def figure3():
    im,d=begin('The CPU reaches resources through access paths','Simplified STM32F303CBT6 map; no clock or bandwidth claim')
    chip(d,80,325,490,200,'Cortex-M4','CPU executes code')
    panel(d,680,325,450,200,'CCM RAM',['CPU access only'],ORANGE)
    arrow(d,[(595,425),(655,425)],ORANGE)
    arrow(d,[(325,550),(325,650)])
    d.rounded_rectangle((70,675,1130,795),18,fill=TEAL);tx(d,250,705,'AHB access / interconnect',49,'white',True)
    for x,w,a in [(65,310,'DMA'),(440,310,'Flash'),(815,310,'Main SRAM')]:
        if a=='DMA':arrow(d,[(x+w/2,1015),(x+w/2,815)])
        else:arrow(d,[(x+w/2,815),(x+w/2,1015)])
        panel(d,x,1040,w,145,a,())
    arrow(d,[(405,815),(405,1230),(315,1230),(315,1270)])
    panel(d,65,1300,500,180,'APB bridges',['Clock setup comes later.'])
    panel(d,635,1300,500,180,'Peripherals',['GPIO, timers, UART...'])
    arrow(d,[(585,1390),(615,1390)])
    tx(d,65,1540,'DMA has no access route to CCM on this part.',43,RED,True)
    foot(d,'Not a complete bus matrix or an ADC-clock diagram.');save(im,3)

def figure4():
    im,d=begin('Three memory regions, three address ranges','Lengths show relative capacities; addresses are separate')
    rows=[('Flash: 128 KiB',128,'0x08000000 .. 0x0801FFFF','Nonvolatile program/data storage',TEAL),('Main SRAM: 32 KiB',32,'0x20000000 .. 0x20007FFF','Volatile RAM; DMA-accessible',INK),('CCM RAM: 8 KiB',8,'0x10000000 .. 0x10001FFF','Volatile CPU-coupled RAM; not for DMA',ORANGE)]
    for k,(title,size,address,note,col) in enumerate(rows):
        yy=310+k*390;tx(d,65,yy,title,48,col,True)
        d.rounded_rectangle((110,yy+115,110+size*7.5,yy+205),12,fill=col)
        tx(d,65,yy+235,address,43,b=True);tx(d,65,yy+310,note,41)
    tx(d,65,1550,'32 +8 =40 KiB RAM, not one contiguous 40 KiB block.',42,RED,True)
    foot(d,'Exact STM32F303CBT6 sizes; KiB =1024 bytes.');save(im,4)

def figure5():
    im,d=begin('Board power and crystals have different jobs','Functional map for GB100ST V2.0; not a placement drawing')
    panel(d,65,300,1070,160,'Nominal 5V board input -> AMS1117-3V3',())
    arrow(d,[(325,485),(325,620)]);arrow(d,[(875,485),(875,620)],ORANGE)
    panel(d,65,645,520,200,'Digital supply',['3V3 -> VDD'])
    panel(d,615,645,520,200,'Analog supply',['Filter -> VDDA'],ORANGE)
    tx(d,65,980,'Two board crystals',47,TEAL,True)
    panel(d,65,1110,520,235,'HSE crystal',['8 MHz','OSC_IN / OSC_OUT'])
    panel(d,615,1110,520,235,'LSE crystal',['32.768 kHz','RTC clock option'],ORANGE)
    para(d,65,1450,'A crystal being fitted does not mean software selected it. This drawing does not show capacitor values or package positions.',1070,43)
    foot(d,'Board schematic V2.0 supplies the functional facts.');save(im,5)

def figure6():
    im,d=begin('Read the signal names, not guessed header numbers','Functional board connections; not a connector-position drawing')
    tx(d,65,305,'USER LED: High on PB6 turns it on',45,TEAL,True)
    panel(d,65,435,300,145,'PB6',());arrow(d,[(390,510),(480,510)])
    panel(d,505,435,310,145,'NPN driver',());arrow(d,[(840,510),(930,510)])
    d.ellipse((955,455,1085,585),outline=ORANGE,width=5);tx(d,973,490,'LED',40,ORANGE,True)
    tx(d,65,710,'USER button -> PA3 input',46,b=True)
    tx(d,65,830,'BOOT selector -> GND by default',46,ORANGE,True)
    d.line((65,960,1135,960),fill=LINE,width=3)
    tx(d,65,1010,'SWD signal names',48,TEAL,True)
    for k,s in enumerate(['PA13 = SWDIO; PA14 = SWCLK','GND and target-voltage reference also matter.','NRST = reset; PB3 = optional SWO.']):tx(d,65,1130+k*120,s,42)
    tx(d,65,1530,'No pull-resistor value or physical header order is assumed.',41)
    foot(d,'Use the exact board schematic and programmer guide.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson01-refresh-figure1.png', 'alt': 'دو نمونهٔ ساختاری MCU و MPU کاربردی', 'caption': 'نمودار تألیفی دو نمونهٔ معماری: MCU می\u200cتواند هسته و حافظه و پریفرال را یکپارچه کند؛ نمونهٔ MPU کاربردی با RAM و ذخیره\u200cساز بیرونی نشان داده شده است. این تمایز گرایش معمول است، نه قانون همهٔ تراشه\u200cها یا حکم دربارهٔ سیستم\u200cعامل و تغذیهٔ آن\u200cها.', 'purpose': 'دو نمونهٔ ساختاری MCU و MPU کاربردی چه چیزی را روشن می\u200cکند؟', 'placement': 'پس از بخش «مقایسه ساختاری: معماری حافظه مجتمع، مدیریت توان و قطعی بودن زمان پاسخ (Determinism)»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'STM32F303CB memory, core, pin and peripheral facts'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'Device memory/access architecture, no reproduced layout'}, {'url': 'https://documentation-service.arm.com/static/62053f0a0ca305732a3a5c17', 'version': 'Official Cortex-M4 datasheet', 'scope': 'Core instruction/DSP/FPU options'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'scope': 'Board power,crystals and signal connections'}], 'rights': 'Original new geometry; no official figure copied, no assumed CC license, systemfontnotredistributed', 'source': 'Codex original Pillow drawing based on acceptedAGplan and checked device/board facts', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'MCUintegratedCPUFlashSRAMperipheralsvsillustrativeapplicationMPUexternalRAM/storage; noallMCUs3.3V/internalreg/noallMPUsneedexternalabsolute.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson01-refresh-figure2.png', 'alt': 'ویژگی\u200cهای کیفی چند هستهٔ Cortex-M', 'caption': 'جدول تألیفی ویژگی\u200cها به\u200cجای رتبه\u200cبندی مصرف و سرعت؛ M0/M0+ زیرمجموعهٔ دستور Thumb دارند و نباید همهٔ Cortex-M را Thumb-2 دانست. FPU تک\u200cدقت در طراحی M4 اختیاری است، اما STM32F303CBT6 این دوره آن را دارد؛ این نقشه انتخاب بهترین هسته یا اندازه\u200cگیری کارایی نیست.', 'purpose': 'ویژگی\u200cهای کیفی چند هستهٔ Cortex-M چه چیزی را روشن می\u200cکند؟', 'placement': 'پس از بخش «مرور تاریخی و طیف عملکردی خانواده Cortex-M از M0 تا M7 و اشاره\u200cای به سری\u200cهای نوین M23 و M33»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'STM32F303CB memory, core, pin and peripheral facts'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'Device memory/access architecture, no reproduced layout'}, {'url': 'https://documentation-service.arm.com/static/62053f0a0ca305732a3a5c17', 'version': 'Official Cortex-M4 datasheet', 'scope': 'Core instruction/DSP/FPU options'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'scope': 'Board power,crystals and signal connections'}], 'rights': 'Original new geometry; no official figure copied, no assumed CC license, systemfontnotredistributed', 'source': 'Codex original Pillow drawing based on acceptedAGplan and checked device/board facts', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'QualitativeM0/M0+Thumbsubset,M3Thumb2,M4DSPoptionalSPFPU,M7implementationchoices;F303actualM4singleprecisionFPU/DSP/noDcache;noenergyaxes/optimalM4claim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson01-refresh-figure3.png', 'alt': 'مسیر سادهٔ دسترسی CPU و DMA', 'caption': 'نمودار تألیفی و ساده\u200cشدهٔ هسته، حافظه و گذرگاه\u200cها؛ Flash و SRAM اصلی و پریفرال\u200cها مسیرهای دسترسی دارند، اما CCM این تراشه در دسترس DMA نیست. مسیرهای دقیق I/D و کلاک ADC یا سرعت APB1/APB2 و پهنای باند اندازه\u200cگیری\u200cشده از این شکل نتیجه نمی\u200cشوند.', 'purpose': 'مسیر سادهٔ دسترسی CPU و DMA چه چیزی را روشن می\u200cکند؟', 'placement': 'پس از بخش «شبکه تبادل داده: ماتریس گذرگاه\u200cهای AHB و پل\u200cهای ارتباطی APB1 و APB2»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'STM32F303CB memory, core, pin and peripheral facts'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'Device memory/access architecture, no reproduced layout'}, {'url': 'https://documentation-service.arm.com/static/62053f0a0ca305732a3a5c17', 'version': 'Official Cortex-M4 datasheet', 'scope': 'Core instruction/DSP/FPU options'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'scope': 'Board power,crystals and signal connections'}], 'rights': 'Original new geometry; no official figure copied, no assumed CC license, systemfontnotredistributed', 'source': 'Codex original Pillow drawing based on acceptedAGplan and checked device/board facts', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'CPUFlashSRAMAHBbridgesperipheralsandDMA;CPU-onlyCCM/noDMAroute;noAPB2ADCblanketclock/nofastslowAPB/noI/Dpathassumption/no32bitbandwidthmeasurement.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson01-refresh-figure4.png', 'alt': 'سه ناحیهٔ جداگانهٔ حافظهٔ F303CB', 'caption': 'نمای تألیفی ظرفیت\u200cها و بازه\u200cهای دقیق: Flash برابر 128 KiB، SRAM اصلی 32 KiB و CCM برابر 8 KiB است. مجموع RAM برابر 40 KiB است، اما این دو RAM یک ناحیهٔ پیوسته نیستند؛ نوارها فقط نسبت ظرفیت را نشان می\u200cدهند، نه فاصلهٔ واقعی آدرس\u200cها.', 'purpose': 'سه ناحیهٔ جداگانهٔ حافظهٔ F303CB چه چیزی را روشن می\u200cکند؟', 'placement': 'پس از بخش «محدودیت حیاتی CCM RAM: عدم پشتیبانی از دسترسی مستقیم به حافظه (DMA) و اختصاص به محاسبات سریع CPU»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'STM32F303CB memory, core, pin and peripheral facts'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'Device memory/access architecture, no reproduced layout'}, {'url': 'https://documentation-service.arm.com/static/62053f0a0ca305732a3a5c17', 'version': 'Official Cortex-M4 datasheet', 'scope': 'Core instruction/DSP/FPU options'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'scope': 'Board power,crystals and signal connections'}], 'rights': 'Original new geometry; no official figure copied, no assumed CC license, systemfontnotredistributed', 'source': 'Codex original Pillow drawing based on acceptedAGplan and checked device/board facts', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Flash0x08000000..0801FFFF128KiB;SRAM0x20000000..20007FFF32KiB;CCM0x10000000..10001FFF8KiB,notcontiguous 40K;barsrelativecapacitynotaddressdistance.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson01-refresh-figure5.png', 'alt': 'نقشهٔ عملکردی تغذیه و کریستال\u200cهای برد', 'caption': 'نمودار تألیفی برد GB100ST V2.0: ورودی اسمی 5 V از رگولاتور به 3V3 می\u200cرسد و مسیر آنالوگ VDDA فیلتر دارد؛ کریستال HSE برابر 8 MHz و LSE برابر 32.768 kHz است. نصب کریستال به معنی انتخاب آن در نرم\u200cافزار نیست و تصویر نقشهٔ جانمایی یا مقدار خازن\u200cها نیست.', 'purpose': 'نقشهٔ عملکردی تغذیه و کریستال\u200cهای برد چه چیزی را روشن می\u200cکند؟', 'placement': 'پس از بخش «نوسان\u200cسازها و کلاک سخت\u200cافزاری: کریستال خارجی 8 MHz (HSE) و کریستال زمان\u200cسنجی 32.768 kHz (LSE)»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'STM32F303CB memory, core, pin and peripheral facts'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'Device memory/access architecture, no reproduced layout'}, {'url': 'https://documentation-service.arm.com/static/62053f0a0ca305732a3a5c17', 'version': 'Official Cortex-M4 datasheet', 'scope': 'Core instruction/DSP/FPU options'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'scope': 'Board power,crystals and signal connections'}], 'rights': 'Original new geometry; no official figure copied, no assumed CC license, systemfontnotredistributed', 'source': 'Codex original Pillow drawing based on acceptedAGplan and checked device/board facts', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Functional5V->AMS1117-3V3->VDD/filterVDDA;HSE8 MHz/LSE32.768kHz;noinventcapvalues/physicalpositions/notcrystalselectproof.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson01-refresh-figure6.png', 'alt': 'نام سیگنال\u200cهای LED و کلید و SWD', 'caption': 'نمودار عملکردی تألیفی: PB6 از مسیر درایور NPN، LED کاربر را با High روشن می\u200cکند؛ کلید به PA3 مربوط است و BOOT selector پیش\u200cفرض به GND است. نام SWDIO/PA13 و SWCLK/PA14 و NRST و SWO اختیاری/PB3 باید همراه زمین و مرجع ولتاژ هدف خوانده شود؛ ترتیب هدر یا مقدار مقاومت فرض نشده است.', 'purpose': 'نام سیگنال\u200cهای LED و کلید و SWD چه چیزی را روشن می\u200cکند؟', 'placement': 'پس از بخش «نشانگرها و ورودی\u200cها: درایور ترانزیستوری NPN برای LED کاربر روی پین PB6 و مدار کلید روی پین PA3»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'STM32F303CB memory, core, pin and peripheral facts'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'Device memory/access architecture, no reproduced layout'}, {'url': 'https://documentation-service.arm.com/static/62053f0a0ca305732a3a5c17', 'version': 'Official Cortex-M4 datasheet', 'scope': 'Core instruction/DSP/FPU options'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0', 'scope': 'Board power,crystals and signal connections'}], 'rights': 'Original new geometry; no official figure copied, no assumed CC license, systemfontnotredistributed', 'source': 'Codex original Pillow drawing based on acceptedAGplan and checked device/board facts', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'PB6NPNactivehigh,PA3buttonlogicalnoinventpull/filter/BOOT10k;BOOTSELdefaultGND;SWDIOPA13SWCLKPA14GNDVtargetNRSToptionalPB3SWO,nofourwireorheaderpositionsclaim.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

"""Original educational diagrams; no copied source layouts or measured data."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
ROOT=Path(__file__).parent
N='#17334a';T='#087f8c';O='#a7601b';G='#526778';BG='#f2f6f9';B='#c8d7e0'
def font(n=43,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def text(d,xy,s,n=43,color=N,b=False):d.text(xy,s,font=font(n,b),fill=color)
def start(title,sub,h=1580):
 im=Image.new('RGB',(1200,h),BG);d=ImageDraw.Draw(im);text(d,(45,32),title,49,b=True);text(d,(45,110),sub,31,G);return im,d
def box(d,xy,title,lines=(),color=T):
 x,y,x2,y2=xy;d.rounded_rectangle(xy,20,fill='white',outline=B,width=3);text(d,(x+25,y+20),title,43,color,True)
 for i,s in enumerate(lines):text(d,(x+25,y+85+i*55),s,39)
def arr(d,pts,color=T,w=7):
 d.line(pts,fill=color,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0]);d.polygon([(x,y),(x-24*math.cos(a-.5),y-24*math.sin(a-.5)),(x-24*math.cos(a+.5),y-24*math.sin(a+.5))],fill=color)
def foot(d,h,s):text(d,(45,h-110),s,29,G);text(d,(45,h-65),'Original diagram / model. No board or scope result.',29,G)
def save(im,n,i):
 p=ROOT;im.save(p/f'lesson{n}-figure{i}.png',optimize=True)
def flow(title,sub,items,n,i):
 h=380+len(items)*235;im,d=start(title,sub,h)
 for k,(a,b) in enumerate(items):
  y=190+k*235;box(d,(70,y,1130,y+170),a,b)
  if k<len(items)-1:arr(d,[(600,y+175),(600,y+227)])
 foot(d,h,'Technical basis: exact F3 HAL / CMSIS and official manuals.');save(im,n,i)
#12.1 serial actualbyte0x41 LSB order
im,d=start('One UART byte: 115200 8N1','Ideal logic model, byte 0x41 = ASCII A, LSB first',1480)
bits=[0,1,0,0,0,0,0,1,0,1];labels=['START','D0','D1','D2','D3','D4','D5','D6','D7','STOP'];left=125;bw=96;hi=360;lo=620
p=[(55,hi),(left,hi)]
for k,bit in enumerate(bits):
 x=left+k*bw;p.extend([(x,hi if bit else lo),(x+bw,hi if bit else lo)]);d.line([(x,250),(x,720)],fill=B,width=2);text(d,(x+20,770),str(bit),44,b=True);text(d,(x+5,860),labels[k],27,T,True)
p.extend([(left+10*bw,hi),(1140,hi)]);d.line(p,fill=T,width=7);text(d,(55,300),'1',44);text(d,(55,600),'0',44)
text(d,(880,200),'Time ->',39,b=True)
text(d,(70,1000),'1 bit = 1 /115200 = 8.68056us',47,b=True)
text(d,(70,1090),'10 bits = 86.8056us per byte on the wire',44)
text(d,(70,1180),'No parity; one stop bit; idle line is High.',43)
foot(d,1480,'Frame duration excludes software and inter-frame gaps.');save(im,12,1)
#12.2 wiring dualdirection noVCC
im,d=start('Cross TX and RX; share ground','Logical connections | Use verified 3.3V USB-TTL adapter',1800)
box(d,(70,210,1130,520),'GB100ST board (separate verified supply)',['PA9 / USART1_TX / AF7 / physical30','PA10 / USART1_RX / AF7 / physical31'])
for x in [260,620,975]:d.ellipse((x-14,505,x+14,533),fill=N)
arr(d,[(260,535),(260,1000)],T);arr(d,[(620,1000),(620,535)],O);d.line([(975,535),(975,1000)],fill=N,width=8)
text(d,(85,700),'TX -> RX',43,T,True);text(d,(450,800),'RX <- TX',43,O,True);text(d,(860,700),'GND',43,b=True)
box(d,(70,1020,1130,1300),'USB-TTL adapter -> computer USB',['RX                  TX                  GND','Check logic level, not only VCC jumper label'])
d.line([(180,1440),(1020,1440)],fill=O,width=7);text(d,(180,1360),'Adapter VCC: leave disconnected in this scheme',39,O,True)
text(d,(75,1510),'No RS232 voltage levels; avoid back-powering.',43,b=True)
foot(d,1800,'Header signal names are not header position numbers.');save(im,12,2)
#12.3 clocktoBRR actualclear
flow('From the clock mux to USART baud','Actual project: USART1 source PCLK2, oversampling16',[
 ('HSE8 /1 x9 -> SYSCLK72MHz',['AHB/1 -> APB2/1 -> PCLK2 = 72MHz']),('USART1 clock mux: choose PCLK2',['APB2 location alone does not select the kernel clock']),('USARTDIV = 72000000 /115200 = 625',['OVER8 = 0 -> BRR = 625 = 0x0271']),('Nominal baud = 72000000 /625',['115200 baud; rounding error = 0%']),('OVER8 = 1 uses a different encoding',['Divider1250 -> BRR0x04E1; bit3 = 0','Comparison only; delivered project uses OVER8 = 0'])],12,3)
#12.4 blocking safe branchflow
im,d=start('Echo only a successfully received byte','Blocking API example | Actual timeout/error path checked in HAL',1740)
box(d,(75,210,1125,425),'HAL_UART_Receive(..., 1, finite timeout)',['No data yet: CPU polls until byte or timeout'])
for x,y in [(290,560),(880,560)]:arr(d,[(600,440),(600,485),(x,485),(x,y)])
box(d,(65,580,565,860),'HAL_OK',['Byte is valid','Transmit the same byte','Check transmit result'])
box(d,(635,580,1135,860),'Other status',['Do not echo byte','Record status/error','Recover as code defines'],O)
arr(d,[(315,875),(315,1020),(600,1020),(600,1100)])
arr(d,[(885,875),(885,1020),(600,1020)])
box(d,(75,1120,1125,1390),'Return to receive loop',['HAL_TIMEOUT can also accompany ORE in this HAL','Read ErrorCode; timeout is not always just silence','Per-byte blocking echo can lose continuous bursts'])
foot(d,1740,'This is not DMA or IRQ-driven reception; see next UART lesson.');save(im,12,4)
#12.5 printfroute
flow('How printf reaches PA9','Application-level retargeting | No output inside ISR',[
 ('printf formats application data',['stdout buffering affects when bytes leave']),('Newlib output path reaches _write',['Provide one correctly linked implementation']),('User _write validates fd / length',['Return byte count or -1 with errno on failure']),('HAL_UART_Transmit with finite timeout',['Poll TXE while sending; wait for TC completion']),('USART1_TDR -> PA9 AF7 -> adapter RX',['Blocking output pauses the main receive loop'])],12,5)
#12.6 actualsequencenotfakeGUI
im,d=start('Predict the echo before connecting','Expected sequence, not an actual terminal screenshot',1680)
text(d,(80,210),'Computer / terminal',46,T,True);text(d,(755,210),'STM32 / UART',46,O,True)
for x in [240,940]:d.line([(x,300),(x,1270)],fill=B,width=5)
for y,direction,label in [(430,1,"Type A -> send 0x41"),(720,-1,'HAL_OK -> echo same 0x41')]:
 if direction==1:arr(d,[(240,y),(940,y)],T)
 else:arr(d,[(940,y),(240,y)],O)
 text(d,(320,y-90),label,39,b=True)
box(d,(65,980,680,1180),'Terminal displays A once',['Local display, not another frame'])
text(d,(75,1330),'115200 /8 data /no parity /1 stop /no flow control',39,b=True)
text(d,(75,1410),'Local echo OFF; start with slowly typed characters.',41)
foot(d,1680,'No proof of continuous-burst losslessness from a clean build.');save(im,12,6)

print("Created6 original lesson figures.")

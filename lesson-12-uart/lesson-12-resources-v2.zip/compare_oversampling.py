"""Arithmetic counterpart of pinned F3 HAL divider packing, not an OVER8 firmware test."""
from pathlib import Path
import json

clock_hz,baud=72_000_000,115200
div16=(clock_hz+baud//2)//baud
div8=(2*clock_hz+baud//2)//baud
brr8=(div8 & 0xfff0) | ((div8 & 0xf)>>1)
assert div16==625 and div8==1250 and brr8==1249
effective_div8=(brr8 & 0xfff0) | ((brr8 & 7)<<1)
assert effective_div8==div8
assert clock_hz/div16==2*clock_hz/effective_div8==baud
result={
 'scope':'Nominal arithmetic only. Actual delivered firmware uses oversampling16; no oversampling8 project/board experiment is claimed.',
 'source':'stm32f3xx_hal_uart.h UART_DIV_SAMPLING8 and stm32f3xx_hal_uart.c UART_SetConfig packing, pinned HAL953955afe65f89e60e556bbcdba752597f5da65d',
 'kernel_clock_hz':clock_hz,'requested_baud':baud,
 'OVER8_0':{'USARTDIV':div16,'BRR_decimal':div16,'BRR_hex':hex(div16)},
 'OVER8_1_comparison_only':{'USARTDIV':div8,'BRR_decimal':brr8,'BRR_hex':hex(brr8),'BRR_bit3_zero':not bool(brr8&8)},
 'nominal_baud_both':baud,
 'warning':'BRR packing differs with oversampling. Do not change OVER8 while retaining the oversampling16 BRR value.'
}
(Path(__file__).parent/'oversampling-comparison.json').write_text(json.dumps(result,indent=2)+'\n','utf8')
print(json.dumps(result,indent=2))

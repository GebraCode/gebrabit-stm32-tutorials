"""Nominal baud/frame arithmetic and real offline Newlib symbol inspection."""
from pathlib import Path
import json,struct,zipfile
def baud16(clock,baud):
    brr=(clock+baud//2)//baud
    actual=clock/brr
    return dict(clock_hz=clock,requested_baud=baud,BRR_decimal=brr,BRR_hex=hex(brr),USARTDIV_ideal_F3_OVER8_0=clock/baud,mantissa=brr>>4,fraction=brr&15,bit_decomposition_note='mantissa/fraction keys are legacy bit decomposition only, not F3 USARTDIV notation',nominal_baud=actual,quantization_error_percent=(actual-baud)/baud*100)
b=baud16(72000000,115200);assert b['BRR_decimal']==625 and b['BRR_hex']=='0x271' and b['mantissa']==39 and b['fraction']==1 and b['quantization_error_percent']==0
assert baud16(72000000,9600)['BRR_decimal']==7500
assert baud16(8000000,115200)['BRR_decimal']==69
frame=[0]+[(0x55>>bit)&1 for bit in range(8)]+[1]
assert frame==[0,1,0,1,0,1,0,1,0,1] and len(frame)==10
bit_us=1e6/115200;frame_us=10*bit_us
assert abs(bit_us-8.680555555555555)<1e-10 and abs(frame_us-86.80555555555556)<1e-10
def classify(status,error):
    if status=='HAL_OK' and error==0:return 'echo'
    if status=='HAL_TIMEOUT' and error==0:return 'idle timeout'
    return 'failure and AbortReceive'
assert classify('HAL_TIMEOUT',8)=='failure and AbortReceive'
assert classify('HAL_TIMEOUT',0)=='idle timeout'
assert classify('HAL_OK',8)=='failure and AbortReceive'
assert classify('HAL_OK',0)=='echo'
def write_result(success_before_failure,total):return total if success_before_failure is None else -1 if success_before_failure==0 else success_before_failure
assert write_result(0,5)==-1 and write_result(2,5)==2 and write_result(None,5)==5
def symbol(data,wanted):
    h=struct.unpack_from('<16sHHIIIIIHHHHHH',data);assert h[0][:6]==b'\x7fELF\x01\x01' and h[2]==40
    sections=[struct.unpack_from('<IIIIIIIIII',data,h[6]+i*h[11]) for i in range(h[12])]
    result={}
    for s in sections:
        if s[1]!=2:continue
        st=sections[s[6]];strings=data[st[4]:st[4]+st[5]]
        for off in range(s[4],s[4]+s[5],s[9]):
            n,value,size,info,other,index=struct.unpack_from('<IIIBBH',data,off);name=strings[n:strings.find(b'\0',n)].decode()
            if name in wanted:result[name]=dict(address=value,size=size,binding=info>>4)
    assert '_write' in result and result['_write']['binding']==1 and 'printf' in result
    return result
root=Path(__file__).parent
with zipfile.ZipFile(root/'lesson-12-build-artifacts-v2.zip') as z:elf={n:symbol(z.read(n),{'_write','printf','_printf_r','HAL_UART_Receive','HAL_UART_Transmit','HAL_UART_AbortReceive'}) for n in z.namelist() if n.endswith('.elf')}
result={'scope':'Nominal configuration calculations and actual offline ELF metadata; not terminal/hardware execution','oversampling':16,'format':'8N1','baud':b,'bit_period_us':bit_us,'frame_period_us':frame_us,'theoretical_one_direction_bytes_per_second':11520,'ideal_frame_byte_0x55_LSB_first':frame,'counterexample_HSI8':baud16(8000000,115200),'same_BRR_wrong_clock36MHz_actual_baud':36000000/625,'HAL_receive_outer_timeout_can_mean_overrun':True,'timeout_requires_progressing_HAL_tick':True,'checks_passed':['BRR625 exact','BRR bit decomposition','9600 baud','HSI8 quantization counterexample','LSB-first8N1 frame','bit/frame periods','status and error classification','partial stdio failure result','strong _write and linked printf in actual ELF'],'ELF':elf}
(root/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

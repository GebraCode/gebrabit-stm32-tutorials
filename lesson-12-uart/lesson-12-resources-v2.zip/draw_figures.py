"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=12
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Read one UART byte as ten serial bits','Illustrative 0xA5 frame at nominal 115200 8N1, not a captured byte')
 tx(d,75,300,'Start + 8 data bits + 1 stop bit; no parity',46,TEAL,True)
 tx(d,75,390,'Nominal 3.3 V logic; idle HIGH; data LSB first',42)
 bits=[0,1,0,1,0,0,1,0,1,1];labels=['Start']+[f'D{i}'for i in range(8)]+['Stop'];pts=[(65,650),(100,650)]
 for k,(v,label)in enumerate(zip(bits,labels)):
  x=100+k*100;y=650 if v else 850
  pts.extend([(x,pts[-1][1]),(x,y),(x+100,y)]);tx(d,x+8,485,label,38,TEAL,True);tx(d,x+35,560,str(v),42)
  dashed(d,x,620,x,910,LINE)
 pts.append((1135,650));d.line(pts,fill=TEAL,width=7)
 arrow(d,[(100,1050),(200,1050)],ORANGE);tx(d,75,1130,'One bit: 8.6806 us',46,ORANGE,True)
 arrow(d,[(100,1320),(1100,1320)])
 tx(d,75,1420,'One 8N1 byte: 10 bits = 86.8056 us nominal',46,TEAL,True)
 tx(d,75,1550,'Both endpoints must agree on baud and frame format.',42)
 foot(d,'Illustration is ideal logic, not measured voltage or timing.');save(im,1)
def figure2():
 im,d=begin('Use the STM32F3 divider notation','Actual firmware uses oversampling 16; oversampling 8 is arithmetic only')
 panel(d,75,300,1050,330,'OVER8=0: oversampling 16',['USARTDIV=fCK/baud=72000000/115200=625','BRR=625=0x0271','Nominal divider-quantization error: 0%'])
 arrow(d,[(600,650),(600,780)])
 panel(d,75,800,1050,440,'Optional OVER8=1 calculation',['USARTDIV=2xfCK/baud=1250=0x04E2','Pack the low field for 8x sampling; bit 3 stays 0.','BRR=0x04E1; decoded divider=1250','Same nominal 115200 baud; not a second firmware build'])
 panel(d,75,1400,1050,200,'Quantization is not link accuracy',['Oscillator mismatch and signal conditions still matter.'])
 foot(d,'Legacy mantissa decomposition is not the F3 USARTDIV label.');save(im,2)
def figure3():
 im,d=begin('Cross data signals and share ground','Logical 3.3 V UART, not RS-232; no board-header positions are assumed')
 tx(d,75,300,'USB-UART adapter',46,TEAL,True);tx(d,760,300,'Board USART1',46,TEAL,True)
 tx(d,75,520,'RXD',46,TEAL,True);tx(d,760,520,'PA9 / TX',46,TEAL,True);arrow(d,[(730,560),(350,560)])
 tx(d,75,780,'TXD',46,TEAL,True);tx(d,760,780,'PA10 / RX',46,TEAL,True);arrow(d,[(350,820),(730,820)])
 tx(d,75,1040,'GND',46,TEAL,True);tx(d,760,1040,'GND',46,TEAL,True);d.line((350,1080,730,1080),fill=INK,width=6)
 panel(d,75,1280,1050,310,'Power is a separate design decision',['Do not tie unknown supply outputs together.','Adapter logic must be compatible with target 3.3 V.','Generic ST-LINK does not imply virtual COM.'])
 foot(d,'PA9/PA10 package 30/31 are not header-pin numbers.');save(im,3)
def figure4():
 im,d=begin('Inspect status and error evidence together','Actual blocking receive path; outer HAL_TIMEOUT can contain an ORE error')
 panel(d,75,300,1050,210,'HAL_UART_Receive: 1 byte, 20 ms budget',['Snapshot return status, ErrorCode and current error flags'])
 arrow(d,[(600,530),(600,630)])
 panel(d,75,650,1050,210,'HAL_OK and no recorded/current errors?',['Only this path echoes the byte with a checked transmit.'])
 arrow(d,[(600,880),(600,980)],ORANGE)
 panel(d,75,1000,1050,210,'HAL_TIMEOUT and no error evidence?',['Count idle; do not confuse timeout alone with clean idle.'])
 panel(d,75,1360,1050,240,'Other / error path',['Record errors; AbortReceive and flush stale RX.','Discard uncertain data; resync can lose bytes.'])
 foot(d,'HAL wait-helper errors can become outer HAL_TIMEOUT.');save(im,4)
def figure5():
 im,d=begin('Follow printf into the actual strong _write','Each byte gets its own checked HAL call and 20 ms configured budget')
 stages=[('printf / Newlib formatting','Produces a sequence of characters'),('Strong _write in user code','Overrides the generated weak syscall'),('Loop over the characters','HAL_UART_Transmit: 1 byte at a time'),('USART1 TDR -> TX pin','Return partial count or -1 on failure; set errno')]
 for k,(a,b)in enumerate(stages):
  y=300+k*300;panel(d,75,y,1050,215,a,[b])
  if k<3:arrow(d,[(600,y+230),(600,y+290)])
 tx(d,75,1560,'Longer text can block longer; no global 20 ms printf budget.',40,ORANGE)
 foot(d,'Main context only; no ISR or concurrent-writer guarantee.');save(im,5)
def figure6():
 im,d=begin('Echo only an accepted byte','Expected source behavior; no terminal screenshot or CPU-usage measurement')
 panel(d,75,300,1050,210,'Terminal: 115200 / 8N1, local echo OFF',['Transmit bytes to the board; opening can precede reset.'])
 arrow(d,[(600,530),(600,620)])
 panel(d,75,640,1050,230,'Receive, inspect errors, then transmit',['One valid byte returns unchanged.','No CRLF conversion or line editing is implemented.'])
 arrow(d,[(600,890),(600,980)])
 panel(d,75,1000,1050,220,'Service gaps occur while main does other work',['TX / printf / processing can delay the next receive call.'])
 panel(d,75,1380,1050,220,'Define burst test conditions',['Full duplex does not make this loop lossless.','Record errors and accepted bytes in a real test.'])
 foot(d,'Interrupts can still run while main is blocked in a polling call.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson12-refresh-figure1.png', 'alt': 'مدل فریم UART با قالب 8N1', 'caption': 'نمودار تألیفی و ایدئال بایت نمونهٔ 0xA5 در 115200 و 8N1: Start، 8 بیت داده از LSB و یک Stop در مجموع 10 بیت با زمان اسمی 86.8056 us می\u200cسازند. این بایت نمونهٔ آموزشی است و از ترمینال یا برد ضبط نشده؛ زمان و ولتاژ نمودار مقدار اندازه\u200cگیری\u200cشده نیستند.', 'purpose': 'مدل فریم UART با قالب 8N1', 'placement': '### محاسبه زمان\u200cبندی بیتی و زمان ارسال یک فریم کامل', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; F3USARTnotation', 'scope': 'Frame/divider/oversampling/registersemantics'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'USART1PA9PA10AF7 andelectricalscope'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a;actualfreshlesson12v2source', 'scope': 'Outerstatus/errorflags/AbortReceive,actual_writeperbytecalls'}, {'url': 'local:compare_oversampling.py and verify_model.py', 'version': 'Fresh3optionaloversamplingassertions plus9modelgroups', 'scope': 'Arithmeticmodels only, nohardwaretrace'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'IllustrativeA5bits[1,0,1,0,0,1,0,1];8N1nominal10bits/8.6806usbit, notcapturedbyte orsource-replayclaim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson12-refresh-figure2.png', 'alt': 'محاسبهٔ BRR با نام\u200cگذاری STM32F3', 'caption': 'نمودار محاسباتی تألیفی: در حالت واقعی oversampling 16، USARTDIV برابر 625 و BRR برابر 0x0271 است. مقایسهٔ اختیاری oversampling 8 فقط حساب بسته\u200cبندی 1250 به 0x04E1 با بیت 3 صفر را نشان می\u200cدهد؛ فریم\u200cور دوم ساخته نشده است. خطای کوانتیزهٔ اسمی 0 درصد به معنی خطای صفر لینک یا نوسان\u200cساز نیست.', 'purpose': 'محاسبهٔ BRR با نام\u200cگذاری STM32F3', 'placement': '### تفاوت Oversampling به میزان 16 و 8 و فرمول محاسبه ثبات USART_BRR', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; F3USARTnotation', 'scope': 'Frame/divider/oversampling/registersemantics'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'USART1PA9PA10AF7 andelectricalscope'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a;actualfreshlesson12v2source', 'scope': 'Outerstatus/errorflags/AbortReceive,actual_writeperbytecalls'}, {'url': 'local:compare_oversampling.py and verify_model.py', 'version': 'Fresh3optionaloversamplingassertions plus9modelgroups', 'scope': 'Arithmeticmodels only, nohardwaretrace'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'F3USARTDIV625notlegacymantissa39;optionalOVER8raw1250packed0x4E1/recovered1250, noactualOVER8variant.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson12-refresh-figure3.png', 'alt': 'اتصال منطقی مبدل سریال و USART1', 'caption': 'نمودار تألیفی اتصال TX و RX ضربدری و زمین مشترک با منطق 3.3 V. تغذیهٔ برد تصمیم جداست و خروجی\u200cهای ناشناختهٔ تغذیه به هم متصل نمی\u200cشوند. شمارهٔ پکیج PA9/PA10 برابر 30/31 شمارهٔ هدر نیست؛ ST-LINK عمومی نیز virtual COM فرض نشده است.', 'purpose': 'اتصال منطقی مبدل سریال و USART1', 'placement': '### الزامات اتصال ضربدری، سطح ولتاژ 3.3V و پیشگیری از تغذیه ناخواسته (Back-powering)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; F3USARTnotation', 'scope': 'Frame/divider/oversampling/registersemantics'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'USART1PA9PA10AF7 andelectricalscope'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a;actualfreshlesson12v2source', 'scope': 'Outerstatus/errorflags/AbortReceive,actual_writeperbytecalls'}, {'url': 'local:compare_oversampling.py and verify_model.py', 'version': 'Fresh3optionaloversamplingassertions plus9modelgroups', 'scope': 'Arithmeticmodels only, nohardwaretrace'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'LogicalPA9TX->adapterRX,adapterTX->PA10RX,GND;3V3notRS232/5Vlogic,noassumedadapterpower/header.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson12-refresh-figure4.png', 'alt': 'تصمیم\u200cگیری با وضعیت و شاهد خطای دریافت', 'caption': 'روندنمای تألیفی مسیر واقعی دریافت یک بایت با بودجهٔ 20 ms: فقط HAL_OK بدون ErrorCode و پرچم جاری خطا پژواک می\u200cشود؛ timeout بدون شاهد خطا idle است و بقیهٔ حالت\u200cها ثبت و abort و flush و کنارگذاشتن داده دارند. در HAL دقیق پروژه، خطای helper از جمله ORE می\u200cتواند در خروجی تابع به HAL_TIMEOUT تبدیل شود.', 'purpose': 'تصمیم\u200cگیری با وضعیت و شاهد خطای دریافت', 'placement': '### تحلیل تابع HAL_UART_Receive با پارامتر مهلت زمانی (Timeout)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; F3USARTnotation', 'scope': 'Frame/divider/oversampling/registersemantics'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'USART1PA9PA10AF7 andelectricalscope'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a;actualfreshlesson12v2source', 'scope': 'Outerstatus/errorflags/AbortReceive,actual_writeperbytecalls'}, {'url': 'local:compare_oversampling.py and verify_model.py', 'version': 'Fresh3optionaloversamplingassertions plus9modelgroups', 'scope': 'Arithmeticmodels only, nohardwaretrace'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualouterHALTIMEOUTcanORE; snapshotstatus+ErrorCode+currentOREFENEPE, no simplisticHALERRORbranch. AbortclearsICR/RQRnotoldSRDR, recoverydataloss.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson12-refresh-figure5.png', 'alt': 'مسیر printf تا _write واقعی و ارسال تک\u200cبایتی', 'caption': 'نمودار تألیفی اتصال printf به _write قوی main و ارسال HAL تک\u200cبایتی. هر بایت فراخوانی بررسی\u200cشده با بودجهٔ 20 ms دارد؛ کل متن بودجهٔ کلی 20 ms ندارد. خطا می\u200cتواند بازگشت جزئی یا -1 و errno داشته باشد؛ استفاده در main است و هم\u200cزمانی و ISR تضمین نشده است.', 'purpose': 'مسیر printf تا _write واقعی و ارسال تک\u200cبایتی', 'placement': '### معماری Newlib و پیاده\u200cسازی تابع _write جهت اتصال به درایور HAL', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; F3USARTnotation', 'scope': 'Frame/divider/oversampling/registersemantics'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'USART1PA9PA10AF7 andelectricalscope'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a;actualfreshlesson12v2source', 'scope': 'Outerstatus/errorflags/AbortReceive,actual_writeperbytecalls'}, {'url': 'local:compare_oversampling.py and verify_model.py', 'version': 'Fresh3optionaloversamplingassertions plus9modelgroups', 'scope': 'Arithmeticmodels only, nohardwaretrace'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Strong_writeoverrideweak;actualperbyte20msHALcalls,partialcount/error,notwholelenbuffer/globaldeadline.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson12-refresh-figure6.png', 'alt': 'رفتار مورد انتظار پژواک و فاصله\u200cهای سرویس\u200cدهی', 'caption': 'روندنمای تألیفی تنظیم ترمینال و پذیرش و بازفرستادن بایت سالم. برنامه تبدیل CRLF و ویرایش خط ندارد؛ TX و printf و پردازش می\u200cتواند رسیدگی به RX را عقب بیندازد و full duplex سخت\u200cافزار دریافت بی\u200cاتلاف را تضمین نمی\u200cکند. نتیجهٔ ترمینال و درصد مصرف CPU اندازه\u200cگیری نشده است.', 'purpose': 'رفتار مورد انتظار پژواک و فاصله\u200cهای سرویس\u200cدهی', 'placement': '### بررسی گلوگاه\u200cهای روش Polling مسدودکننده در ترافیک پیوسته و لزوم گذار به وقفه', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; F3USARTnotation', 'scope': 'Frame/divider/oversampling/registersemantics'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'USART1PA9PA10AF7 andelectricalscope'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a;actualfreshlesson12v2source', 'scope': 'Outerstatus/errorflags/AbortReceive,actual_writeperbytecalls'}, {'url': 'local:compare_oversampling.py and verify_model.py', 'version': 'Fresh3optionaloversamplingassertions plus9modelgroups', 'scope': 'Arithmeticmodels only, nohardwaretrace'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Expectedflow/error-awareperbyteecho,nofakecapture/100%CPUbar. Mainblockingdoesnotdisableinterrupts;declaredburstconditionsneeded.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

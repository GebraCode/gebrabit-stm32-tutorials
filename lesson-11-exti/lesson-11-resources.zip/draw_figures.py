"""Original educational diagrams; no copied source layouts or measured data."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
ROOT=Path(__file__).parent
N='#17334a';T='#087f8c';O='#a7601b';G='#526778';BG='#f2f6f9';B='#c8d7e0'
def font(n=43,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def text(d,xy,s,n=43,color=N,b=False):d.text(xy,s,font=font(n,b),fill=color)
def start(title,sub,h=1580):
 im=Image.new('RGB',(1200,h),BG);d=ImageDraw.Draw(im);text(d,(45,32),title,49,b=True);text(d,(45,110),sub,31,G);return im,d
def box(d,xy,title,lines=(),color=T):
 x,y,x2,y2=xy;d.rounded_rectangle(xy,20,fill='white',outline=B,width=3);text(d,(x+25,y+20),title,43,color,True)
 for i,s in enumerate(lines):text(d,(x+25,y+85+i*55),s,39)
def arr(d,pts,color=T,w=7):
 d.line(pts,fill=color,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0]);d.polygon([(x,y),(x-24*math.cos(a-.5),y-24*math.sin(a-.5)),(x-24*math.cos(a+.5),y-24*math.sin(a+.5))],fill=color)
def foot(d,h,s):text(d,(45,h-110),s,29,G);text(d,(45,h-65),'Original diagram / model. No board or scope result.',29,G)
def save(im,n,i):
 p=ROOT;im.save(p/f'lesson{n}-figure{i}.png',optimize=True)
def flow(title,sub,items,n,i):
 h=380+len(items)*235;im,d=start(title,sub,h)
 for k,(a,b) in enumerate(items):
  y=190+k*235;box(d,(70,y,1130,y+170),a,b)
  if k<len(items)-1:arr(d,[(600,y+175),(600,y+227)])
 foot(d,h,'Technical basis: exact F3 HAL / CMSIS and official manuals.');save(im,n,i)
# 11.1 real board button circuit
im,d=start('The PA3 button already has a pull-up','Original circuit explanation | GB100ST V2.0',1720)
text(d,(430,200),'3.3V',49,T,True);d.line([(540,280),(540,340)],fill=N,width=7)
d.rectangle((485,340,595,560),outline=N,width=6);text(d,(660,405),'R2 = 10k',47,b=True);d.line([(540,560),(540,700),(1040,700)],fill=N,width=7)
d.ellipse((526,686,554,714),fill=N);text(d,(690,620),'R17 = 0 ohm -> PA3',38,T,True);text(d,(685,760),'LQFP48 pin13',39)
d.line([(540,700),(240,700),(240,900)],fill=N,width=7);d.line([(190,900),(290,900)],fill=N,width=7);d.line([(190,945),(290,945)],fill=N,width=7);d.line([(240,945),(240,1160)],fill=N,width=7);text(d,(650,1170),'C2 = 100nF',42,b=True)
d.line([(540,700),(540,910)],fill=N,width=7);d.ellipse((526,900,554,928),fill='white',outline=N,width=4);d.line([(540,930),(620,1030)],fill=N,width=7);d.line([(540,1070),(540,1160)],fill=N,width=7);text(d,(700,970),'USER button',42,b=True)
for x in [240,540]:
 d.line([(x,1160),(x,1200)],fill=N,width=6)
 for j,w in enumerate([70,48,24]):d.line([(x-w/2,1200+j*18),(x+w/2,1200+j*18)],fill=N,width=5)
text(d,(75,1340),'Released = High; pressed = Low; GPIO_NOPULL.',43,b=True)
text(d,(75,1420),'Nominal R xC = 1ms; not a debounce guarantee.',41)
foot(d,1720,'Basis: board V2.0 R2/C2/R17 and DS9118.');save(im,11,1)
# 11.2 mux actual bonded pins
im,d=start('One port source per EXTI line','Available example pins on this LQFP48 package',1580)
box(d,(65,240,440,430),'PA3',['Selected portA'],T);box(d,(65,750,440,940),'PB3',['Not selected'],O)
d.polygon([(590,370),(830,470),(830,880),(590,980)],fill='white',outline=N,width=5)
arr(d,[(440,330),(590,510)]);arr(d,[(440,845),(590,845)],O)
arr(d,[(620,510),(805,660)]);d.line([(545,800),(575,830)],fill=O,width=7);d.line([(575,800),(545,830)],fill=O,width=7)
arr(d,[(835,665),(1110,665)]);text(d,(890,565),'EXTI3',47,T,True)
text(d,(75,1100),'SYSCFG_EXTICR1: EXTI3 field selects portA.',42,b=True)
text(d,(75,1190),'PA3 and PB3 cannot both feed EXTI3 at once.',42)
text(d,(75,1280),'RCC SYSCFGEN enables the configuration block.',40)
foot(d,1580,'Other generic port options do not imply bonded pins here.');save(im,11,2)
# 11.3 logical edges
im,d=start('Active-Low button: two useful edges','Ideal logic model; no voltage or bounce measurement',1530)
pts=[(120,380),(370,380),(370,650),(800,650),(800,380),(1100,380)];d.line(pts,fill=T,width=8)
text(d,(50,350),'1',45);text(d,(50,620),'0',45);arr(d,[(370,735),(370,660)],O);arr(d,[(800,735),(800,395)],T)
text(d,(160,790),'PRESS / Falling',42,O,True);text(d,(690,790),'RELEASE / Rising',42,T,True)
for k,(a,b) in enumerate([('FTSR bit3 = 1','Falling edge detector'),('RTSR bit3 = 1','Rising edge detector'),('Both bits = 1','Both edges; chosen in this project')]):
 y=940+k*115;text(d,(70,y),a,43,b=True);text(d,(520,y),b,38)
foot(d,1530,'An edge sets a pending bit; this is not a held-level interrupt.');save(im,11,3)
#11.4 mapping exact vectors
im,d=start('EXTI lines and shared IRQ vectors','F303xC device names | Software checks individual pending bits',1600)
for k,(a,b) in enumerate([('EXTI0','EXTI0_IRQn'),('EXTI1','EXTI1_IRQn'),('EXTI2','EXTI2_TSC_IRQn'),('EXTI3','EXTI3_IRQn'),('EXTI4','EXTI4_IRQn'),('EXTI5..9','EXTI9_5_IRQn'),('EXTI10..15','EXTI15_10_IRQn')]):
 y=230+k*145;box(d,(60,y,440,y+105),a);arr(d,[(460,y+52),(650,y+52)]);text(d,(680,y+25),b,42,T,True)
text(d,(75,1345),'Shared vector: dispatch every configured EXTI line.',41,b=True)
foot(d,1600,'Basis: exact stm32f303xc.h IRQn_Type and startup table.');save(im,11,4)
#11.5 actual HAL pipeline
flow('From a PA3 edge to the application','Actual F3 HAL order: clear peripheral flag before callback',[
 ('PA3 edge -> EXTI_PR bit3 = 1',['IMR bit3 permits IRQ request']),('NVIC -> EXTI3_IRQHandler',['Priority and masks decide exception entry']),('HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_3)',['Checks pending; writes1 to EXTI_PR to clear']),('HAL_GPIO_EXTI_Callback(GPIO_PIN_3)',['Short ISR: count / mark event, then return']),('Main loop validates stable level',['20ms debounce; accepted press toggles PB6'])],11,5)
#11.6 debounce expected levels
im,d=start('Stable time is different from edge count','Synthetic input model | 20ms qualification, no board capture',1710)
left,right=170,1100
def xx(t):return left+t/80*(right-left)
for t in range(0,81,20):
 x=xx(t);d.line([(x,300),(x,1100)],fill=B,width=2);text(d,(x-20,1140),str(t),37)
text(d,(75,190),'Raw logic (model)',44,T,True)
events=[(0,1),(5,0),(7,1),(9,0),(40,1),(43,0),(46,1),(80,1)]
p=[];last=1
for t,v in events:p.extend([(xx(t),360 if last else 540),(xx(t),360 if v else 540)]);last=v
d.line(p,fill=T,width=7);text(d,(75,635),'Debounced stable state',44,O,True)
stable=[(0,1),(29,0),(66,1),(80,1)];p=[];last=1
for t,v in stable:p.extend([(xx(t),800 if last else 980),(xx(t),800 if v else 980)]);last=v
d.line(p,fill=O,width=7)
for a,b,y in [(9,29,585),(46,66,1030)]:
 d.line([(xx(a),y),(xx(b),y)],fill=N,width=4);text(d,(xx(a),y+20),'20ms',39,b=True)
text(d,(910,1220),'Time (ms)',40,b=True)
text(d,(75,1330),'One accepted press at t29; release at t66.',43,b=True)
text(d,(75,1410),'IRQ callbacks may merge events: not a bounce counter.',39)
foot(d,1710,'Assumption: loop samples fast enough to see modeled transitions.');save(im,11,6)

print("Created6 original lesson figures.")

"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=11
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Select one port for each numbered EXTI line','PA3 and PB3 are two possible sources of line 3, not two independent lines')
 panel(d,75,300,475,180,'PA3: selected',['GPIOA in this project'])
 panel(d,650,300,475,180,'PB3: alternative',['Not selected for line 3'])
 arrow(d,[(300,500),(300,650),(500,650)])
 dashed(d,900,500,900,650,MUTED);dashed(d,900,650,700,650,MUTED)
 panel(d,500,575,200,180,'MUX',())
 arrow(d,[(600,770),(600,900)])
 panel(d,75,920,1050,190,'EXTI3 -> edge detection -> EXTI3_IRQn',['One port selection for the numbered input line'])
 tx(d,75,1220,'SYSCFG EXTICR1: four port-selection fields',44,TEAL,True)
 for k,(a,b)in enumerate([('EXTI3','15:12'),('EXTI2','11:8'),('EXTI1','7:4'),('EXTI0','3:0')]):
  x=75+k*270;panel(d,x,1330,245,210,a,['Bits '+b],TEAL if k==0 else MUTED)
 foot(d,'Only bonded PA3 / PB3 examples; no header positions assumed.');save(im,1)
def figure2():
 im,d=begin('Turn a selected edge into one pending flag','Functional model; not a copy of internal gates or a debounce filter')
 panel(d,75,300,1050,170,'Selected GPIO line',['Actual PA3 configuration: rising and falling edges'])
 arrow(d,[(600,490),(600,575),(300,575),(300,650)])
 arrow(d,[(600,575),(900,575),(900,650)])
 panel(d,65,670,470,220,'Rising edge enable',['RTSR bit'])
 panel(d,665,670,470,220,'Falling edge enable',['FTSR bit'])
 arrow(d,[(300,910),(300,1020),(600,1020),(600,1080)])
 arrow(d,[(900,910),(900,1020),(600,1020)])
 panel(d,75,1100,1050,190,'PR pending bit',['Either selected edge can set the same flag.'])
 arrow(d,[(600,1310),(600,1400)])
 panel(d,75,1420,1050,180,'IMR + NVIC eligibility -> IRQ service',['Write 1 to the selected PR bit to clear it (W1C).'])
 foot(d,'The HAL handler clears PR before invoking the callback.');save(im,2)
def figure3():
 im,d=begin('Map GPIO EXTI lines to IRQ groups','This project enables only EXTI3; the rest is an architecture map')
 rows=[('Line 0','EXTI0_IRQn'),('Line 1','EXTI1_IRQn'),('Line 2','EXTI2_TSC_IRQn'),('Line 3','EXTI3_IRQn'),('Line 4','EXTI4_IRQn')]
 for k,(a,b)in enumerate(rows):
  y=300+k*150;tx(d,75,y,a,46,TEAL,True);arrow(d,[(335,y+40),(545,y+40)]);tx(d,590,y,b,44,TEAL,True)
 panel(d,75,1140,390,170,'Lines 5..9',());arrow(d,[(480,1220),(570,1220)]);panel(d,590,1140,535,170,'EXTI9_5_IRQn',())
 panel(d,75,1410,390,170,'Lines 10..15',());arrow(d,[(480,1490),(570,1490)]);panel(d,590,1410,535,170,'EXTI15_10_IRQn',())
 foot(d,'Shared handlers must identify and service pending sources.');save(im,3)
def ground(d,x,y):
 d.line((x,y,x,y+20),fill=INK,width=5)
 for yy,ww in [(y+20,30),(y+35,20),(y+50,10)]:d.line((x-ww,yy,x+ww,yy),fill=INK,width=4)
def figure4():
 im,d=begin('Use the onboard pull-up deliberately','Functional redraw of the onboard active-LOW PA3 button')
 tx(d,180,300,'3V3',45,TEAL,True);d.line((240,370,240,450),fill=INK,width=5)
 d.rectangle((220,450,260,500),fill=WHITE,outline=INK,width=4);d.line((240,500,240,670),fill=INK,width=5)
 tx(d,315,440,'External 10 kOhm',44)
 d.line((240,670,890,670),fill=INK,width=5);tx(d,950,630,'PA3',46,TEAL,True)
 d.line((490,670,490,770),fill=INK,width=5);d.line((450,770,530,770),fill=INK,width=5);d.line((450,810,530,810),fill=INK,width=5);d.line((490,810,490,900),fill=INK,width=5);ground(d,490,900)
 tx(d,600,770,'100 nF',44)
 d.line((240,670,240,760),fill=INK,width=5);d.line((240,760,300,830),fill=TEAL,width=6);d.line((240,850,240,900),fill=INK,width=5);ground(d,240,900)
 tx(d,75,1040,'Nominal R x C = 10 kOhm x 100 nF = 1 ms',45,ORANGE,True)
 panel(d,75,1190,1050,200,'Actual input mode: NOPULL + both edges',['The board already supplies the external pull-up.'])
 para(d,75,1450,'The 1 ms RC calculation is not proof of complete debounce. The main loop qualifies observed activity for 20 ms.',1040,43)
 foot(d,'Logical circuit, not a measured waveform or header position.');save(im,4)
def figure5():
 im,d=begin('A pending bit cannot count every edge','Synthetic ordering example; the flag is not an event queue')
 tx(d,75,300,'Four qualifying edge requests',46,TEAL,True)
 for x,label in [(200,'E1'),(360,'E2'),(480,'E3'),(900,'E4')]:
  tx(d,x-35,420,label,42,TEAL,True);arrow(d,[(x,500),(x,620)])
 tx(d,75,710,'PR',46,ORANGE,True)
 pts=[(120,930),(200,930),(200,800),(680,800),(680,930),(900,930),(900,800),(1040,800),(1040,930),(1140,930)]
 d.line(pts,fill=ORANGE,width=7)
 for x,label in [(680,'C1'),(1040,'C2')]:
  dashed(d,x,650,x,1000,RED);tx(d,x-35,1035,label,42,RED,True)
 tx(d,75,1160,'Callbacks',44,TEAL,True)
 arrow(d,[(740,1130),(740,1260)]);tx(d,680,1300,'CB1',42,TEAL,True)
 arrow(d,[(1100,1130),(1100,1260)]);tx(d,1020,1300,'CB2',42,TEAL,True)
 tx(d,75,1430,'C1 / C2: W1C clear before each callback.',43,RED)
 tx(d,75,1520,'E2 / E3 merge while PR is set, before C1.',43)
 foot(d,'Synthetic relative order; separate from packaged debounce traces.');save(im,5)
def figure6():
 im,d=begin('Keep IRQ capture short and qualify in main','Observed-data qualification, not a guarantee of all physical edges')
 panel(d,65,300,470,370,'ISR callback',['Check pin bitmask','Increment irq_callbacks','Record HAL_GetTick'])
 arrow(d,[(300,685),(300,800)])
 panel(d,65,820,470,280,'Shared state',['Count + service tick','No LED or delay work'])
 arrow(d,[(550,960),(650,960)])
 panel(d,665,300,470,400,'Main snapshot',['Save PRIMASK / mask','Read level, ticks, count','Restore saved PRIMASK'])
 arrow(d,[(900,715),(900,780)])
 panel(d,665,800,470,280,'Observed activity',['Restart 20 ms wait','Callback or new level'])
 arrow(d,[(900,1100),(900,1200)])
 panel(d,665,1220,470,360,'After >= 20 ms',['Update stable level','LOW: count, toggle','HIGH: no toggle'])
 para(d,65,1240,'Initialize from the current level. A held boot key is not a new press.',470,42)
 tx(d,65,1530,'Callback count != all contact edges',40,ORANGE)
 foot(d,'Restore the saved mask; acceptance latency is not exact.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson11-refresh-figure1.png', 'alt': 'انتخاب فقط یک پورت برای خط EXTI3', 'caption': 'نمودار تألیفی انتخاب PA3 یا PB3 برای خط شمارهٔ 3. پروژه GPIOA را انتخاب می\u200cکند و این دو پایه دو منبع مستقل هم\u200cزمان برای یک خط نیستند. فیلد EXTI3 در EXTICR1 بیت\u200cهای 15:12 است؛ پایه\u200cهای بی\u200cپکیج و شمارهٔ هدر فرض نشده\u200cاند.', 'purpose': 'انتخاب فقط یک پورت برای خط EXTI3', 'placement': 'در بخش «تضاد انتخاب همزمان پینهای همشماره: بررسی تداخل PA3 با PB3»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'EXTICRfield, RTSR/FTSR/PRW1C, exactIRQgroups'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'BondedlogicalPA3/PB3, no inferredheader'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3externalpull10kand100nF'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfreshlesson11v2source', 'scope': 'HALclearbeforecallback, actualdeferredqualification source'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'BondedPA3/PB3only, noPC3/PD3LQFP48claim. EXTICR1bits15:12 not0:3; oneportperline.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson11-refresh-figure2.png', 'alt': 'تشخیص لبه و پرچم pending مشترک', 'caption': 'مدل عملکردی تألیفی مسیر enable لبه\u200cهای rising و falling به یک بیت PR. پروژهٔ واقعی PA3 هر دو لبه را فعال می\u200cکند. این شکل گیت داخلی یا فیلتر debounce را بازسازی نمی\u200cکند؛ HAL پرچم W1C را پیش از callback پاک می\u200cکند.', 'purpose': 'تشخیص لبه و پرچم pending مشترک', 'placement': 'در بخش «آشکارسازی لبه بالارونده (RTSR)، پایینرونده (FTSR) و دوطرفه»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'EXTICRfield, RTSR/FTSR/PRW1C, exactIRQgroups'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'BondedlogicalPA3/PB3, no inferredheader'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3externalpull10kand100nF'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfreshlesson11v2source', 'scope': 'HALclearbeforecallback, actualdeferredqualification source'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'RTSR/FTSRfunctionalmodel notinventedfilter/gates. Pendingflagnotcount, W1Cwrite1; actualHALclearbeforecallback.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson11-refresh-figure3.png', 'alt': 'نگاشت خطوط GPIO EXTI به IRQ اختصاصی و مشترک', 'caption': 'نقشهٔ تألیفی معماری: خطوط 0 تا 4 IRQ متناظر دارند و نام خط 2 برابر EXTI2_TSC است؛ خطوط 5 تا 9 و 10 تا 15 به IRQهای مشترک می\u200cرسند. این پروژه فقط EXTI3 را فعال می\u200cکند و handler چندمنبعی ساختگی ارائه نشده است.', 'purpose': 'نگاشت خطوط GPIO EXTI به IRQ اختصاصی و مشترک', 'placement': 'در بخش «نگاشت خطوط EXTI به بردارهای NVIC در تراشه STM32F303CB»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'EXTICRfield, RTSR/FTSR/PRW1C, exactIRQgroups'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'BondedlogicalPA3/PB3, no inferredheader'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3externalpull10kand100nF'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfreshlesson11v2source', 'scope': 'HALclearbeforecallback, actualdeferredqualification source'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ExactEXTI2_TSC/EXTI9_5/EXTI15_10; actualonlyEXTI3, othergroupsarchitectureonly.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson11-refresh-figure4.png', 'alt': 'مدار کلید PA3 و دلیل NOPULL', 'caption': 'بازترسیم عملکردی تألیفی کلید روی برد: pull-up خارجی 10 kOhm و خازن 100 nF ثابت زمانی اسمی 1 ms می\u200cدهند و ورودی واقعی NOPULL با هر دو لبه است. این محاسبه حذف کامل bounce را اثبات نمی\u200cکند؛ تأیید دادهٔ مشاهده\u200cشده در main با 20 ms انجام می\u200cشود.', 'purpose': 'مدار کلید PA3 و دلیل NOPULL', 'placement': 'در بخش «مدار ورودی کلید PA3 و فیلتر RC با مقاومت 10k و خازن 100nF»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'EXTICRfield, RTSR/FTSR/PRW1C, exactIRQgroups'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'BondedlogicalPA3/PB3, no inferredheader'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3externalpull10kand100nF'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfreshlesson11v2source', 'scope': 'HALclearbeforecallback, actualdeferredqualification source'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Verifiedboardlogicalcircuit10k100nF, nominalRC1msnotphysicalfilterproof; noheaderpositionorwaveformmeasurement.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson11-refresh-figure5.png', 'alt': 'ادغام چند درخواست در یک بیت pending', 'caption': 'مثال مصنوعی تألیفی ترتیب 4 درخواست: E2 و E3 زمانی می\u200cآیند که PR از E1 هنوز set است و پیش از C1 ادغام می\u200cشوند؛ پس از پاک\u200cکردن، E4 دوباره PR را set می\u200cکند. C1 و C2 پاک\u200cکردن W1C پیش از callback هستند. این نمونهٔ ساده از ردگیری بستهٔ debounce جداست و شمارش callback برابر همهٔ لبه\u200cهای تماس نیست.', 'purpose': 'ادغام چند درخواست در یک بیت pending', 'placement': 'در بخش «چرا تعداد رخدادهای Callback برابر با جهشهای فیزیکی کلید نیست؟»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'EXTICRfield, RTSR/FTSR/PRW1C, exactIRQgroups'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'BondedlogicalPA3/PB3, no inferredheader'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3externalpull10kand100nF'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfreshlesson11v2source', 'scope': 'HALclearbeforecallback, actualdeferredqualification source'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Separate syntheticrelativeorder, noactual4edges2ISRmeasurement. CoalescingwhilePRsetbeforeclear, notallISRduration; actualHALclearthenCB.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson11-refresh-figure6.png', 'alt': 'تقسیم کار callback کوتاه و تأیید در main', 'caption': 'نمودار تألیفی کد واقعی: callback پس از بررسی bitmask شمارنده و tick سرویس را ثبت می\u200cکند؛ main با ذخیره و بازگرداندن PRIMASK snapshot می\u200cگیرد و پس از حداقل 20 ms نبود فعالیت تازهٔ مشاهده\u200cشده سطح پایدار را به\u200cروز می\u200cکند. LOW شمارش و PB6 را Toggle می\u200cکند و HIGH بدون Toggle پذیرفته می\u200cشود. سطح اولیه از کلید خوانده می\u200cشود؛ کلید نگه\u200cداشته\u200cشده در روشن\u200cشدن فشار تازه نیست و timestamp زمان دقیق لبهٔ فیزیکی نیست.', 'purpose': 'تقسیم کار callback کوتاه و تأیید در main', 'placement': 'در بخش «الگوریتم غیرمسدودکننده: ثبت برچسب زمانی در وقفه و اعتبارسنجی 20ms در حلقه اصلی»', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'EXTICRfield, RTSR/FTSR/PRW1C, exactIRQgroups'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'BondedlogicalPA3/PB3, no inferredheader'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3externalpull10kand100nF'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfreshlesson11v2source', 'scope': 'HALclearbeforecallback, actualdeferredqualification source'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actualirq_callbacks/last_irq_tick plusshortsavedPRIMASKsnapshot; observedactivity20ms notcontinuousphysicalstabilityguarantee. NoHALDelay/LEDworkISR; release/heldnofalsetoggle.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

"""Main-loop debounce model fed by synthetic IRQ callback times; not a CPU simulator."""
from pathlib import Path
import json
def run(events,end,start=0,initial_count=0,extra_callbacks=None):
    raw=stable=events[0][1];seen=count=initial_count;activity=start&0xffffffff;irq_tick=0;presses=led=0;history=[];previous=raw
    for time in range(start,end+1):
        sample=events[0][1]
        for edge,value in events:
            if edge<=time:sample=value
        added=(1 if sample!=previous else 0)+(extra_callbacks or {}).get(time,0)
        if added:count=(count+added)&0xffffffff;irq_tick=time&0xffffffff
        previous=sample;now=time&0xffffffff
        if count!=seen:seen=count;activity=irq_tick
        if sample!=raw:raw=sample;activity=now
        if raw!=stable and ((now-activity)&0xffffffff)>=20:
            stable=raw
            if stable==0:presses+=1;led^=1
        history.append(dict(time=time,tick=now,irq_callbacks=count,raw=raw,stable=stable,presses=presses,LED=led))
    return history
events=[(0,1),(10,0),(11,1),(12,0),(14,1),(16,0),(70,1),(71,0),(73,1),(110,0)]
t=run(events,150)
assert t[35]['presses']==0 and t[36]['presses']==1
assert t[92]['stable']==0 and t[93]['stable']==1 and t[93]['presses']==1
assert t[129]['presses']==1 and t[130]['presses']==2 and t[-1]['LED']==0
assert run([(0,0)],200)[-1]['presses']==0
assert run([(0,0),(50,1),(100,0)],150)[-1]['presses']==1
assert run([(0,1),(10,0),(29,1)],100)[-1]['presses']==0
assert run([(0,1),(10,0)],500)[-1]['presses']==1
late=run([(0,1),(10,0)],70,extra_callbacks={25:2})
assert late[44]['presses']==0 and late[45]['presses']==1
wrap=run([(0xfffffff0,1),(0xfffffffa,0)],0x100000040,0xfffffff0)
assert next(x for x in wrap if x['tick']==13)['presses']==0 and next(x for x in wrap if x['tick']==14)['presses']==1
counter=run([(0,1),(10,0),(50,1),(90,0)],130,initial_count=0xfffffffe)
assert counter[-1]['irq_callbacks']==1 and counter[-1]['presses']==2
result={'scope':'Synthetic callback/sample arithmetic; physical RC/contact bounce, EXTI coalescing and MCU execution not simulated','qualification_ms':20,'normal_callbacks':t[-1]['irq_callbacks'],'accepted_presses':t[-1]['presses'],'checks_passed':['bouncing press','stable release without toggle','second press','boot held','release then press','short pulse rejection','long held no repeats','extra IRQ postpones acceptance','uint32 tick wrap','uint32 callback counter wrap'],'timeline':t}
(Path(__file__).parent/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k!='timeline'},indent=2))

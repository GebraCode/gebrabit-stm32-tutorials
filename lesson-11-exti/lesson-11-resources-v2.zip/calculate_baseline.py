"""Nominal RC and sampled qualification arithmetic; not a board waveform model."""
from pathlib import Path
import json
r_ohm=10000
c_farad=100e-9
tau_ms=r_ohm*c_farad*1000
assert abs(tau_ms-1.0)<1e-12
last_activity_ms=16
qualification_ms=20
expected_sampled_acceptance_ms=last_activity_ms+qualification_ms
assert expected_sampled_acceptance_ms==36
result={'scope':'Nominal RC and1ms sampled-time arithmetic only. No mechanical contact, continuous stability, hardware IRQ latency or actual waveform simulated.',
 'pullup_ohm':r_ohm,'capacitor_farad':c_farad,'nominal_RC_ms':tau_ms,
 'synthetic_last_activity_ms':last_activity_ms,'qualification_ms':qualification_ms,
 'expected_acceptance_ms_if_no_new_observed_activity':expected_sampled_acceptance_ms}
(Path(__file__).parent/'baseline-calculations.json').write_text(json.dumps(result,indent=2)+'\n','utf8')
print(json.dumps(result,indent=2))

"""Editable original educational diagrams. Requires Pillow and Windows Segoe UI.
All timelines and waveforms are models, never captured hardware results.
Regenerates only this lesson's PNGs and image-metadata.json beside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, json, textwrap
OUT=Path(__file__).resolve().parent
LESSON=17
W,H=1200,1800
INK='#16354b';TEAL='#087f8c';ORANGE='#ac5c18';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c7d7e1';PALE='#e3f1f2';WHITE='#ffffff'
def font(n=43,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if bold else '')+'.ttf',n)
def tx(d,x,y,s,n=43,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1060,n=43,c=INK,b=False,gap=12):
    words=s.split();lines=[];line=''
    for word in words:
        test=(line+' '+word).strip()
        if d.textlength(test,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,sub='Original diagram / synthetic model'):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,38,title,1090,52,b=True)
    para(d,55,y+10,sub,1090,38,c=MUTED)
    d.line((55,185,1145,185),fill=LINE,width=3)
    return im,d
def footer(d,s='STM32F303CBT6 | Official manuals + exact F3 HAL'):
    d.line((55,H-165,1145,H-165),fill=LINE,width=3)
    para(d,55,H-140,s,1090,33,c=MUTED,gap=6)
    tx(d,55,H-50,'Original model. No board measurement or GUI capture.',32,MUTED)
def arrow(d,pts,c=TEAL,width=7):
    d.line(pts,fill=c,width=width)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+13,s,w-48,42)
    assert yy-18<=y+h+5,(title,yy,y+h)
def note(d,y,s,c=INK):return para(d,65,y,s,1070,43,c)
def save(im,i):im.save(OUT/f'lesson{LESSON}-figure{i}.png',optimize=True)
def axis(d,x0=160,y0=1150,x1=1110,y1=340,xlabel='Time ->',ylabel=None):
    arrow(d,[(x0,y0),(x1,y0)],INK,4);arrow(d,[(x0,y0),(x0,y1)],INK,4)
    tx(d,x1-230,y0+95,xlabel,39)
    if ylabel:tx(d,65,y1-70,ylabel,42,b=True)
def dots(d,x,y,count,active=None,step=70):
    for k in range(count):
        color=TEAL if active is None or k in active else LINE
        d.rounded_rectangle((x+k*step,y,x+k*step+step-9,y+70),8,fill=color)
def step(d,events,xmap,yhi,ylo,c=TEAL,width=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,yhi if last else ylo),(x,yhi if v else ylo)]);last=v
    d.line(pts,fill=c,width=width)
def ring(d,cx,cy,r=310,n=16,start=3,end=11):
    # Sectors represent groups of bytes, not a false256-cell screenshot.
    for k in range(n):
        d.pieslice((cx-r,cy-r,cx+r,cy+r),k*360/n-90,(k+1)*360/n-90,fill=TEAL if (start<=k<end or end>n and k<end-n) else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+100,cy-r+100,cx+r-100,cy+r-100),fill=BG)
def lineplot(d,points,x0,y0,xscale,yscale,c=TEAL):
    d.line([(x0+x*xscale,y0-y*yscale) for x,y in points],fill=c,width=7)





def lesson17():
    im,d=begin('Unsigned subtraction crosses one wrap','TIM2:32-bit free-running counter at1MHz')
    ring(d,600,650,r=330,n=24,start=23,end=25)
    tx(d,415,580,'Modulo2^32',49,TEAL,True)
    tx(d,460,665,'1 tick =1us',44)
    arrow(d,[(210,420),(400,345)],ORANGE);tx(d,65,275,'start:0xFFFFFFF0',43,ORANGE,True)
    arrow(d,[(1050,515),(875,430)]);tx(d,670,1080,'end:0x00000010',43,TEAL,True)
    tx(d,65,1240,'(uint32_t)(end - start) =32 ticks',46,b=True)
    tx(d,65,1350,'Elapsed model =32us',47,TEAL,True)
    note(d,1460,'The elapsed interval must be less than one full counter period. Equal samples cannot detect a missed full wrap.')
    footer(d,'Wrap period:2^32 /1000000 =4294.967296s.');save(im,1)

    im,d=begin('Two arithmetic examples, same rule','Known inputs for a model, not debugger observations')
    for base,title,start,end,diff in [(250,'A: no wrap','0x00001000','0x00001500','0x00000500 =1280us'),(860,'B: crosses wrap','0xFFFFFF00','0x00000100','0x00000200 =512us')]:
        tx(d,65,base,title,48,TEAL,True)
        tx(d,100,base+120,'start  '+start,46);tx(d,100,base+220,'end    '+end,46)
        d.line((100,base+320,1100,base+320),fill=LINE,width=4)
        tx(d,100,base+370,diff,47,ORANGE,True)
    note(d,1450,'Unsigned modular subtraction does not count multiple wraps. Keep the measurement shorter than4294.967296s.')
    footer(d,'Actual project uses TIM2 CNT32; the prescaler remains16-bit.');save(im,2)

    im,d=begin('Load the prescaler before starting','Exact project sequence | No update interrupt enabled')
    stages=[('Timer stopped','Issue EGR.UG to load buffered settings.'),('Inspect UIF','UG can leave the update flag set.'),('Clear UIF','HAL clear macro writes SR = ~UIF mask.'),('Start the timer','HAL_TIM_Base_Start: ordinary free running.'),('Poll or measure CNT','Read SR/CNT as required; clear handled flags.')]
    for k,(a,b) in enumerate(stages):
        y=235+k*245;panel(d,80,y,1040,180,a,[b],ORANGE if k==2 else TEAL)
        if k<4:arrow(d,[(600,y+190),(600,y+235)])
    footer(d,'UIF is cleared by writing0; avoid a read-modify-write race on SR.');save(im,3)

    im,d=begin('A busy wait includes software overhead','Event-order model | No measured cycle counts or accuracy claim')
    labels=[('Read start CNT',TEAL),('Compare elapsed',ORANGE),('Loop / branch',TEAL),('Read CNT again',ORANGE),('Exit when elapsed >= request',TEAL)]
    y=270
    for k,(label,c) in enumerate(labels):
        d.rounded_rectangle((200,y,1030,y+125),15,fill=c);tx(d,225,y+32,label,44,'white',True)
        if k<4:arrow(d,[(615,y+135),(615,y+205)],INK)
        y+=230
    d.line((120,300,120,1260),fill=INK,width=4);tx(d,65,1350,'The caller also pays entry + exit and bus access cost.',42)
    note(d,1450,'A1us counter tick does not guarantee an accurate1us delay function. Interrupts and instruction timing add uncertainty.',ORANGE)
    footer(d,'Actual bounded wait rejects >1000000us; SysTick timeout is a guard.');save(im,4)

    im,d=begin('DWT and TIM2 do not use identical windows','Actual sample order | Both counters are discrete')
    names=[('DWT c0',TEAL),('TIM2 t0',ORANGE),('Work / empty baseline',INK),('TIM2 t1',ORANGE),('DWT c1',TEAL)]
    for k,(label,c) in enumerate(names):
        yy=280+k*195;d.ellipse((140,yy+5,175,yy+40),fill=c);tx(d,220,yy-5,label,48,c,True)
        if k<4:d.line((157,yy+60,157,yy+175),fill=LINE,width=6)
    d.line((1040,290,1100,290,1100,1090,1040,1090),fill=TEAL,width=6)
    d.line((950,485,1000,485,1000,895,950,895),fill=ORANGE,width=6)
    tx(d,65,1340,'DWT:1 /72MHz =13.8889ns per cycle',44,TEAL,True)
    tx(d,65,1430,'TIM2:1us per tick; DWT encloses TIM2 reads.',42,ORANGE,True)
    footer(d,'DWT wraps59.6523236s; TIM2 wraps4294.967296s.');save(im,5)

    im,d=begin('Read saved results; do not invent traces','Observation plan | Actual hardware run is still pending')
    panel(d,70,235,1060,215,'Run foreground work',['Volatile1024-step LCG is a test workload.','Save raw DWT and TIM2 differences in RAM.'])
    arrow(d,[(600,470),(600,620)])
    d.rectangle((120,640,1080,940),fill=WHITE,outline=INK,width=4)
    for k,t in enumerate(['measured_dwt_cycles','measured_timer_ticks','empty_dwt_cycles','empty_timer_ticks']):
        tx(d,180,665+k*65,t,44,TEAL,k==0)
    arrow(d,[(600,960),(600,1120)])
    panel(d,70,1140,1060,215,'Inspect through SWD / debugger',['PA13 = SWDIO; PA14 = SWCLK; common GND.','A debugger halt may freeze the timer.'])
    note(d,1460,'Printing inside the timed window changes the experiment. Live reads can also disturb timing; record the method used.',ORANGE)
    footer(d,'No oscilloscope pulse or live-debugger screenshot was produced.');save(im,6)


def run():
    globals()[f'lesson{LESSON}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')



METADATA=[{'id': 1, 'filename': 'lesson17-figure1.png', 'alt': 'تفریق بدون علامت دو نمونه با عبور از wrap', 'caption': 'مدل تألیفی TIM2 آزاد 32 بیتی و 1MHz: فاصلهٔ 0xFFFFFFF0 تا 0x00000010 در حساب uint32 برابر 32 تیک یا 32us است. بازه باید کمتر از یک دور کامل 4294.967296s باشد؛ حلقه بخش\u200cهای گروهی است، نه ثبت برد.', 'purpose': 'تفریق uint32 هنگام عبور از یک wrap چگونه فاصلهٔ صحیح را می\u200cدهد؟', 'placement': 'زیربخش اصول ریاضی تفریق بدون علامت 32 بیتی در سرریز مجاز', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 2, 'filename': 'lesson17-figure2.png', 'alt': 'دو مثال حساب زمان با و بدون سرریز', 'caption': 'مثال محاسباتی تألیفی: 0x1500-0x1000 برابر 1280 تیک و تفریق پیمانه\u200cای 0x100-0xFFFFFF00 برابر 512 تیک است؛ این اعداد ورودی مدل\u200cاند و خروجی دیباگر نیستند. چند دور کامل از تفریق دو نمونه بازیابی نمی\u200cشود.', 'purpose': 'نمونه\u200cهای تفریق با و بدون wrap چه محدودیت زمانی دارند؟', 'placement': 'زیربخش چرخه شمارنده 32 بیتی و مرز سرریز 4294.967296 ثانیه\u200cای', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 3, 'filename': 'lesson17-figure3.png', 'alt': 'بارگذاری تنظیمات و پاک\u200cکردن UIF پیش از شروع', 'caption': 'نمودار توالی تألیفی مطابق کد پروژه: UG در حالت توقف برای بارگذاری تنظیمات صادر می\u200cشود، UIF بررسی و با ماکروی HAL و نوشتن SR=~UIF پاک می\u200cشود و سپس Base_Start بدون وقفه اجرا می\u200cشود. روی SR از read-modify-write استفاده نشود.', 'purpose': 'چرا پس از UG و پیش از شروع، UIF پاک می\u200cشود؟', 'placement': 'بخش رجیستر وضعیت و مدیریت پرچم به\u200cروزرسانی (UIF Polling)', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 4, 'filename': 'lesson17-figure4.png', 'alt': 'سربار نرم\u200cافزاری تأخیر به روش Polling', 'caption': 'نمودار ترتیب تألیفی حلقهٔ خواندن CNT و مقایسه و بازگشت؛ هیچ تعداد سیکل یا خطای درصدی ساختگی نمایش داده نشده است. گام 1us شمارنده تضمین دقت تابع تأخیر 1us نیست. پروژه درخواست بیشتر از 1000000us را رد و از timeout وابسته به SysTick به\u200cعنوان محافظ استفاده می\u200cکند.', 'purpose': 'چه هزینه\u200cهایی علاوه بر تیک تایمر در تأخیر Polling وجود دارند؟', 'placement': 'زیربخش الگوریتم پایش CNT و تحلیل بودجه سربار فراخوانی', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 5, 'filename': 'lesson17-figure5.png', 'alt': 'پنجره\u200cهای متفاوت نمونه\u200cبرداری DWT و TIM2', 'caption': 'مدل تألیفی ترتیب واقعی DWTc0، TIMt0، workload، TIMt1، DWTc1؛ بازهٔ DWT خواندن\u200cهای TIM2 را نیز در بر می\u200cگیرد و دقیقاً همان پنجره نیست. DWT در 72MHz گام 13.8889ns و TIM2 گام 1us دارد؛ هر دو شمارنده گسسته\u200cاند و هیچ اندازه\u200cگیری روی برد انجام نشده است.', 'purpose': 'چرا پنجرهٔ DWT و TIM2 در کد واقعی یکسان نیست؟', 'placement': 'بخش آزمایش عملی: سنجش و مقایسه زمان اجرای تابع با TIM2 و DWT', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 6, 'filename': 'lesson17-figure6.png', 'alt': 'ثبت نتیجه در حافظه و بررسی با SWD', 'caption': 'نمودار تألیفی برنامهٔ مشاهده: workload واقعی LCG با 1024 تکرار و baseline جداست؛ نتایج خام در متغیرهای volatile ذخیره می\u200cشوند. روش مشاهده و اثر halt باید ثبت شود؛ چاپ در بازهٔ زمان\u200cسنجی وارد نمی\u200cشود. تصویر scope یا Live Expressions واقعی موجود نیست.', 'purpose': 'نتایج خام کجا ذخیره می\u200cشوند و روش مشاهده چه اثری بر آزمایش دارد؟', 'placement': 'زیربخش متدولوژی ثبت داده غیرمخرب با Live Expressions و پین سخت\u200cافزاری PB7', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 inspected timer/DMA/USART facts; PM0214 Rev10; F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; exact generated lesson project; GB100ST V2.0 where relevant', 'source': 'Original Pillow drawing by Codex based on official facts and actual project', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST schematic V2.0'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}]
if __name__=='__main__':run()

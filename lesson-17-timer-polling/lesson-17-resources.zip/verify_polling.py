"""Arithmetic models, not measurements from the MCU."""
import json
mask=0xffffffff
def delta(end,start):return (end-start)&mask
assert delta(0x20,0xfffffff0)==48
assert delta(1234,1234)==0
result={'assumptions':'TIM2 full32bit upcounter at1MHz, DWT CYCCNT at72MHz, one wrap maximum between samples; no hardware timing data','timer_tick_us':1,'timer_wrap_s':2**32/1_000_000,'dwt_tick_ns':1e9/72_000_000,'dwt_wrap_s':2**32/72_000_000,'wrap_example':{'start_hex':'0xfffffff0','end_hex':'0x20','elapsed_ticks':delta(0x20,0xfffffff0)},'requested_delay_us':100,'delay_api_maximum_us':1_000_000,'guard_for_100us_ms':100//1000+10,'work_iterations':1024,'work_measured_duration':None,'empty_baseline_measured_duration':None}
print(json.dumps(result,indent=2))

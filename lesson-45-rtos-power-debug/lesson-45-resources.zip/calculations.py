"""Arithmetic predictions only. Not hardware measurements or firmware execution."""
from fractions import Fraction
import json
assert 72000000//72==1000000
assert 16777215//72000==233
assert Fraction(32768,16)==2048
assert (200-2)*2048//1000==405
def tick_plan(expected,tick,rtc_cycles,initial_phase_counts):
    elapsed=Fraction(rtc_cycles*1000,32768)+Fraction(initial_phase_counts,72000)
    whole=elapsed.numerator//elapsed.denominator
    step=min(whole,expected-1,0xffffffff-tick)
    return whole,step,whole-step
assert tick_plan(1000,0,32768,0)==(1000,999,1)
assert tick_plan(1000,0,6553,0)==(199,199,0)
assert tick_plan(5,0,327,0)==(9,4,5)
assert tick_plan(1000,0xfffffffe,327,0)==(9,1,8)
assert tick_plan(1000,0,0,0)==(0,0,0)
assert tick_plan(1000,0,1,71999)==(1,1,0)
result={"scope":"Independent unit-conversion arithmetic; no target runtime","SysTick24bit_max_nominal_ticks":233,"TIM2_Hz_at72MHz":1000000,"TIM2_wrap_seconds":float(Fraction(2**32,1000000)),"RTC_resolution_us":float(Fraction(1000000,32768)),"RTC_WUT_Hz":2048,"WUT_counts_for_requested200ms_with2ms_guard":405,"corresponding_WUT_interval_ms":float(Fraction(405*1000,2048)),"note":"Actual elapsed RTC cycles, not programmed WUT duration, determine compensation. RTC quantization/code overhead remain; no exact latency or current saving asserted.","Stop_TIM2_warning":"TIM2 stops in Stop, so its stats are not wall-clock percentages."}
print(json.dumps(result,indent=2))

"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=14
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('DMA needs access to its buffers','Functional access map, not an exact reproduced bus-fabric schematic')
 panel(d,65,300,470,200,'Cortex-M4F CPU',['Runs setup and application code'])
 panel(d,665,300,470,200,'DMA1 / DMA2',['Transfer bus masters'])
 arrow(d,[(300,520),(300,745)]);arrow(d,[(900,520),(900,745)])
 d.rounded_rectangle((75,760,1125,880),15,fill=PALE,outline=TEAL,width=4)
 tx(d,350,790,'AHB access paths',48,TEAL,True)
 arrow(d,[(300,895),(300,1030)]);arrow(d,[(900,895),(900,1030)])
 panel(d,65,1050,470,220,'Main SRAM',['32 KiB: DMA buffers here'])
 panel(d,665,1050,470,220,'Peripheral registers',['Mapped request routes'])
 arrow(d,[(65,400),(45,400),(45,1500),(60,1500)],ORANGE)
 panel(d,65,1420,470,160,'CCM: 8 KiB',['CPU access only'],ORANGE)
 panel(d,665,1420,470,200,'No DMA route',['Not fixed by volatile / DMB'],RED)
 foot(d,'This F303 has no D-cache maintenance step to add.');save(im,1)
def figure2():
 im,d=begin('Use the fixed request map for this device','Mapping examples are alternatives, not independent queues on one channel')
 rows=[('ADC1','DMA1 channel 1'),('USART1 TX','DMA1 channel 4'),('USART1 RX','DMA1 channel 5')]
 for k,(a,b)in enumerate(rows):
  y=300+k*230;tx(d,75,y,a,46,TEAL,True);arrow(d,[(430,y+35),(680,y+35)]);tx(d,730,y,b,42,TEAL,True)
 tx(d,75,1030,'DMA1: 7 channels',44,TEAL,True)
 for k in range(7):panel(d,75+k*145,1120,125,120,str(k+1),())
 tx(d,75,1320,'DMA2: 5 channels',44,TEAL,True)
 for k in range(5):panel(d,75+k*145,1410,125,120,str(k+1),())
 foot(d,'Actual project: DMA1 channel 1 MEM2MEM; no DMAMUX.');save(im,2)
def figure3():
 im,d=begin('Count elements before counting bytes','Actual transfer: 256 words of 32 bits = 1024 bytes, both addresses increment')
 tx(d,75,300,'Source CPAR',46,TEAL,True);tx(d,690,300,'Destination CMAR',46,TEAL,True)
 for k in range(3):
  yy=470+k*240;tx(d,75,yy-60,f'S+{k*4}',42);tx(d,690,yy-60,f'D+{k*4}',42)
  for j in range(4):
   d.rectangle((75+j*100,yy,165+j*100,yy+120),fill=TEAL if j%2==0 else PALE,outline=TEAL,width=3)
   d.rectangle((690+j*100,yy,780+j*100,yy+120),fill=TEAL if j%2==0 else PALE,outline=TEAL,width=3)
  arrow(d,[(500,yy+60),(650,yy+60)])
 tx(d,75,1260,'Each small cell: 1 byte; each row: 1 word',43,TEAL,True)
 panel(d,75,1390,1050,230,'CNDTR counts words, not bytes',['256 -> 255 -> 254 -> ... -> 0','4-byte aligned; distinct source and destination.'])
 foot(d,'CPAR register naming does not imply a peripheral in MEM2MEM.');save(im,3)
def figure4():
 im,d=begin('Progress and operating mode differ','Actual MEM2MEM is Normal; peripheral Circular operation is a separate concept')
 tx(d,75,300,'Actual 256-word transfer',46,TEAL,True)
 d.line((140,650,1070,650),fill=TEAL,width=8)
 for x,a,b in [(140,'Start','256 left'),(605,'HT','128 left'),(1070,'TC','0 left')]:
  d.ellipse((x-16,634,x+16,666),fill=TEAL);tx(d,x-60,450,a,42,TEAL,True);tx(d,x-70,535,b,40)
 panel(d,75,800,1050,200,'Normal: complete the programmed block',['TC ends this transfer; TE reports a transfer error.'])
 panel(d,75,1160,1050,200,'Peripheral Circular concept',['Reload count for a valid peripheral stream.'])
 arrow(d,[(1090,1280),(1150,1280),(1150,1100),(600,1100),(600,1140)],ORANGE)
 tx(d,75,1480,'MEM2MEM: no Circular mode; keep CIRC clear.',42,RED,True)
 foot(d,'An invalid mode is not a promised TE flag or a valid experiment.');save(im,4)
def figure5():
 im,d=begin('Compare buffers only after completion','Actual three arrays are each uint32[256], 1024 bytes in main SRAM')
 panel(d,75,300,1050,180,'dma_source',['Prepared pattern; not modified while DMA is active'])
 arrow(d,[(600,500),(600,590),(300,590),(300,650)]);arrow(d,[(600,590),(900,590),(900,650)])
 panel(d,65,670,470,260,'cpu_destination',['CPU memcpy baseline'])
 panel(d,665,670,470,260,'dma_destination',['DMA1 channel 1 Normal'])
 panel(d,75,1100,1050,210,'HAL_DMA_Start_IT -> IRQ HT / TC / TE',['TC records elapsed cycles, then publishes independent done.'])
 panel(d,75,1410,1050,190,'Two DMA trials, then compare results',['Trial 0: wait. Trial 1: 1024 LCG ops, then wait.'])
 foot(d,'Each array is 4-byte aligned and verified nonoverlapping.');save(im,5)
def figure6():
 im,d=begin('Define timing windows before comparison','One possible schedule: TC callback can run before the HAL call returns')
 tx(d,75,300,'All cycle values remain unmeasured on hardware.',44,ORANGE,True)
 for x,a in [(150,'Start'),(500,'TC'),(700,'HAL return'),(1070,'Main')]:
  tx(d,x-55,380,a,38,TEAL,True);dashed(d,x,440,x,1510,LINE)
 rows=[(520,'dma_start_cycles',150,700),(800,'dma_elapsed_at_callback',150,500),(1080,'dma_total_wait_cycles',150,1070),(1360,'foreground_work_cycles',720,1000)]
 for y,label,a,b in rows:
  tx(d,75,y-65,label,43,TEAL,True);arrow(d,[(a,y+45),(b,y+45)],TEAL,8)
 tx(d,75,1540,'Foreground after launch does not establish actual overlap.',41,ORANGE)
 foot(d,'Relative order only; HAL-return time is not pure launch overhead.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson14-refresh-figure1.png', 'alt': 'مسیر قابل دسترس DMA و محدودیت CCM', 'caption': 'نمودار عملکردی تألیفی دسترسی CPU و DMA به منابع. بافر DMA این قطعه در SRAM اصلی 32 KiB قرار می\u200cگیرد و CCM برابر 8 KiB مسیر DMA ندارد؛ volatile و DMB مسیر سخت\u200cافزاری نمی\u200cسازند. تصویر کپی دقیق ماتریس گذرگاه و مسیرهای I/D نیست و برای F303 فاقد D-cache عملیات cache maintenance اختراع نشده است.', 'purpose': 'مسیر قابل دسترس DMA و محدودیت CCM', 'placement': 'H2: نگاشت حافظه و محدودیت دسترسی به CCM SRAM', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified table/revision asserted', 'scope': 'DMAfixedmapping/widths/NormalCircular/HTTC/CCMaccess'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactF303xB/C resources andmemory'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson14v2source', 'scope': 'Start_ITcallbackorder, actualbuffers/DWTwindows/trialsetup'}, {'url': 'local:verify_model.py and actual ELF inspection', 'version': 'Fresh8modelgroups including actualELFnonoverlap', 'scope': 'Arithmetic/source/placement checks, notDMAhardwareexecution'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Functionalnotexactbusfabric; CPU-onlyCCM noDMA, actualSRAMbuffer, noDCacheF303.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson14-refresh-figure2.png', 'alt': 'نمونه\u200cهای نگاشت ثابت درخواست\u200cهای DMA', 'caption': 'نمودار تألیفی چند نگاشت ثابت ADC1 و USART1 و تعداد کانال\u200cهای DMA1 و DMA2 در F303xB/C. پروژهٔ واقعی channel 1 در DMA1 را برای MEM2MEM نرم\u200cافزاری به کار می\u200cگیرد؛ نمونه\u200cهای پریفرالی صف\u200cهای مستقل هم\u200cزمان روی یک کانال نیستند و DMAMUX وجود ندارد.', 'purpose': 'نمونه\u200cهای نگاشت ثابت درخواست\u200cهای DMA', 'placement': 'H2: ساختار کنترلرهای DMA1 و DMA2 در میکروکنترلر STM32F303CBT6', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified table/revision asserted', 'scope': 'DMAfixedmapping/widths/NormalCircular/HTTC/CCMaccess'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactF303xB/C resources andmemory'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson14v2source', 'scope': 'Start_ITcallbackorder, actualbuffers/DWTwindows/trialsetup'}, {'url': 'local:verify_model.py and actual ELF inspection', 'version': 'Fresh8modelgroups including actualELFnonoverlap', 'scope': 'Arithmetic/source/placement checks, notDMAhardwareexecution'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'DMA1has7/DMA2has5, ADC1Ch1 USART1TXCh4 RXCh5 verifiedfixedexamples; no unseenTable29/30assertion oractualADCconfigclaim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson14-refresh-figure3.png', 'alt': 'عرض داده و شمارش عناصر انتقال', 'caption': 'مدل تألیفی انتقال واقعی 256 کلمهٔ 32 بیتی برابر 1024 بایت با افزایش هر دو آدرس به گام 4 بایت. S و D مبداهای نمادین\u200cاند، نه آدرس اندازه\u200cگیری\u200cشدهٔ ELF. CNDTR تعداد wordها را می\u200cشمارد؛ نام CPAR در MEM2MEM به معنی وجود پریفرال منبع نیست و بافرهای واقعی هم\u200cتراز و غیرهمپوشان\u200cاند.', 'purpose': 'عرض داده و شمارش عناصر انتقال', 'placement': 'H2: پارامترهای پایه\u200cای پیکربندی کانال DMA', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified table/revision asserted', 'scope': 'DMAfixedmapping/widths/NormalCircular/HTTC/CCMaccess'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactF303xB/C resources andmemory'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson14v2source', 'scope': 'Start_ITcallbackorder, actualbuffers/DWTwindows/trialsetup'}, {'url': 'local:verify_model.py and actual ELF inspection', 'version': 'Fresh8modelgroups including actualELFnonoverlap', 'scope': 'Arithmetic/source/placement checks, notDMAhardwareexecution'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualWORD32/PINC+MINC/CNDTR256elements1024B, sourceCPARdestinationCMAR; baseS/DsymbolicnotinventedELFaddresses.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson14-refresh-figure4.png', 'alt': 'پیشرفت HT و TC و تفاوت Normal و Circular', 'caption': 'مدل تألیفی پیشرفت انتقال واقعی 256 word تا HT در 128 word باقی\u200cمانده و TC در پایان. این پروژه Normal است؛ Circular فقط برای جریان پریفرالیِ مجاز توضیح داده شده و ترکیب MEM2MEM با Circular پشتیبانی نمی\u200cشود. نامعتبر بودن حالت تضمین تولید TE یا مجوز آزمون خطا نیست.', 'purpose': 'پیشرفت HT و TC و تفاوت Normal و Circular', 'placement': 'H2: پرچم\u200cهای وضعیت، رخدادها و مدیریت وقفه در DMA', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified table/revision asserted', 'scope': 'DMAfixedmapping/widths/NormalCircular/HTTC/CCMaccess'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactF303xB/C resources andmemory'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson14v2source', 'scope': 'Start_ITcallbackorder, actualbuffers/DWTwindows/trialsetup'}, {'url': 'local:verify_model.py and actual ELF inspection', 'version': 'Fresh8modelgroups including actualELFnonoverlap', 'scope': 'Arithmetic/source/placement checks, notDMAhardwareexecution'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualMEM2MEMNormal HT128words/512B TC0left. PeripheralCircularconceptonly, CIRCmustclear, no guaranteedTEfrominvalidmode orintentionalTEtest.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson14-refresh-figure5.png', 'alt': 'سه بافر و تکمیل وقفه\u200cای آزمایش کپی', 'caption': 'نمودار تألیفی ساختار واقعی سه آرایهٔ مجزای 1024 بایتی source و دو destination. برنامه از HAL_DMA_Start_IT و IRQهای HT/TC/TE استفاده می\u200cکند؛ TC ابتدا elapsed cycle را ثبت و سپس flag مستقل done را منتشر می\u200cکند. trial 0 انتظار می\u200cکشد و trial 1 پس از launch تعداد 1024 عملیات LCG انجام می\u200cدهد؛ صحت داده پس از تکمیل مقایسه می\u200cشود و هم\u200cزمانی واقعی اندازه\u200cگیری نشده است.', 'purpose': 'سه بافر و تکمیل وقفه\u200cای آزمایش کپی', 'placement': 'H2: پیاده\u200cسازی آزمایش انتقال حافظه به حافظه با DMA1 Channel 1', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified table/revision asserted', 'scope': 'DMAfixedmapping/widths/NormalCircular/HTTC/CCMaccess'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactF303xB/C resources andmemory'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson14v2source', 'scope': 'Start_ITcallbackorder, actualbuffers/DWTwindows/trialsetup'}, {'url': 'local:verify_model.py and actual ELF inspection', 'version': 'Fresh8modelgroups including actualELFnonoverlap', 'scope': 'Arithmetic/source/placement checks, notDMAhardwareexecution'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualStart_ITnotPollForTransfer, all3arrays1024B alignednonoverlap, separateTCelapsed/done nozero-to1fabrication. TwoDMAtrials/CPUmemcpy, noactualcycles.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson14-refresh-figure6.png', 'alt': 'تعریف پنجره\u200cهای اندازه\u200cگیری DMA', 'caption': 'مدل تألیفی یک ترتیب ممکن که callback اتمام پیش از بازگشت HAL اجرا می\u200cشود. بنابراین dma_start_cycles الزاماً سربار خالص راه\u200cاندازی نیست و پنجره\u200cهای elapsed در callback و ادامهٔ main و کار foreground متفاوت\u200cاند. طول پیکان\u200cها زمان اندازه\u200cگیری\u200cشده نیست؛ اجرای foreground پس از launch اثبات overlap نیست و همهٔ cycleهای سخت\u200cافزار هنوز نامشخص\u200cاند.', 'purpose': 'تعریف پنجره\u200cهای اندازه\u200cگیری DMA', 'placement': 'H2: تحلیل تحلیلی و مقایسه\u200cای انتقال با DMA در برابر تابع memcpy', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316; no unverified table/revision asserted', 'scope': 'DMAfixedmapping/widths/NormalCircular/HTTC/CCMaccess'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactF303xB/C resources andmemory'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a and actualfreshlesson14v2source', 'scope': 'Start_ITcallbackorder, actualbuffers/DWTwindows/trialsetup'}, {'url': 'local:verify_model.py and actual ELF inspection', 'version': 'Fresh8modelgroups including actualELFnonoverlap', 'scope': 'Arithmetic/source/placement checks, notDMAhardwareexecution'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'PossiblecallbackbeforeHALreturn schedule notactualmeasurement. start_cyclesmayincludecompletionIRQ, callbackincludesIRQlatency, totaltrial1includeswork, no100%CPU/speedup/guaranteedoverlap; timeoutcheckafterforegroundnotwholefunctiondeadline.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

"""Nominal cycle/time arithmetic only; no measured DMA/memcpy speed."""
from pathlib import Path
import json
hclk=72_000_000
cycle_ns=1e9/hclk
assert abs(cycle_ns-13.88888888888889)<1e-12
words=256
assert words*4==1024 and (words//2)*4==512
result={'scope':'Nominal clock/element arithmetic, not runtime timing evidence.',
 'configured_HCLK_hz':hclk,'nominal_cycle_ns':cycle_ns,
 'words':words,'bytes_per_word':4,'transfer_bytes':words*4,'half_transfer_words':words//2,'half_transfer_bytes':words//2*4,
 'measured_DMA_cycles':None,'measured_memcpy_cycles':None}
(Path(__file__).parent/'clock-calculations.json').write_text(json.dumps(result,indent=2)+'\n','utf8')
print(json.dumps(result,indent=2))

"""Array/width arithmetic and actual ELF SRAM placement; no DMA execution."""
from pathlib import Path
import json,struct,zipfile
words=256;source=[0x13570000^(i*17) for i in range(words)]
assert words*4==1024 and len(source[:128])*4==512
checksum=sum(source)&0xffffffff
destination=source.copy();assert destination==source
wrong=bytearray(1024)
for i,value in enumerate(source):wrong[4*i:4*i+4]=value.to_bytes(4,'little')
assert int.from_bytes(wrong[:4],'little')==source[0]
assert ((0x10-0xfffffff0)&0xffffffff)==32
value=1
for i in range(1024):value=(value*1664525+1013904223)&0xffffffff
def inspect(data):
 h=struct.unpack_from('<16sHHIIIIIHHHHHH',data);assert h[0][:6]==b'\x7fELF\x01\x01' and h[2]==40
 sections=[struct.unpack_from('<IIIIIIIIII',data,h[6]+i*h[11]) for i in range(h[12])];symbols={}
 for s in sections:
  if s[1]!=2:continue
  st=sections[s[6]];ss=data[st[4]:st[4]+st[5]]
  for o in range(s[4],s[4]+s[5],s[9]):
   n,a,z,info,other,index=struct.unpack_from('<IIIBBH',data,o);name=ss[n:ss.find(b'\0',n)].decode()
   if name in ['dma_source','cpu_destination','dma_destination']:
    assert z==1024 and a%4==0 and 0x20000000<=a and a+z<=0x20008000
    symbols[name]={'address':hex(a),'bytes':z,'alignment4':True,'in_main_SRAM_not_CCM':True}
 assert len(symbols)==3;return symbols
root=Path(__file__).parent
with zipfile.ZipFile(root/'lesson-14-build-artifacts.zip') as z:elf={n:inspect(z.read(n)) for n in z.namelist() if n.endswith('.elf')}
result={'scope':'Array arithmetic and offline inspection of actual linked ELF; no DMA run or cycle measurement','words':words,'bytes_per_copy':1024,'half_transfer_bytes':512,'expected_sum32':checksum,'foreground_LCG1024_expected':value,'MEM2MEM_with_Circular_allowed':False,'checks_passed':['word/byte count','half transfer size','copy content expectation','little-endian word layout','uint32 cycle wrap','foreground workload expected result','actual ELF arrays in aligned SRAM notCCM'],'ELF':elf,'measured_cycles':None}
(root/'model-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

"""Editable original educational diagrams. Requires Pillow and Windows Segoe UI.
All timelines and waveforms are models, never captured hardware results.
Regenerates only this lesson's PNGs and image-metadata.json beside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, json, textwrap
OUT=Path(__file__).resolve().parent
LESSON=14
W,H=1200,1800
INK='#16354b';TEAL='#087f8c';ORANGE='#ac5c18';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c7d7e1';PALE='#e3f1f2';WHITE='#ffffff'
def font(n=43,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if bold else '')+'.ttf',n)
def tx(d,x,y,s,n=43,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1060,n=43,c=INK,b=False,gap=12):
    words=s.split();lines=[];line=''
    for word in words:
        test=(line+' '+word).strip()
        if d.textlength(test,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,sub='Original diagram / synthetic model'):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,38,title,1090,52,b=True)
    para(d,55,y+10,sub,1090,38,c=MUTED)
    d.line((55,185,1145,185),fill=LINE,width=3)
    return im,d
def footer(d,s='STM32F303CBT6 | Official manuals + exact F3 HAL'):
    d.line((55,H-165,1145,H-165),fill=LINE,width=3)
    para(d,55,H-140,s,1090,33,c=MUTED,gap=6)
    tx(d,55,H-50,'Original model. No board measurement or GUI capture.',32,MUTED)
def arrow(d,pts,c=TEAL,width=7):
    d.line(pts,fill=c,width=width)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),radius=18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+13,s,w-48,42)
    assert yy-18<=y+h+5,(title,yy,y+h)
def note(d,y,s,c=INK):return para(d,65,y,s,1070,43,c)
def save(im,i):im.save(OUT/f'lesson{LESSON}-figure{i}.png',optimize=True)
def axis(d,x0=160,y0=1150,x1=1110,y1=340,xlabel='Time ->',ylabel=None):
    arrow(d,[(x0,y0),(x1,y0)],INK,4);arrow(d,[(x0,y0),(x0,y1)],INK,4)
    tx(d,x1-230,y0+95,xlabel,39)
    if ylabel:tx(d,65,y1-70,ylabel,42,b=True)
def dots(d,x,y,count,active=None,step=70):
    for k in range(count):
        color=TEAL if active is None or k in active else LINE
        d.rounded_rectangle((x+k*step,y,x+k*step+step-9,y+70),8,fill=color)
def step(d,events,xmap,yhi,ylo,c=TEAL,width=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,yhi if last else ylo),(x,yhi if v else ylo)]);last=v
    d.line(pts,fill=c,width=width)
def ring(d,cx,cy,r=310,n=16,start=3,end=11):
    # Sectors represent groups of bytes, not a false256-cell screenshot.
    for k in range(n):
        d.pieslice((cx-r,cy-r,cx+r,cy+r),k*360/n-90,(k+1)*360/n-90,fill=TEAL if start<=k<end else '#dce7ee',outline=BG,width=5)
    d.ellipse((cx-r+100,cy-r+100,cx+r-100,cy+r-100),fill=BG)
def lineplot(d,points,x0,y0,xscale,yscale,c=TEAL):
    d.line([(x0+x*xscale,y0-y*yscale) for x,y in points],fill=c,width=7)


def lesson14():
    im,d=begin('DMA is another bus master','Simplified access model, not a copied bus-matrix layout')
    for x,a in [(65,'CPU'),(455,'DMA1'),(845,'DMA2')]:panel(d,x,245,290,150,a,())
    for x in [210,600,990]:arrow(d,[(x,410),(x,610)])
    d.rounded_rectangle((85,630,1115,790),20,fill=TEAL)
    tx(d,285,675,'AHB interconnect / arbitration',44,'white',True)
    for x,a in [(65,'Flash'),(455,'SRAM'),(845,'APB bridge')]:
        arrow(d,[(x+145,810),(x+145,1010)]);panel(d,x,1030,290,150,a,())
    note(d,1300,'CPU and DMA can compete for the same memory or peripheral route. Separate engines do not imply infinite parallel bandwidth.')
    note(d,1450,'Access depends on the exact F303 device and DMA transfer configuration.',ORANGE)
    footer(d,'RM0316 memory architecture + DMA. Diagram omits unrelated buses.');save(im,1)

    im,d=begin('Main SRAM and CCM have different routes')
    panel(d,75,240,1050,160,'Cortex-M4 CPU',['Different CPU paths reach different memory regions.'])
    arrow(d,[(350,420),(350,590)]);arrow(d,[(850,420),(850,590)],ORANGE)
    panel(d,65,610,520,290,'Main SRAM',['0x20000000','DMA-accessible SRAM','32KiB on this part'])
    panel(d,615,610,520,290,'CCM RAM',['0x10000000','CPU-coupled memory','8KiB on this part'],ORANGE)
    panel(d,75,1150,1050,165,'DMA controller',['Place source and destination in supported regions.'])
    arrow(d,[(300,1130),(300,900)])
    d.line((870,1130,870,925),fill=RED,width=7)
    for off in [-20,20]:d.line((835,950+off,905,1020-off),fill=RED,width=8)
    tx(d,650,1050,'No DMA route',43,RED,True)
    note(d,1420,'Unsupported CCM transfer is not a promise of one particular observed fault. Do not run an unsafe address experiment automatically.')
    footer(d,'DS9118 device memory sizes + RM0316 access rules.');save(im,2)

    im,d=begin('DMA descriptors count items, not bytes')
    tx(d,65,235,'CCR controls width, increment and direction.',45,b=True)
    fields=[('MEM2MEM','Memory-to-memory mode'),('PL','Arbitration priority'),('MSIZE / PSIZE','Memory / peripheral item widths'),('MINC / PINC','Address increment switches'),('DIR / CIRC','Direction / circular mode'),('TCIE / HTIE / TEIE','Interrupt enables')]
    for k,(a,b) in enumerate(fields):
        y=355+k*140;d.rectangle((70,y,400,y+100),fill=TEAL)
        tx(d,88,y+23,a,38,'white',True);para(d,430,y+20,b,690,42)
    panel(d,70,1245,1060,275,'Addresses + count',['CPAR / CMAR: roles depend on DIR and mode.','CNDTR: remaining items','Project:256 words x4 bytes =1024 bytes'])
    footer(d,'Never treat CPAR as source for every possible DMA direction.');save(im,3)

    im,d=begin('Normal stops; Circular reloads','Conceptual peripheral stream; memory-to-memory is Normal')
    tx(d,70,240,'NORMAL',48,TEAL,True);dots(d,90,350,12,step=85)
    arrow(d,[(95,510),(1085,510)]);tx(d,70,575,'N items -> CNDTR0 -> transfer complete',43)
    tx(d,70,660,'No automatic next-buffer replay.',43,ORANGE,True)
    tx(d,70,860,'CIRCULAR',48,TEAL,True);dots(d,90,970,12,step=85)
    arrow(d,[(95,1130),(1085,1130)])
    arrow(d,[(1085,1150),(1085,1260),(95,1260),(95,1150)])
    tx(d,280,1320,'Reload count and addresses',45,TEAL,True)
    note(d,1440,'MEM2MEM and CIRC must not be enabled together on this DMA. Circular operation still needs timely software consumption.',RED)
    footer(d,'RM0316 DMA normal/circular behavior; no double-buffer hardware claim.');save(im,4)

    im,d=begin('DMA flags describe different events','EvenN example | Progress axis is transferred items')
    x=lambda k:150+k*900
    axis(d,150,660,1110,340,'Progress ->')
    for k,a,b in [(0,'0','CNDTR=N'),(.5,'N/2','HTIF'),(1,'N','TCIF')]:
        xx=x(k);d.line((xx,380,xx,660),fill=TEAL,width=5);tx(d,xx-30,700,a,43,b=True)
        tx(d,max(70,xx-95),830,b,43,TEAL,True)
    arrow(d,[(600,930),(600,1030)])
    panel(d,70,1050,1060,230,'HAL_DMA_IRQHandler',['Check enabled HT / TC / TE flag paths.','Clear handled flags and dispatch callbacks.'])
    d.line((200,1440,1000,1440),fill=RED,width=7)
    tx(d,175,1340,'TEIF: transfer error can interrupt progress.',43,RED,True)
    tx(d,70,1500,'A single flag is not a counter of missed full cycles.',42)
    footer(d,'HT/TC shown for evenN; IRQ delivery depends on enables/NVIC.');save(im,5)

    im,d=begin('Compare the same end-to-end operation','Event-order model | Durations not to scale')
    for base,label,color in [(270,'CPU memcpy',ORANGE),(850,'DMA copy',TEAL)]:
        tx(d,70,base,label,48,color,True)
        d.line((100,base+250,1100,base+250),fill=INK,width=4)
        for x,a in [(130,'DWT c0'),(950,'DWT c1')]:
            d.line((x,base+95,x,base+280),fill=color,width=5);tx(d,x-65,base+320,a,40,color,True)
        if label.startswith('CPU'):
            d.rectangle((160,base+130,925,base+220),fill=color);tx(d,360,base+150,'CPU performs copy',42,'white',True)
        else:
            d.rectangle((160,base+130,360,base+220),fill=color);tx(d,170,base+150,'Setup',42,'white',True)
            d.rectangle((390,base+130,925,base+220),fill=PALE);tx(d,435,base+150,'DMA moves items',42,color,True)
    note(d,1420,'Measure setup + completion, use identical buffers and length, and verify copied data. CPU cycles and wall time answer different questions.')
    footer(d,'IRQ/polling completion, bus contention and optimization affect results.');save(im,6)

def run():
    globals()[f'lesson{LESSON}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')



METADATA=[{'id': 1, 'filename': 'lesson14-figure1.png', 'alt': 'مسیرهای CPU و DMA در گذرگاه حافظه', 'caption': 'نمودار معماری تألیفی و ساده\u200cشدهٔ CPU و DMA1 و DMA2 به حافظه و پریفرال؛ مسیر مشترک می\u200cتواند رقابت و توقف ایجاد کند. جزئیات غیرمرتبط حذف شده\u200cاند و شکل رسمی سازنده بازنشر نشده است.', 'purpose': 'DMA و CPU چگونه برای دسترسی به حافظه و پریفرال مسیر مشترک دارند؟', 'placement': 'بخش معماری کنترلر DMA در STM32F303 و ماتریس گذرگاه', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 2, 'filename': 'lesson14-figure2.png', 'alt': 'مسیرهای متفاوت SRAM اصلی و CCM RAM', 'caption': 'نمودار تألیفی برای STM32F303CBT6: SRAM اصلی 32KiB در ناحیهٔ 0x20000000 برای DMA قابل دسترس است؛ CCM برابر 8KiB در 0x10000000 مسیر DMA ندارد. انتقال نامعتبر به معنی تضمین یک HardFault مشاهده\u200cشده نیست و آزمایش خودکار نامعتبر پیشنهاد نمی\u200cشود.', 'purpose': 'چرا CCM این تراشه برای بافر DMA مناسب نیست؟', 'placement': 'بخش تفاوت توپولوژی گذرگاهی SRAM و حافظه CCM RAM', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 3, 'filename': 'lesson14-figure3.png', 'alt': 'فیلدهای پیکربندی DMA و معنای شمارندهٔ آیتم', 'caption': 'نمای تألیفی گروه\u200cبندی فیلدهای CCR و آدرس\u200cها؛ نقش CPAR و CMAR به جهت و حالت انتقال وابسته است و CNDTR تعداد آیتم\u200cهای باقی\u200cمانده را می\u200cشمارد. در پروژهٔ واقعی 256 آیتم 4 بایتی برابر 1024 بایت است؛ این نما اسکرین\u200cشات رجیستر نیست.', 'purpose': 'عرض آیتم و آدرس و CNDTR در انتقال DMA چه معنایی دارند؟', 'placement': 'بخش پارامترها و ثبات\u200cهای پیکربندی کانال DMA', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 4, 'filename': 'lesson14-figure4.png', 'alt': 'تفاوت توقف Normal با بازگردش Circular', 'caption': 'نمودار تألیفی حرکت آیتم\u200cها و بازگشت آدرس و شمارنده در حالت Circular؛ حالت MEM2MEM و Circular هم\u200cزمان مجاز نیستند. بازگردش DMA جای مصرف به\u200cموقع داده توسط برنامه را نمی\u200cگیرد.', 'purpose': 'چرا Normal و Circular رفتار پایانی متفاوت دارند و MEM2MEM با Circular ترکیب نمی\u200cشود؟', 'placement': 'بخش حالت عادی (Normal) در برابر حلقوی (Circular) و محدودیت انتقال حافظه به حافظه', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 5, 'filename': 'lesson14-figure5.png', 'alt': 'زمان منطقی رخدادهای HT و TC و TE', 'caption': 'مدل تألیفی با طول زوج N؛ رخداد نیمه در N/2 و پایان در N آیتم نمایش داده شده\u200cاند. TE رخداد خطای انتقال است و می\u200cتواند مسیر را متوقف کند؛ تحویل callback به فعال\u200cبودن وقفه و NVIC وابسته است.', 'purpose': 'پرچم\u200cهای HT و TC و TE چه رخدادهایی را توصیف می\u200cکنند؟', 'placement': 'بخش رویدادها، پرچم\u200cها و وقفه\u200cهای DMA', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL commit953955afe65f89e60e556bbcdba752597f5da65d'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}, {'id': 6, 'filename': 'lesson14-figure6.png', 'alt': 'مقایسهٔ بازهٔ کامل کپی با CPU و DMA', 'caption': 'نمودار زمانی تألیفی بدون عدد بنچمارک: محدودهٔ DWT باید هزینهٔ شروع و تکمیل انتقال را پوشش دهد و صحت محتوای کپی نیز بررسی شود. اجرای هم\u200cزمان ممکن به معنی درصد بار CPU ثابت یا برتری قطعی DMA نیست.', 'purpose': 'برای مقایسهٔ کپی CPU و DMA چه بازه\u200cای باید اندازه\u200cگیری و چه نتیجه\u200cای باید بررسی شود؟', 'placement': 'بخش روش\u200cشناسی اندازه\u200cگیری و مقایسه کارایی با memcpy', 'type': 'original explanatory diagram / synthetic model', 'rights': 'Original layout and drawing; no third-party figure reproduced', 'technical_basis': 'DS9118 Rev14; RM0316 DMA/USART/memory; PM0214 Rev10; exact F3 HAL953955afe65f89e60e556bbcdba752597f5da65d; GB100ST V2.0 where relevant', 'physical_measurement': False, 'AI_generated_image': False, 'source': 'Original Pillow drawing by Codex, based on official facts and actual lesson project', 'status': 'prepared-for-Codex-visual-review', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316; inspected facts, no unverified revision/page citation'}], 'provenance': 'Programmatically drawn with Pillow from original Codex-authored geometry; no AI raster generation and no official figure copied.', 'visual_review': 'Codex helper viewed the real390px contact sheet; root final review/publication is separate. No Antigravity image-viewing claim.'}]
if __name__=='__main__':run()

"""Six original course teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson{LESSON}-course-figure{n}.png',optimize=True)

LESSON=25

def figure1():
    im,d=begin('A phase index selects a stored sine code','Actual N 100 table:round(2048 +1536 x sin(2pi x i/N))')
    cx,cy,r=300,650,215
    d.ellipse((cx-r,cy-r,cx+r,cy+r),outline=LINE,width=4)
    for i in range(100):
        a=2*math.pi*i/100;xx=cx+r*math.cos(a);yy=cy-r*math.sin(a);d.ellipse((xx-4,yy-4,xx+4,yy+4),fill=TEAL)
    tx(d,170,600,'100 phases',44,TEAL,True);tx(d,155,675,'3.6deg /step',40)
    arrow(d,[(545,800),(640,800)],INK,5)
    x=lambda i:670+i*4.3;y=lambda code:930-(code-512)/3072*550
    d.line((670,350,670,970,1125,970),fill=INK,width=4)
    tx(d,675,285,'Code',43,b=True)
    for code in [512,2048,3584]:
        dashed(d,670,y(code),1100,y(code),LINE,2);tx(d,550,y(code)-22,str(code),38)
    pts=[]
    for i in range(100):
        code=round(2048+1536*math.sin(2*math.pi*i/100));xx=x(i);yy=y(code);d.ellipse((xx-4,yy-4,xx+4,yy+4),fill=TEAL)
    tx(d,675,1040,'Index 0..99',43,b=True)
    tx(d,65,1170,'Center 2048 | amplitude 1536 codes',47,TEAL,True)
    tx(d,65,1280,'N 100 limits:512..3584',46,b=True)
    tx(d,65,1390,'At assumed 3.3 V:0.4125 V..2.8875 V ideal',43)
    tx(d,65,1510,'Headroom helps; actual loaded output still needs checking.',41,ORANGE)
    foot(d,'Codes are computed LUT values, not measured voltages.');save(im,1)

def figure2():
    im,d=begin('A trigger advances a staged data pipeline','Event-order diagram, not APB-cycle timing or a phase guarantee')
    panel(d,70,265,1060,170,'TIM6 update -> TRGO',['Nominal 100k triggers/s for the N 100 variant.'])
    arrow(d,[(320,455),(320,620)]);arrow(d,[(890,455),(890,620)],ORANGE)
    panel(d,65,640,520,230,'DAC data transfer',['Staged DHR value','moves to DOR'])
    panel(d,615,640,520,230,'DMA request',['DMA2 Channel 3','reads next SRAM value'],ORANGE)
    arrow(d,[(325,890),(325,1040)]);arrow(d,[(875,890),(875,1040)],ORANGE)
    panel(d,65,1060,520,230,'Analog output',['DOR drives conversion','then the PA4 output.'])
    panel(d,615,1060,520,230,'Next DHR value',['Stage the next code','for a later trigger.'],ORANGE)
    para(d,65,1410,'Startup seeds DHR before starting DMA and TIM6. Do not assume the first output sample has a universal phase or latency.',1070,43)
    foot(d,'Event order does not specify a cycle latency.');save(im,2)

def figure3():
    im,d=begin('Frequency = trigger rate / N','Keep one quantity fixed before comparing table lengths')
    tx(d,65,270,'A: fixed trigger rate 100k/s',46,TEAL,True)
    x=lambda ms:380+ms*350
    for row,N in enumerate([50,100,200]):
        y=430+row*235;period=N/100
        tx(d,65,y+25,f'N {N}',46,b=True)
        d.line((380,y+120,1100,y+120),fill=INK,width=3)
        t=period
        while t<=2.0001:
            arrow(d,[(x(t),y+20),(x(t),y+110)],TEAL,4);t+=period
        tx(d,65,y+105,f'{100/N:g}kHz',41,TEAL,True)
    for ms in [0,1,2]:tx(d,x(ms)-10,1110,str(ms),38)
    tx(d,885,1195,'Time (ms)',41,b=True)
    tx(d,65,1300,'B: keep output at 1 kHz',46,ORANGE,True)
    tx(d,65,1390,'N 50 ->50k triggers/s; N 100 ->100k triggers/s',42)
    tx(d,65,1480,'N 200 ->200k triggers/s (calculation only)',42)
    tx(d,65,1560,'The two delivered variants are N 50 and N 100.',41,ORANGE)
    foot(d,'N alone does not improve all analog quality measures.');save(im,3)

def figure4():
    im,d=begin('Match the DMA width to the table','Actual uint16 LUT -> HALFWORD -> DAC DHR12R1')
    panel(d,70,265,1060,185,'Main SRAM table, aligned 4',['uint16 sample:16 bits, containing a 12-bit code'])
    for k in range(16):
        bit=15-k;xx=95+k*63;active=bit<12
        tx(d,xx+8,540,str(bit),38);d.rectangle((xx,625,xx+57,720),fill=TEAL if active else '#dce7ee')
    tx(d,65,790,'Upper 4 bits zero; data code is 0..4095.',44,b=True)
    arrow(d,[(600,885),(600,995)])
    panel(d,70,1015,1060,205,'DMA2 Channel 3: Circular',['Memory increment; HALFWORD on both sides.','Destination:DAC DHR12R1'])
    tx(d,65,1320,'The HAL pointer cast does not choose DMA width.',43,ORANGE,True)
    tx(d,65,1430,'Do not place the DMA table in CCM RAM.',44,RED,True)
    foot(d,'A Cortex-M4 D-cache maintenance routine is not required here.');save(im,4)

def figure5():
    im,d=begin('Reconstruction filtering has trade-offs','Normalized models; not a component design or output capture')
    tx(d,65,265,'One 100-sample cycle: staircase + reference',44,b=True)
    tx(d,65,335,'Amplitude normalized about its DC center',40,MUTED)
    x=lambda i:170+i*9;y=lambda v:590-v*170
    pts=[]
    for i in range(101):
        v=math.sin(2*math.pi*(i%100)/100)
        if i:pts.append((x(i),y(math.sin(2*math.pi*(i-1)/100))))
        pts.append((x(i),y(v)))
    d.line([(x(i/10),y(math.sin(2*math.pi*i/1000)))for i in range(1001)],fill=MUTED,width=3)
    d.line(pts,fill=TEAL,width=5)
    for v in [-1,0,1]:tx(d,65,y(v)-22,str(v),38)
    tx(d,65,800,'Phase 0..1cycle; gray curve is a sine reference.',40)
    tx(d,65,900,'An assumed first-order low-pass magnitude',44,ORANGE,True)
    xx=lambda r:210+(math.log10(r)+1)*420
    yy=lambda gain:1420-gain*390
    d.line((210,1000,210,1460,1120,1460),fill=INK,width=4)
    for v in [0,.5,1]:tx(d,65,yy(v)-22,str(v),38)
    curve=[]
    for j in range(301):
        r=10**(-1+2*j/300);curve.append((xx(r),yy(1/math.sqrt(1+r*r))))
    d.line(curve,fill=ORANGE,width=7)
    for r in [.1,1,10]:tx(d,xx(r)-12,1495,str(r),38)
    tx(d,860,1570,'f /f_c',40,b=True)
    foot(d,'Filter model is not a component prescription.');save(im,5)

def figure6():
    im,d=begin('DAC underrun and DMA error differ','Fault-handling model:stream stops; no auto-restart')
    items=[('Running waveform','TIM6 triggers; DMA stages samples.'),('Underrun or DMA error detected','The matching callback records a fault flag.'),('Return from short ISR','No formatting or restart loop inside the callback.'),('Main stops TIM6 first','Then stop DAC DMA; check operation statuses.'),('Fault remains visible','No automatic restart; reinitialize deliberately.')]
    for k,(a,b) in enumerate(items):
        y=245+k*255;panel(d,75,y,1050,190,a,[b],RED if k==1 else TEAL)
        if k<4:arrow(d,[(600,y+202),(600,y+240)])
    foot(d,'DMA avoids per-sample CPU copies, not all CPU work.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson25-course-figure1.png', 'alt': 'نگاشت فاز به جدول واقعی سینوسی', 'caption': 'نمودار تألیفی جدول N=100 با round(2048+1536sin(2πi/N))؛ کدها512..3584 هستند. با مرجع فرضی3.3 V، بازهٔ ایدئال0.4125..2.8875 V می\u200cشود؛ headroom به معنی تضمین خروجی بار یا دقت آنالوگ نیست. جدول N=50 به\u200cدلیل فازهای گسسته کدهای515..3581 دارد.', 'purpose': 'نگاشت فاز به جدول واقعی سینوسی چگونه تفسیر می\u200cشود؟', 'placement': 'بخش جدول نمونه\u200cها (Lookup Table): ساختار ریاضی و محاسبه مقادیر گسسته سینوسی', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualrebuiltLUTcenter2048amp1536,N 100512..3584,N 50515..3581;u16SRAM;3.3ideal.4125..2.8875;notold1500/1792amplitude/norailsafetyproof.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 2, 'filename': 'lesson25-course-figure2.png', 'alt': 'پایپ\u200cلاین تریگر و دادهٔ مرحله\u200cبندی\u200cشده', 'caption': 'بلوک\u200cدیاگرام تألیفی ترتیب رویداد، نه تعداد سیکل APB: تریگر TIM6، دادهٔ مرحله\u200cبندی\u200cشدهٔ DHR را برای مسیر DOR و خروجی به\u200cکار می\u200cگیرد و DMA نمونهٔ بعد را آماده می\u200cکند. پیش از StartDMA و تایمر، DHR با نمونهٔ آخر جدول seed می\u200cشود؛ شکل تضمین فاز اولین نمونه یا تأخیر یک\u200cسیکل نیست.', 'purpose': 'پایپ\u200cلاین تریگر و دادهٔ مرحله\u200cبندی\u200cشده چگونه تفسیر می\u200cشود؟', 'placement': 'بخش محرک سخت\u200cافزاری و هم\u200cگام\u200cسازی: تریگر DAC با رویداد TRGO در تایمر TIM6', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualpreseedDHRlastLUTsample->StartDACDMA->StartTIM6;stagedDHR/DOR plusDMA2Ch3nextsample;nooneAPBcycle/nofirstphaseguarantee.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 3, 'filename': 'lesson25-course-figure3.png', 'alt': 'رابطهٔ نرخ تریگر و طول جدول', 'caption': 'مدل محاسباتی تألیفی f_out=f_trigger/N؛ در تریگر ثابت100k/s، Nهای50 و100 و200 به\u200cترتیب2 kHz و1 kHz و0.5 kHz می\u200cدهند. برای خروجی1 kHz باید تریگر را متناسب تغییر داد؛ فقط N=50/50k و N=100/100k پروژهٔ تحویل\u200cشده\u200cاند و N=200 محاسبات آموزشی است.', 'purpose': 'رابطهٔ نرخ تریگر و طول جدول چگونه تفسیر می\u200cشود؟', 'placement': 'بخش رابطه ریاضی فرکانس خروجی و مصالحه بین تعداد نمونه\u200cها (N) و کیفیت موج', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'N 100TIM6PSC71ARR9=>100k/1001k,N 50PSC71ARR19=>50k/501k;fixed100k N 50=>2k N 1001k N 200.5k;N 200calculationonly,notunqualifiedqualityclaim.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 4, 'filename': 'lesson25-course-figure4.png', 'alt': 'انطباق uint16 با عرض Halfword در DMA', 'caption': 'نمای تألیفی مسیر واقعی جدول uint16 هم\u200cتراز4 در SRAM اصلی، DMA2 Channel 3 با Halfword در هر دو سمت و رجیستر DHR12R1؛ cast اشاره\u200cگر API تعیین\u200cکنندهٔ عرض سخت\u200cافزاری انتقال نیست. جدول در CCM قرار نگیرد و روتین نگهداری D-cache از خانواده\u200cهای دیگر وارد نشود.', 'purpose': 'انطباق uint16 با عرض Halfword در DMA چگونه تفسیر می\u200cشود؟', 'placement': 'بخش انتقال خودکار داده با DMA در حالت چرخشی (Circular Mode)', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualDMA2Ch3CircularMINCHALFWORDboth,aligned 4staticu16mainSRAMnotCCM;HALuint32pointercastnotDMA32width;lower12codewithin16word,noM4Dcachemaintenance.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 5, 'filename': 'lesson25-course-figure5.png', 'alt': 'پله\u200cهای DAC و مدل نرمال فیلتر بازسازی', 'caption': 'نمودار تألیفی یک چرخهٔ100نمونه\u200cای با دامنهٔ حول مرکز DC نرمال\u200cشده؛ خط مرجع سینوسی نتیجهٔ فیلتر یا اسکوپ نیست. بخش پایین پاسخ اندازهٔ یک پایین\u200cگذر مرتبهٔاول فرضی را برحسب f/fc نشان می\u200cدهد؛ طرح R/C واقعی یا اتصال مستقیم1.5k/10nF و حذف کامل تصاویر فرکانسی پیشنهاد نمی\u200cشود.', 'purpose': 'پله\u200cهای DAC و مدل نرمال فیلتر بازسازی چگونه تفسیر می\u200cشود؟', 'placement': 'بخش پدیده\u200cهای آنالوگ: اثر پله\u200cای نگه\u200cدارنده مرتبه صفر و فیلتر بازسازی (Reconstruction Filter)', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'NormalizedcenteredN 100staircase+analyticreference,notnegativephysicalpinvoltage;assumedLPF1/sqrt(1+(f/fc)^2),notcomponentdesign/no1.5k10nFdirectDACload/noAN4566Rev2claim.', 'status': 'prepared-awaiting-final-visual-review'}, {'id': 6, 'filename': 'lesson25-course-figure6.png', 'alt': 'توقف جریان پس از underrun یا خطای DMA', 'caption': 'فلوچارت تألیفی سیاست واقعی: callback مربوط خطا را ثبت می\u200cکند؛ main ابتدا TIM6 و سپس DAC DMA را متوقف و نتیجهٔ عملیات را بررسی می\u200cکند. Underrun با خطای DMA یکی نیست و راه\u200cاندازی دوبارهٔ خودکار وجود ندارد؛ DMA همهٔ کار CPU را حذف نمی\u200cکند.', 'purpose': 'توقف جریان پس از underrun یا خطای DMA چگونه تفسیر می\u200cشود؟', 'placement': 'بخش تله\u200cهای رایج، خطای سرریز منفی (Underrun) و اصول عیب\u200cیابی', 'type': 'original explanatory diagram / synthetic model', 'source': 'Codex original Pillow geometry from actual project and primary facts', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision', 'scope': 'DAC, DHR/DOR and trigger; DAC formula section16.5.3'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'DAC Table 75 conditions and pin map'}, {'url': 'https://www.st.com/resource/en/application_note/an3126-audio-and-waveform-generation-using-the-dac-in-stm32-products-stmicroelectronics.pdf', 'version': 'AN3126 Rev6 October2026', 'scope': 'DAC formula/format/waveform concepts; no figure layout copied'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'DAC start/stop/DMA/error callbacks'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Power and PA4/PA5 signals'}], 'rights': 'Original drawing; no official layout copied or invented CC license; fontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualUDRorDMAerrorcallbacksrecordfault;mainStopTIM6thenHAL_DAC_Stop_DMAchecked;NOautorestart;deliberatereinit;notzeroCPU/bandwidthcost.', 'status': 'prepared-awaiting-final-visual-review'}]
if __name__=='__main__':run()

"""Rebuild integer LUTs and ideal timing; not scope data or analog distortion tests."""
from pathlib import Path
import math,json
root=Path(__file__).resolve().parent
checks={};tables={}
def test(n,c):checks[n]=bool(c);assert c,n
for N,arr in [(100,9),(50,19)]:
    values=[math.floor(2048+1536*math.sin(2*math.pi*i/N)+0.5) for i in range(N)]
    actual=json.loads((root/('sine-lut-'+str(N)+'.json')).read_text())
    test('exact_firmware_LUT_'+str(N),values==actual)
    test('12bit_range_'+str(N),all(0<=x<=4095 for x in values))
    fs=72_000_000/(71+1)/(arr+1)
    test('same_1kHz_'+str(N),fs/N==1000)
    test('nominal_3p3_headroom_'+str(N),min(values)*3.3/4096>0.2 and max(values)*3.3/4096<3.1)
    test('2p4_headroom_'+str(N),min(values)*2.4/4096>0.2 and max(values)*2.4/4096<2.2)
    test('fullscale_settling_max_fits_interval_'+str(N),4e-6<1/fs)
    tables[str(N)]={'N':N,'PSC':71,'ARR':arr,'trigger_hz':fs,'table_frequency_hz':fs/N,'sample_interval_us':1e6/fs,'LUT_min':min(values),'LUT_max':max(values),'ideal_nominal3p3_min_V':min(values)*3.3/4096,'ideal_nominal3p3_max_V':max(values)*3.3/4096,'DMA_half_callbacks_per_s':fs/(N/2),'DMA_full_callbacks_per_s':fs/N,'actual_frequency':None}
test('N100_minmax',min(json.loads((root/'sine-lut-100.json').read_text()))==512 and max(json.loads((root/'sine-lut-100.json').read_text()))==3584)
test('N50_minmax',min(json.loads((root/'sine-lut-50.json').read_text()))==515 and max(json.loads((root/'sine-lut-50.json').read_text()))==3581)
print(json.dumps({'model_only':True,'checks':checks,'passed_checks':len(checks),'LUT_formula':'floor(2048 + 1536*sin(2*pi*i/N) + 0.5), i0..N-1','reference_V_nominal':3.3,'transfer_denominator':4096,'settling_condition':'Datasheet max4us for fullscale step to1LSB when Rload>=5kohm Cload<=50pF; does not establish measured waveform quality.','tables':tables,'triangle_noise_modes':'concept only; not implemented in these firmware projects','scope_data':None},indent=2))

"""Small stdlib ELF32/little-endian ARM inspector; no target execution."""
import struct
def inspect(data):
 assert data[:6] == b'\x7fELF\x01\x01'
 assert struct.unpack_from('<HH',data,16) == (2,40)
 phoff,shoff=struct.unpack_from('<II',data,28)
 phsize,phnum,shsize,shnum,shstr=struct.unpack_from('<HHHHH',data,42)
 ph=[struct.unpack_from('<IIIIIIII',data,phoff+i*phsize) for i in range(phnum)]
 sh=[struct.unpack_from('<IIIIIIIIII',data,shoff+i*shsize) for i in range(shnum)]
 def string(blob,off):return blob[off:].split(b'\0',1)[0].decode()
 names=data[sh[shstr][4]:sh[shstr][4]+sh[shstr][5]]
 sections=[];symbols={}
 for h in sh:
  lma=None
  if h[1]!=8 and h[2]&2:
   for p in ph:
    if p[0]==1 and p[1]<=h[4] and h[4]+h[5]<=p[1]+p[4]:
     lma=p[3]+h[4]-p[1];break
  sections.append(dict(name=string(names,h[0]),type=h[1],flags=h[2],VMA=h[3],size=h[5],file_offset=h[4],LMA=lma))
  if h[1]==2:
   st=sh[h[6]];strings=data[st[4]:st[4]+st[5]]
   for off in range(h[4],h[4]+h[5],h[9]):
    name,value,size,info,other,index=struct.unpack_from('<IIIBBH',data,off)
    label=string(strings,name)
    if label:symbols[label]=dict(address=value,size=size,section_index=index)
 return dict(sections=sections,symbols=symbols,segments=[dict(type=p[0],offset=p[1],VMA=p[2],physical_address=p[3],file_size=p[4],memory_size=p[5],flags=p[6]) for p in ph])

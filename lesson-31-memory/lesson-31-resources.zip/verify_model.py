"""Archive/source/ELF checks and conceptual initialization model. No MCU execution."""
from pathlib import Path
import json,zipfile,hashlib,struct,sys
sys.dont_write_bytecode=True
from inspect_elf import inspect
P=Path(__file__).resolve().parent
meta=json.loads((P/'toolchain-and-validation.json').read_text());name=meta['project'];checks=[]
def check(label,value):
 assert value,label
 checks.append(label)
with zipfile.ZipFile(P/'lesson-31-projects.zip') as z:
 check('sourceZIP CRC',z.testzip() is None)
 hashes=json.loads((P/'source-manifest.json').read_text())
 check('all sourceSHA256',all(hashlib.sha256(z.read(name+'/'+p)).hexdigest()==v for p,v in hashes.items()))
 check('component licenses',all(name+'/'+x in z.namelist() for x in meta['component_licenses']))
 main=z.read(name+'/Core/Src/main.c').decode();startup=z.read(name+'/startup_stm32f303xc.s').decode();ld=z.read(name+'/STM32F303XX_FLASH.ld').decode()
 check('first application action CCM init',main.index('CCM_Initialize();')<main.index('HAL_Init();'))
 check('actual startup order',startup.index('bl  SystemInit')<startup.index('CopyDataInit:')<startup.index('FillZerobss:')<startup.index('bl __libc_init_array')<startup.index('bl\tmain'))
 check('generated startup has no CCMcopy','_sccmram' not in startup)
 check('explicit CCM copy and zero source',all(x in main for x in ['(uintptr_t)&_siccmram','(uintptr_t)&_sccm_bss','*(volatile uint8_t *)target++ = 0U','__DSB()']))
 check('custom zero section NOLOAD','.ccm_bss (NOLOAD)' in ld)
 check('actual clocksource',all(s in main for s in ['RCC_HSE_PREDIV_DIV1','RCC_PLL_MUL9','RCC_HCLK_DIV2','FLASH_LATENCY_2']))
with zipfile.ZipFile(P/'lesson-31-build-artifacts.zip') as z:
 check('artifactZIP CRC',z.testzip() is None)
 elf=z.read(name+'/'+name+'.elf');check('ELF SHA256',hashlib.sha256(elf).hexdigest()==meta['ELF_SHA256']);report=inspect(elf)
sections={s['name']:s for s in report['sections']};symbols=report['symbols']
check('debug info present','.debug_info' in sections and '.debug_line' in sections)
for label,section,size in [('demo_data','.data',4),('main_buffer','.bss',256),('lookup_table','.rodata',16),('ccm_initialized','.ccmram',256),('ccm_zeroed','.ccm_bss',256)]:
 s=symbols[label];check(label+' section and size',report['sections'][s['section_index']]['name']==section and s['size']==size)
check('CCM initialized VMA and LMA',sections['.ccmram']['VMA']==0x10000000 and sections['.ccmram']['LMA']==0x0800211c and sections['.ccmram']['size']==256)
check('CCM NOLOAD zero section',sections['.ccm_bss']['type']==8 and sections['.ccm_bss']['VMA']==0x10000100 and sections['.ccm_bss']['size']==256)
check('stack starts at end mainRAM',symbols['_estack']['address']==0x20008000)
check('mainRAM accounting',sum(sections[s]['size'] for s in ['.data','.bss','._user_heap_stack'])==1856)
check('separate CCM accounting',sections['.ccmram']['size']+sections['.ccm_bss']['size']==512)
check('copy source symbol matches ELFload',symbols['_siccmram']['address']==sections['.ccmram']['LMA'])
image=elf[sections['.ccmram']['file_offset']:sections['.ccmram']['file_offset']+256]
check('initializer load image exact',struct.unpack('<64I',image)==tuple([0x11223344,0x55667788]+[0]*62))
# Model only: byte copies/zeroing demonstrate initialization semantics, not target run.
ram=bytearray([0xA5]*512);ram[:256]=image;ram[256:]=bytes(256)
check('conceptual copy zero model',ram[:256]==image and ram[256:]==bytes(256))
check('compileflag evidence',all(s in meta['main_compile_command'] for s in ['-O0','-g3','-Wall','-Werror']))
selected={x:symbols[x] for x in ['demo_data','main_buffer','lookup_table','ccm_initialized','ccm_zeroed','_sidata','_sdata','_edata','_sbss','_ebss','_siccmram','_sccmram','_eccmram','_sccm_bss','_eccm_bss','_estack','CCM_Initialize']}
(P/'elf-placement.json').write_text(json.dumps(dict(sections=[s for s in report['sections'] if s['flags']&2],symbols=selected,segments=report['segments']),indent=2)+'\n')
result=dict(scope='Offline source/archive/ELF checks and conceptual byte-copy model, not MCU/GUI/debugger execution or stack-peak measurement.',passed=len(checks),checks=checks,values=dict(mainRAM_reserved_bytes=1856,CCM_bytes=512,Flash_payload_bytes=8732,heap_bytes=512,stack_min_bytes=1024,alignment_padding_bytes=4,expected_sum=100,expected_initialization_ok=1))
(P/'model-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent



LESSON=31
def save(im,n):im.save(OUT/f'lesson31-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Separate memory regions and access paths','Functional access diagram, not a copied bus-fabric schematic or performance result')
 panel(d,75,290,470,170,'Cortex-M4 CPU',());panel(d,655,290,470,170,'DMA1 / DMA2',())
 arrow(d,[(310,480),(310,600),(600,600),(600,710)]);arrow(d,[(890,480),(890,600),(600,600)])
 panel(d,75,730,1050,210,'System-accessible resources',['Flash / main SRAM / memory-mapped peripherals'])
 arrow(d,[(310,480),(55,480),(55,1170),(260,1170)])
 panel(d,280,1080,845,280,'CCM RAM: CPU only',['8 KiB: 0x10000000 .. 0x10001FFF','Separate from 32 KiB main SRAM.'])
 dashed(d,890,480,1145,480,RED);dashed(d,1145,480,1145,1180,RED)
 d.line((1100,1080,1170,1150),fill=RED,width=8);d.line((1170,1080,1100,1150),fill=RED,width=8)
 panel(d,75,1450,1050,150,'DMA buffers belong in DMA-accessible memory',())
 foot(d,'Simplified access paths, not private I-Code / D-Code wiring.');save(im,1)
def figure2():
 im,d=begin('Stored bytes and runtime addresses differ','Conceptual section layout; box heights are not linked byte counts')
 tx(d,75,285,'Flash storage',46,TEAL,True);tx(d,680,285,'Runtime location',46,TEAL,True)
 rows=[('.isr_vector / .text','Flash VMA'),('.rodata','Flash VMA'),('.data load image','SRAM .data VMA'),('No stored initializer','SRAM .bss: zero')]
 for k,(a,b)in enumerate(rows):
  yy=420+k*230;panel(d,65,yy,470,180,a,());panel(d,665,yy,470,180,b,())
  if k==2:arrow(d,[(550,yy+90),(650,yy+90)])
 tx(d,75,1370,'LMA = load address',44,TEAL,True);tx(d,680,1370,'VMA = runtime address',42,TEAL,True)
 panel(d,75,1460,1050,155,'Stack / heap reservation is not measured peak use',())
 foot(d,'.data uses Flash AND RAM; .bss has no load image.');save(im,2)
def figure3():
 im,d=begin('Follow the actual reset startup order','Generated startup initializes ordinary data; the new CCM section needs explicit care')
 seq=[('Reset vectors -> initial SP / Reset_Handler','Generated Reset_Handler also sets SP.'),('SystemInit','Runs before the generated .data copy loop.'),('Copy ordinary .data; zero ordinary .bss','_sidata -> _sdata.._edata; zero _sbss.._ebss'),('__libc_init_array -> main','C / C++ library initialization precedes main.'),('Early USER initialization of CCM','Copy / zero required CCM storage before first use.')]
 for k,(a,b)in enumerate(seq):
  yy=285+k*260;panel(d,75,yy,1050,220,a,[b])
  if k<4:arrow(d,[(600,yy+225),(600,yy+250)])
 foot(d,'A section attribute does not add a startup copy loop.');save(im,3)
def figure4():
 im,d=begin('Link sections, then inspect the map','Original linker-to-output diagram; symbol evidence comes from the ELF audit')
 panel(d,75,290,1050,230,'MEMORY defines capacity and origins',['FLASH: 0x08000000 / 128 KiB','RAM: 0x20000000 / 32 KiB; CCM: 0x10000000 / 8 KiB'])
 arrow(d,[(600,540),(600,610)])
 panel(d,75,630,1050,240,'SECTIONS assigns output placement',['.ccmram > CCMRAM AT> FLASH','VMA in CCM; LMA holds the initial bytes in Flash.'])
 arrow(d,[(600,890),(600,960)])
 panel(d,75,980,1050,240,'ELF / MAP: linked evidence',['Section VMA / LMA / size and symbol addresses.','Check the load segments, not only the C attribute.'])
 panel(d,75,1360,1050,255,'Capacity checks have limits',['Reservation checks do not monitor runtime stack.','Link success does not prove physical execution.'])
 foot(d,'Diagram labels explain syntax; they are not a fake map screenshot.');save(im,4)
def figure5():
 im,d=begin('CCM initialization is your responsibility','The generated linker already has .ccmram; generated startup does not copy it')
 panel(d,75,290,1050,210,'Declare storage in the CCM section',['section(".ccmram") selects placement, not initialization.'])
 arrow(d,[(600,520),(600,590)])
 panel(d,75,610,1050,225,'Flash load image: _siccmram',['LOADADDR(.ccmram) locates the stored initializer.'])
 arrow(d,[(600,855),(600,930)])
 panel(d,75,950,1050,250,'Explicit USER copy before use',['_siccmram -> _sccmram .. _eccmram','Custom NOLOAD storage needs its own zero loop.'])
 arrow(d,[(600,1220),(600,1290)])
 panel(d,75,1310,1050,295,'Only then use the CCM data',['Copy initializers; separately zero NOLOAD.','No DMA access or guaranteed speed-up.','Missing initialization need not cause a HardFault.'])
 foot(d,'The application initialization is separate from generated startup.');save(im,5)
def figure6():
 im,d=begin('Prove placement before claiming execution','ELF / MAP are build evidence; debugger and hardware observations remain separate')
 fields=[('1. Actual initialized CCM symbol','ccm_initialized = 0x10000000; size 256 B'),('2. Actual Flash load image','CCM LMA = 0x0800211C; size 256 B'),('3. Actual NOLOAD zeroed CCM symbol','ccm_zeroed = 0x10000100; size 256 B'),('4. Record a separate board observation','Address / value / reset path / tool version when tested.')]
 for k,(a,b)in enumerate(fields):
  yy=300+k*295;panel(d,75,yy,1050,225,a,[b])
  if k<3:arrow(d,[(600,yy+235),(600,yy+280)])
 panel(d,75,1500,1050,110,'No DMA fault or performance test was run.',())
 foot(d,'A blank debugger worksheet is not a completed hardware test.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson31-refresh-figure1.png', 'alt': 'حافظه\u200cهای جدا و محدودیت دسترسی DMA', 'caption': 'نمودار عملکردی تألیفی دسترسی CPU و DMA، نه کپی معماری باس: CCM برابر 8 KiB در 0x10000000..0x10001FFF و جدا از SRAM اصلی 32 KiB است. CPU به CCM دسترسی دارد ولی DMA این تراشه به آن مسیر ندارد. شکل سیم\u200cبندی خصوصی I-Code یا D-Code و برتری عملکرد اندازه\u200cگیری\u200cشده را ادعا نمی\u200cکند.', 'purpose': 'حافظه\u200cهای جدا و محدودیت دسترسی DMA', 'placement': 'بخش 1، پس از مقایسه ماتریس گذرگاه و نواحی حافظه', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactCB memory capacities'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, targeted memory sections', 'scope': 'Memory region / access concepts, no complete fabric redraw'}, {'url': 'https://sourceware.org/binutils/docs/ld/MEMORY.html', 'version': 'GNU ld official documentation', 'scope': 'Region definitions and capacity limits'}, {'url': 'https://sourceware.org/binutils/docs/ld/Output-Section-LMA.html', 'version': 'GNU ld official documentation', 'scope': 'LMA / VMA and explicit initialization responsibility'}, {'url': 'https://www.st.com/resource/en/application_note/dm00083249.pdf', 'version': 'AN4296 Rev6 April2025, Table2 / section4.1', 'scope': 'F303xB/C CCM8KiB/noDMA and GNUld initialization responsibility; generated startup order is checked separately against actual lesson31 source'}], 'type': 'original explanatory diagram / conceptual memory model', 'source': 'Original Codex Pillow geometry based on accepted AG questions and target/toolchain facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 2, 'filename': 'lesson31-refresh-figure2.png', 'alt': 'تفاوت LMA و VMA و بخش\u200cهای برنامه', 'caption': 'مدل مفهومی تألیفی بخش\u200cها با اندازه\u200cهای غیرمقیاسی: .data هم تصویر اولیه در Flash و هم محل اجرای RAM دارد؛ .bss با صفر مقداردهی می\u200cشود و تصویر اولیه ذخیره\u200cشده ندارد. .text و .rodata معمولاً در Flash قرار دارند. رزرو Stack و Heap اندازه\u200cگیری بیشینهٔ مصرف یا محافظ برخورد خودکار نیست.', 'purpose': 'تفاوت LMA و VMA و بخش\u200cهای برنامه', 'placement': 'بخش 2، پس از توضیح بخش\u200cهای شش\u200cگانه حافظه', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactCB memory capacities'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, targeted memory sections', 'scope': 'Memory region / access concepts, no complete fabric redraw'}, {'url': 'https://sourceware.org/binutils/docs/ld/MEMORY.html', 'version': 'GNU ld official documentation', 'scope': 'Region definitions and capacity limits'}, {'url': 'https://sourceware.org/binutils/docs/ld/Output-Section-LMA.html', 'version': 'GNU ld official documentation', 'scope': 'LMA / VMA and explicit initialization responsibility'}, {'url': 'https://www.st.com/resource/en/application_note/dm00083249.pdf', 'version': 'AN4296 Rev6 April2025, Table2 / section4.1', 'scope': 'F303xB/C CCM8KiB/noDMA and GNUld initialization responsibility; generated startup order is checked separately against actual lesson31 source'}], 'type': 'original explanatory diagram / conceptual memory model', 'source': 'Original Codex Pillow geometry based on accepted AG questions and target/toolchain facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 3, 'filename': 'lesson31-refresh-figure3.png', 'alt': 'ترتیب واقعی راه\u200cانداز و مقداردهی CCM', 'caption': 'روندنمای تألیفی بر اساس ترتیب startup تولیدشدهٔ این هدف: تنظیم SP، SystemInit، کپی .data و صفرکردن .bss، سپس __libc_init_array و main. startup تولیدشده CCM را کپی یا صفر نمی\u200cکند؛ مقداردهی صریح USER باید پیش از نخستین دسترسی به دادهٔ CCM اجرا شود.', 'purpose': 'ترتیب واقعی راه\u200cانداز و مقداردهی CCM', 'placement': 'بخش 3، در شرح مرحله\u200cبه\u200cمرحله Reset_Handler', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactCB memory capacities'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, targeted memory sections', 'scope': 'Memory region / access concepts, no complete fabric redraw'}, {'url': 'https://sourceware.org/binutils/docs/ld/MEMORY.html', 'version': 'GNU ld official documentation', 'scope': 'Region definitions and capacity limits'}, {'url': 'https://sourceware.org/binutils/docs/ld/Output-Section-LMA.html', 'version': 'GNU ld official documentation', 'scope': 'LMA / VMA and explicit initialization responsibility'}, {'url': 'https://www.st.com/resource/en/application_note/dm00083249.pdf', 'version': 'AN4296 Rev6 April2025, Table2 / section4.1', 'scope': 'F303xB/C CCM8KiB/noDMA and GNUld initialization responsibility; generated startup order is checked separately against actual lesson31 source'}], 'type': 'original explanatory diagram / conceptual memory model', 'source': 'Original Codex Pillow geometry based on accepted AG questions and target/toolchain facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 4, 'filename': 'lesson31-refresh-figure4.png', 'alt': 'رابطهٔ linker و شواهد ELF یا MAP', 'caption': 'نمودار تألیفی تعریف MEMORY، تخصیص SECTIONS و بررسی خروجی linker. عبارت .ccmram >CCMRAM AT>FLASH، VMA را در CCM و LMA را در Flash می\u200cگذارد. نشانی واقعی نماد و اندازهٔ بخش باید از ELF یا MAP پروژه خوانده شود؛ شکل اسکرین\u200cشات جعلی map یا اثبات اجرای برد نیست.', 'purpose': 'رابطهٔ linker و شواهد ELF یا MAP', 'placement': 'بخش 4، پس از تشریح ساختار فایل\u200cهای .ld و .map', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactCB memory capacities'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, targeted memory sections', 'scope': 'Memory region / access concepts, no complete fabric redraw'}, {'url': 'https://sourceware.org/binutils/docs/ld/MEMORY.html', 'version': 'GNU ld official documentation', 'scope': 'Region definitions and capacity limits'}, {'url': 'https://sourceware.org/binutils/docs/ld/Output-Section-LMA.html', 'version': 'GNU ld official documentation', 'scope': 'LMA / VMA and explicit initialization responsibility'}, {'url': 'https://www.st.com/resource/en/application_note/dm00083249.pdf', 'version': 'AN4296 Rev6 April2025, Table2 / section4.1', 'scope': 'F303xB/C CCM8KiB/noDMA and GNUld initialization responsibility; generated startup order is checked separately against actual lesson31 source'}], 'type': 'original explanatory diagram / conceptual memory model', 'source': 'Original Codex Pillow geometry based on accepted AG questions and target/toolchain facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 5, 'filename': 'lesson31-refresh-figure5.png', 'alt': 'مسئولیت کپی و صفرکردن CCM', 'caption': 'روندنمای تألیفی: attribute محل بخش را تعیین می\u200cکند اما startup را تغییر نمی\u200cدهد. initializer از _siccmram به _sccmram.._eccmram کپی می\u200cشود و بخش NOLOAD سفارشی در صورت نیاز صفرسازی مستقل می\u200cخواهد. این کار مقداردهی برنامهٔ کاربر است؛ نبود آن الزاماً HardFault ایجاد نمی\u200cکند و هیچ ادعای سرعت یا خطای DMA اندازه\u200cگیری\u200cشده ارائه نشده است. در پروژهٔ ساخته\u200cشده، CCM_Initialize در USER CODE 1 نخستین دستور main و پیش از HAL_Init است؛ داده\u200cها bytewise کپی و بخش NOLOAD صفر و سپس DSB اجرا می\u200cشود.', 'purpose': 'مسئولیت کپی و صفرکردن CCM', 'placement': 'بخش 5، در تشریح روش قرار دادن داده و کد در CCM', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactCB memory capacities'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, targeted memory sections', 'scope': 'Memory region / access concepts, no complete fabric redraw'}, {'url': 'https://sourceware.org/binutils/docs/ld/MEMORY.html', 'version': 'GNU ld official documentation', 'scope': 'Region definitions and capacity limits'}, {'url': 'https://sourceware.org/binutils/docs/ld/Output-Section-LMA.html', 'version': 'GNU ld official documentation', 'scope': 'LMA / VMA and explicit initialization responsibility'}, {'url': 'https://www.st.com/resource/en/application_note/dm00083249.pdf', 'version': 'AN4296 Rev6 April2025, Table2 / section4.1', 'scope': 'F303xB/C CCM8KiB/noDMA and GNUld initialization responsibility; generated startup order is checked separately against actual lesson31 source'}], 'type': 'original explanatory diagram / conceptual memory model', 'source': 'Original Codex Pillow geometry based on accepted AG questions and target/toolchain facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 6, 'filename': 'lesson31-refresh-figure6.png', 'alt': 'بررسی شواهد جای\u200cگذاری و کاربرگ برد', 'caption': 'نمودار تألیفی شواهد واقعی ELF و MAP: ccm_initialized در VMA برابر 0x10000000 با اندازهٔ 256 B و LMA برابر 0x0800211C؛ ccm_zeroed در بخش NOLOAD از 0x10000100 با اندازهٔ 256 B. این آدرس\u200cها از خروجی واقعی ساخت گرفته شده\u200cاند؛ ثبت دیباگر، اجرای برد، خطای DMA یا سرعت اندازه\u200cگیری نشده است. کاربرگ مشاهدهٔ برد باید جدا و فقط پس از آزمایش واقعی تکمیل شود.', 'purpose': 'بررسی شواهد جای\u200cگذاری و کاربرگ برد', 'placement': 'بخش 6، در زیربخش پیش\u200cبینی آزمایش و لاگ ترمینال', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'ExactCB memory capacities'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, targeted memory sections', 'scope': 'Memory region / access concepts, no complete fabric redraw'}, {'url': 'https://sourceware.org/binutils/docs/ld/MEMORY.html', 'version': 'GNU ld official documentation', 'scope': 'Region definitions and capacity limits'}, {'url': 'https://sourceware.org/binutils/docs/ld/Output-Section-LMA.html', 'version': 'GNU ld official documentation', 'scope': 'LMA / VMA and explicit initialization responsibility'}, {'url': 'https://www.st.com/resource/en/application_note/dm00083249.pdf', 'version': 'AN4296 Rev6 April2025, Table2 / section4.1', 'scope': 'F303xB/C CCM8KiB/noDMA and GNUld initialization responsibility; generated startup order is checked separately against actual lesson31 source'}], 'type': 'original explanatory diagram / conceptual memory model', 'source': 'Original Codex Pillow geometry based on accepted AG questions and target/toolchain facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}]
if __name__=='__main__':run()

"""Original lesson35 educational diagrams (PNG + editable SVG), not GUI/measurements.
Requires Pillow. Run from any directory; output is beside this script.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,html,hashlib
P=Path(__file__).resolve().parent;I=P/'images';I.mkdir(exist_ok=True)
W,H=1200,1800
COL={'bg':'#F3F6FA','ink':'#16324A','muted':'#476176','line':'#CCD7E1','white':'#FFFFFF','blue':'#E1EEF9','green':'#E0F1EB','amber':'#FFF0D3','red':'#F9E6E2','navy':'#102C43'}
FONT=next((p for p in [Path('C:/Windows/Fonts/segoeui.ttf'),Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')] if p.exists()),None)
BOLD=next((p for p in [Path('C:/Windows/Fonts/segoeuib.ttf'),Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')] if p.exists()),FONT)
def font(size,bold=False):
    return ImageFont.truetype(str(BOLD if bold else FONT),size) if FONT else ImageFont.load_default(size=size)
class Figure:
    def __init__(self,n,title,subtitle):
        self.n=n;self.im=Image.new('RGB',(W,H),COL['bg']);self.d=ImageDraw.Draw(self.im);self.svg=[];self.checked=[]
        self.rect((0,0,W,190),COL['navy'],radius=0)
        self.text((64,34),title,58,COL['white'],True)
        self.text((66,111),subtitle,38,'#D2E4F0')
    def rect(self,box,fill,outline=None,radius=20):
        self.d.rounded_rectangle(box,fill=fill,outline=outline,width=3,radius=radius)
        x,y,x2,y2=box;self.svg.append(f'<rect x="{x}" y="{y}" width="{x2-x}" height="{y2-y}" rx="{radius}" fill="{fill}" stroke="{outline or fill}" stroke-width="3"/>')
    def text(self,xy,value,size=46,fill=None,bold=False):
        fill=fill or COL['ink'];x,y=xy;f=font(size,bold)
        for j,line in enumerate(value.split('\n')):
            yy=y+j*int(size*1.30)
            self.d.text((x,yy),line,font=f,fill=fill)
            width=self.d.textlength(line,font=f)
            assert x+width<=W-34,(self.n,line,width)
            assert yy+size<=H-24,(self.n,line,yy)
            self.checked.append({'text':line,'size_px':size,'x':x,'y':yy,'right':round(x+width,1)})
            self.svg.append(f'<text x="{x}" y="{yy+size}" font-size="{size}" font-weight="{700 if bold else 400}" fill="{fill}">{html.escape(line)}</text>')
    def card(self,y,h,title,body,fill='white',size=46):
        self.rect((64,y,1136,y+h),COL[fill],COL['line'])
        self.text((94,y+20),title,50,bold=True)
        self.text((94,y+92),body,size)
    def arrow(self,y1,y2):
        self.d.line((600,y1,600,y2-10),fill=COL['muted'],width=6)
        self.d.polygon([(587,y2-23),(613,y2-23),(600,y2)],fill=COL['muted'])
        self.svg.append(f'<path d="M600 {y1} V{y2-10} M587 {y2-23} L600 {y2} L613 {y2-23}" fill="none" stroke="{COL["muted"]}" stroke-width="6"/>')
    def path(self,points):
        self.d.line(points,fill=COL['muted'],width=4)
        self.svg.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in points)+f'" fill="none" stroke="{COL["muted"]}" stroke-width="4"/>')
    def save(self,ref):
        self.text((66,1670),'Original educational diagram | Not measured',36,COL['muted'])
        self.text((66,1722),ref,34,COL['muted'])
        stem=f'fig35-{self.n:02d}'
        self.im.save(I/(stem+'.png'),optimize=True)
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><title>{stem}: original educational diagram</title><g font-family="Segoe UI, DejaVu Sans, sans-serif">'+''.join(self.svg)+'</g></svg>'
        (I/(stem+'.svg')).write_text(svg,'utf8')
        return {'id':stem,'file':'images/'+stem+'.png','svg':'images/'+stem+'.svg','width':W,'height':H,'text_bounds_checked':True,'labels':self.checked}

figs=[]
f=Figure(1,'Fault categories and escalation','Cortex-M4 | distinguish the cause from its handler')
f.card(230,165,'MemManage','Protection / execute-permission violation','blue')
f.card(425,165,'BusFault','Instruction or data bus-access error','blue')
f.card(620,165,'UsageFault','Undefined instruction / invalid state / trap','blue')
for yy in [312,507,702]:f.path([(64,yy),(35,yy)])
f.path([(35,312),(35,822),(600,822)])
f.arrow(822,850)
f.card(870,215,'Escalation condition','Handler disabled, or priority prevents\nhandling the configurable fault','amber',44)
f.arrow(1105,1155)
f.card(1175,160,'HardFault','Inspect HFSR and CFSR together','red')
f.card(1375,225,'Keep the distinction','Vector-table read error: HFSR.VECTTBL\nSome failures can lead to lockup.','white',44)
figs.append(f.save('Technical basis: PM0214 Rev10; Arm AN209 V5.0'))

f=Figure(2,'Locate the saved core registers','Offsets from the original raw SP | valid frames only')
f.rect((64,230,1136,330),COL['navy']);f.text((96,246),'BYTE OFFSET',46,COL['white'],True);f.text((600,246),'REGISTER',46,COL['white'],True)
rows=[('+0','R0'),('+4','R1'),('+8','R2'),('+12','R3'),('+16','R12'),('+20','Saved LR'),('+24','Saved PC'),('+28','xPSR')]
for j,(a,b) in enumerate(rows):
    y=340+j*87;fill='green' if a=='+24' else 'white';f.rect((64,y,1136,y+79),COL[fill],COL['line'],10);f.text((100,y+8),a,48,bold=a=='+24');f.text((600,y+8),b,48,bold=a=='+24')
f.card(1070,240,'Same core offsets in BOTH layouts','Basic: 8 words = 32 bytes\nExtended: 26 words = 104 bytes','blue',46)
f.card(1340,265,'FP extension follows the core frame','R0 remains at raw SP + 0.\nPC remains at raw SP + 24.\nOptional padding is at the high end.','white',44)
figs.append(f.save('Technical basis: Arm DUI0553B, Figure 2-3'))

f=Figure(3,'Read CFSR by fault group','Global bit numbers within the 32-bit CFSR register')
f.card(230,305,'MMFSR | bits 0..7','0 IACCVIOL     1 DACCVIOL\n3 MUNSTKERR   4 MSTKERR\n5 MLSPERR      7 MMARVALID','blue',46)
f.card(570,310,'BFSR | bits 8..15','8 IBUSERR      9 PRECISERR\n10 IMPRECISERR\n15 BFARVALID','blue',46)
f.card(915,275,'UFSR | bits 16..31','16 UNDEFINSTR   17 INVSTATE\n24 UNALIGNED    25 DIVBYZERO','blue',44)
f.card(1230,360,'Validate addresses before use','MMFAR: use only if MMARVALID = 1\nBFAR: use only if BFARVALID = 1\nFlags can coexist. Save before clearing.\nIMPRECISERR: PC may not locate cause.','amber',42)
figs.append(f.save('Technical basis: PM0214 Rev10, SCB fault registers'))

f=Figure(4,'Select and validate the frame','Preserve original SP and EXC_RETURN before C code')
f.card(230,205,'EXC_RETURN bit 2 selects the saved SP','0 -> MSP\n1 -> PSP','blue',46)
f.card(470,205,'EXC_RETURN bit 4 selects frame size','1 -> basic, 8 words\n0 -> extended, 26 words','blue',46)
f.arrow(695,735)
f.card(755,375,'Check before reading frame memory','1. Raw SP is 4-byte aligned.\n2. Entire frame is in main SRAM or CCM.\n3. No stacking / unstacking / lazy error\n   is set in CFSR (mask 0x3838).','white',44)
f.arrow(1150,1190)
f.card(1210,350,'Two separate validity checks','magic = 0xFA017035: snapshot complete\nframe_valid = 1: core frame accepted\nThen inspect stacked[6] for saved PC.\nSCB evidence may survive an invalid frame.','green',42)
figs.append(f.save('Technical basis: compiled lesson35 recorder; Arm DUI0553B'))

f=Figure(5,'Three causes, two handler modes','Expected isolated results after reset | NOT board data')
f.card(230,230,'1 | UDIV with divisor = 0','DIVBYZERO, bit 25\nCFSR = 0x02000000','blue',48)
f.card(495,230,'2 | UDF #0','UNDEFINSTR, bit 16\nCFSR = 0x00010000','blue',48)
f.card(760,230,'3 | BX to an even valid code address','INVSTATE, bit 17\nCFSR = 0x00020000','blue',48)
f.card(1035,245,'Default: enable_configurable_faults = 0','HardFault, exception number = 3\nHFSR.FORCED mask = 0x40000000','amber',44)
f.card(1320,250,'Set enable_configurable_faults = 1 first','UsageFault, exception number = 6\nHFSR = 0, assuming no other faults','green',44)
figs.append(f.save('Technical basis: actual UDIV / UDF / BX project; PM0214'))

f=Figure(6,'DWT can halt or produce trace','Different debug functions | support is target-dependent')
f.card(230,370,'DATA WATCHPOINT: stop the CPU','Selected read / write address access\nDWT comparator matches the condition\n-> debugger halts the core\nExample target: watch_counter','blue',44)
f.card(645,600,'SWV TRACE: observe event packets','DWT / ITM event packets\n-> TPIU / SWO output\n-> compatible probe\n-> host SWV viewer\nCore Clock = 72 MHz in this project\nSWO bitrate is configured separately.','green',44)
f.card(1290,295,'Check the complete trace path','SWO routing and probe support required.\nTrace can overflow or lose packets.\nNo SWV capture was performed here.','amber',44)
figs.append(f.save('Technical basis: UM2609 Rev15, sections 3.2.2 and 3.5'))

caps=[
('انواع چهارگانه خطاهای معماری Cortex-M4 و شرایط رخداد','نمودار تألیفی: دسته‌های Fault و شرط تشدید به HardFault؛ هر خطا الزاماً قابل بازیابی نیست.','دسته‌های MemManage، BusFault و UsageFault و مسیر مشروط تشدید به HardFault'),
('کالبدشکافی ساختار پشته (Stack Frame) و بازخوانی ثبات‌ها','جدول تألیفی افست ثبات‌های هسته در قاب معتبر Cortex-M4: مکان PC در هر دو چیدمان پایه و گسترش‌یافته، raw SP + 24 است.','جدول افست بایتی R0 تا xPSR و جایگاه PC و LR؛ بخش ممیز شناور پس از قاب هسته قرار دارد'),
('رمزگشایی ثبات‌های تشخیصی CFSR، HFSR، MMFAR و BFAR','نمودار تألیفی: چند بیت مهم CFSR با شمارهٔ سراسری بیت؛ نشانی‌های MMFAR و BFAR فقط با پرچم اعتبار مربوط قابل استنادند.','گروه‌های MMFSR و BFSR و UFSR و شمارهٔ بیت‌های مهم و پرچم اعتبار نشانی'),
('کالبدشکافی ساختار پشته (Stack Frame) و بازخوانی ثبات‌ها','نمودار تألیفی روش انتخاب پشته و کنترل قاب در پروژه؛ کامل‌بودن snapshot با معتبر‌بودن قاب دو شرط جدا هستند.','انتخاب MSP یا PSP و اندازهٔ قاب با EXC_RETURN و شروط magic و frame_valid پیش از خواندن PC'),
('آزمایش عملی: پیاده‌سازی 3 سناریوی خطای مجزا و ردیابی رجیستری','نمودار تألیفی مقادیر مورد انتظار برای 3 علت UsageFault در پروژهٔ همراه؛ دادهٔ اندازه‌گیری‌شده روی برد نیست.','3 محرک UDIV و UDF و BX و ماسک CFSR مورد انتظار در حالت HardFault و UsageFault'),
('روش‌های پیشرفته عیب‌یابی: Fault Analyzer و پایش با DWT/SWV','نمودار مفهومی تألیفی: Watchpoint اجرای هسته را متوقف می‌کند؛ SWV مسیر ردیابی جداگانه با اتصال و پروب سازگار می‌خواهد. کلاک هسته و نرخ خط SWO یکسان نیستند.','تفاوت مسیر توقف داده‌ای DWT با ارسال بستهٔ ردیابی SWV از SWO به پروب و رایانه')]
for fig,(placement,caption,alt) in zip(figs,caps):
    fig.update({'placement':placement,'caption':caption,'alt':alt,'kind':'original educational diagram, not GUI or measurement','rights':'Original Gebrabit diagram; educational reuse with attribution; source figure not copied','sha256':hashlib.sha256((P/fig['file']).read_bytes()).hexdigest()})
(P/'image-metadata.json').write_text(json.dumps(figs,ensure_ascii=False,indent=2),'utf8')
for width in [390,600]:
    sheet=Image.new('RGB',(width*3,(H*width//W+50)*2),'#E5EAF0');d=ImageDraw.Draw(sheet)
    for j,fig in enumerate(figs):
        thumb=Image.open(P/fig['file']).resize((width,H*width//W),Image.Resampling.LANCZOS)
        review=P/'review';review.mkdir(exist_ok=True);thumb.save(review/(fig['id']+f'-{width}.png'))
        x=(j%3)*width;y=(j//3)*(H*width//W+50);sheet.paste(thumb,(x,y));d.text((x+8,y+H*width//W+8),fig['id'],font=font(22),fill=COL['ink'])
    sheet.save(P/f'contact-sheet-{width}.png')
print('Created 6 original PNG + SVG figures, metadata and 390/600 review sheets')

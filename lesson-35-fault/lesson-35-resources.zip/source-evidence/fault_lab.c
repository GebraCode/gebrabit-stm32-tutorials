/* Gebrabit lesson 35: deliberate, debugger-triggered fault experiments.
 * No HAL calls, printing, allocation or breakpoint instructions in capture.
 */
#include "fault_lab.h"

volatile FaultSnapshot g_fault;
__attribute__((aligned(8))) uint32_t g_fault_emergency_stack[128];
volatile uint32_t fault_request;
volatile uint32_t enable_configurable_faults;
volatile uint32_t watch_counter;
static volatile uint32_t numerator = 10U;
static volatile uint32_t denominator = 0U;
static volatile uint32_t division_result;

static void Trigger_DivideByZero(void)
{
  uint32_t a = numerator, b = denominator, out;
  /* Deliberate CPU instruction, not undefined C division by zero. */
  __asm volatile("udiv %0, %1, %2" : "=r"(out) : "r"(a), "r"(b));
  division_result = out;
}

static void Trigger_UndefinedInstruction(void)
{
  __asm volatile("udf #0");
}

static void Trigger_InvalidThumbState(void)
{
  /* Target is valid Flash code, but BX receives an even address (T=0).
   * This is an assembly experiment, not a portable C function-pointer call.
   */
  __asm volatile(
    "adr r0, 1f\n"
    "bic r0, r0, #1\n"
    "bx r0\n"
    ".align 2\n"
    "1: nop\n" ::: "r0", "memory");
}

void FaultLab_Init(void)
{
  SCB->CCR |= SCB_CCR_DIV_0_TRP_Msk | SCB_CCR_STKALIGN_Msk;
  SCB->CFSR = 0xFFFFFFFFU; /* W1C: clear any old sticky fault status. */
  SCB->HFSR = SCB_HFSR_FORCED_Msk | SCB_HFSR_VECTTBL_Msk | SCB_HFSR_DEBUGEVT_Msk;
  __DSB();
  __ISB();
}

void FaultLab_Poll(void)
{
  const uint32_t request = fault_request;
  ++watch_counter; /* A simple, non-timing-critical data-watchpoint target. */
  if ((request < 1U) || (request > 3U)) { return; }
  fault_request = 0U;
  const uint32_t mask = SCB_SHCSR_MEMFAULTENA_Msk |
                        SCB_SHCSR_BUSFAULTENA_Msk |
                        SCB_SHCSR_USGFAULTENA_Msk;
  if (enable_configurable_faults != 0U) { SCB->SHCSR |= mask; }
  else { SCB->SHCSR &= ~mask; } /* Default: force escalation to HardFault. */
  __DSB();
  __ISB();
  if (request == 1U) { Trigger_DivideByZero(); }
  else if (request == 2U) { Trigger_UndefinedInstruction(); }
  else { Trigger_InvalidThumbState(); }
}

/* A tiny teaching recorder, not a production crash-recovery facility.
 * It only reads complete, aligned frames in the main SRAM or CCM SRAM.
 * A damaged stack can still prevent exception entry before this is reached.
 */
__attribute__((noreturn)) void Fault_Capture(uint32_t *raw_sp,
                                            uint32_t exc_return,
                                            uint32_t exception_number)
{
  __disable_irq();
  g_fault.magic = 0U;
  g_fault.exception_number = exception_number;
  g_fault.exc_return = exc_return;
  g_fault.raw_sp = (uint32_t)raw_sp;
  /* Save address first, then its validity flag (PM0214 section 4.4). */
  g_fault.mmfar = SCB->MMFAR;
  g_fault.bfar = SCB->BFAR;
  g_fault.cfsr = SCB->CFSR;
  g_fault.hfsr = SCB->HFSR;
  g_fault.dfsr = SCB->DFSR;
  g_fault.afsr = SCB->AFSR;
  g_fault.shcsr = SCB->SHCSR;
  g_fault.ccr = SCB->CCR;
  g_fault.mmfar_valid = ((g_fault.cfsr & SCB_CFSR_MMARVALID_Msk) != 0U);
  g_fault.bfar_valid = ((g_fault.cfsr & SCB_CFSR_BFARVALID_Msk) != 0U);
  g_fault.extended_frame = ((exc_return & (1U << 4U)) == 0U);
  g_fault.frame_valid = 0U;
  for (uint32_t i = 0U; i < 8U; ++i) { g_fault.stacked[i] = 0U; }

  const uintptr_t start = (uintptr_t)raw_sp;
  const uint32_t words = g_fault.extended_frame ? 26U : 8U;
  const uintptr_t bytes = words * sizeof(uint32_t);
  const uint32_t stack_error_mask = 0x00003838U;
  const uint32_t in_main = (start >= 0x20000000U) && (start <= 0x20008000U - bytes);
  const uint32_t in_ccm = (start >= 0x10000000U) && (start <= 0x10002000U - bytes);
  if (((start & 3U) == 0U) && ((in_main != 0U) || (in_ccm != 0U)) &&
      ((g_fault.cfsr & stack_error_mask) == 0U))
  {
    /* Arm DUI0553B Figure 2-3: R0 is at raw SP in BOTH frame layouts.
     * The FP extension is ABOVE the core frame, not before R0. */
    const uint32_t *core_frame = raw_sp;
    for (uint32_t i = 0U; i < 8U; ++i) { g_fault.stacked[i] = core_frame[i]; }
    g_fault.frame_valid = 1U;
  }
  __DSB();
  g_fault.magic = 0xFA017035U; /* Complete snapshot marker, written last. */
  __DSB();
  for (;;) { __NOP(); } /* Pause the debugger here; reset between experiments. */
}

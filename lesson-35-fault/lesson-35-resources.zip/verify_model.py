"""Offline checks of illustrative register decoding, not board results."""
from pathlib import Path
import json
from decode_snapshot import decode
p=Path(__file__).parent
cases=[]
for request,mask,label in [(1,0x02000000,'DIVBYZERO'),(2,0x00010000,'UNDEFINSTR'),(3,0x00020000,'INVSTATE')]:
    for enabled in [False, True]:
        snapshot={'magic':'0xFA017035','exception_number':6 if enabled else 3,
                  'exc_return':'0xFFFFFFF9','cfsr':hex(mask),
                  'hfsr':0 if enabled else '0x40000000','mmfar':'0xDEADBEEF','bfar':'0xDEADBEEF',
                  'frame_valid':1,'stacked':[0,0,0,0,0,'0x08001235','0x08001240','0x21000000']}
        result=decode(snapshot)
        assert result['fault_bits']==[label]
        assert result['forced_escalation'] != enabled
        assert result['mmfar'] is None and result['bfar'] is None
        cases.append({'request':request,'configurable_enabled':enabled,'kind':'illustrative expected register values, not measured','snapshot':snapshot,'decoded':result})
good=cases[0]['snapshot']
assert decode(dict(good,magic=0))['use_stacked_frame'] is False
assert decode(dict(good,frame_valid=0))['use_stacked_frame'] is False
assert decode(dict(good,cfsr='0x00001000'))['use_stacked_frame'] is False
assert decode(dict(good,cfsr='0x00000400'))['pc_is_not_a_reliable_faulting_instruction'] is True
assert decode(dict(good,cfsr='0x00008000'))['bfar']=='0xdeadbeef'
assert decode(dict(good,cfsr='0x00000080'))['mmfar']=='0xdeadbeef'
extended=decode(dict(good,exc_return='0xFFFFFFED'))
assert extended['original_stack']=='PSP' and extended['extended_frame']
assert extended['stacked_pc']=='0x8001240'
report={'kind':'offline illustrative decoding checks; no target execution','passed':True,'assertions':26,'cases':cases,'limitations':['The snapshot examples and PC/LR values are synthetic','Decoder validates exported metadata, not actual memory accessibility','This is not a target CPU or FPU emulator']}
(p/'expected-cases.json').write_text(json.dumps(report,indent=2),'utf8')
(p/'example-snapshot.json').write_text(json.dumps(cases[0]['snapshot'],indent=2),'utf8')
print('PASS: 26 offline assertions; 6 illustrative scenarios; no board results')

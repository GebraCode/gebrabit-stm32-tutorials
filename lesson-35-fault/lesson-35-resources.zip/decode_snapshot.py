"""Decode an exported g_fault JSON object. This is not a target emulator.

Usage: python decode_snapshot.py snapshot.json
Expected input: integer fields, or hex strings such as "0x02000000".
The tool never dereferences a target memory address or predicts execution.
"""
import json, sys

CAUSES = {
    0: 'IACCVIOL', 1: 'DACCVIOL', 3: 'MUNSTKERR', 4: 'MSTKERR',
    5: 'MLSPERR', 8: 'IBUSERR', 9: 'PRECISERR', 10: 'IMPRECISERR',
    11: 'UNSTKERR', 12: 'STKERR', 13: 'LSPERR', 16: 'UNDEFINSTR',
    17: 'INVSTATE', 18: 'INVPC', 19: 'NOCP', 24: 'UNALIGNED',
    25: 'DIVBYZERO',
}

def number(value):
    return int(value, 0) if isinstance(value, str) else int(value)

def decode(snapshot):
    cfsr = number(snapshot.get('cfsr', 0))
    hfsr = number(snapshot.get('hfsr', 0))
    exc_return = number(snapshot.get('exc_return', 0))
    mmfar = number(snapshot.get('mmfar', 0))
    bfar = number(snapshot.get('bfar', 0))
    complete = number(snapshot.get('magic', 0)) == 0xFA017035
    result = {
        'snapshot_complete': complete,
        'fault_bits': [name for bit, name in CAUSES.items() if cfsr & (1 << bit)],
        'forced_escalation': bool(hfsr & (1 << 30)),
        'vector_table_fault': bool(hfsr & (1 << 1)),
        'original_stack': 'PSP' if exc_return & 4 else 'MSP',
        'extended_frame': not bool(exc_return & 16),
        'mmfar': hex(mmfar) if cfsr & (1 << 7) else None,
        'bfar': hex(bfar) if cfsr & (1 << 15) else None,
        'stacking_or_unstacking_error': bool(cfsr & 0x3838),
    }
    frame = snapshot.get('stacked', [])
    valid = (complete and number(snapshot.get('frame_valid', 0)) != 0
             and not result['stacking_or_unstacking_error'] and len(frame) == 8)
    result['use_stacked_frame'] = valid
    if valid:
        result['stacked_lr'] = hex(number(frame[5]))
        result['stacked_pc'] = hex(number(frame[6]))
        result['stacked_xpsr'] = hex(number(frame[7]))
        result['pc_is_not_a_reliable_faulting_instruction'] = bool(cfsr & (1 << 10))
    else:
        result['frame_note'] = 'Do not interpret the supplied stacked[] as a valid exception frame.'
    return result

if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    with open(sys.argv[1], encoding='utf8') as stream:
        print(json.dumps(decode(json.load(stream)), indent=2))

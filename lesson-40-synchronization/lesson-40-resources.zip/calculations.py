"""Reproducible arithmetic/ordering model, NOT hardware measurement."""
import json
baud=115200; frame_bits=1+8+1; queue_bytes=32
result={"uart_baud":baud,"bits_per_character_8N1":frame_bits,"ideal_character_us":frame_bits/baud*1e6,"ideal_32byte_wire_ms":queue_bytes*frame_bits/baud*1000,"Sample_bytes":2*4,"Sample_queue_payload_bytes":4*2*4,"NVIC_library_priority":5,"NVIC_encoded_priority":5<<(8-4),"phase0_expected_order":["Low takes binary","High blocks","Medium completes","Low releases","High acquires"],"phase1_expected_order":["Low takes mutex","High blocks;Low inherits3","Low releases","High acquires","Medium completes"],"hardware_measured":False}
assert result["NVIC_encoded_priority"]==0x50
assert result["Sample_queue_payload_bytes"]==32
assert abs(result["ideal_32byte_wire_ms"]-2.7777777777777777)<1e-12
print(json.dumps(result,indent=2))

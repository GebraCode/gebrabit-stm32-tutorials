"""Original explanatory diagrams. Pillow required; no screenshots or measurements.
Copy to the lesson public folder, then run with 40 or 41 to rebuild that lesson.
Uses installed Segoe UI / DejaVu Sans; font files are not bundled.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json,sys
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e';LINE='#ccdbe3';BG='#f5f8fa';WHITE='#ffffff';PALE='#dceef0'
P=Path(__file__).resolve().parent
def font(n=44,b=False):
 for f in [f'C:/Windows/Fonts/segoeui{"b" if b else ""}.ttf',f'/usr/share/fonts/truetype/dejavu/DejaVuSans{"-Bold" if b else ""}.ttf']:
  if Path(f).exists():return ImageFont.truetype(f,n)
 raise FileNotFoundError('Install Segoe UI or DejaVu Sans.')
def text(d,x,y,s,n=44,c=INK,b=False):
 assert s.isascii(),s
 z=d.textbbox((x,y),s,font=font(n,b));assert z[2]<=W-30 and z[3]<=H-15,(s,z)
 d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,w=1050,n=44,c=INK,b=False):
 line='';lines=[]
 for word in s.split():
  q=(line+' '+word).strip()
  if line and d.textlength(q,font=font(n,b))>w:lines.append(line);line=word
  else:line=q
 if line:lines.append(line)
 for line in lines:text(d,x,y,line,n,c,b);y+=n+12
 return y
def start(title,subtitle):
 im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
 y=para(d,65,35,title,1070,55,INK,True);y=para(d,65,y+12,subtitle,1070,40,MUTED)
 assert y<245,(title,y)
 d.line((65,250,1135,250),fill=LINE,width=3)
 return im,d
def foot(d,s='Original conceptual diagram; no physical measurement.'):
 d.line((65,1640,1135,1640),fill=LINE,width=3);para(d,65,1660,s,1070,37,MUTED)
def box(d,x,y,w,h,title,lines=(),c=TEAL,n=44):
 d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=c,width=4)
 yy=para(d,x+22,y+16,title,w-44,n,c,True)
 for t in lines:yy=para(d,x+22,yy+10,t,w-44,n-2)
 assert yy<=y+h-12,(title,yy,y+h)
def arrow(d,x,y,x2,y2,c=TEAL):
 d.line((x,y,x2,y2),fill=c,width=7);a=math.atan2(y2-y,x2-x)
 d.polygon([(x2,y2),(x2-24*math.cos(a-.5),y2-24*math.sin(a-.5)),(x2-24*math.cos(a+.5),y2-24*math.sin(a+.5))],fill=c)
def pill(d,x,y,w,label,c=TEAL,n=42):
 d.rounded_rectangle((x,y,x+w,y+90),10,fill=c);text(d,x+18,y+12,label,n,WHITE,True)
def save(im,n,k):
 im.save(P/f'lesson{n}-figure{k}.png',optimize=True)
 qa=P.parent/'visual-qa';qa.mkdir(exist_ok=True)
 for width in [390,600]:im.resize((width,H*width//W),Image.Resampling.LANCZOS).save(qa/f'fig{k}-{width}.png')
def fig40_1():
 im,d=start('Queue: copy the value','Actual project: 4 entries, each Sample contains two uint32_t fields.')
 box(d,80,300,1040,220,'Producer local item',['sequence = 7; value = 70','xQueueSend copies sizeof(Sample) = 8 bytes.'],n=43)
 arrow(d,600,530,600,600)
 text(d,90,625,'Queue storage: 4 x 8 = 32 payload bytes',44,TEAL,True)
 for i in range(4):
  x=80+i*265;d.rectangle((x,730,x+245,950),outline=TEAL,width=4,fill=WHITE)
  text(d,x+20,750,f'Slot {i}',41,TEAL,True)
  para(d,x+20,820,'7 / 70' if i==0 else 'empty',210,42)
 arrow(d,600,970,600,1040)
 box(d,80,1060,1040,220,'Consumer local item',['xQueueReceive copies the oldest queued value.','The consumer receives sequence 7 and value 70.'],n=42)
 box(d,80,1330,1040,250,'The queue stores its own copy',['A queue of pointers copies only the pointer value; object lifetime and ownership still need a design.'],c=ORANGE,n=41)
 foot(d,'32 bytes is payload only; kernel object and alignment add memory.');return im
def fig40_2():
 im,d=start('A queue wait blocks the task','Example: xQueueReceive on an empty queue, block time 50 ticks.')
 box(d,100,295,1000,180,'Running: try to receive',['No data now; a positive wait permits blocking.'],n=43)
 arrow(d,600,485,600,550)
 box(d,100,570,1000,180,'Blocked: waiting for this queue',['Other Ready tasks can run; this is not a busy loop.'],n=43)
 arrow(d,350,760,350,830);arrow(d,850,760,850,830)
 box(d,65,850,520,180,'Data arrival',['May make a waiter Ready.'],n=42)
 box(d,620,850,515,180,'Wait expires',['May make the task Ready.'],c=ORANGE,n=42)
 arrow(d,350,1040,350,1115);arrow(d,850,1040,850,1115)
 box(d,100,1135,1000,220,'Ready is not Running or guaranteed success',['When scheduled, the API rechecks the queue.','Another consumer may have taken the item first.'],n=42)
 box(d,100,1390,1000,210,'Return condition',['pdPASS: copied an item. No item by timeout: failure. Block time 0: no blocking.'],c=ORANGE,n=41)
 foot(d,'50 ticks = 50 ms nominal at 1000 Hz; scheduling adds latency.');return im
def fig40_3():
 im,d=start('Semaphores count permits','No message payload is stored in a semaphore.')
 box(d,80,300,1040,400,'Binary: capacity 1; initially empty',['Give: 0 -> 1. Another Give while full fails.','Take: 1 -> 0. Repeated events can merge.'],n=43)
 for i in range(2):pill(d,140+i*520,565,410,['0: empty','1: one permit'][i],TEAL,40)
 box(d,80,800,1040,400,'Counting: capacity 3; initial count 0',['3 successful Gives fill it. The next Give fails.','Each successful Take consumes one permit.'],n=43)
 for i in range(3):
  d.ellipse((190+i*300,1050,310+i*300,1170),fill=TEAL);text(d,226+i*300,1070,str(i+1),44,WHITE,True)
 box(d,80,1320,1040,270,'Mutex is different',['Starts available; the taking task owns it.','The owner must Give it. Priority inheritance may help. No mutex Take/Give from an ISR.'],c=ORANGE,n=42)
 foot(d,'Binary gates and a counting completion semaphore are used in lesson 40.');return im
def timeline(im,d,mutex):
 text(d,80,310,'Higher task-priority number runs first.',43,TEAL,True)
 names=[('High',3),('Medium',2),('Low',1)]
 for i,(name,pr) in enumerate(names):
  y=430+i*300;text(d,75,y,f'{name}: {pr}',43,TEAL,True)
  d.line((290,y+120,1120,y+120),fill=LINE,width=5)
 if not mutex:
  pill(d,300,450,170,'Try',ORANGE,40);pill(d,480,450,410,'Blocked',MUTED,40);pill(d,900,450,210,'Acquire',TEAL,39)
  pill(d,480,750,220,'CPU work',ORANGE,38)
  pill(d,300,1050,170,'Owns',TEAL,40);pill(d,710,1050,180,'Work',TEAL,40)
  para(d,80,1260,'Medium can run before Low releases the binary semaphore. High waits for both Medium and Low.',1040,43)
  box(d,80,1410,1040,205,'Finite experiment',['Medium and Low have bounded work loops; no infinite wait is claimed for this test.'],c=ORANGE,n=40)
 else:
  pill(d,300,450,170,'Try',ORANGE,40);pill(d,480,450,200,'Blocked',MUTED,38);pill(d,690,450,210,'Acquire',TEAL,39)
  pill(d,900,750,220,'CPU work',ORANGE,38)
  pill(d,300,1050,170,'Owns',TEAL,40);pill(d,480,1050,200,'Run at 3',TEAL,38)
  para(d,80,1260,'High blocks on the mutex. Low inherits priority 3, completes its work, then explicitly Gives the mutex.',1040,43)
  box(d,80,1410,1040,205,'Medium waits longer in this phase',['Inheritance helps Low run; it does not release the resource instantly or prevent every deadlock.'],c=ORANGE,n=40)
 for x,label in [(300,'request'),(900 if not mutex else 690,'release')]:
  d.line((x,410,x,1200),fill=LINE,width=3);text(d,x,1210,label,38,MUTED)
 foot(d,'Schematic order only; bar lengths are not durations or measurements.')
 return im
def fig40_4():return timeline(*start('Without priority inheritance','Phase 0: a binary semaphore is used as the comparison lock.'),False)
def fig40_5():return timeline(*start('With mutex priority inheritance','Phase 1: the same bounded work uses a mutex.'),True)
def fig40_6():
 im,d=start('Two locks can create a deadlock','A circular wait between two tasks; other unrelated tasks may still run.')
 box(d,80,360,430,200,'Task A',['Owns Mutex 1.'],n=44)
 box(d,690,360,430,200,'Mutex 1',['Held by A.'],n=44)
 box(d,80,1040,430,200,'Mutex 2',['Held by B.'],n=44)
 box(d,690,1040,430,200,'Task B',['Owns Mutex 2.'],n=44)
 arrow(d,670,460,530,460);text(d,545,390,'owner',38,MUTED)
 arrow(d,300,580,300,1010);para(d,80,740,'A waits for Mutex 2',200,42,RED,True)
 arrow(d,530,1140,670,1140);text(d,540,1170,'owner',38,MUTED)
 arrow(d,900,1020,900,590);para(d,940,740,'B waits for Mutex 1',180,42,RED,True)
 box(d,80,1330,1040,270,'Prevent the cycle in the design',['Use one global lock order: Mutex 1 before Mutex 2.','Keep ownership short; handle timeouts with rollback. Priority inheritance alone cannot break this cycle.'],c=ORANGE,n=40)
 foot(d,'This is a separate conceptual case, not the running firmware experiment.');return im
def fig41_1():
 im,d=start('NVIC: separate the two ranges','STM32F303: 4 implemented priority bits; lower number means higher urgency.')
 box(d,80,300,1040,350,'0-4: must not call FreeRTOS kernel APIs',['These IRQs are above the normal BASEPRI syscall mask. This does not mean zero latency.'],c=RED,n=43)
 for i in range(5):pill(d,110+i*205,530,180,str(i),RED,44)
 box(d,80,760,1040,490,'5-15: permitted FromISR APIs only',['USART1 is set to 5 in this project.','The API contract, grouping and other rules still apply.'],n=43)
 for i in range(11):pill(d,110+(i%6)*170,990+(i//6)*110,145,str(i+5),TEAL,44)
 box(d,80,1360,1040,230,'HAL gets an unshifted priority: 5',['Kernel encoded threshold: 5 << (8 - 4) = 0x50.','Do not pass 0x50 as HAL priority.'],c=ORANGE,n=42)
 foot(d,'These values are project-specific; do not copy blindly to another MCU.');return im
def fig41_2():
 im,d=start('Task context and ISR context','Use the API designed for the current execution context.')
 box(d,80,300,1040,430,'Task: xQueueSend',['A positive timeout may block this task.','The scheduler can run another Ready task.','Use return status; a timeout may fail to send.'],n=44)
 box(d,80,840,1040,430,'ISR: xQueueSendFromISR',['No wait time; an interrupt must not block.','A full queue fails immediately: count or handle loss.','Initialize higher_priority_task_woken = pdFALSE.'],n=43)
 box(d,80,1380,1040,210,'Then request a context switch if needed',['portYIELD_FROM_ISR(flag) pends PendSV when flag is true. Not every API has an ISR variant.'],c=ORANGE,n=42)
 foot(d,'The project counts full-queue loss in g_rx_dropped.');return im
def fig41_3():
 im,d=start('A yield request is conditional','An unblocked higher-priority task may need a scheduling decision.')
 box(d,80,300,1040,180,'Before queue send: flag = pdFALSE',['xQueueSendFromISR may set the flag to pdTRUE.'],n=43)
 arrow(d,600,495,600,555)
 box(d,80,575,1040,240,'portYIELD_FROM_ISR(flag)',['FALSE: no yield request from this call.','TRUE: PendSV is made pending.'],n=44)
 arrow(d,600,830,600,895)
 box(d,80,915,1040,260,'Execution must still permit PendSV',['The current ISR must finish. Other exceptions and interrupt masking can delay servicing PendSV.'],n=43)
 arrow(d,600,1190,600,1255)
 box(d,80,1275,1040,310,'PendSV saves and restores task context',['The scheduler chooses a Ready task. This can avoid waiting for a later tick, but gives no zero-latency or deadline guarantee.'],c=ORANGE,n=43)
 foot(d,'Schematic control flow; no measured interrupt-to-task latency supplied.');return im
def fig41_4():
 im,d=start('Move processing out of the ISR','Actual lesson 41: one-byte UART interrupt reception, then a 32-byte queue.')
 rows=[('USART1 hardware + HAL IRQ',['Receive status/data are handled by HAL_UART_IRQHandler.']),('ISR callback: short, bounded work',['Reject errored bytes; rearm good reception.','Queue the copied byte with xQueueSendFromISR.']),('Queue: 32 entries, 1 byte each',['A finite buffer; a full queue increments g_rx_dropped.']),('Processor task: normal task APIs',['xQueueReceive blocks until a byte is available.','Count bytes; LF increments lines and toggles PB6.'])]
 for i,(t,ls) in enumerate(rows):
  y=290+i*330;box(d,80,y,1040,245,t,ls,n=41)
  if i<3:arrow(d,600,y+255,600,y+315)
 foot(d,'No UART echo is implemented; the task handles received bytes only.');return im
def fig41_5():
 im,d=start('The priority assertion checks a rule','Pinned ARM_CM4F port: vPortValidateInterruptPriority.')
 box(d,80,300,1040,210,'1. Identify the active external IRQ',['Read its encoded NVIC priority. USART1 uses 0x50.'],n=43)
 arrow(d,600,525,600,575)
 box(d,80,595,1040,270,'2. Check encoded priority >= threshold',['Threshold is 0x50 in this project.','0x40 fails; 0x50 and 0x60 pass this comparison.'],n=43)
 arrow(d,600,880,600,930)
 box(d,80,950,1040,225,'3. Check priority grouping',['The port also asserts that PRIGROUP is acceptable. The project uses NVIC_PRIORITYGROUP_4.'],n=42)
 arrow(d,600,1190,600,1240)
 box(d,80,1260,1040,330,'If a check fails: configASSERT',['Application trap: g_app_error = 1; save source line and stop for debugger inspection.','This is not proof that every race or invalid API use is detected.'],c=ORANGE,n=42)
 foot(d,'Assertions must remain enabled; a diagnostic trap is not recovery.');return im
def fig41_6():
 im,d=start('UART wiring and loss counters','Actual project: 115200 baud, 8 data bits, no parity, 1 stop bit.')
 box(d,80,300,440,230,'USB-UART',['3.3 V logic TX','Common GND'],n=43)
 box(d,690,300,430,230,'STM32F303',['PA10: USART1 RX','GND'],n=43)
 arrow(d,535,370,675,370);arrow(d,535,470,675,470)
 box(d,80,600,1040,170,'PA9 TX is configured but unused here',['No echo is expected. Do not apply 5 V logic.'],c=ORANGE,n=41)
 box(d,80,840,1040,225,'Errored receive: reject before rearming',['g_rx_rejected counts rejected completed bytes.','Leave HAL ErrorCode intact for ErrorCallback.'],c=RED,n=42)
 box(d,80,1120,1040,210,'ErrorCallback: count and recover',['g_rx_errors / g_rx_last_error. Rearm only when RxState is READY; count rearm failures.'],n=42)
 box(d,80,1390,1040,200,'Good byte but queue full: separate loss',['g_rx_dropped increments. An empty 32-byte queue holds about 2.78 ms of ideal wire data; not a timing guarantee.'],c=ORANGE,n=40)
 foot(d,'One-byte rearm gaps and finite buffering can lose data under load.');return im
metadata={40:[
('نمودار تألیفی انتقال با کپی در Queue؛ ساختار 8 بایتی ابتدا در فضای صف و سپس در متغیر گیرنده کپی می‌شود. تغییر بعدی متغیر فرستنده، نسخهٔ صف را تغییر نمی‌دهد.','انتقال یک ساختار شامل sequence و value از تولیدکننده به صف 4 عضوی و مصرف‌کننده'),
('نمودار تألیفی انتظار برای صف خالی؛ رسیدن داده یا انقضای مهلت می‌تواند وظیفه را آماده کند. آماده‌شدن به معنی اجرا یا دریافت قطعی داده نیست.','حالت‌های Running و Blocked و Ready در انتظار دریافت از صف'),
('نمودار تألیفی سمافور دودویی و شمارشی؛ هر Take موفق یک مجوز را مصرف می‌کند. سمافور بدنهٔ پیام ندارد و با Mutex از نظر مالکیت و وراثت اولویت متفاوت است.','مقایسهٔ ظرفیت 1 و 3 سمافورها با رفتار اولیه و عملیات Give و Take'),
('نمودار تألیفی ترتیب مورد انتظار در فاز استفاده از سمافور دودویی؛ وظیفهٔ متوسط پیش از آزادکردن منبع توسط وظیفهٔ کم‌اولویت اجرا می‌شود. طول نوارها زمان اندازه‌گیری‌شده نیست و کار هر وظیفه در این آزمایش محدود است.','وارونگی اولویت در آزمایش محدود با سمافور دودویی و سه وظیفه'),
('نمودار تألیفی ترتیب مورد انتظار با Mutex؛ وقتی وظیفهٔ پراولویت منتظر منبع می‌شود، دارندهٔ آن موقتاً اولویت بالاتر می‌گیرد و پس از پایان کار، منبع را صریحاً آزاد می‌کند. این سازوکار آزادسازی فوری یا حذف همهٔ انواع بن‌بست را تضمین نمی‌کند.','وراثت اولویت از High با اولویت 3 به Low و اجرای Medium پس از آزادشدن منبع'),
('نمودار تألیفی بن‌بست میان 2 وظیفه و 2 قفل؛ هر وظیفه منبعی را نگه داشته و منتظر دیگری است. وظیفه‌های نامرتبط ممکن است همچنان اجرا شوند. ترتیب ثابت گرفتن قفل‌ها، یکی از راه‌های پیشگیری است.','حلقهٔ انتظار Task A و Task B برای Mutex 1 و Mutex 2')],
41:[
('نمودار تألیفی محدودهٔ اولویت وقفه‌ها در این پروژه؛ وقفه‌های 0 تا 4 نباید API هسته را فراخوانی کنند. وقفه‌های 5 تا 15 با رعایت قرارداد APIهای FromISR مجازند. مقدار 5 برای HAL با آستانهٔ کدشدهٔ 0x50 یکسان نوشته نمی‌شود.','محدوده‌های اولویت NVIC با 4 بیت و آستانهٔ فراخوانی هسته در مقدار 5'),
('نمودار تألیفی تفاوت ارسال به صف از Task و ISR؛ Task می‌تواند با مهلت مثبت مسدود شود، اما نسخهٔ FromISR منتظر خالی‌شدن صف نمی‌ماند و نتیجهٔ آن باید بررسی شود.','مقایسهٔ xQueueSend و xQueueSendFromISR و پرچم درخواست تعویض وظیفه'),
('نمودار تألیفی درخواست مشروط تعویض وظیفه؛ portYIELD_FROM_ISR با پرچم درست، PendSV را معلق می‌کند. اجرای آن پس از اجازهٔ وضعیت وقفه‌ها و ماسک‌ها انجام می‌شود و تأخیر صفر تضمین نیست.','روند تنظیم پرچم higher priority task woken تا PendSV و انتخاب وظیفهٔ آماده'),
('نمودار تألیفی مسیر واقعی پروژهٔ درس 41؛ وقفه بایت معتبر را در صف 32 عضوی قرار می‌دهد و Task آن را مصرف می‌کند. دریافت LF شمارندهٔ خط را افزایش می‌دهد و LED روی PB6 را تغییر می‌دهد؛ پاسخ سریال ارسال نمی‌شود.','مسیر USART1 و callback وقفه و صف بایت تا Task پردازش‌گر'),
('نمودار تألیفی بررسی اولویت و گروه‌بندی وقفه در پورت ARM_CM4F؛ شکست شرط به دام configASSERT برنامه می‌رود. این بررسی، آشکارسازی همهٔ خطاهای هم‌زمانی یا بازیابی خودکار نیست.','مراحل بررسی اولویت کدشده و PRIGROUP و توقف در configASSERT'),
('نمودار تألیفی سیم‌بندی UART با سطح منطقی 3.3 ولت و تفکیک خطاها؛ بایت خطادار پیش از راه‌اندازی مجدد رد می‌شود تا ErrorCode برای callback خطا حفظ شود. پرشدن صف، خطای UART و شکست راه‌اندازی مجدد شمارنده‌های جدا دارند.','اتصال TX مبدل به PA10 و زمین مشترک همراه شمارنده‌های رد بایت و خطای UART و پرشدن صف')]}
def main(n):
 funcs=[globals()[f'fig{n}_{k}'] for k in range(1,7)]
 out=[]
 for k,f in enumerate(funcs,1):
  save(f(),n,k);caption,alt=metadata[n][k-1]
  source=('Original diagram based on actual lesson40 code and pinned FreeRTOS V11.2.0 queue.c / semphr.h / tasks.c.' if n==40 else 'Original diagram based on actual lesson41 code, STM32F3 HAL UART1.5.8, pinned FreeRTOS V11.2.0 ARM_CM4F port.c / portmacro.h / queue.c.')
  out.append({'id':f'fig{k:02d}','filename':f'lesson{n}-figure{k}.png','width':W,'height':H,'caption':caption,'alt':alt,'source':source,'license':'Original diagram and drawing code by GEBRA ENG, CC BY 4.0; source documents cited, not copied.','kind':'original conceptual diagram','pixels_reviewed':False})
 (P/'image-metadata.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
 qa=P.parent/'visual-qa'
 for w in [390,600]:
  sheet=Image.new('RGB',(w*3,H*w//W*2),WHITE)
  for k in range(1,7):sheet.paste(Image.open(qa/f'fig{k}-{w}.png'),(((k-1)%3)*w,((k-1)//3)*(H*w//W)))
  sheet.save(qa/f'contact-sheet-{w}.png')
 print(n,'6 original figures generated')
if __name__=='__main__':main(int(sys.argv[1]))

"""Validate teaching workflow records only; never launches or installs an application."""
from pathlib import Path
import json, csv
P=Path(__file__).resolve().parent
w=json.loads((P/'workflow-model.json').read_text(encoding='utf-8'))
v=json.loads((P/'versions-and-sources.json').read_text(encoding='utf-8'))
checks=[]
def check(name,condition):
    if not condition: raise AssertionError(name)
    checks.append(name)
check('five distinct tool roles',len(w['roles'])==5)
check('catalog versions independently recorded',v['catalog_not_local_install']=={'STM32CubeIDE_Eclipse':'2.2.0','STM32CubeMX_classic':'6.18.1'})
check('course generation baseline differs',v['course_generation_baseline']['STM32CubeMX']=='6.14.0')
check('actual package pin preserved',v['course_generation_baseline']['STM32CubeF3_commit']=='663d2baae3604244f90ed80d0d757df17e36ada9')
check('GCC not assumed bundled IDE',v['course_generation_baseline']['Arm_GNU_GCC']=='13.2.1' and 'IDE bundled GCC version' in w['backend_does_not_prove'])
check('no GUI/firmware/hardware execution invented',all(x is False for x in w['validation'].values()))
check('generation before build',next(i for i,s in enumerate(w['desktop_steps']) if 'generate' in s)<next(i for i,s in enumerate(w['desktop_steps']) if s.startswith('build')))
check('program before debug taught later',w['desktop_steps'][-2].endswith('lesson 6') and w['desktop_steps'][-1].endswith('lesson 7'))
check('installation/workspace/project examples differ',len({w['paths'][k] for k in ('installation_example','workspace_example','project_example')})==3)
with (P/'installation-version-worksheet.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
check('11 observable worksheet tasks',len(rows)==11 and all(r['observable_pass_evidence'] for r in rows))
check('reader evidence not prefilled',all(r['status']=='pending' and not r['my_evidence'] and not r['my_version_or_path'] for r in rows))
check('official catalog date checks present',len(v['official_catalog_evidence'])==2)
report={'kind':'workflow data consistency checks, not application execution','checks_passed':len(checks),'checks':checks,'limits':'No IDE/CubeMX GUI launch, installation, import, driver enumeration, firmware build, target connection or board test was performed by this script. A tool absent from PATH may still be installed elsewhere. Proposed desktop workflow requires reader verification with the installed version official guide.'}
(P/'workflow-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

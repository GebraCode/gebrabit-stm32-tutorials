"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=3
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Give each tool a clear job','A conceptual workflow, not an observed application screen')
 panel(d,100,300,1000,200,'CubeMX: configure and generate',['Pins, clocks and initial source files'])
 arrow(d,[(600,505),(600,575)])
 panel(d,100,580,1000,240,'CubeIDE: edit, build and debug',['Editor + GCC tools + debugger integration'])
 arrow(d,[(600,825),(600,895)])
 panel(d,100,900,1000,220,'CubeProgrammer: program device memory',['An alternative programming / recovery tool'])
 panel(d,100,1250,1000,260,'CubeF3 package: reusable source resources',['HAL / LL / CMSIS and device support','ST-LINK driver connects the host and probe.'])
 foot(d,'Roles overlap; this is not a mandatory launch sequence.');save(im,1)
def figure2():
 im,d=begin('Recognize the workflow version','CubeMX is standalone in the classic CubeIDE 2.x workflow')
 tx(d,70,300,'Older CubeIDE 1.x tutorials',48,ORANGE,True)
 d.rounded_rectangle((80,390,1120,670),20,fill=WHITE,outline=ORANGE,width=4)
 tx(d,120,425,'IDE shell with integrated CubeMX configuration',42)
 tx(d,120,535,'Old screenshots may describe this arrangement.',40,MUTED)
 tx(d,70,780,'Classic CubeIDE 2.x course route',48,TEAL,True)
 panel(d,80,890,450,220,'Standalone CubeMX',['Configure + generate'])
 arrow(d,[(540,1000),(660,1000)])
 panel(d,670,890,450,220,'CubeIDE',['Import + edit + build'])
 panel(d,80,1250,1040,280,'Separate catalog and production records',['Catalog: IDE 2.2.0 / CubeMX 6.18.1','This course backend: CubeMX 6.14.0','No local IDE GUI installation was performed.'])
 foot(d,'IDE 2.x can also create empty projects; roles are distinct.');save(im,2)
def figure3():
 im,d=begin('Separate four kinds of folders','Project location and workspace metadata are different concepts')
 folder(d,80,330,440,220,'Application installation')
 folder(d,680,330,440,220,'Firmware repository')
 tx(d,100,610,'Executable tools',42);tx(d,700,610,'CubeF3 package files',42)
 d.rounded_rectangle((80,800,1120,1420),22,outline=TEAL,width=5)
 tx(d,120,835,'Workspace',48,TEAL,True)
 folder(d,130,950,430,220,'.metadata')
 folder(d,640,950,430,220,'Project: .ioc + source')
 tx(d,130,1230,'IDE state and settings',40);tx(d,640,1230,'Portable project files',40)
 para(d,100,1480,'A project may be inside or outside the workspace. Keep source and configuration under backup.',1020,42)
 foot(d,'Conceptual nesting; no required disk path is implied.');save(im,3)
def figure4():
 im,d=begin('Find the view that answers your question','Conceptual roles only; not a screenshot or actual window layout')
 roles=[('Where are my files?','Project Explorer','Navigate source and project items'),('Where do I change code?','Editor','Read and edit the current file'),('What happened in this build?','Console','Inspect the current build log'),('Which diagnostic needs action?','Problems','Inspect warnings and errors'),('What is the target state?','Debug views','Variables, registers and memory')]
 for k,(q,a,b)in enumerate(roles):
  y=295+k*250;tx(d,70,y,q,43,TEAL,True)
  arrow(d,[(95,y+120),(360,y+120)])
  panel(d,390,y+68,735,152,a,[b])
 foot(d,'Views can be arranged differently by version and user.');save(im,4)
def figure5():
 im,d=begin('Follow source files into a program image','Compiler tools transform files; linking resolves the final layout')
 stages=[('C source + headers','Preprocess'),('Expanded C','Compile'),('Assembly / object files','Assemble + link')]
 for k,(a,b)in enumerate(stages):
  y=290+k*250;panel(d,80,y,620,150,a,());tx(d,750,y+40,b,40,TEAL,True)
  if k<2:arrow(d,[(390,y+160),(390,y+230)])
 arrow(d,[(390,950),(390,1060)])
 panel(d,80,1070,1040,220,'ELF: program container',['Sections, symbols and optionally DWARF debug data'])
 arrow(d,[(600,1300),(600,1375)])
 tx(d,80,1420,'Optional objcopy outputs',45,TEAL,True)
 tx(d,80,1510,'HEX: address records     BIN: raw bytes',42)
 foot(d,'An ELF file can contain DWARF; the formats are not synonyms.');save(im,5)
def figure6():
 im,d=begin('Check readiness before the next lesson','These are learner checkpoints, not observed pass results')
 steps=[('1 Record tool versions','Distinguish catalog versions from tools actually used.'),('2 Make CubeF3 available','Record the selected package version and location.'),('3 Generate in lesson 4','Keep the .ioc file and the generated project.'),('4 Build and program later','Use the build/debug lesson for target verification.')]
 for k,(a,b)in enumerate(steps):
  y=290+k*315;panel(d,100,y,1000,220,a,[b])
  if k<3:arrow(d,[(600,y+225),(600,y+300)])
 tx(d,100,1570,'If a checkpoint is incomplete, resolve it before moving on.',40,ORANGE)
 foot(d,'Installation, import and hardware checks remain unobserved.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson03-refresh-figure1.png', 'alt': 'نقش ابزارهای زنجیرهٔ توسعه', 'caption': 'نمودار تألیفی نقش CubeMX برای پیکربندی و تولید کد، CubeIDE برای ویرایش و ساخت و دیباگ، CubeProgrammer برای برنامه\u200cریزی حافظه و بستهٔ CubeF3 برای منابع نرم\u200cافزاری. این شکل ترتیب اجباری اجرای ابزارها یا تصویر رابط کاربری نیست.', 'purpose': 'نقش ابزارهای زنجیرهٔ توسعه', 'placement': 'اجزای اکوسیستم نرم\u200cافزاری STM32 و مرزبندی دقیق وظایف هر ابزار', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um2609-stm32cubeide-user-guide-stmicroelectronics.pdf', 'version': 'UM2609 Rev18, June29 2026', 'scope': 'Classic CubeIDE roles and development concepts'}, {'url': 'https://www.st.com/en/development-tools/stm32cubeide.html', 'version': 'Catalog2.2.0', 'scope': 'Catalog identity, not locally tested GUI'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Catalog6.18.1; actual course backend6.14.0 separately', 'scope': 'Standalone configuration and generation'}, {'url': 'https://sourceware.org/binutils/docs/binutils/objcopy.html', 'version': 'Official GNU binutils documentation', 'scope': 'ELF input and optional HEX/BIN output concepts'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Tool roles overlap; no observed GUI or mandatory programmer launch sequence.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson03-refresh-figure2.png', 'alt': 'تفاوت گردش کار قدیمی و مستقل CubeMX', 'caption': 'نمودار تألیفی روش یکپارچهٔ قدیمی و مسیر مستقل CubeMX در CubeIDE کلاسیک 2.x. نسخه\u200cهای معرفی\u200cشده در کاتالوگ IDE 2.2.0 و CubeMX 6.18.1 از ابزار تولید واقعی این دوره، CubeMX 6.14.0، جدا هستند. نصب یا اجرای محلی رابط IDE انجام نشده است.', 'purpose': 'تفاوت گردش کار قدیمی و مستقل CubeMX', 'placement': 'تحول بنیادین از نسخه 2.0: جدایی CubeMX از CubeIDE و چرخه کار استاندارد جدید', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um2609-stm32cubeide-user-guide-stmicroelectronics.pdf', 'version': 'UM2609 Rev18, June29 2026', 'scope': 'Classic CubeIDE roles and development concepts'}, {'url': 'https://www.st.com/en/development-tools/stm32cubeide.html', 'version': 'Catalog2.2.0', 'scope': 'Catalog identity, not locally tested GUI'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Catalog6.18.1; actual course backend6.14.0 separately', 'scope': 'Standalone configuration and generation'}, {'url': 'https://sourceware.org/binutils/docs/binutils/objcopy.html', 'version': 'Official GNU binutils documentation', 'scope': 'ELF input and optional HEX/BIN output concepts'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Classic Eclipse route, standalone CubeMX from IDE2.0; IDE still creates empty projects. Catalog is not proof of installed or tested GUI.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson03-refresh-figure3.png', 'alt': 'تفاوت مسیر نصب و مخزن بسته و فضای کاری و پروژه', 'caption': 'نمودار تألیفی نقش چهار محل ذخیره\u200cسازی. پوشهٔ پروژه می\u200cتواند داخل یا خارج Workspace باشد؛ شکل مسیر اجباری یا تصویر فایل\u200cهای واقعی کاربر نیست.', 'purpose': 'تفاوت مسیر نصب و مخزن بسته و فضای کاری و پروژه', 'placement': 'تفکیک چهار لایه ذخیره\u200cسازی داده: مسیر نصب، فضای کاری (Workspace)، پوشه پروژه و مخزن بسته\u200cها', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um2609-stm32cubeide-user-guide-stmicroelectronics.pdf', 'version': 'UM2609 Rev18, June29 2026', 'scope': 'Classic CubeIDE roles and development concepts'}, {'url': 'https://www.st.com/en/development-tools/stm32cubeide.html', 'version': 'Catalog2.2.0', 'scope': 'Catalog identity, not locally tested GUI'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Catalog6.18.1; actual course backend6.14.0 separately', 'scope': 'Standalone configuration and generation'}, {'url': 'https://sourceware.org/binutils/docs/binutils/objcopy.html', 'version': 'Official GNU binutils documentation', 'scope': 'ELF input and optional HEX/BIN output concepts'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Conceptual folder roles; project may be inside or outside workspace.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson03-refresh-figure4.png', 'alt': 'پرسش\u200cهای کاربر و نقش نماهای محیط توسعه', 'caption': 'نمودار تألیفی نقش Project Explorer، Editor، Console، Problems و نماهای Debug بر اساس پرسشی که پاسخ می\u200cدهند. جای\u200cگذاری پنجره\u200cها و منوهای رابط واقعی بازسازی نشده و مشاهدهٔ اجرای IDE ادعا نشده است.', 'purpose': 'پرسش\u200cهای کاربر و نقش نماهای محیط توسعه', 'placement': 'آشنایی با نماها (Perspectives) و پنجره\u200cهای اصلی در STM32CubeIDE', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um2609-stm32cubeide-user-guide-stmicroelectronics.pdf', 'version': 'UM2609 Rev18, June29 2026', 'scope': 'Classic CubeIDE roles and development concepts'}, {'url': 'https://www.st.com/en/development-tools/stm32cubeide.html', 'version': 'Catalog2.2.0', 'scope': 'Catalog identity, not locally tested GUI'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Catalog6.18.1; actual course backend6.14.0 separately', 'scope': 'Standalone configuration and generation'}, {'url': 'https://sourceware.org/binutils/docs/binutils/objcopy.html', 'version': 'Official GNU binutils documentation', 'scope': 'ELF input and optional HEX/BIN output concepts'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Abstract roles only, not fake UI layout, screenshot, observed menu positions or test evidence.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson03-refresh-figure5.png', 'alt': 'مسیر تبدیل منبع C به ELF و خروجی\u200cهای اختیاری', 'caption': 'نمودار تألیفی مراحل زنجیرهٔ ساخت: پیش\u200cپردازش، کامپایل، اسمبل و لینک. ELF ظرف برنامه و نمادهاست و می\u200cتواند دادهٔ DWARF داشته باشد. تولید HEX دارای آدرس و BIN خام با objcopy اختیاری است؛ این شکل گزارش ساخت پروژه نیست.', 'purpose': 'مسیر تبدیل منبع C به ELF و خروجی\u200cهای اختیاری', 'placement': 'مقدمه\u200cای بر زنجیره ابزار GCC و تنظیمات پایه کامپایلر Arm GNU Toolchain', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um2609-stm32cubeide-user-guide-stmicroelectronics.pdf', 'version': 'UM2609 Rev18, June29 2026', 'scope': 'Classic CubeIDE roles and development concepts'}, {'url': 'https://www.st.com/en/development-tools/stm32cubeide.html', 'version': 'Catalog2.2.0', 'scope': 'Catalog identity, not locally tested GUI'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Catalog6.18.1; actual course backend6.14.0 separately', 'scope': 'Standalone configuration and generation'}, {'url': 'https://sourceware.org/binutils/docs/binutils/objcopy.html', 'version': 'Official GNU binutils documentation', 'scope': 'ELF input and optional HEX/BIN output concepts'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ELF can contain DWARF, not ELF format DWARF. HEX address records versus raw BIN; optional conversion.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson03-refresh-figure6.png', 'alt': 'نقاط بررسی آمادگی برای درس بعد', 'caption': 'نمودار تألیفی نقاط بررسی ثبت نسخه، دسترسی به بسته، تولید پروژه در درس 4 و ساخت و برنامه\u200cریزی در درس مربوط. شکل نتیجهٔ موفقیت نصب، ساخت یا آزمون سخت\u200cافزار را نشان نمی\u200cدهد.', 'purpose': 'نقاط بررسی آمادگی برای درس بعد', 'placement': 'گام 4: نصب درایور سخت\u200cافزاری ST-LINK و ابزار کمکی CubeProgrammer', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/user_manual/um2609-stm32cubeide-user-guide-stmicroelectronics.pdf', 'version': 'UM2609 Rev18, June29 2026', 'scope': 'Classic CubeIDE roles and development concepts'}, {'url': 'https://www.st.com/en/development-tools/stm32cubeide.html', 'version': 'Catalog2.2.0', 'scope': 'Catalog identity, not locally tested GUI'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Catalog6.18.1; actual course backend6.14.0 separately', 'scope': 'Standalone configuration and generation'}, {'url': 'https://sourceware.org/binutils/docs/binutils/objcopy.html', 'version': 'Official GNU binutils documentation', 'scope': 'ELF input and optional HEX/BIN output concepts'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Readiness decision sequence, not SWD wiring or fabricated green pass results.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

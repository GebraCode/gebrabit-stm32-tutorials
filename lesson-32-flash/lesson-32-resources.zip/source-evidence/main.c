/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct { uint16_t word[8]; } SettingsRecord;
typedef enum {
  STORE_OK = 0, STORE_EMPTY, STORE_FULL, STORE_BAD_INPUT,
  STORE_UNLOCK_ERROR, STORE_PROGRAM_ERROR, STORE_ERASE_ERROR,
  STORE_VERIFY_ERROR, STORE_SEQUENCE_LIMIT, STORE_BAD_COMMAND
} StoreStatus;
_Static_assert(sizeof(SettingsRecord) == 16U, "Record size");
_Static_assert(FLASH_PAGE_SIZE == 2048U, "Wrong target Flash page");
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define STORAGE_BASE 0x0801F800UL
#define STORAGE_END  0x08020000UL
#define RECORD_BYTES 16U
#define RECORD_COUNT 128U
#define CMD_SAVE  0x53415645UL
#define CMD_ERASE 0x45524153UL
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint32_t flash_command;
volatile uint32_t requested_period_ms = 500U;
volatile uint32_t requested_threshold = 2048U;
volatile uint32_t active_period_ms = 500U;
volatile uint32_t active_threshold = 2048U;
volatile uint32_t latest_sequence;
volatile uint32_t valid_records, used_slots;
volatile uint32_t last_store_status;
volatile uint32_t last_hal_status;
volatile uint32_t last_flash_error;
volatile uint32_t last_page_error = 0xFFFFFFFFU;
volatile uint32_t last_failed_address;
static uint32_t next_empty_slot;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void Settings_Load(void);
static StoreStatus Settings_Save(uint32_t period, uint32_t threshold);
static StoreStatus Settings_Erase(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */
Settings_Load(); /* Read only: never erase/program at boot. */
/* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
uint32_t command = flash_command;
    flash_command = 0U; /* Consume before operation; no automatic retries. */
    if (command == CMD_SAVE)
    {
      last_store_status = Settings_Save(requested_period_ms, requested_threshold);
    }
    else if (command == CMD_ERASE)
    {
      last_store_status = Settings_Erase();
    }
    else if (command != 0U) { last_store_status = STORE_BAD_COMMAND; }
    if (command != 0U) { Settings_Load(); }
    HAL_GPIO_WritePin(USER_LED_GPIO_Port, USER_LED_Pin,
                      (valid_records != 0U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_Delay(10U);
  }
/* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
static uint16_t Record_Checksum(const SettingsRecord *record)
{
  uint32_t sum = 0U;
  for (uint32_t i = 0U; i < 6U; ++i) { sum += record->word[i]; }
  return (uint16_t)~sum;
}

static void Record_Read(uint32_t slot, SettingsRecord *record)
{
  const volatile uint16_t *source =
      (const volatile uint16_t *)(STORAGE_BASE + slot * RECORD_BYTES);
  for (uint32_t i = 0U; i < 8U; ++i) { record->word[i] = source[i]; }
}

static uint32_t Record_Empty(const SettingsRecord *record)
{
  for (uint32_t i = 0U; i < 8U; ++i)
  {
    if (record->word[i] != 0xFFFFU) { return 0U; }
  }
  return 1U;
}

static uint32_t Record_Valid(const SettingsRecord *record)
{
  return (record->word[0] == 0x5A32U) && (record->word[1] == 1U) &&
         (record->word[2] != 0U) && (record->word[2] != 0xFFFFU) &&
         (record->word[3] >= 100U) && (record->word[3] <= 5000U) &&
         (record->word[4] <= 4095U) && (record->word[5] == 0U) &&
         (record->word[6] == Record_Checksum(record)) &&
         (record->word[7] == 0xA55AU);
}

static void Settings_Load(void)
{
  SettingsRecord record;
  next_empty_slot = RECORD_COUNT;
  latest_sequence = valid_records = used_slots = 0U;
  active_period_ms = 500U;
  active_threshold = 2048U;
  for (uint32_t slot = 0U; slot < RECORD_COUNT; ++slot)
  {
    Record_Read(slot, &record);
    if (Record_Empty(&record))
    {
      if (next_empty_slot == RECORD_COUNT) { next_empty_slot = slot; }
    }
    else
    {
      ++used_slots;
      if (Record_Valid(&record))
      {
        ++valid_records;
        if (record.word[2] > latest_sequence)
        {
          latest_sequence = record.word[2];
          active_period_ms = record.word[3];
          active_threshold = record.word[4];
        }
      }
    }
  }
}

static HAL_StatusTypeDef Program_Checked(uint32_t address, uint16_t value)
{
  if ((address < STORAGE_BASE) || (address > STORAGE_END - 2U) ||
      ((address & 1U) != 0U) || (*(volatile uint16_t *)address != 0xFFFFU))
  {
    last_failed_address = address;
    return HAL_ERROR;
  }
  HAL_StatusTypeDef result = HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD,
                                              address, value);
  if ((result == HAL_OK) && (*(volatile uint16_t *)address != value))
  {
    result = HAL_ERROR;
  }
  if (result != HAL_OK) { last_failed_address = address; }
  return result;
}

static StoreStatus Settings_Save(uint32_t period, uint32_t threshold)
{
  SettingsRecord record, verify;
  HAL_StatusTypeDef status;
  StoreStatus result = STORE_OK;
  last_hal_status = HAL_OK;
  last_flash_error = last_failed_address = 0U;
  Settings_Load();
  if ((period < 100U) || (period > 5000U) || (threshold > 4095U))
  { return STORE_BAD_INPUT; }
  if (next_empty_slot >= RECORD_COUNT) { return STORE_FULL; }
  if (latest_sequence >= 0xFFFEU) { return STORE_SEQUENCE_LIMIT; }
  const uint32_t address = STORAGE_BASE + next_empty_slot * RECORD_BYTES;
  Record_Read(next_empty_slot, &verify);
  if (!Record_Empty(&verify)) { return STORE_VERIFY_ERROR; }
  record = (SettingsRecord){{0x5A32U, 1U, (uint16_t)(latest_sequence + 1U),
                            (uint16_t)period, (uint16_t)threshold, 0U, 0U, 0xA55AU}};
  record.word[6] = Record_Checksum(&record);
  status = HAL_FLASH_Unlock();
  if (status != HAL_OK) { result = STORE_UNLOCK_ERROR; }
  else
  {
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
    for (uint32_t i = 0U; i < 7U; ++i)
    {
      status = Program_Checked(address + 2U * i, record.word[i]);
      if (status != HAL_OK) { result = STORE_PROGRAM_ERROR; break; }
    }
    if (result == STORE_OK)
    {
      /* Only after all body halfwords pass readback, write commit LAST. */
      status = Program_Checked(address + 14U, record.word[7]);
      if (status != HAL_OK) { result = STORE_PROGRAM_ERROR; }
    }
    if (result == STORE_OK)
    {
      Record_Read(next_empty_slot, &verify);
      if (!Record_Valid(&verify)) { result = STORE_VERIFY_ERROR; }
    }
  }
  last_hal_status = status;
  last_flash_error = HAL_FLASH_GetError();
  (void)HAL_FLASH_Lock(); /* Including unlock/program/verify failure paths. */
  return result;
}

static StoreStatus Settings_Erase(void)
{
  FLASH_EraseInitTypeDef erase = {0};
  HAL_StatusTypeDef status = HAL_FLASH_Unlock();
  StoreStatus result = STORE_OK;
  last_page_error = 0xFFFFFFFFU;
  last_failed_address = 0U;
  if (status != HAL_OK) { result = STORE_UNLOCK_ERROR; }
  else
  {
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
    erase.TypeErase = FLASH_TYPEERASE_PAGES;
    erase.PageAddress = STORAGE_BASE;
    erase.NbPages = 1U;
    uint32_t page_error = 0xFFFFFFFFU;
    status = HAL_FLASHEx_Erase(&erase, &page_error);
    last_page_error = page_error;
    if (status != HAL_OK) { result = STORE_ERASE_ERROR; }
  }
  last_hal_status = status;
  last_flash_error = HAL_FLASH_GetError();
  (void)HAL_FLASH_Lock();
  if (result == STORE_OK)
  {
    for (uint32_t address = STORAGE_BASE; address < STORAGE_END; address += 2U)
    {
      if (*(volatile uint16_t *)address != 0xFFFFU)
      { last_failed_address = address; return STORE_VERIFY_ERROR; }
    }
  }
  return result;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */


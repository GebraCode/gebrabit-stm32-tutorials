"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent



LESSON=32
def save(im,n):im.save(OUT/f'lesson32-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Flash changes bits in one direction','Logical cell model, not a drawing of the physical transistor or a measured timing result')
 panel(d,75,290,1050,200,'SRAM: volatile read / write',['Flash retains data after normal power is removed.'])
 tx(d,75,610,'Program: erased 1 -> stored 0',48,TEAL,True)
 for k,a in enumerate(['1','1','1','1']):panel(d,75+k*275,740,225,150,a,())
 arrow(d,[(600,910),(600,1000)])
 for k,a in enumerate(['1','0','1','0']):panel(d,75+k*275,1030,225,150,a,(),TEAL if a=='1'else ORANGE)
 panel(d,75,1320,1050,285,'To restore 0 -> 1, erase the whole page',['F303CB: 64 pages x 2 KiB; halfword programming.','Erase is not an independent per-bit operation.'])
 foot(d,'Programming is 1 -> 0; page erase restores the erased 1 state.');save(im,1)
def figure2():
 im,d=begin('Reserve the last Flash page in the linker','Actual application limit: 126 KiB; the settings page is not part of the load image')
 x=100;y=390;w=340;h=1050
 d.rectangle((x,y,x+w,y+h),fill=WHITE,outline=TEAL,width=5)
 d.rectangle((x,y+h-180,x+w,y+h),fill='#fff0df',outline=ORANGE,width=5)
 tx(d,500,390,'0x08000000',46,TEAL,True)
 tx(d,500,570,'Pages 0 .. 62',46,TEAL,True);tx(d,500,650,'Application / 126 KiB',42)
 tx(d,500,990,'End 0x0801F7FF',42)
 tx(d,500,1240,'Page 63 / 2 KiB',46,ORANGE,True)
 tx(d,500,1320,'0x0801F800',44,ORANGE);tx(d,500,1400,'.. 0x0801FFFF',44,ORANGE)
 dashed(d,90,1260,470,1260,ORANGE)
 panel(d,75,1500,1050,110,'NOLOAD is not hardware protection',())
 foot(d,'Page-block heights are schematic, not a 63:1 area ratio.');save(im,2)
def figure3():
 im,d=begin('Unlock, check, program, then relock','Actual helper uses bounded addresses and deliberately requested operations only')
 steps=[('Unlock and prepare operation','Capture / clear stale flags intentionally.'),('Erase only when explicitly requested','One reserved page; Flash fetches can stall.'),('Program erased aligned halfwords','Write 16 bits; check status and readback.'),('Write the commit marker LAST','Payload and checksum must be ready first.'),('Relock on success and every error path','Report first operation failure / Flash error flags.')]
 for k,(a,b)in enumerate(steps):
  yy=285+k*260;panel(d,75,yy,1050,220,a,[b])
  if k<4:arrow(d,[(600,yy+225),(600,yy+250)])
 foot(d,'A SysTick timeout cannot independently bound a Flash stall.');save(im,3)
def figure4():
 im,d=begin('Append records; reject invalid entries','Actual 16 B record, 128 slots in one 2048 B page; no power-failure atomicity claim')
 rows=[('Slot 0','Valid seq 1'),('Slot 1','Partial / invalid'),('Slot 2','Valid seq 2'),('Slot 3','Fully erased')]
 for k,(a,b)in enumerate(rows):
  yy=300+k*180;panel(d,75,yy,1050,140,a+': '+b,(),c=ORANGE if k==1 else TEAL)
 panel(d,75,1080,1050,245,'Scan all slots, including gaps',['Write only a completely erased slot.','Commit A55A at byte offset 14 is written last.'])
 panel(d,75,1360,1050,245,'Erase can destroy every saved record',['Single-page append reduces erase frequency.','No guaranteed survival of interrupted erase.'])
 foot(d,'Partial writes are validated, not assumed atomic or universally safe.');save(im,4)
def figure5():
 im,d=begin('Save is deliberate, not automatic at boot','Actual project uses debugger request words; no PA3 button or UART trigger is implemented')
 panel(d,75,300,1050,220,'Boot: scan and load valid record',['Otherwise use RAM defaults; do not write Flash.'])
 arrow(d,[(600,520),(600,620)])
 panel(d,75,640,1050,250,'SAVE = 0x53415645',['Check inputs and a fully erased slot before append.','Sequence 1 .. 0xFFFE; no ambiguous wrap.'])
 arrow(d,[(600,900),(600,1000)])
 panel(d,75,1020,1050,240,'ERAS = 0x45524153',['Explicitly erase the reserved page only.','Never silently erase on page-full or reset.'])
 panel(d,75,1400,1050,205,'No Option Byte programming',['Settings change; boot protection does not.'])
 foot(d,'Debugger requests were implemented, not observed on a board.');save(im,5)
def figure6():
 im,d=begin('Validate the whole record after reset','Actual stored format is explicit 16-bit fields; checksum is not a CRC or authentication')
 names=['Magic 5A32','Format 1','Sequence','Period','Threshold','Reserved 0','Checksum','Commit A55A']
 for k,a in enumerate(names):
  xx=65+(k%2)*580;yy=290+(k//2)*165
  panel(d,xx,yy,490,125,a,());tx(d,xx+25,yy+120,f'offset {k*2} B',38,MUTED)
 panel(d,75,1040,1050,250,'Validate before selecting newest',['Period 100 .. 5000; threshold 0 .. 4095.','Complement the 16-bit sum of first 6 halfwords.'])
 panel(d,75,1360,1050,250,'Inspect failure flags and bounds',['PG / WRP errors have different causes.','Do not blame every timeout on high IRQ load.'])
 foot(d,'No physical reset / power-cut recovery was measured.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson32-refresh-figure1.png', 'alt': 'جهت برنامه\u200cریزی بیت و پاک\u200cسازی صفحه', 'caption': 'مدل منطقی تألیفی: برنامه\u200cریزی Flash بیت 1 را به 0 می\u200cبرد و برای بازگرداندن 0 به 1 باید صفحه پاک شود؛ این شکل ساختار واقعی ترانزیستور نیست. Flash تراشهٔ F303CB شامل 64 صفحهٔ 2 KiB است و مثال نیم\u200cکلمهٔ 16 بیتی می\u200cنویسد. SRAM فرّار و قابل خواندن و نوشتن است؛ زمان یا نتیجهٔ فیزیکی اندازه\u200cگیری نشده است.', 'purpose': 'جهت برنامه\u200cریزی بیت و پاک\u200cسازی صفحه', 'placement': 'بخش 1، بلافاصله پس از توضیح مفهوم حافظه نامتغیر و ساختار سلول\u200cهای Flash', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, printed82 Tables47/48', 'scope': 'ExactCB capacity and conditioned timing/endurance specifications; not runtime measurement'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted Flash sections', 'scope': 'Page organization, program / erase semantics and stalls'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a plus actual lesson32 compiled source', 'scope': 'FLASH_PAGE_SIZE0x800 / halfword operations / relock/error behavior'}], 'type': 'original explanatory diagram / logical storage model', 'source': 'Original Codex Pillow geometry based on accepted AG question and actual lesson32 facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 2, 'filename': 'lesson32-refresh-figure2.png', 'alt': 'رزرو صفحهٔ آخر و مرز برنامه', 'caption': 'نقشهٔ تألیفی مطابق linker واقعی: ناحیهٔ برنامه 126 KiB در 0x08000000..0x0801F7FF و صفحهٔ 63 به اندازهٔ 2 KiB در 0x0801F800..0x0801FFFF برای داده رزرو شده است. رزرو NOLOAD صفحه را از تصویر بارگذاری برنامه جدا می\u200cکند؛ حفاظت Option Bytes نیست و ارتفاع بلوک\u200cها مقیاس 63 به 1 ندارد.', 'purpose': 'رزرو صفحهٔ آخر و مرز برنامه', 'placement': 'بخش 2 و 3، در ابتدای مبحث نگاشت حافظه و اصلاح اسکریپت لینکر', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, printed82 Tables47/48', 'scope': 'ExactCB capacity and conditioned timing/endurance specifications; not runtime measurement'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted Flash sections', 'scope': 'Page organization, program / erase semantics and stalls'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a plus actual lesson32 compiled source', 'scope': 'FLASH_PAGE_SIZE0x800 / halfword operations / relock/error behavior'}], 'type': 'original explanatory diagram / logical storage model', 'source': 'Original Codex Pillow geometry based on accepted AG question and actual lesson32 facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 3, 'filename': 'lesson32-refresh-figure3.png', 'alt': 'ترتیب عملیات و قفل\u200cگذاری Flash', 'caption': 'روندنمای تألیفی بازکردن قفل، آماده\u200cسازی flags، پاک\u200cسازی فقط با درخواست صریح، برنامه\u200cریزی aligned halfword در محل erased و بررسی، نوشتن commit در پایان و قفل\u200cگذاری مجدد در همهٔ مسیرهای خطا و موفقیت. fetch از Flash هنگام busy ممکن است متوقف شود؛ timeout مبتنی بر SysTick حد مستقل سخت\u200cافزاری برای erase نیست.', 'purpose': 'ترتیب عملیات و قفل\u200cگذاری Flash', 'placement': 'بخش 4، پیش از نمایش قطعه\u200cکدهای توابع فلش', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, printed82 Tables47/48', 'scope': 'ExactCB capacity and conditioned timing/endurance specifications; not runtime measurement'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted Flash sections', 'scope': 'Page organization, program / erase semantics and stalls'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a plus actual lesson32 compiled source', 'scope': 'FLASH_PAGE_SIZE0x800 / halfword operations / relock/error behavior'}], 'type': 'original explanatory diagram / logical storage model', 'source': 'Original Codex Pillow geometry based on accepted AG question and actual lesson32 facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 4, 'filename': 'lesson32-refresh-figure4.png', 'alt': 'رکوردهای ترتیبی و محدودیت قطع تغذیه', 'caption': 'مدل تألیفی رکوردهای واقعی 16 B و ظرفیت 128 slot در یک صفحهٔ 2048 B. تمام slotها، حتی پس از شکاف، بررسی می\u200cشوند و slot نیمه\u200cنوشته دوباره مصرف نمی\u200cشود. commit برابر A55A در offset برابر 14 آخر نوشته می\u200cشود؛ این ترتیب تضمین اتمیک\u200cبودن یا دوام در قطع تغذیه نیست. erase تک\u200cصفحه\u200cای می\u200cتواند همهٔ تنظیمات را از بین ببرد.', 'purpose': 'رکوردهای ترتیبی و محدودیت قطع تغذیه', 'placement': 'بخش 5، در مبحث الگوریتم\u200cهای ذخیره\u200cسازی و پایداری قطع برق', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, printed82 Tables47/48', 'scope': 'ExactCB capacity and conditioned timing/endurance specifications; not runtime measurement'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted Flash sections', 'scope': 'Page organization, program / erase semantics and stalls'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a plus actual lesson32 compiled source', 'scope': 'FLASH_PAGE_SIZE0x800 / halfword operations / relock/error behavior'}], 'type': 'original explanatory diagram / logical storage model', 'source': 'Original Codex Pillow geometry based on accepted AG question and actual lesson32 facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 5, 'filename': 'lesson32-refresh-figure5.png', 'alt': 'درخواست عمدی ذخیره و پاک\u200cسازی', 'caption': 'روندنمای تألیفی منطبق با پروژه: راه\u200cاندازی فقط scan و بارگذاری معتبر یا defaults در RAM دارد. ذخیره با درخواست debugger برابر SAVE=0x53415645 و maintenance جدا با ERAS=0x45524153 انجام می\u200cشود؛ PA3 یا UART برای تحریک عملیات در این پروژه پیاده نشده است. نبود slot یا reset مجوز erase خودکار نیست؛ Option Bytes نوشته نمی\u200cشوند.', 'purpose': 'درخواست عمدی ذخیره و پاک\u200cسازی', 'placement': 'بخش 6، در زیربخش مدارات سخت\u200cافزاری و پیکربندی ورودی/خروجی', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, printed82 Tables47/48', 'scope': 'ExactCB capacity and conditioned timing/endurance specifications; not runtime measurement'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted Flash sections', 'scope': 'Page organization, program / erase semantics and stalls'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a plus actual lesson32 compiled source', 'scope': 'FLASH_PAGE_SIZE0x800 / halfword operations / relock/error behavior'}], 'type': 'original explanatory diagram / logical storage model', 'source': 'Original Codex Pillow geometry based on accepted AG question and actual lesson32 facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}, {'id': 6, 'filename': 'lesson32-refresh-figure6.png', 'alt': 'قالب و اعتبارسنجی رکورد واقعی', 'caption': 'نمودار قالب تألیفی با 8 نیم\u200cکلمه: magic برابر 5A32، format برابر 1، sequence، period، threshold، reserved برابر 0، checksum و commit برابر A55A. checksum متمم مجموع 6 نیم\u200cکلمهٔ نخست است؛ CRC یا احراز اصالت نیست. period از 100 تا 5000 و threshold از 0 تا 4095 بررسی می\u200cشوند. بازیابی پس از reset یا power-cut روی برد مشاهده نشده است.', 'purpose': 'قالب و اعتبارسنجی رکورد واقعی', 'placement': 'بخش 7، در ابتدای بخش آزمایش پیش\u200cبینی\u200cشده و عیب\u200cیابی خط\u200cبه\u200cخط', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, printed82 Tables47/48', 'scope': 'ExactCB capacity and conditioned timing/endurance specifications; not runtime measurement'}, {'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316 targeted Flash sections', 'scope': 'Page organization, program / erase semantics and stalls'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'HAL953955a plus actual lesson32 compiled source', 'scope': 'FLASH_PAGE_SIZE0x800 / halfword operations / relock/error behavior'}], 'type': 'original explanatory diagram / logical storage model', 'source': 'Original Codex Pillow geometry based on accepted AG question and actual lesson32 facts.', 'rights': 'Original layout; no official artwork copied; no invented CC license; system font not redistributed.', 'physical_measurement': False, 'AI_generated_image': False, 'status': 'final source-bound; Codex390/600px and root390px visual reviews completed; frozen'}]
if __name__=='__main__':run()

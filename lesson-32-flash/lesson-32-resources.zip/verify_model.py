"""Offline archive/ELF proof and conceptual Flash-record model, not MCU execution."""
from pathlib import Path
import json,zipfile,hashlib,sys
sys.dont_write_bytecode=True
from inspect_elf import inspect
P=Path(__file__).resolve().parent
meta=json.loads((P/'toolchain-and-validation.json').read_text());name=meta['project'];checks=[]
def check(label,value):
 assert value,label
 checks.append(label)
with zipfile.ZipFile(P/'lesson-32-projects.zip') as z:
 check('sourceZIP CRC',z.testzip() is None)
 hashes=json.loads((P/'source-manifest.json').read_text())
 check('all sourceSHA256',all(hashlib.sha256(z.read(name+'/'+p)).hexdigest()==v for p,v in hashes.items()))
 check('component licenses',all(name+'/'+x in z.namelist() for x in meta['component_licenses']))
 main=z.read(name+'/Core/Src/main.c').decode();ld=z.read(name+'/STM32F303XX_FLASH.ld').decode()
 boot=main.split('/* USER CODE BEGIN 2 */')[1].split('/* USER CODE END 2 */')[0]
 check('boot reads only','Settings_Load();' in boot and 'Settings_Save' not in boot and 'Settings_Erase' not in boot)
 check('no OptionBytes or mass erase app',all(x not in main for x in ['HAL_FLASH_OB_','HAL_FLASHEx_OB','FLASH_TYPEERASE_MASSERASE']))
 check('manual commands consume before write',main.index('flash_command = 0U;')<main.index('last_store_status = Settings_Save'))
 check('one page exact erase source','erase.PageAddress = STORAGE_BASE;' in main and 'erase.NbPages = 1U;' in main)
 check('alignment bounds and empty guard',all(x in main for x in ['address < STORAGE_BASE','address > STORAGE_END - 2U','address & 1U','!= 0xFFFFU']))
 check('body then last marker source',main.index('i < 7U')<main.index('Program_Checked(address + 14U'))
 check('relock both operation functions',main.count('(void)HAL_FLASH_Lock();')==2)
 check('full and sequence limits explicit','return STORE_FULL;' in main and 'return STORE_SEQUENCE_LIMIT;' in main)
 check('actual PLL9 and Flash2',all(s in main for s in ['RCC_HSE_PREDIV_DIV1','RCC_PLL_MUL9','FLASH_LATENCY_2']))
with zipfile.ZipFile(P/'lesson-32-build-artifacts.zip') as z:
 check('artifactZIP CRC',z.testzip() is None)
 elf=z.read(name+'/'+name+'.elf');check('ELF SHA256',hashlib.sha256(elf).hexdigest()==meta['ELF_SHA256']);report=inspect(elf)
sections={s['name']:s for s in report['sections']};symbols=report['symbols']
check('settingsNOLOAD exact region',sections['.settings']['type']==8 and sections['.settings']['VMA']==0x0801F800 and sections['.settings']['size']==2048)
check('settingsboundary ELF symbols',symbols['__settings_start']['address']==0x0801F800 and symbols['__settings_end']['address']==0x08020000)
check('all stored Flash load images below settings',all(s['LMA']+s['size']<=0x0801F800 for s in report['sections'] if s['LMA'] is not None and 0x08000000<=s['LMA']<0x08020000))
check('mainRAM accounting excludes settings',sum(sections[s]['size'] for s in ['.data','.bss','._user_heap_stack'])==1672)
check('Flash geometry',128*1024//2048==64 and 0x08000000+63*2048==0x0801F800 and 126*1024==0x1F800)
check('record capacity',2048//16==128 and 0x0801F800+127*16+14==0x0801FFFE)
check('compileflag evidence',all(s in meta['main_compile_command'] for s in ['-O0','-g3','-Wall','-Werror']))
def checksum(w):return (~sum(w[:6]))&65535
def record(seq=1,period=500,threshold=2048):
 w=[0x5A32,1,seq,period,threshold,0,0,0xA55A];w[6]=checksum(w);return w
def valid(w):
 return w[0]==0x5A32 and w[1]==1 and 0<w[2]<65535 and 100<=w[3]<=5000 and w[4]<=4095 and w[5]==0 and w[6]==checksum(w) and w[7]==0xA55A
def scan(page):
 chosen=None;empty=None;used=0;count=0
 for i,w in enumerate(page):
  if all(x==65535 for x in w):
   if empty is None:empty=i
  else:
   used+=1
   if valid(w):
    count+=1
    if chosen is None or w[2]>chosen[2]:chosen=w
 return chosen,empty,used,count
erased=lambda:[[65535]*8 for _ in range(128)]
check('erased no records defaults case',scan(erased())==(None,0,0,0))
w=record();check('valid model record',valid(w))
check('all prefix cuts before marker rejected',all(not valid(w[:cut]+[65535]*(8-cut)) for cut in range(8)))
page=erased();page[0]=w;page[1]=record(2,750,3000)
check('latest valid record selected',scan(page)[0][2:5]==[2,750,3000])
page[1][7]=65535;check('torn slot not reused and old selected',scan(page)[0][2]==1 and scan(page)[1:]==(2,2,1))
page[5]=record(5);check('scan beyond empty gaps',scan(page)[0][2]==5 and scan(page)[1]==2)
bad=record();bad[4]^=1;check('singlebit checksum model rejects',not valid(bad))
collision=record();collision[3]+=1;collision[4]-=1
check('checksum is not collisionproof',valid(collision))
full=[record(i+1) for i in range(128)];check('fullpage refuses impliciterase',scan(full)[1] is None and scan(full)[2:]==(128,128))
check('bad periods and threshold rejected',not valid(record(period=99)) and not valid(record(period=5001)) and not valid(record(threshold=4096)))
check('sequence boundaries',valid(record(65534)) and not valid(record(0)) and not valid(record(65535)))
check('programming only erased halfword model',all((65535&x)==x for x in record()))
check('erase loses sole latest copy model',scan(erased())[0] is None)
check('manual maintenance budget',128*10000==1280000)
(P/'elf-placement.json').write_text(json.dumps(dict(sections=[s for s in report['sections'] if s['flags']&2],symbols={k:symbols[k] for k in ['__settings_start','__settings_end','_estack','Settings_Load','Settings_Save','Settings_Erase']},segments=report['segments']),indent=2)+'\n')
result=dict(scope='Offline archive/source/ELF checks and abstract record model; prefix-cut model assumes completed halfword steps and does NOT model analog interrupted programming, retention, erase failures, watchdog timing or target execution.',passed=len(checks),checks=checks,values=dict(page_bytes=2048,pages=64,last_page_index=63,last_page_address='0x0801F800',application_bytes=129024,record_bytes=16,records_per_page=128,commit_offset=14,example_record_halfwords=[hex(x) for x in w],mainRAM_reserved_bytes=1672,Flash_payload_bytes=10520,ideal_record_writes_per_10000_erases=1280000,lifetime_note='Arithmetic illustration with full128slot usage per erase only; not a guaranteed durable write count or years of service.'))
(P/'model-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

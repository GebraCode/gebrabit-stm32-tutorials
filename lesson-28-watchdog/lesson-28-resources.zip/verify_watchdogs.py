"""Arithmetic/source/archive checks. Not a watchdog or CPU simulation."""
from pathlib import Path
import json,zipfile,hashlib,math
P=Path(__file__).resolve().parent;checks=[]
def check(n,c):
 assert c,n
 checks.append(n)
iwdg={str(f):64*625/f for f in [30000,40000,50000,60000]}
check('40kHz nominal1second',iwdg['40000']==1)
check('50kHz timeout800ms',iwdg['50000']==.8)
check('60kHz additional assumption666.7ms',math.isclose(iwdg['60000'],2/3))
tau=4096*8/36000000
check('WWDG step910.222us',math.isclose(tau*1e6,910.2222222222))
window=[46*tau,47*tau];reset=[63*tau,64*tau]
counts_at50ms={127-math.floor(.05/tau),127-math.ceil(.05/tau)}
check('50ms healthy counter lies inside66..79',all(66<=x<=79 for x in counts_at50ms))
check('guard avoids high/low boundaries',all(64<=x<=80 for x in range(66,80)))
check('tick subtraction wraps',((7-0xFFFFFFF0)&0xFFFFFFFF)==23)
for kind in ['projects','build-artifacts']:
 with zipfile.ZipFile(P/f'lesson-28-{kind}.zip')as z:
  check(kind+' CRC',z.testzip() is None)
  m=json.loads((P/(kind+'-manifest.json')).read_text());check(kind+' hashes',all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in m.items()))
  if kind=='projects':
   for typ in ['iwdg','wwdg']:
    root='gebrabit_lesson28_'+typ;s=z.read(root+'/Core/Src/main.c').decode();w=z.read(root+'/Core/Src/'+typ+'.c').decode()
    check(typ+' prestartreport',w.index('App_ReportReset();')<w.index('HAL_'+typ.upper()+'_Init('))
    check(typ+' independentflagsnotexclusive',all('RCC_CSR_'+x in s for x in ['IWDGRSTF','WWDGRSTF','PINRSTF','PORRSTF','SFTRSTF','LPWRRSTF','OBLRSTF']))
    check(typ+' intentionalhangnotISRfeed','fault_request != 0U' in s and 'health_tokens == 3U' in s)
r={'scope':'Calculated predictions and static source/archive checks only; no board resets or UART observations','checks_passed':len(checks),'checks':checks,'IWDG_seconds_by_assumed_LSI_Hz':iwdg,'LSI_note':'DS9118 Table45:30/40/50kHz atstatedconditions; Table59footnote60kHz is disclosed separately, not reconciled as verifiedmaximum','WWDG_step_seconds':tau,'WWDG_window_open_time_phase_bounds_seconds':window,'WWDG_reset_time_phase_bounds_seconds':reset,'counter_at50ms_phase_bounds':sorted(counts_at50ms)}
(P/'watchdog-model-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

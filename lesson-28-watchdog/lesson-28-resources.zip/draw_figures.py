"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy+15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=28
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Compare watchdog clocks and windows','Both watchdog-specific Init calls start the counter.')
 panel(d,65,300,470,210,'IWDG',['Independent LSI clock'])
 panel(d,665,300,470,210,'WWDG',['PCLK1=36 MHz'])
 arrow(d,[(300,530),(300,670)]);arrow(d,[(900,530),(900,670)])
 panel(d,65,690,470,330,'12-bit counter',['P=64 / R=624','Window optional','Disabled here'])
 panel(d,665,690,470,330,'7-bit counter',['/4096 /8','C=127 / W=80','Early / late -> reset'])
 panel(d,75,1260,1050,330,'Application progress must justify each refresh',['IWDG ignores system-clock changes, not every fault.','APB1 clocks WWDG; no timer x2 multiplier.','Once started, reset is required to disable.'])
 foot(d,'Clock independence is not a guarantee of detecting every fault.');save(im,1)
def figure2():
 im,d=begin('Model timeout across LSI variation','Actual prescaler 64 and reload 624; models exclude hardware phase uncertainty')
 x0=330;scale=500
 rows=[(40000,1.0,'40 kHz nominal',TEAL),(50000,.8,'50 kHz table limit',TEAL),(30000,4/3,'30 kHz table limit',TEAL),(60000,2/3,'60 kHz separate assumption',ORANGE)]
 for k,(hz,t,label,c)in enumerate(rows):
  y=300+k*280;tx(d,75,y,label,43,c,True);d.rectangle((x0,y+110,x0+t*scale,y+190),fill=c);tx(d,x0,y+200,f'{t:.3f} s',40,c)
 d.line((x0,1460,1110,1460),fill=INK,width=4)
 for t in [0,.5,1,1.5]:
  x=x0+t*scale;d.line((x,1445,x,1475),fill=INK,width=3);tx(d,x-20,1490,str(t),40)
 tx(d,75,1570,'T=(624+1)x64/fLSI; time axis in seconds',42)
 foot(d,'30..50 kHz table conditions and the 60 kHz footnote differ.');save(im,2)
def figure3():
 im,d=begin('Use counter checks inside the window','WWDG: 36 MHz /(4096 x 8), one decrement nominal 0.910222 ms')
 tx(d,75,300,'Start 127; Window 80(0x50); reset at 64 -> 63',45,TEAL,True)
 x0=180;y0=570;scale=9;w=900
 d.rectangle((x0,y0+47*scale,x0+w,y0+63*scale),fill=PALE)
 pts=[]
 for k in range(65):
  xx=x0+k/64*w;yy=y0+k*scale
  if pts:pts.append((xx,pts[-1][1]))
  pts.append((xx,yy))
 d.line(pts,fill=TEAL,width=5);d.line((x0,520,x0,1220,x0+w,1220),fill=INK,width=4)
 tx(d,75,545,'127',40);tx(d,75,970,'80',40)
 tx(d,230,1050,'Legal counts: 0x50..0x40',43,TEAL,True)
 for k in [0,47,64]:tx(d,x0+k/64*w-20,1260,str(k),40)
 tx(d,500,1340,'Decrements since reload',42,TEAL,True)
 tx(d,75,1440,'Phase-bounded window opens: 41.870..42.780 ms',41)
 tx(d,75,1520,'Reset: 57.344..58.254 ms; actual guard uses 66..79.',41)
 foot(d,'These are nominal phase bounds, not measured reset deadlines.');save(im,3)
def figure4():
 im,d=begin('Gate refresh on main progress','Original health-gating model; the delivered demo has two main-context tokens')
 panel(d,65,300,470,380,'Blind ISR refresh',['Main is hung.','Timer ISR still runs.','Watchdog keeps being fed.'],RED)
 panel(d,665,300,470,380,'Main supervisor',['Work A ->token 0x1','Work B ->token 0x2','Required mask: 3'],TEAL)
 arrow(d,[(300,700),(300,820)],RED);arrow(d,[(900,700),(900,820)])
 panel(d,65,840,470,300,'Failure can be hidden',['ISR activity != main health.'],RED)
 panel(d,665,840,470,300,'Health-gated',['Check time / window.','Refresh, clear tokens.','No progress: no feed.'],TEAL)
 panel(d,75,1330,1050,260,'Actual demo health gates',['Work A: 5 ms; B: 10 ms; LED toggles after 50 B units.','Main hang keeps IRQs enabled and stops feeding.'])
 foot(d,'Tokens show selected progress, not proof of all correctness.');save(im,4)
def figure5():
 im,d=begin('Save reset flags before clearing them','Source flags can coexist; no exclusive single-cause classification')
 steps=[('Early main: copy raw RCC_CSR','Save the complete snapshot before changing live flags.'),('Clear live reset flags','Later reset evidence starts from the cleared hardware state.'),('Report saved flags after UART init','IWDG / WWDG / PIN / POR / SW / LP / OBL: all independent.'),('Start watchdog after the report','HAL_IWDG_Init / HAL_WWDG_Init starts the counter.')]
 for k,(a,b)in enumerate(steps):
  yy=300+k*310;panel(d,75,yy,1050,240,a,[b])
  if k<3:arrow(d,[(600,yy+250),(600,yy+300)])
 tx(d,75,1570,'Debug freeze changes the experiment; record its setting.',41,ORANGE)
 foot(d,'This diagram does not claim any actual board flag readback.');save(im,5)
def figure6():
 im,d=begin('Request a controlled watchdog reset','Original logical test setup; no board photo or measured reset log')
 tx(d,75,300,'Onboard PA3 button',46,TEAL,True);tx(d,75,390,'Active LOW; 10 kOhm / 100 nF',40)
 tx(d,75,580,'USART1 board',45,TEAL,True);tx(d,760,580,'3.3 V adapter',45,TEAL,True)
 for y,a,b,left in [(760,'PA9 TX','RXD',False),(940,'PA10 RX','TXD',True)]:
  tx(d,75,y,a,43,TEAL,True);tx(d,840,y,b,43,TEAL,True);arrow(d,[(730 if left else 450,y+35),(450 if left else 730,y+35)])
 tx(d,75,1120,'GND',43);tx(d,840,1120,'GND',43);d.line((450,1160,730,1160),fill=INK,width=5)
 panel(d,75,1310,1050,300,'Expected test sequence',['Press -> main hang -> watchdog reset.','Next boot: compare saved flags with expectation.','PB6 status; SWD PA13/PA14 kept for debug.'])
 foot(d,'Power separately; do not use RS-232 or 5 V UART signals.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson28-refresh-figure1.png', 'alt': 'تفاوت کلاک و رفتار پنجرهٔ انتخاب\u200cشده در دو Watchdog', 'caption': 'نمودار تألیفی IWDG با LSI و شمارندهٔ 12 بیتی و WWDG با PCLK1 برابر 36 MHz و شمارندهٔ 7 بیتی. IWDG در F3 هم پنجرهٔ اختیاری دارد ولی در این پروژه غیرفعال است. فراخوانی HAL_IWDG_Init یا HAL_WWDG_Init ناظر مربوط را شروع می\u200cکند؛ استقلال کلاک تضمین تشخیص همهٔ خرابی\u200cها نیست.', 'purpose': 'تفاوت کلاک و رفتار پنجرهٔ انتخاب\u200cشده در دو Watchdog', 'placement': 'بخش 2: مدل ذهنی و تفاوت\u200cهای بنیادین دو ناظر سخت\u200cافزاری (IWDG در برابر WWDG)', 'type': 'original explanatory diagram / calculated model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, Tables45/59 with distinctnotes', 'scope': 'LSIconditionedrange and conflicting60kfootnote; exactF303watchdogresources'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, checkedindexedsections; no fullmanualreadclaim', 'scope': 'Counter/window/reset/phase concepts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfresh28IWDG/WWDGsource', 'scope': 'Initstarts, optionalIWDGwindow, actualhealthgates/resetreport'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3button/PB6LED/USARTlogicalsetup'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual project/source facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualIWDGP64R624windowdisabled;WWDGdiv4096/8C127W80;bothInitstart/no timerAPBdoublingrule.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 2, 'filename': 'lesson28-refresh-figure2.png', 'alt': 'مدل تغییر timeout مستقل با فرکانس LSI', 'caption': 'نمودار محاسباتی تألیفی با P=64 و RLR=624: در LSI اسمی 40 kHz حدود 1 s و در 50 و 30 kHz حدود 0.8 و 1.333 s به دست می\u200cآید. بازهٔ جدول 45 تحت VDDA برابر 3.3 V و دمای -40 تا 105 درجه است. مقدار 60 kHz از یادداشت دیگر همان دیتاشیت فقط به\u200cعنوان فرض جدا با حدود 0.667 s نمایش داده شده، نه حداکثر قطعی جدول؛ فاز و زمان reset اندازه\u200cگیری نشده\u200cاند.', 'purpose': 'مدل تغییر timeout مستقل با فرکانس LSI', 'placement': 'بخش 3: واچ\u200cداگ مستقل (IWDG): کلاک LSI، روابط ریاضی و افشای تناقض اسناد ST', 'type': 'original explanatory diagram / calculated model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, Tables45/59 with distinctnotes', 'scope': 'LSIconditionedrange and conflicting60kfootnote; exactF303watchdogresources'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, checkedindexedsections; no fullmanualreadclaim', 'scope': 'Counter/window/reset/phase concepts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfresh28IWDG/WWDGsource', 'scope': 'Initstarts, optionalIWDGwindow, actualhealthgates/resetreport'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3button/PB6LED/USARTlogicalsetup'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual project/source facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'T625*64/f, table30..50conditionsnotglobalwrong60claim;60separateassumptionfromTable59footnote. No measuredtimeout.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 3, 'filename': 'lesson28-refresh-figure3.png', 'alt': 'پنجرهٔ WWDG در حوزهٔ شمارنده و کران فاز', 'caption': 'مدل پله\u200cای تألیفی WWDG با Counter=127 و Window=80 یا 0x50. بازخوانی در شمارندهٔ 0x40 تا 0x50 مجاز است و گذار 0x40 به 0x3F reset می\u200cکند؛ برنامه از داخل بازه با شرط 66 تا 79 استفاده می\u200cکند. با کلاک اسمی 36 MHz و تقسیم 4096 و 8، فاز مقسم شروع پنجره را حدود 41.870 تا 42.780 ms و reset را حدود 57.344 تا 58.254 ms محدود می\u200cکند؛ این\u200cها deadline واقعی اندازه\u200cگیری\u200cشده نیستند.', 'purpose': 'پنجرهٔ WWDG در حوزهٔ شمارنده و کران فاز', 'placement': 'بخش 4: واچ\u200cداگ پنجره\u200cای (WWDG): روابط زمانی دقیق بر پایه کلاک 36 MHz باس APB1', 'type': 'original explanatory diagram / calculated model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, Tables45/59 with distinctnotes', 'scope': 'LSIconditionedrange and conflicting60kfootnote; exactF303watchdogresources'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, checkedindexedsections; no fullmanualreadclaim', 'scope': 'Counter/window/reset/phase concepts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfresh28IWDG/WWDGsource', 'scope': 'Initstarts, optionalIWDGwindow, actualhealthgates/resetreport'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3button/PB6LED/USARTlogicalsetup'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual project/source facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Step32,768/36MHz=.910222ms;47thdecrementwindowopensphase46..47;64thresetphase63..64; actualguard66..79notboundaryfeed.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 4, 'filename': 'lesson28-refresh-figure4.png', 'alt': 'وابسته\u200cکردن Refresh به پیشرفت main', 'caption': 'مدل تألیفی تفاوت تغذیهٔ کورکورانه در ISR و supervisor حلقهٔ اصلی. در کد واقعی دو واحد main با دورهٔ اسمی 5 و 10 ms توکن\u200cهای 0x1 و 0x2 می\u200cسازند و تنها mask برابر 3 همراه شرایط زمانی و پنجره مجوز Refresh می\u200cدهد؛ پس از آن توکن\u200cها پاک می\u200cشوند. LED پس از 50 واحد دوم Toggle می\u200cشود. توکن شاهد پیشرفت انتخاب\u200cشده است، نه گواه درستی همهٔ برنامه.', 'purpose': 'وابسته\u200cکردن Refresh به پیشرفت main', 'placement': 'بخش 5: راهبردهای ریفرش (Watchdog Refresh Strategies): الگوها و پادالگوها', 'type': 'original explanatory diagram / calculated model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, Tables45/59 with distinctnotes', 'scope': 'LSIconditionedrange and conflicting60kfootnote; exactF303watchdogresources'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, checkedindexedsections; no fullmanualreadclaim', 'scope': 'Counter/window/reset/phase concepts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfresh28IWDG/WWDGsource', 'scope': 'Initstarts, optionalIWDGwindow, actualhealthgates/resetreport'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3button/PB6LED/USARTlogicalsetup'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual project/source facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actualtwohealthtokensmask3, main5/10ms;IWDG250ms/WWDG50mspluscounterguard;blindISRantipatternconceptnotcompiledvariant.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 5, 'filename': 'lesson28-refresh-figure5.png', 'alt': 'ذخیرهٔ همهٔ پرچم\u200cهای reset پیش از پاک\u200cسازی', 'caption': 'روندنمای تألیفی کد واقعی: در ابتدای main کل RCC_CSR snapshot و سپس پرچم\u200cهای زنده پاک می\u200cشوند؛ پس از راه\u200cاندازی clock و UART مقدار ذخیره\u200cشده و هر هفت پرچم مستقل گزارش و سپس Watchdog شروع می\u200cشود. چند پرچم می\u200cتواند هم\u200cزمان set باشد و شکل یک علت انحصاری یا خواندن واقعی پرچم روی برد را ادعا نمی\u200cکند.', 'purpose': 'ذخیرهٔ همهٔ پرچم\u200cهای reset پیش از پاک\u200cسازی', 'placement': 'بخش 6: ثبت و پردازش پرچم\u200cهای علت ریست در رجیستر RCC_CSR', 'type': 'original explanatory diagram / calculated model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, Tables45/59 with distinctnotes', 'scope': 'LSIconditionedrange and conflicting60kfootnote; exactF303watchdogresources'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, checkedindexedsections; no fullmanualreadclaim', 'scope': 'Counter/window/reset/phase concepts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfresh28IWDG/WWDGsource', 'scope': 'Initstarts, optionalIWDGwindow, actualhealthgates/resetreport'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3button/PB6LED/USARTlogicalsetup'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual project/source facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'RawCSRcapturethenRMVFclear; UARTreportbeforeInitstartsWD;7independentflagsnotelse-ifexclusivecause;debugfreezechangestest.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}, {'id': 6, 'filename': 'lesson28-refresh-figure6.png', 'alt': 'اتصال منطقی ترمینال و آزمایش هنگ کنترل\u200cشده', 'caption': 'نمودار تألیفی کلید onboard روی PA3 و USART1 روی PA9/PA10 با مبدل TTL سازگار 3.3 V و زمین مشترک. فشار تازهٔ تأییدشده درخواست هنگ main و قطع Refresh می\u200cدهد و انتظار می\u200cرود راه\u200cاندازی بعدی پرچم\u200cها را گزارش کند. PB6 LED وضعیت و SWD محفوظ است؛ تصویر برد یا لاگ reset واقعی ارائه نشده است.', 'purpose': 'اتصال منطقی ترمینال و آزمایش هنگ کنترل\u200cشده', 'placement': 'بخش 10: آزمایش تجربی و مدل رفتاری پیش\u200cبینی\u200cشده روی برد GebraBit GB100ST', 'type': 'original explanatory diagram / calculated model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14, Tables45/59 with distinctnotes', 'scope': 'LSIconditionedrange and conflicting60kfootnote; exactF303watchdogresources'}, {'url': 'https://www.st.com/resource/en/reference_manual/DM00043574.pdf', 'version': 'RM0316, checkedindexedsections; no fullmanualreadclaim', 'scope': 'Counter/window/reset/phase concepts'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx-hal-driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'PinnedHAL953955a; actualfresh28IWDG/WWDGsource', 'scope': 'Initstarts, optionalIWDGwindow, actualhealthgates/resetreport'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'PA3button/PB6LED/USARTlogicalsetup'}], 'rights': 'Original new geometry; no official figure/photo copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and actual project/source facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualPA3debounced20msnewpress/faultrequest mainhangIRQsremainon, noheldbootfalsepress; expectedresetnotmeasured. TXRXcross3V3commonGNDnoRS232.', 'status': 'final-source-bound; Codex visual review completed; no physical measurement'}]
if __name__=='__main__':run()

"""Original reproducible USB CDC teaching diagrams; Python + Pillow required.
Uses installed Segoe UI or DejaVu Sans. No font files are distributed.
All diagrams describe the included F303CB project, not observed USB traffic.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math
P=Path(__file__).resolve().parent;Q=P.parent/'visual-qa';Q.mkdir(exist_ok=True)
W,H=1200,1800;INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e';LINE='#ccdbe3';BG='#f5f8fa';FREE='#d8f0e9';WHITE='white'
def font(n=44,b=False):
 for p in ['C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf','DejaVuSans'+('-Bold' if b else '')+'.ttf']:
  try:return ImageFont.truetype(p,n)
  except OSError:pass
 raise RuntimeError('Install Segoe UI or DejaVu Sans')
def text(d,x,y,s,w=1050,n=44,c=INK,b=False):
 lines=[];line=''
 for word in s.split():
  trial=(line+' '+word).strip()
  if line and d.textlength(trial,font=font(n,b))>w:lines.append(line);line=word
  else:line=trial
 if line:lines.append(line)
 for ln in lines:
  box=d.textbbox((x,y),ln,font=font(n,b));assert box[2]<=W-25 and box[3]<H-20,(s,box)
  d.text((x,y),ln,font=font(n,b),fill=c);y+=n+13
 return y
def box(d,x,y,w,h,fill='white',outline=LINE):d.rounded_rectangle((x,y,x+w,y+h),18,fill=fill,outline=outline,width=4)
def arrow(d,x,y,x2,y2,c=TEAL):
 d.line((x,y,x2,y2),fill=c,width=7);a=math.atan2(y2-y,x2-x)
 d.polygon([(x2,y2),(x2-25*math.cos(a-.5),y2-25*math.sin(a-.5)),(x2-25*math.cos(a+.5),y2-25*math.sin(a+.5))],fill=c)
def header(title,sub):
 im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im);y=text(d,65,35,title,1070,58,INK,True);text(d,65,y+12,sub,1070,42,MUTED);d.line((65,245,1135,245),fill=LINE,width=3);return im,d
def card(d,y,title,body,h=260,c=TEAL):
 box(d,65,y,1070,h,outline=c);yy=text(d,90,y+18,title,1020,46,c,True);yy=text(d,90,yy+14,body,1020,43);assert yy<=y+h-10,(title,yy,y+h)
def footer(d,s='Original diagram; no hardware test or captured USB traffic.'):
 d.line((65,1640,1135,1640),fill=LINE,width=3);text(d,65,1660,s,1070,38,MUTED)
def save(im,i):
 im.save(P/f'lesson48-figure{i}.png',optimize=True)
 for size in [390,600]:im.resize((size,H*size//W),Image.Resampling.LANCZOS).save(Q/f'fig{i}-{size}.png')

im,d=header('External USB connection','Bus-powered bench setup: GB100ST V2.0 / STM32F303CB')
box(d,65,365,300,1020,WHITE,TEAL);text(d,90,395,'USB port',250,47,TEAL,True)
box(d,800,675,335,710,WHITE,TEAL);text(d,825,700,'STM32F303CB',285,42,TEAL,True)
box(d,650,300,485,240,WHITE,ORANGE);text(d,680,330,'Board regulator',425,47,ORANGE,True);text(d,680,420,'5 V -> 3.3 V',425,45)
for label,y in [('VBUS 5 V',510),('D+',840),('D-',1070),('GND',1320)]:text(d,90,y-38,label,260,46,INK,True)
for label,y in [('PA12 / D+',840),('PA11 / D-',1070),('GND',1320)]:text(d,825,y-38,label,280,44,INK,True)
d.line((365,510,500,510,500,400,650,400),fill=ORANGE,width=7)
d.line((965,540,965,620,620,620,620,700),fill=TEAL,width=7);text(d,755,553,'3.3 V',300,43,TEAL,True)
d.rectangle((597,700,643,780),fill=WHITE,outline=TEAL,width=6);text(d,390,700,'1.5 kOhm',200,40,TEAL,True)
d.line((620,780,620,840),fill=TEAL,width=7)
for y,c in [(840,TEAL),(1070,TEAL),(1320,INK)]:d.line((365,y,800,y),fill=c,width=7)
d.ellipse((609,829,631,851),fill=TEAL)
text(d,405,1120,'Short data pair',340,41,MUTED)
text(d,85,1440,'Use one power source. Never connect D+ pull-up to 5 V. A real PCB also needs suitable ESD protection and routing.',1030,45,RED)
footer(d,'Logical connections, not connector pin order. Check the breakout labels.')
save(im,1)

im,d=header('The USB clock is 48 MHz','The USB line rate is 12 Mbit/s: a different quantity')
card(d,300,'HSE crystal: 8 MHz','PREDIV /1 supplies the PLL input.',220)
arrow(d,600,535,600,610)
card(d,630,'PLL x9: 72 MHz','SYSCLK 72 MHz; AHB /1. APB1 /2 = 36 MHz, APB2 /1 = 72 MHz. Flash latency 2 WS.',310)
arrow(d,600,955,600,1030)
card(d,1050,'USB prescaler /1.5','72 MHz /1.5 = 48 MHz nominal USB peripheral clock.',260)
text(d,85,1400,'The crystal and clock circuit still need to meet USB clock tolerance. Arithmetic alone is not a physical frequency test.',1030,45,ORANGE)
footer(d,'Matches actual generated SystemClock_Config and the included arithmetic model.')
save(im,2)

im,d=header('USB and CAN memories differ','Correction for STM32F303xB/C: do not copy the F103 restriction')
box(d,75,325,490,370,WHITE,TEAL);text(d,110,365,'USB peripheral',420,48,TEAL,True);text(d,110,495,'Dedicated 512 B packet memory',420,46)
box(d,635,325,490,370,WHITE,ORANGE);text(d,670,365,'CAN peripheral',420,48,ORANGE,True);text(d,670,495,'Dedicated 512 B memory',420,46)
text(d,185,760,'Separate memories on F303xB/C',920,49,INK,True)
card(d,920,'Pin conflicts are a separate question','USB uses PA11/PA12. CAN on those same pins would conflict; other mappings need their own configuration.',310)
card(d,1310,'This project: CAN is disabled','The separate-memory fact does not claim that simultaneous CAN/USB was tested here.',260,ORANGE)
footer(d,'Source: ST AN4228 Rev 6, Table 6, page 12. No simultaneous-peripheral test.')
save(im,3)

im,d=header('Enumeration is host-controlled','Simplified example sequence; hosts may repeat requests')
text(d,105,290,'Host PC',360,48,TEAL,True);text(d,785,290,'USB device',360,48,TEAL,True)
d.line((200,380,200,1410),fill=LINE,width=6);d.line((975,380,975,1410),fill=LINE,width=6)
events=[('Detect D+ pull-up',440,'back'),('Bus reset',605,'forward'),('Read device descriptor',770,'forward'),('Assign an address',935,'forward'),('Read configuration',1100,'forward'),('Set configuration',1265,'forward')]
for label,y,direction in events:
 text(d,280,y-75,label,650,43,INK,True)
 if direction=='forward':arrow(d,210,y,965,y)
 else:arrow(d,965,y,210,y)
text(d,85,1470,'The host may bind a CDC driver and create a virtual serial port. The actual port name depends on the host.',1030,45,ORANGE)
footer(d,'Conceptual sequence, not a bus trace or a verified host-driver screenshot.')
save(im,4)

im,d=header('CDC endpoints in this project','IN and OUT are named from the host perspective')
card(d,300,'EP0: control, both directions','Descriptors, configuration and CDC requests such as SET_LINE_CODING and DTR/RTS.',275)
card(d,630,'0x81 IN + 0x01 OUT: data','Bulk endpoints, maximum 64 B per packet. They carry the echoed byte stream.',260)
card(d,945,'0x82 IN: notification endpoint','Interrupt type, maximum 8 B. The descriptor includes it; this echo application does not send serial-state notifications.',310)
text(d,85,1360,'Communication interface 0 + data interface 1. Packet boundaries do not define application message boundaries.',1030,45,ORANGE)
footer(d,'Matches the pinned ST USB Device Library 2.5.3 CDC descriptor and header.')
save(im,5)

im,d=header('One packet owns the mailbox','Static 64 B echo buffer; no FIFO and no busy wait in the ISR')
card(d,300,'1. OUT callback: copy received bytes','Copy at most 64 B and mark phase 1. Leave OUT unarmed: later OUT packets receive NAK.',285)
arrow(d,600,600,600,650)
card(d,670,'2. Main poll: submit IN transfer','USBD_BUSY keeps phase 1 for a later poll. USBD_OK moves to phase 2. Keep the bytes unchanged.',285)
arrow(d,600,970,600,1020)
card(d,1040,'3. Later poll: TxState becomes 0','The class has completed IN, including a required ZLP. Release mailbox and rearm OUT.',285)
text(d,85,1410,'Main poll saves and restores PRIMASK around shared state. No application Tx-complete callback exists in this library version.',1030,44,ORANGE)
footer(d,'USB 2.5.3 class state is polled. Disconnection can discard unfinished data.')
save(im,6)

captions=[
 'شماتیک تألیفی اتصال آزمایشی USB به GB100ST؛ D+ به PA12 و D- به PA11 متصل می‌شود و مقاومت خارجی 1.5 کیلو‌اهم، D+ را به 3.3V بالا می‌کشد. در مثال تغذیه از گذرگاه، VBUS تنها ورودی 5V رگولاتور برد را تغذیه می‌کند؛ منبع تغذیهٔ دوم متصل نشود. ترتیب ترسیم پایه‌ها، ترتیب فیزیکی کانکتور نیست. این شکل جای طراحی ESD، مسیرکشی USB یا تأیید سازگاری الکتریکی را نمی‌گیرد.',
 'نمودار تألیفی مسیر کلاک واقعی پروژه؛ HSE برابر 8MHz با ضریب PLL برابر 9 به 72MHz می‌رسد و تقسیم‌کنندهٔ USB با ضریب 1.5 کلاک اسمی 48MHz می‌سازد. نرخ سیگنال‌دهی Full-Speed برابر 12Mbit/s است و با فرکانس کلاک یا تنظیم Baud پورت مجازی یکی نیست. این محاسبه اندازه‌گیری کریستال یا احراز تلرانس فرکانسی نیست.',
 'نمودار تألیفی اصلاح یک خطای سند سفارش: طبق AN4228، در STM32F303xB/C حافظهٔ 512 بایتی USB با حافظهٔ CAN مشترک نیست. محدودیت اشتراک حافظهٔ STM32F103 نباید به این تراشه تعمیم داده شود. تداخل احتمالی پایه‌ها مسئلهٔ جداگانه‌ای است و پروژهٔ این درس، CAN یا اجرای هم‌زمان دو رابط را آزمایش نمی‌کند.',
 'توالی مفهومی و ساده‌شدهٔ شناسایی USB؛ میزبان پس از مشاهدهٔ وضعیت اتصال، Reset و درخواست‌های کنترلی را مدیریت می‌کند و از توصیفگرها برای انتخاب پیکربندی و درایور استفاده می‌کند. ترتیب جزئی و تکرار درخواست‌ها به میزبان بستگی دارد. این شکل ردگیری واقعی گذرگاه یا تصویر پورت COM نیست.',
 'نمودار تألیفی نقاط پایانی واقعی کلاس CDC این پروژه؛ EP0 درخواست‌های کنترلی از جمله تنظیم خط مجازی و DTR/RTS را جابه‌جا می‌کند، 0x81 و 0x01 برای دادهٔ Bulk با بستهٔ حداکثر 64 بایت هستند و 0x82 برای Notification از نوع Interrupt با حداکثر 8 بایت تعریف شده است. برنامهٔ پژواک، Notification وضعیت سریال ارسال نمی‌کند.',
 'نمودار تألیفی چرخهٔ مالکیت بافر در پژواک؛ یک صندوق 64 بایتی تا پایان ارسال IN ثابت می‌ماند و OUT در این فاصله دوباره آماده نمی‌شود. Main در نوبت‌های بعدی وضعیت TxState را بررسی و پس از تکمیل، دریافت را آماده می‌کند. این پیاده‌سازی FIFO یا حلقهٔ انتظار داخل وقفه ندارد و کتابخانهٔ نسخهٔ 2.5.3 نیز Callback تکمیل ارسال برای برنامه تعریف نکرده است.'
]
alts=['اتصال منطقی D+ و D- به PA12 و PA11 با مقاومت1.5کیلو‌اهم به3.3V و مسیر جداگانهٔ تغذیه5Vرگولاتور','تولید کلاک USB48MHz از PLL72MHz با تقسیم1.5 و تفکیک آن از نرخ خط12Mbit/s','دو ناحیهٔ حافظهٔ مستقل USB و CAN در STM32F303xB/C و تفکیک آن از تداخل پایه‌ها','توالی مفهومی درخواست‌های میزبان برای شناسایی و پیکربندی دستگاه USB','نگاشت EP0کنترل،0x81و0x01داده و0x82اعلان در CDC واقعی پروژه','چرخهٔ سه‌مرحله‌ای دریافت یک بسته، ارسال با بافر ثابت و آماده‌سازی دوبارهٔ OUT پس از تکمیل']
pin='https://github.com/STMicroelectronics/stm32-mw-usb-device/blob/e5a58ee2260204bfed632c7c56da0fdb41514a51/'
sources=['ST AN2606 F303xB/C hardware table; ST AN4879 mainstream family table; actual generated PA11/12 AF14 setup','Actual generated Core/Src/main.c SystemClock_Config; included usb_model.py','ST AN4228 Rev6 Table6 printedpage12; ST AN4879 Rev12 Table3','Pinned ST USB Core enumeration handling and USB2.0 conceptual sequence',pin+'Class/CDC/Inc/usbd_cdc.h; '+pin+'Class/CDC/Src/usbd_cdc.c','Actual USER CODE in USB_DEVICE/App/usbd_cdc_if.c; pinned CDC DataIn TxState handling']
metadata=[{'id':f'fig{i:02d}','filename':f'lesson48-figure{i}.png','width':W,'height':H,'caption':captions[i-1],'alt':alts[i-1],'source':sources[i-1],'license':'Original diagrams and drawing code by GEBRA ENG, CC BY 4.0; sources cited, not reproduced.','kind':'original conceptual diagram','pixels_reviewed':False} for i in range(1,7)]
(P/'image-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for size in [390,600]:
 sheet=Image.new('RGB',(size*3,H*size//W*2),'white')
 for i in range(1,7):sheet.paste(Image.open(Q/f'fig{i}-{size}.png'),(((i-1)%3)*size,((i-1)//3)*H*size//W))
 sheet.save(Q/f'contact-sheet-{size}.png')
print('6 USB diagrams generated; inspect actual pixels before publication.')

"""Reproducible clock/PMA/packet arithmetic. No USB device is accessed."""
from pathlib import Path
from fractions import Fraction
import json
P=Path(__file__).resolve().parent
clock=Fraction(8_000_000*9,1)/Fraction(3,2)
assert clock==48_000_000
regions=[('BTABLE_EP0_EP1_EP2',0x000,24),('EP0_OUT',0x018,64),('EP0_IN',0x058,64),('EP1_IN',0x0c0,64),('EP2_INTERRUPT_IN',0x100,8),('EP1_OUT',0x110,64)]
for i,(_,start,size) in enumerate(regions):
 assert start%2==0 and start+size<=512
 for _,other,other_size in regions[i+1:]:assert start+size<=other or other+other_size<=start
packets=[]
for length in [1,63,64,65,128,257,1024]:
 chunks=[min(64,length-n) for n in range(0,length,64)]
 assert sum(chunks)==length and all(0<n<=64 for n in chunks)
 packets.append({'payload_bytes':length,'hypothetical_OUT_chunks':chunks,'echo_IN_ZLPs_if_each_chunk_is_its_own_transfer':sum(n==64 for n in chunks)})
r={'kind':'offline arithmetic, not hardware measurement','USB_clock_Hz':int(clock),'USB_FullSpeed_signalling_bit_s':12_000_000,'PMA_bytes':512,'PMA_regions':[{'name':n,'offset':hex(s),'bytes':z} for n,s,z in regions],'packet_model_assumption':'Assume host OUT splits into maximal64B chunks. Real host driver may split differently. Each chunk is echoed independently. CDC byte stream is not message-framed.','packet_model':packets,'hardware_accessed':False}
(P/'usb-model-output.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
print(json.dumps({'USB_clock_Hz':int(clock),'disjoint_PMA_regions':len(regions),'model_payload_cases':len(packets)}))

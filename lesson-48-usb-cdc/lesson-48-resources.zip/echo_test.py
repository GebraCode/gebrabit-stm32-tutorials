"""Optional real-host USB CDC echo test. Requires pyserial. Not run by the author.

The user must explicitly provide the actual USB CDC port. This script does not
search for ports or communicate with any device until invoked with that port.
"""
import argparse,time
def main():
 parser=argparse.ArgumentParser(description='Compare exact binary USB CDC echo bytes on an explicitly selected port.')
 parser.add_argument('port',help='Actual USB CDC port, e.g. COM7 or /dev/ttyACM0')
 parser.add_argument('--timeout',type=float,default=5.0,help='Per-case completion timeout in seconds (default5)')
 args=parser.parse_args()
 if args.timeout<=0:parser.error('--timeout must be positive')
 import serial
 with serial.Serial(args.port,115200,timeout=0.1,write_timeout=args.timeout) as link:
  link.reset_input_buffer()
  for length in [1,63,64,65,128,257,1024]:
   payload=bytes(i%256 for i in range(length))
   sent=link.write(payload)
   if sent!=len(payload):raise RuntimeError(f'Only {sent} of {length} bytes accepted by host driver')
   received=bytearray();deadline=time.monotonic()+args.timeout
   while len(received)<length and time.monotonic()<deadline:
    received.extend(link.read(length-len(received)))
   if bytes(received)!=payload:raise RuntimeError(f'Echo mismatch: sent{length}, received{len(received)} bytes')
   print(f'PASS: exact binary echo, {length} bytes')
 print('These results describe this host/board run only; they are not a USB compliance or throughput test.')
if __name__=='__main__':main()

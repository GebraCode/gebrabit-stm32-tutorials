"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)
OUT=Path(__file__).resolve().parent
LESSON=7
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)

def figure1():
 im,d=begin('Debug access and trace are different paths','Logical connections only; no assumed connector numbering')
 tx(d,75,300,'Probe',48,TEAL,True);tx(d,800,300,'STM32',48,TEAL,True)
 rows=[('SWDIO','PA13'),('SWCLK','PA14'),('NRST','NRST'),('GND / reference','GND / target VDD')]
 for k,(a,b)in enumerate(rows):
  y=470+k*170;tx(d,75,y,a,40,TEAL,True);tx(d,765,y,b,40,TEAL,True);arrow(d,[(450,y+30),(735,y+30)])
 tx(d,75,1210,'SWO input',44,ORANGE,True);tx(d,765,1210,'PB3 / SWO',44,ORANGE,True)
 arrow(d,[(735,1250),(450,1250)],ORANGE)
 panel(d,75,1390,1050,200,'SWO is optional and probe-dependent',['SWD-only probes cannot provide this trace channel.'])
 foot(d,'Probe voltage and power rules remain model-specific.');save(im,1)
def figure2():
 im,d=begin('Choose how to cross a function call','Conceptual source stepping, not an observed debugger session')
 panel(d,80,300,1040,180,'Caller: Trace_TryPutChar(...)',['The actual exercise calls this user helper.'])
 panel(d,360,700,760,245,'Helper body',['Check trace readiness, write or count a drop'])
 panel(d,80,1220,1040,180,'Next caller statement',['Execution resumes after the helper returns.'])
 arrow(d,[(600,500),(600,670)]);tx(d,650,570,'Step Into',46,TEAL,True)
 arrow(d,[(1125,800),(1150,800),(1150,1170),(1000,1170),(1000,1200)],ORANGE)
 tx(d,650,1000,'Step Return',46,ORANGE,True)
 arrow(d,[(160,500),(160,1160),(260,1160),(260,1200)],TEAL)
 tx(d,185,1010,'Step Over',44,TEAL,True)
 para(d,80,1490,'Breakpoints, interrupts and optimized source mapping can affect where a step stops.',1030,42)
 foot(d,'Step Over executes a call; it does not skip its effects.');save(im,2)
def figure3():
 im,d=begin('Use a condition to inspect a boundary','A predicted exercise result, not a live variable capture')
 tx(d,75,300,'Actual buggy condition: step_count > 10',46,TEAL,True)
 tx(d,75,400,'Boundary to investigate: step_count = 10',44)
 d.line((125,700,1080,700),fill=INK,width=4)
 for x,a in [(180,'9'),(570,'10'),(980,'11')]:
  d.ellipse((x-18,682,x+18,718),fill=TEAL);tx(d,x-25,600,a,48,TEAL,True)
 arrow(d,[(570,740),(570,870)])
 panel(d,75,890,1050,210,'Conditional breakpoint: stop when condition is true',['Evaluation depends on debugger / server support.'])
 panel(d,75,1210,1050,320,'Predicted first event from the actual source',['Buggy > 10: loop 11, observed_value 22','Fixed >= 10: loop 10, observed_value 20','A condition may involve halt / inspect / resume work.'])
 foot(d,'No native hardware variable-compare or zero-overhead claim.');save(im,3)
def figure4():
 im,d=begin('Ask what a debugger view can observe','Scope, update mode and target state constrain the answer')
 rows=[('Variables','Current scope and debug information','Often inspected while halted'),('Expressions','Chosen expressions and global values','Validity depends on location and evaluation'),('Live Expressions','Supported reads while the target runs','Probe, server and memory access dependent')]
 for k,(a,b,c)in enumerate(rows):
  yy=300+k*360;panel(d,75,yy,1050,265,a,[b,c])
 panel(d,75,1410,1050,210,'Core / peripheral registers and memory',['Reading some peripheral registers can have side effects.'])
 foot(d,'No fixed sample rate or continuous real-time visibility is promised.');save(im,4)
def figure5():
 im,d=begin('Follow one trace character out of the core','The helper attempts once; it does not configure the trace transport')
 stages=[('Trace_TryPutChar','Check TRCENA, ITMENA, TER0 and port readiness'),('ITM stimulus port 0','Write the byte only if the path is ready'),('ITM -> TPIU -> PB3 SWO','Debugger must set up the transport and core clock'),('Compatible probe -> trace viewer','Core clock setting: nominal 8 MHz, not SWO baud')]
 for k,(a,b)in enumerate(stages):
  y=290+k*305;panel(d,75,y,1050,220,a,[b])
  if k<3:arrow(d,[(600,y+230),(600,y+295)])
 tx(d,75,1560,'Not ready? Count trace_dropped; return without waiting.',40,ORANGE)
 foot(d,'No actual SWO capture or trace-viewer session was performed.');save(im,5)
def figure6():
 im,d=begin('Optimization changes debug visibility','Real build sizes below; source-level variable visibility is not guaranteed')
 vals=[('Buggy Debug -O0 -g3',8284),('Buggy -Og -g3',4408),('Fixed Debug -O0 -g3',8284)]
 for k,(a,v)in enumerate(vals):
  y=300+k*250;tx(d,75,y,a,44,TEAL,True)
  d.rectangle((75,y+90,75+v/8284*1000,y+165),fill=TEAL);tx(d,75,y+175,f'{v} bytes Flash',40)
 panel(d,75,1120,1050,230,'RAM link region: 1600 bytes in all three',['These include reservations, not measured runtime peak.'])
 para(d,75,1440,'DWARF may describe changing locations or no usable value. Neither -O0 nor -Og guarantees every variable stays visible.',1030,42)
 foot(d,'Build results are real; live debugger availability was not tested.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson07-refresh-figure1.png', 'alt': 'تفاوت مسیر SWD و خروجی اختیاری SWO', 'caption': 'نمودار تألیفی اتصال منطقی SWD به PA13 و PA14 و مسیر برگشتی SWO روی PB3. شمارهٔ کانکتور و مقاومت فرض نشده است؛ قابلیت دریافت SWO و قواعد مرجع ولتاژ به مدل دقیق پروب وابسته است.', 'purpose': 'تفاوت مسیر SWD و خروجی اختیاری SWO', 'placement': 'در بخش مسیرهای سیگنال SWD و پایه ردیابی SWO در بورد GB100ST V2.0', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10', 'scope': 'Cortex-M4 debug and ITM concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical SWD/SWO names, no connectorpositions'}, {'url': 'local:toolchain-and-validation.json and actual project source/artifacts', 'version': 'Fresh lesson07 v2 builds; GCC13.2.1; HAL953955a', 'scope': 'Source prediction, helper behavior and actual measured host build sizes'}, {'url': 'https://gcc.gnu.org/onlinedocs/gcc/Debugging-Options.html', 'version': 'Official GCC documentation', 'scope': 'Optimization and debug information limitations'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Logical signals only, no invented headerpositions/pullups/impedance; SWO probe-dependent.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson07-refresh-figure2.png', 'alt': 'معنای گام\u200cبرداری در یک فراخوانی تابع', 'caption': 'مدل تألیفی Step Into و Step Over و Step Return با نام helper واقعی پروژه. Step Over اثر تابع را حذف نمی\u200cکند؛ نقطهٔ توقف و وقفه و بهینه\u200cسازی می\u200cتواند محل توقف را تغییر دهد. این نمودار نتیجهٔ جلسهٔ واقعی دیباگ نیست.', 'purpose': 'معنای گام\u200cبرداری در یک فراخوانی تابع', 'placement': 'در بخش مفاهیم پایه گام\u200cبرداری: تفاوت عملیاتی Step Into، Step Over و Step Return', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10', 'scope': 'Cortex-M4 debug and ITM concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical SWD/SWO names, no connectorpositions'}, {'url': 'local:toolchain-and-validation.json and actual project source/artifacts', 'version': 'Fresh lesson07 v2 builds; GCC13.2.1; HAL953955a', 'scope': 'Source prediction, helper behavior and actual measured host build sizes'}, {'url': 'https://gcc.gnu.org/onlinedocs/gcc/Debugging-Options.html', 'version': 'Official GCC documentation', 'scope': 'Optimization and debug information limitations'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Uses actual Trace_TryPutChar caller; conceptual stepping, no UI/run evidence or guaranteed line mapping.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson07-refresh-figure3.png', 'alt': 'بررسی مرز خطای منطقی و توقف شرطی', 'caption': 'نمودار تألیفی مرز step_count برابر 10 و نتیجهٔ پیش\u200cبینی\u200cشده از منبع واقعی: شرط نادرست >10 نخست در حلقهٔ 11 با observed_value برابر 22 و نسخهٔ اصلاح\u200cشده >=10 در حلقهٔ 10 با مقدار 20 رویداد می\u200cسازد. ارزیابی شرط ممکن است توقف و خواندن و ادامهٔ داخلی داشته باشد؛ این اعداد مشاهدهٔ زنده نیستند.', 'purpose': 'بررسی مرز خطای منطقی و توقف شرطی', 'placement': 'در بخش نقاط توقف شرطی (Conditional Breakpoint) بر پایه مقادیر متغیرها و شمارنده\u200cها', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10', 'scope': 'Cortex-M4 debug and ITM concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical SWD/SWO names, no connectorpositions'}, {'url': 'local:toolchain-and-validation.json and actual project source/artifacts', 'version': 'Fresh lesson07 v2 builds; GCC13.2.1; HAL953955a', 'scope': 'Source prediction, helper behavior and actual measured host build sizes'}, {'url': 'https://gcc.gnu.org/onlinedocs/gcc/Debugging-Options.html', 'version': 'Official GCC documentation', 'scope': 'Optimization and debug information limitations'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Predicted11/10 not actualGUI; debugger-dependent conditional evaluation, no native hardware variable comparator or overhead-free claim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson07-refresh-figure4.png', 'alt': 'قابلیت مشاهده در نماهای دیباگر', 'caption': 'نمودار تألیفی نقش Variables و Expressions و Live Expressions و نماهای رجیستر و حافظه. دسترس\u200cپذیری مقدار به دامنه و دادهٔ دیباگ و وضعیت هدف و پشتیبانی ابزار وابسته است؛ نرخ ثابت 10 Hz یا مشاهدهٔ بلادرنگ پیوسته ادعا نشده است.', 'purpose': 'قابلیت مشاهده در نماهای دیباگر', 'placement': 'در بخش پنجره\u200cهای مانیتورینگ متغیرها و تفاوت\u200cهای کاربردی آن\u200cها', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10', 'scope': 'Cortex-M4 debug and ITM concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical SWD/SWO names, no connectorpositions'}, {'url': 'local:toolchain-and-validation.json and actual project source/artifacts', 'version': 'Fresh lesson07 v2 builds; GCC13.2.1; HAL953955a', 'scope': 'Source prediction, helper behavior and actual measured host build sizes'}, {'url': 'https://gcc.gnu.org/onlinedocs/gcc/Debugging-Options.html', 'version': 'Official GCC documentation', 'scope': 'Optimization and debug information limitations'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'No invented10Hz, uninterrupted live read guarantee or universal local visibility; peripheral reads may have side effects.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson07-refresh-figure5.png', 'alt': 'مسیر ارسال یک کاراکتر با ITM', 'caption': 'نمودار تألیفی مسیر helper واقعی تا stimulus port 0 و ITM و TPIU و PB3 و پروب سازگار. helper فقط یک بار آمادگی را بررسی می\u200cکند و در صورت نبود آن trace_dropped را افزایش می\u200cدهد؛ پیکربندی کامل انتقال به دیباگر وابسته است و کلاک هستهٔ 8 MHz نرخ baud خروجی SWO نیست.', 'purpose': 'مسیر ارسال یک کاراکتر با ITM', 'placement': 'در بخش سازوکار سخت\u200cافزاری ITM بدون اشغال منابع UART یا بار پردازشی سنگین', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10', 'scope': 'Cortex-M4 debug and ITM concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical SWD/SWO names, no connectorpositions'}, {'url': 'local:toolchain-and-validation.json and actual project source/artifacts', 'version': 'Fresh lesson07 v2 builds; GCC13.2.1; HAL953955a', 'scope': 'Source prediction, helper behavior and actual measured host build sizes'}, {'url': 'https://gcc.gnu.org/onlinedocs/gcc/Debugging-Options.html', 'version': 'Official GCC documentation', 'scope': 'Optimization and debug information limitations'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual nonblocking user helper, no traceconfiguration by helper, no SWOcapture/GUI evidence or8MHzbaud claim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson07-refresh-figure6.png', 'alt': 'اثر بهینه\u200cسازی و اندازه\u200cهای واقعی سه ساخت', 'caption': 'نمودار تألیفی با نتایج ساخت واقعی GCC: Flash نسخهٔ نادرست Debug برابر 8284، نسخهٔ -Og برابر 4408 و نسخهٔ اصلاح\u200cشدهٔ Debug برابر 8284 بایت است؛ RAM لینک هر سه 1600 بایت و شامل رزروهاست. نه -O0 و نه -Og تضمین مشاهدهٔ همهٔ متغیرها نیست و محوشدن متغیر محلی در دیباگر آزمایش نشده است.', 'purpose': 'اثر بهینه\u200cسازی و اندازه\u200cهای واقعی سه ساخت', 'placement': 'در بخش تأثیر سطوح بهینه\u200cسازی کامپایلر بر سادگی فرآیند دیباگ', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/programming_manual/pm0214-stm32-cortexm4-mcus-and-mpus-programming-manual-stmicroelectronics.pdf', 'version': 'PM0214 Rev10', 'scope': 'Cortex-M4 debug and ITM concepts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Logical SWD/SWO names, no connectorpositions'}, {'url': 'local:toolchain-and-validation.json and actual project source/artifacts', 'version': 'Fresh lesson07 v2 builds; GCC13.2.1; HAL953955a', 'scope': 'Source prediction, helper behavior and actual measured host build sizes'}, {'url': 'https://gcc.gnu.org/onlinedocs/gcc/Debugging-Options.html', 'version': 'Official GCC documentation', 'scope': 'Optimization and debug information limitations'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'RealFlash8284/4408/8284 RAM1600; no fake assembly/liveoptimized-out proof or guaranteed DWARFlocation.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

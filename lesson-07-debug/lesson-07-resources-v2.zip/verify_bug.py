"""Pure arithmetic model of the intentional off-by-one exercise, not a CPU simulator."""
from pathlib import Path
import json
def predict(fixed,iterations=22):
    step=0;event=0;history=[]
    for iteration in range(1,iterations+1):
        step+=1
        observed=step*2
        if (step>=10 if fixed else step>10):
            event+=1;step=0
        history.append({'iteration':iteration,'step_after_body':step,'event_count':event,'observed_value':observed})
    return history
buggy=predict(False);fixed=predict(True)
assert buggy[9]['event_count']==0 and buggy[10]['event_count']==1
assert fixed[9]['event_count']==1
result={'model':'arithmetic prediction only; not a debugger capture or board execution','buggy_first_event_iteration':11,'fixed_first_event_iteration':10,'requested_loop_delay_ms':100,'default_hal_delay_wait_threshold_ticks':101,'actual_time_warning':'Tick phase, execution, interruptions and clock error affect elapsed time. No exact real period is predicted.','buggy':buggy,'fixed':fixed}
(Path(__file__).resolve().parent/'bug-predictions.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ['buggy','fixed']},indent=2))

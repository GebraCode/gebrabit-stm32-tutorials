"""Original flat technical diagrams. Requires Pillow; no AI image synthesis.
Rebuild with Python. Images are explanatory models, never lab screenshots.
Font fallback: Segoe UI on Windows, DejaVu Sans on Linux. Fonts not bundled.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json,hashlib,zipfile,ast,shutil,sys
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f5f8fa';LINE='#ccdbe3';PALE='#dceef0';WHITE='#ffffff'
ROOT=Path(__file__).resolve().parents[1]
FOLDERS={37:'lesson37-architecture',38:'lesson38-tasks',39:'lesson39-scheduling'}
def font(n=44,b=False):
    paths=[f'C:/Windows/Fonts/segoeui{"b" if b else ""}.ttf',f'/usr/share/fonts/truetype/dejavu/DejaVuSans{"-Bold" if b else ""}.ttf']
    for p in paths:
        if Path(p).exists():return ImageFont.truetype(p,n)
    raise FileNotFoundError('Set an installed sans-serif font path in font().')
def tx(d,x,y,s,n=44,c=INK,b=False):
    box=d.textbbox((x,y),s,font=font(n,b))
    assert box[2]<=W-30 and box[3]<=H-15,(s,box)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1050,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        new=(line+' '+word).strip()
        if line and d.textlength(new,font=font(n,b))>width:lines.append(line);line=word
        else:line=new
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,60,35,title,1080,54,b=True)
    y=para(d,60,y+12,subtitle,1080,40,MUTED)
    assert y<=240,(title,y)
    d.line((60,250,1140,250),fill=LINE,width=3)
    return im,d
def foot(d,s='Original diagram; no physical measurement supplied.'):
    d.line((60,1640,1140,1640),fill=LINE,width=3)
    y=para(d,60,1670,s,1080,38,MUTED)
    assert y<=1790
def arrow(d,points,c=TEAL,w=7):
    d.line(points,fill=c,width=w);x,y=points[-1];px,py=points[-2];a=math.atan2(y-py,x-px)
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,p0,p1,c=ORANGE):
    x0,y0=p0;x1,y1=p1;dist=math.hypot(x1-x0,y1-y0)
    for a in range(0,int(dist),30):
        b=min(a+14,dist);d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=4)
def box(d,x,y,w,h,title,lines=(),c=TEAL,n=44):
    d.rounded_rectangle((x,y,x+w,y+h),16,fill=WHITE,outline=c,width=3)
    yy=para(d,x+22,y+15,title,w-44,n,c,True)
    for line in lines:yy=para(d,x+22,yy+10,line,w-44,n-2)
    assert yy+10<=y+h,(title,yy,y+h)
def axis(d,x,y,w,start,end,label,ticks):
    arrow(d,[(x,y),(x+w,y)],INK,4)
    for t in ticks:
        xx=x+(t-start)/(end-start)*w;d.line((xx,y-12,xx,y+12),fill=INK,width=3)
        tx(d,max(40,xx-25),y+20,str(t),38,MUTED)
    tx(d,x,y+83,label,40,MUTED)
def rect(d,x,y,w,h,label,c=TEAL,n=42):
    d.rectangle((x,y,x+w,y+h),fill=c)
    if label:tx(d,x+14,y+10,label,n,WHITE,True)
def save(im,n,k):
    im.save(Path(__file__).resolve().parent/f'lesson{n}-figure{k}.png',optimize=True)



def fig37_1():
    im,d=begin('Where the kernel fits','Native API integration in the compiled project; conceptual software layers')
    box(d,90,300,1020,180,'Application',['App/Rtos/rtos_app.c: HeartbeatTask'])
    arrow(d,[(350,490),(350,555)]);arrow(d,[(860,490),(860,555)])
    box(d,70,575,510,205,'Native API',['xTaskCreate / vTaskDelay'],n=42)
    box(d,620,575,510,205,'STM32 support',['HAL / CMSIS device','GPIO and TIM6'],n=42)
    arrow(d,[(350,790),(350,860)])
    box(d,70,880,510,255,'Portable kernel',['tasks.c / list.c / queue.c','Scheduling and objects'],n=42)
    arrow(d,[(325,1145),(325,1190)]);arrow(d,[(875,790),(875,1440)])
    box(d,70,1210,510,180,'CPU port',['GCC / ARM_CM4F'],n=42)
    arrow(d,[(325,1400),(325,1440)])
    box(d,90,1460,1020,145,'Cortex-M4F / STM32F303CB',['Port and HAL reach different hardware roles.'],n=40)
    foot(d,'CMSIS core/device support is not the CMSIS-RTOS wrapper.');save(im,37,1)

def fig37_2():
    im,d=begin('Read the actual file tree','CubeMX hardware baseline plus an explicitly hand-integrated native kernel')
    rows=[('App/Rtos/','rtos_app.c + FreeRTOSConfig.h'),('Core/Src/','main.c + generated HAL timebase'),('Middlewares/Third_Party/','FreeRTOS-Kernel/'),('  include/','FreeRTOS.h + task.h + other headers'),('  portable/GCC/ARM_CM4F/','port.c + portmacro.h'),('  portable/MemMang/','heap_4.c only in this build')]
    for k,(a,b) in enumerate(rows):
        yy=300+k*180
        if k<3:d.line((82,yy+35,110,yy+35),fill=TEAL,width=6)
        tx(d,115,yy,a,42,TEAL,True);tx(d,115,yy+65,b,40)
    box(d,90,1405,1020,190,'One allocator linked',['Other heap schemes are alternatives, not extra heaps.'],n=42)
    foot(d,'Pinned kernel: V11.2.0 / commit 0adc196d4bd5.');save(im,37,2)

def fig37_3():
    im,d=begin('Starting and switching tasks','Conceptual execution order; lengths do not represent measured durations')
    box(d,90,300,1020,230,'First task: port startup, then SVC',['Read initial MSP value from the first vector word.','Set MSP before SVC; SVC restores task context.'],n=42)
    tx(d,90,595,'Later: a scheduling event requests PendSV',44,TEAL,True)
    stages=[('Task A',TEAL),('SysTick',ORANGE),('Urgent ISR',RED),('PendSV',ORANGE),('Task B',TEAL)]
    for k,(s,c) in enumerate(stages):
        yy=690+k*135;rect(d,340,yy,760,90,s,c,44);tx(d,95,yy+20,str(k+1),44,MUTED)
        if k<4:arrow(d,[(230,yy+75),(230,yy+125)],MUTED,4)
    box(d,90,1400,1020,200,'Context includes software-saved registers',['R4-R11 / EXC_RETURN; S16-S31 if FP context is active.'],n=40)
    foot(d,'Hardware extended FP frame: base 8 + FP 18 = 26 words.');save(im,37,3)

def fig37_4():
    im,d=begin('Two independent time counters','Actual generated TIM6 HAL base; native port owns the kernel SysTick')
    box(d,90,300,1020,190,'TIM6 hardware timer',['72 MHz / (71+1) / (999+1) = 1000 Hz nominal'],n=42)
    arrow(d,[(600,500),(600,555)])
    box(d,90,575,1020,240,'Generated HAL interrupt path',['TIM6_DAC_IRQHandler -> HAL_TIM_IRQHandler','PeriodElapsed callback -> HAL_IncTick -> uwTick'],n=40)
    box(d,90,915,1020,175,'SysTick core timer',['configTICK_RATE_HZ = 1000'],n=42)
    arrow(d,[(600,1100),(600,1150)])
    box(d,90,1170,1020,235,'FreeRTOS port interrupt path',['SysTick_Handler -> xTaskIncrementTick','Delayed tasks may become Ready.'],n=42)
    para(d,95,1465,'HAL_Delay: busy wait. vTaskDelay: block the task. Separation is not a guarantee against all timing errors.',1000,42,c=ORANGE)
    foot(d,'These are nominal clock calculations, not measured frequencies.');save(im,37,4)

def fig37_5():
    im,d=begin('Keep ISR priority rules separate','NVIC: smaller number = higher urgency. Task priorities use the opposite direction.')
    tx(d,90,300,'BASEPRI threshold: 5 << 4 = 0x50',46,TEAL,True)
    box(d,90,410,1020,375,'NVIC priorities 0-4',['Not masked by this normal BASEPRI threshold.','Do not call FreeRTOS APIs from these ISRs.'],c=ORANGE,n=42)
    for k in range(5):rect(d,120+k*195,675,160,80,str(k),ORANGE,46)
    box(d,90,880,1020,470,'NVIC priorities 5-15',['Masked during kernel BASEPRI critical sections.','Only permitted FromISR APIs, with their conditions.'],n=42)
    for k in range(11):rect(d,120+(k%6)*160,1120+(k//6)*100,130,80,str(k+5),TEAL,46)
    para(d,95,1420,'Not zero latency: other interrupts, PRIMASK and processor entry latency still matter.',1000,44,c=ORANGE)
    foot(d,'This project sets 4 NVIC priority bits; not a universal MCU value.');save(im,37,5)

def fig37_6():
    im,d=begin('Choose one heap implementation','Comparison of the pinned FreeRTOS schemes; the project links heap_4.c')
    rows=[('heap_1','Allocate only; deallocation unsupported.'),('heap_2','Allocate/free; no adjacent-block coalescing.'),('heap_3','Wraps the C library malloc/free.'),('heap_4','First-fit; free + adjacent coalescing.'),('heap_5','Coalescing; no joining across region gaps.')]
    for k,(a,b) in enumerate(rows):
        yy=300+k*180;tx(d,90,yy,a,46,TEAL,True);para(d,310,yy,b,800,42);d.line((90,yy+135,1110,yy+135),fill=LINE,width=3)
    tx(d,90,1250,'First-fit example: request 32 bytes',44,TEAL,True)
    rect(d,90,1350,300,110,'Free 40',TEAL,42);rect(d,390,1350,180,110,'Used',MUTED,42);rect(d,570,1350,540,110,'Free 80',TEAL,42)
    arrow(d,[(240,1530),(240,1475)],ORANGE)
    tx(d,350,1500,'First suitable block is selected.',42,ORANGE,True)
    foot(d,'Block sizes are a schematic example; allocator overhead omitted.');save(im,37,6)

if __name__=="__main__":
    for k in range(1,7):globals()[f"fig37_{k}"]()

"""ADC arithmetic, quantization and alias illustrations; not measurements."""
import json,math
checks=0
def check(value):
 global checks
 assert value
 checks+=1
def estimate(code,vdda=3300):
 if not(0<=code<=4095): raise ValueError('12bit code')
 return code*vdda//4095
check(estimate(0)==0)
check(estimate(4095)==3300)
check(estimate(2048)==1650)
check(estimate(1024)==825)
check(estimate(2048,3200)==1600)
check(estimate(3072)==2475)
rc_ns=(45000+1000)*5e-12*1e9
settle_ns=math.log(2**13)*rc_ns
check(math.isclose(rc_ns,230))
check(19.5/18e6*1e9 < settle_ns < 61.5/18e6*1e9)
check(4*15000==60000)
check(3300/4096!=3300/4095)
for raw in [-1,4096]:
 try: estimate(raw)
 except ValueError: checks+=1
 else: raise AssertionError('invalidcodeaccepted')
adc_clock=72000000/4
check(adc_clock==18000000)
sample_us=181.5/adc_clock*1e6
convert_us=(181.5+12.5)/adc_clock*1e6
check(math.isclose(sample_us,10.083333333333334))
check(math.isclose(convert_us,10.777777777777779))
check(((10-0xfffffff0)&0xffffffff)==26)
# A higher-frequency sine may alias to a lower one at a fixed sample cadence.
fs=1000
for n in range(20):
 check(math.isclose(math.sin(2*math.pi*100*n/fs),math.sin(2*math.pi*1100*n/fs),abs_tol=1e-12))
print(json.dumps({'checks_passed':checks,'hardware':'NOT TESTED',
 'hypothetical_RC_exercise':{'Rsource_ohm':45000,'Rswitch_assumed_ohm':1000,'C_assumed_pF':5,'tau_ns':rc_ns,'halfLSB_settle_ns':settle_ns,'selected_sample_cycles':61.5},
 'Nyquist_exercise':{'bandlimit_Hz':15000,'theoretical_fs_Hz':'>30000','four_times_fs_Hz':60000,'maximum_interval_us':1e6/60000},
 '12bit_levels':4096,'maximum_code':4095,'ideal_quantization_step_mV':3300/4096,
 'endpoint_scale_mV_per_code':3300/4095,'sample_us':sample_us,
 'conversion_us_nominal':convert_us,'conversion_rate_ceiling_without_overhead_Hz':1e6/convert_us,
 'application_attempt_interval_ms':100,'notes':[
 'Actual application rate includes software and is not the raw ADC conversion ceiling.',
 'code*VDDA/4095 is an endpoint voltage estimate; quantization bin width isVDDA/4096.',
 'No noise, offset, INL, source impedance or board accuracy was measured.']},indent=2))

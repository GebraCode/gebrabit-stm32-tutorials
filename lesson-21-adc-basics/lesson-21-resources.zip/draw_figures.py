"""Six original course teaching diagrams. No hardware captures or AI raster assets.
Requires Pillow and Windows Segoe UI (system font, not redistributed).
Run this script to regenerate only this lesson's PNGs and metadata beside it.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=1200,1800
INK='#18384f';TEAL='#087f8c';ORANGE='#aa5918';RED='#ac3941';MUTED='#526c7e'
BG='#f3f7fa';LINE='#c8d8e1';PALE='#e2f1f2';WHITE='#ffffff'
def font(n=44,b=False):return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    assert d.textbbox((x,y),s,font=font(n,b))[2] <= W-35,(s,x,n)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    lines=[];line=''
    for word in s.split():
        t=(line+' '+word).strip()
        if d.textlength(t,font=font(n,b))>width and line:lines.append(line);line=word
        else:line=t
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    yy=para(d,55,35,title,1090,52,b=True)
    yy=para(d,55,yy+8,subtitle,1090,38,MUTED)
    assert yy<=225,(title,yy)
    d.line((55,210,1145,210),fill=LINE,width=3)
    return im,d
def foot(d,basis='Basis: RM0316 + exact F3 HAL.'):
    d.line((55,1650,1145,1650),fill=LINE,width=3)
    tx(d,55,1670,basis,38,MUTED)
    tx(d,55,1740,'Original diagram / model. Not measured.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-25*math.cos(a-.48),y-25*math.sin(a-.48)),(x-25*math.cos(a+.48),y-25*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,width=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),dash*2):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=width)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+14,title,w-48,46,c,True)
    for s in lines:yy=para(d,x+24,yy+12,s,w-48,42)
    assert yy-18<=y+h,(title,yy,y+h)
def wave(d,events,xmap,hi,lo,c=TEAL,w=7):
    pts=[];last=events[0][1]
    for t,v in events:
        x=xmap(t);pts.extend([(x,hi if last else lo),(x,hi if v else lo)]);last=v
    d.line(pts,fill=c,width=w)
def save(im,n):im.save(OUT/f'lesson{LESSON}-course-figure{n}.png',optimize=True)

LESSON=21

def figure1():
    im,d=begin('SAR tries one binary decision at a time','A 4-bit teaching toy | Not the timing of the actual 12-bit ADC')
    x=lambda step:220+step*260;y=lambda v:970-v*580
    tx(d,65,260,'Voltage / Vref (normalized)',45,b=True)
    d.line((170,350,170,1010,1120,1010),fill=INK,width=4)
    for v in [0,.25,.5,.75,1]:
        yy=y(v);d.line((170,yy,1110,yy),fill=LINE,width=2);tx(d,65,yy-25,str(v),38)
    dashed(d,170,y(.7),1110,y(.7),INK,4);tx(d,600,360,'Vin =0.7 x Vref',44,INK,True)
    trials=[(.5,'1000','KEEP'),(.75,'1100','CLEAR'),(.625,'1010','KEEP'),(.6875,'1011','KEEP')]
    for k,(v,bits,decision) in enumerate(trials):
        xx=x(k);yy=y(v);col=TEAL if decision=='KEEP' else ORANGE
        d.line((xx,y(0),xx,yy),fill=col,width=7);d.ellipse((xx-10,yy-10,xx+10,yy+10),fill=col)
        tx(d,xx-45,1090,bits,44,col,True);tx(d,xx-55,1190,decision,40,col,True);tx(d,xx-20,1015,str(k+1),38)
    tx(d,700,1310,'Decision step ->',42,b=True)
    tx(d,65,1420,'Result 1011 =11; no physical cycle count implied.',44,TEAL,True)
    tx(d,65,1530,'Real project: 12-bit codes 0..4095.',45,b=True)
    foot(d,'Toy search explains the method, not ADC conversion timing.');save(im,1)

def figure2():
    im,d=begin('ADC codes are discrete intervals','Interior-bin rounding model | Ideal12-bit LSB = Vref /4096')
    x=lambda v:190+v*170;y=lambda v:950-v*110
    tx(d,65,265,'Local code index, away from clipping',43,b=True)
    d.line((190,350,190,1000,1110,1000),fill=INK,width=4)
    for k in range(6):
        tx(d,95,y(k)-20,str(k),38);tx(d,x(k)-10,1030,str(k),38)
    dashed(d,x(0),y(0),x(5),y(5),MUTED,3)
    events=[]
    for j in range(501):
        v=j/100;code=math.floor(v+.5);events.append((x(v),y(code)))
    d.line(events,fill=TEAL,width=7)
    tx(d,670,1130,'Input / LSB',42,b=True)
    tx(d,65,1240,'Ideal rounding error: up to 0.5 LSB',46,TEAL,True)
    tx(d,65,1335,'This bound excludes clipping and device errors.',42,ORANGE)
    panel(d,70,1450,1060,150,'Do not mix two meanings',['LSB:Vref /4096; endpoint estimate:code xVDDA /4095.'])
    foot(d,'Local ideal quantizer model, not a measured ADC transfer curve.');save(im,2)

def figure3():
    im,d=begin('Aliasing makes a fast wave look slow','Synthetic normalized sines | Signal 900 Hz, sample rate 1000 S/s')
    x=lambda ms:160+ms*90;y=lambda v:660-v*220
    d.line((160,370,160,950,1100,950),fill=INK,width=4)
    for v in [-1,0,1]:tx(d,65,y(v)-22,str(v),38)
    pts=[(x(t/100),y(math.sin(2*math.pi*.9*t/100))) for t in range(1001)]
    d.line(pts,fill=TEAL,width=4)
    pts=[(x(t/100),y(-math.sin(2*math.pi*.1*t/100))) for t in range(1001)]
    d.line(pts,fill=ORANGE,width=7)
    for ms in range(11):
        xx=x(ms);yy=y(math.sin(2*math.pi*.9*ms));d.ellipse((xx-8,yy-8,xx+8,yy+8),fill=INK)
    for ms in [0,5,10]:tx(d,x(ms)-15,1000,str(ms),40)
    tx(d,870,1090,'Time (ms)',42,b=True)
    tx(d,65,1200,'Dots fit a 100 Hz alias as well.',47,ORANGE,True)
    tx(d,65,1300,'Nyquist frequency: fs /2 =500 Hz',45,b=True)
    para(d,65,1410,'Limit the input band before sampling. Choose sample rate above 2 x the highest wanted frequency, with a practical guard band.',1070,43)
    foot(d,'Illustration only; no real waveform or filter response captured.');save(im,3)

def figure4():
    im,d=begin('The sampling capacitor needs time','An assumed normalized RC model, not actual ADC R or C values')
    tx(d,65,270,'Vin',45,TEAL,True);d.line((130,400,300,400),fill=INK,width=6)
    d.rectangle((300,355,560,445),outline=INK,width=5);tx(d,305,280,'Rsource + Rswitch',38,b=True)
    d.line((560,400,900,400,900,520),fill=INK,width=6)
    d.line((810,520,990,520),fill=INK,width=6);d.line((810,560,990,560),fill=INK,width=6);d.line((900,560,900,650),fill=INK,width=6)
    for j,w in enumerate([100,70,35]):d.line((900-w/2,650+j*20,900+w/2,650+j*20),fill=INK,width=5)
    tx(d,650,590,'Chold',43,TEAL,True)
    x=lambda t:180+t*90;y=lambda v:1270-v*380
    tx(d,65,790,'Vcap / Vin',42,b=True)
    d.line((180,820,180,1320,1120,1320),fill=INK,width=4)
    for v in [0,.5,1]:tx(d,65,y(v)-25,str(v),38)
    d.line([(x(i/50),y(1-math.exp(-i/50))) for i in range(501)],fill=TEAL,width=7)
    dashed(d,x(0),y(1),x(10),y(1),MUTED,3)
    for t in [0,5,10]:tx(d,x(t)-12,1350,str(t),38)
    tx(d,740,1430,'Time / tau',42,b=True)
    tx(d,65,1530,'Actual sample time: 181.5 /18 MHz =10.0833 us.',42)
    foot(d,'tau depends on the actual source and input circuit.');save(im,4)

def figure5():
    im,d=begin('A pot sets the test input voltage','Proposed external 10k potentiometer; not a part on the board')
    tx(d,365,275,'3V3 nominal',45,TEAL,True)
    d.line((490,355,490,440),fill=INK,width=6)
    d.rectangle((435,440,545,770),outline=INK,width=6)
    tx(d,150,535,'10k pot',44,b=True)
    arrow(d,[(800,610),(550,610)],ORANGE)
    d.line((800,610,1000,610),fill=ORANGE,width=6)
    tx(d,660,450,'Wiper -> PA1',44,ORANGE,True)
    tx(d,650,730,'ADC1_IN2',44,TEAL,True)
    tx(d,650,820,'Physical pin 11',41)
    d.line((490,770,490,940),fill=INK,width=6)
    for j,w in enumerate([100,70,35]):d.line((490-w/2,940+j*20,490+w/2,940+j*20),fill=INK,width=5)
    tx(d,600,935,'Common GND',44,b=True)
    panel(d,70,1110,1060,280,'Check before applying input',['Keep PA1 within its allowed range and measured VDDA.','Do not connect the board 5 V input to the ADC pin.'])
    para(d,65,1430,'Package pin 11 is not header position 11. Board input power and internal 3V3 are different nodes.',1070,43,ORANGE)
    foot(d,'Logical wiring plan; no photo or physical test is claimed.');save(im,5)

def figure6():
    im,d=begin('Read a conversion with a finite wait','Actual ADC1 single-ended polling flow')
    panel(d,70,250,1060,170,'Initialize, then calibrate',['Calibration runs while ADC is disabled.'])
    arrow(d,[(600,440),(600,550)])
    panel(d,70,570,1060,170,'HAL_ADC_Start',['Check return status before polling.'])
    arrow(d,[(600,760),(600,870)])
    panel(d,70,890,1060,200,'PollForConversion:10 ms limit',['HAL_OK permits GetValue; otherwise handle failure.'])
    arrow(d,[(600,1110),(600,1190)])
    panel(d,70,1210,1060,215,'Stop attempt; save valid result',['Record errors; do not treat old data as a new sample.','Main pacing is separate from conversion time.'])
    tx(d,65,1530,'12-bit conversion:181.5 +12.5 =194 ADC cycles.',42)
    foot(d,'18 MHz clock gives nominal 10.7778 us, not a timing capture.');save(im,6)

def run():
    for n in range(1,7):globals()[f'figure{n}']()
    (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson21-course-figure1.png', 'alt': 'جستجوی دودویی ساده\u200cشدهٔ SAR', 'caption': 'مدل آموزشی تألیفی 4 بیتی با Vin برابر 0.7 مرجع؛ آزمون\u200cهای 1000 و 1100 و 1010 و 1011 مفهوم نگه\u200cداشتن یا حذف بیت را نشان می\u200cدهند. محور افقی گام تصمیم است، نه سیکل واقعی ADC دوازده\u200cبیتی.', 'purpose': 'SAR چگونه با آزمون بیت\u200cها مقدار ورودی را تقریب می\u200cزند؟', 'placement': 'در بخش «اصل کار مبدل SAR» پس از تشریح سازوکار وزنه\u200cها و ثبت\u200cکننده تقریب متوالی', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': '4bit toy Vin0.7Vref; trial8/16 keep,12/16 clear,10/16 keep,11/16 keep->1011; not actual conversion cycles.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 2, 'filename': 'lesson21-course-figure2.png', 'alt': 'پله\u200cهای ایدئال ADC و معنای LSB', 'caption': 'نمودار تألیفی چند بازهٔ داخلی یک مدل گردکردن ایدئال؛ کران 0.5LSB فقط برای همین مدل و دور از clipping است و دقت کل تراشه نیست. در 12 بیت، LSB برابر Vref/4096 است؛ فرمول code×VDDA/4095 تخمین انتهای بازه است و معنای متفاوتی دارد.', 'purpose': 'چرا شمار کدها و تخمین ولتاژ انتهای بازه یک مخرج واحد ندارند؟', 'placement': 'در بخش «تفکیک\u200cپذیری، ولتاژ مرجع، خطای کوانتیزه شدن» ذیل توضیح LSB و خطای تبدیل', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Local interior quantizer staircase;12bit4096codes0..4095,LSB=Vref/4096. HalfLSB onlyidealroundingawayclipping;endpointestimatecodeVDDA/4095notexactinverse/accuracy.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 3, 'filename': 'lesson21-course-figure3.png', 'alt': 'نمونه\u200cبرداری و فرکانس کاذب', 'caption': 'مدل تألیفی دو سینوس نرمال\u200cشده: نمونه\u200cهای یک سیگنال 900Hz در نرخ 1000S/s با یک الیاس 100Hz نیز سازگارند. این ردگیری سخت\u200cافزار نیست؛ فیلتر پیش از ADC و حاشیهٔ مناسب بالاتر از دو برابر فرکانس موردنظر لازم است.', 'purpose': 'چگونه نمونه\u200cهای یک موج تند با یک موج آهسته نیز سازگار می\u200cشوند؟', 'placement': 'در بخش «نرخ نمونه\u200cبرداری و قضیهٔ نایکوئیست در یک نگاه»', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Synthetic900Hz signal sampled1000S/s gives100Hzalias; normalizedamplitude andmsaxis; no real capture/filter response. fs>2fmax withbandlimitandguard.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 4, 'filename': 'lesson21-course-figure4.png', 'alt': 'زمان شارژ خازن نمونه\u200cبرداری', 'caption': 'مدار و منحنی RC تألیفی با زمان نرمال\u200cشده؛ هیچ مقدار واقعی R_ADC یا C_ADC فرض نشده است. زمان نمونه\u200cبرداری پروژه 181.5 سیکل در 18MHz یا 10.0833us است، اما رسیدن خازن به ورودی به مدار و مقاومت واقعی منبع وابسته است.', 'purpose': 'چرا خازن نمونه\u200cبرداری با منبع پرامپدانس به زمان بیشتری نیاز دارد؟', 'placement': 'در بخش «امپدانس ورودی و نقش خازن نمونه\u200cبرداری»', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'NormalizedassumedRC1-exp(-t/tau),noactualADCohm/pFvalues or physicalsettlingtimeclaim;181.5cycles/18MHz10.0833us isconfiguredsampleintervalonly.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 5, 'filename': 'lesson21-course-figure5.png', 'alt': 'اتصال منطقی پتانسیومتر به PA1', 'caption': 'شماتیک تألیفی یک پتانسیومتر خارجی پیشنهادی 10k؛ دو سر به 3V3 اسمی و GND و لغزنده به PA1/ADC1_IN2 با پایهٔ فیزیکی 11 وصل می\u200cشود. شمارهٔ بسته، شمارهٔ هدر نیست. پیش از اتصال، محدودهٔ ورودی و VDDA واقعی بررسی شود؛ ورودی 5V برد به ADC متصل نشود.', 'purpose': 'چگونه ولتاژ قابل تنظیم را بدون اشتباه\u200cگرفتن گره\u200cهای تغذیه به ADC بدهیم؟', 'placement': 'در بخش «آزمایش: خواندن ولتاژ پتانسیومتر و مقایسه با مولتی\u200cمتر»', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Externalproposed10kpot notonboard,3V3/GND/wiperPA1IN2physical11,verifyinputwithinVDDA;no optional1kprotectionguarantee/no damagecertainty.', 'status': 'prepared-for-Codex-final-visual-review'}, {'id': 6, 'filename': 'lesson21-course-figure6.png', 'alt': 'توالی محدود و قابل بررسی Polling', 'caption': 'فلوچارت تألیفی مطابق پروژه: کالیبراسیون Single-ended در حالت غیرفعال، Start با بررسی نتیجه، Poll با timeout برابر 10ms، خواندن فقط پس از HAL_OK و تلاش Stop. تبدیل اسمی 181.5+12.5 سیکل در 18MHz برابر 10.7778us است؛ زمان HAL و توقف حلقه با این عدد یکی نیست.', 'purpose': 'خواندن یک تبدیل چگونه با خطا و timeout محدود می\u200cشود؟', 'placement': 'در بخش «خواندن ساده یک کانال و تبدیل کد به ولتاژ با توابع HAL»', 'type': 'original explanatory diagram / synthetic model', 'references': [{'url': 'https://www.st.com/resource/en/reference_manual/dm00043574.pdf', 'version': 'RM0316, no unverified revision asserted', 'scope': 'ADC regular conversions, sample timing, EOC/EOS/OVR and calibration'}, {'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Part-specific analog and pin electrical limits'}, {'url': 'https://github.com/STMicroelectronics/stm32f3xx_hal_driver/tree/953955afe65f89e60e556bbcdba752597f5da65d', 'version': 'F3 HAL953955afe65f89e60e556bbcdba752597f5da65d', 'scope': 'F3 ADC init/calibration/read and device calibration macro'}, {'url': 'https://www.st.com/resource/en/application_note/cd00211314-how-to-optimize-the-adc-accuracy-in-the-stm32-mcus-stmicroelectronics.pdf', 'version': 'AN2834 Rev10 October2024', 'scope': 'ADC acquisition/quantization principles, not copied figure layouts'}, {'url': 'https://gebrabit.com/wp-content/uploads/2024/07/GebraBit-STM32F303-Schematic-V2.0.pdf', 'version': 'GB100ST V2.0', 'scope': 'Board supply and signal connections'}], 'source': 'Codex original Pillow geometry, exact lesson facts and primary sources; not a copied layout', 'rights': 'Original drawing, no assumed CC license or third-party figure copied; systemfontnotredistributed', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'ActualADC1PA1singleended12bitAHB/4=18MHz,Ts181.5,12.5conversion,calibratewhileADCdisabled,Start/Poll10ms/GetonlyOK/Stopattempt,main100mspacing. No fake measured timing.', 'status': 'prepared-for-Codex-final-visual-review'}]
if __name__=='__main__':run()

"""Check real before/after CubeMX snapshots and linker arithmetic, not hardware."""
from pathlib import Path
import json,re,hashlib

root=Path(__file__).resolve().parent
evidence=root/'regeneration-evidence'
read=lambda name:(evidence/name).read_text(encoding='utf-8-sig')
before,after=read('main-before.c'),read('main-after.c')
before_ioc,after_ioc=read('project-before.ioc'),read('project-after.ioc')
before_ld,after_ld=read('linker-before.ld'),read('linker-after.ld')
checks={}
def check(name,value):
    checks[name]=bool(value)
    assert value,name
def block(text,label):
    return re.search(r'/\* USER CODE BEGIN '+label+r' \*/([\s\S]*?)/\* USER CODE END '+label+r' \*/',text)[1]
for label,statement in [('PV','volatile uint32_t lesson4_marker = 0U;'),('2','lesson4_marker = 1U;')]:
    check('before_'+label,statement in block(before,label))
    check('after_'+label,statement in block(after,label))
    check('preserved_'+label,block(before,label)==block(after,label))
marker='LESSON4_OUTSIDE_USER_CODE_V2'
check('controlled_outside_marker_before',marker in before)
check('controlled_outside_marker_removed_after',marker not in after)
check('before_heap_setting','ProjectManager.HeapSize=0x200' in before_ioc)
check('after_heap_setting','ProjectManager.HeapSize=0x300' in after_ioc)
check('before_linker_reservation','_Min_Heap_Size = 0x200;' in before_ld)
check('after_linker_reservation','_Min_Heap_Size = 0x300;' in after_ld)
check('firmware_pinned','ProjectManager.LastFirmware=false' in after_ioc)
check('backup_previous','ProjectManager.BackupPrevious=true' in after_ioc)
check('keep_user_code','ProjectManager.KeepUserCode=true' in after_ioc)
check('separate_peripheral_files','ProjectManager.CoupleFile=true' in after_ioc)
check('no_output_pin','GPIO_Output' not in after_ioc)
check('SWD_preserved',all(x in after_ioc for x in ['PA13.Signal=SYS_JTMS-SWDIO','PA14.Signal=SYS_JTCK-SWCLK']))
check('generated_HSI',all(x in after for x in ['RCC_OSCILLATORTYPE_HSI','RCC_SYSCLKSOURCE_HSI','FLASH_LATENCY_0']))
check('no_PLL_system_source','SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK' not in after)
check('empty_gpio_no_pin_initialization','HAL_GPIO_Init(' not in read('gpio-after.c'))
check('before_RAM_arithmetic',12+36+512+1024==1584)
check('after_RAM_arithmetic',12+36+768+1024==1840)
check('RAM_reservation_delta',1840-1584==int('300',16)-int('200',16)==256)
manifest=json.loads(read('snapshot-sha256.json'))
for name,expected in manifest.items():
    check('snapshot_sha_'+name,hashlib.sha256((evidence/name).read_bytes()).hexdigest()==expected)
print(json.dumps({'checks_passed':len(checks),'checks':checks,
 'clock_HSI_nominal_Hz':8000000,'heap_reservation_bytes_before_after':[512,768],
 'RAM_region_bytes_before_after':[1584,1840],'note':'Real regeneration snapshots and real clean build reports; no GUI, board, runtime marker observation or memory-peak measurement.'},indent=2))

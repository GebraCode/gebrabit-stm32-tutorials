"""Shared preparation helpers for original novice-oriented course drawings.
Copied into each public draw_figures.py so final scripts remain standalone.
No figure selection or rendering occurs in this style-preparation module.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
W,H=1200,1800
INK='#19394f';TEAL='#087f8c';ORANGE='#a95a1d';RED='#a83b47';MUTED='#526d7e'
BG='#f4f8fa';LINE='#cad9e2';PALE='#e2f0f1';WHITE='#ffffff'
def font(n=44,b=False):
    assert n>=38
    return ImageFont.truetype('C:/Windows/Fonts/segoeui'+('b' if b else '')+'.ttf',n)
def tx(d,x,y,s,n=44,c=INK,b=False):
    bounds=d.textbbox((x,y),s,font=font(n,b))
    assert bounds[2]<=W-35,(s,x,n,bounds)
    assert bounds[3]<=H-15,(s,y,bounds)
    d.text((x,y),s,font=font(n,b),fill=c)
def para(d,x,y,s,width=1070,n=44,c=INK,b=False,gap=12):
    line='';lines=[]
    for word in s.split():
        candidate=(line+' '+word).strip()
        if line and d.textlength(candidate,font=font(n,b))>width:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    for line in lines:tx(d,x,y,line,n,c,b);y+=n+gap
    return y
def begin(title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    y=para(d,55,35,title,1090,52,b=True)
    y=para(d,55,y+8,subtitle,1090,38,MUTED)
    assert y<=235,(title,subtitle,y)
    d.line((55,240,1145,240),fill=LINE,width=3)
    return im,d
def foot(d,s='Original drawing; no physical result is shown.'):
    d.line((55,1640,1145,1640),fill=LINE,width=3)
    tx(d,55,1670,s,38,MUTED)
    tx(d,55,1730,'Technical basis and limitations are in the caption.',38,MUTED)
def arrow(d,pts,c=TEAL,w=7):
    d.line(pts,fill=c,width=w);x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    d.polygon([(x,y),(x-24*math.cos(a-.48),y-24*math.sin(a-.48)),(x-24*math.cos(a+.48),y-24*math.sin(a+.48))],fill=c)
def dashed(d,x0,y0,x1,y1,c=ORANGE,w=4,dash=18):
    dist=math.hypot(x1-x0,y1-y0)
    if not dist:return
    for a in range(0,int(dist),2*dash):
        b=min(a+dash,dist)
        d.line((x0+(x1-x0)*a/dist,y0+(y1-y0)*a/dist,x0+(x1-x0)*b/dist,y0+(y1-y0)*b/dist),fill=c,width=w)
def panel(d,x,y,w,h,title,lines=(),c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=WHITE,outline=LINE,width=3)
    yy=para(d,x+24,y+15,title,w-48,46,c,True)
    for line in lines:yy=para(d,x+24,yy+12,line,w-48,42)
    assert yy-15<=y+h,(title,yy,y+h)
def chip(d,x,y,w,h,label,sub='',c=TEAL):
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=WHITE,outline=c,width=5)
    for a in range(5):
        yy=y+45+a*(h-70)/4
        d.line((x-25,yy,x,yy),fill=c,width=7);d.line((x+w,yy,x+w+25,yy),fill=c,width=7)
    para(d,x+25,y+30,label,w-50,46,c,True)
    if sub:para(d,x+25,y+105,sub,w-50,40)
def folder(d,x,y,w,h,label,c=TEAL):
    d.rounded_rectangle((x,y+28,x+w,y+h),12,fill=WHITE,outline=c,width=4)
    d.rectangle((x+15,y,x+w*.46,y+35),fill=WHITE,outline=c,width=4)
    para(d,x+22,y+55,label,w-44,42,c,True)

OUT=Path(__file__).resolve().parent
LESSON=4
def save(im,n):im.save(OUT/f'lesson{LESSON:02d}-refresh-figure{n}.png',optimize=True)
def figure1():
 im,d=begin('Turn a configuration into a project','Keep configuration, generated source and build products distinct')
 folder(d,335,300,530,205,'.ioc configuration')
 arrow(d,[(600,525),(600,600)])
 panel(d,100,610,1000,215,'Standalone CubeMX + selected CubeF3',['Device / pins / clock / project options'])
 arrow(d,[(600,840),(600,920)])
 folder(d,100,940,440,215,'Core + Drivers')
 folder(d,660,940,440,215,'Build configuration')
 panel(d,100,1320,1000,230,'Separate toolchain paths',['Delivered: generated CMake + GCC build','GUI guide: generate for CubeIDE, then import'])
 foot(d,'No CubeIDE GUI import/build is claimed for this kit.');save(im,1)
def figure2():
 im,d=begin('Start with the smallest pin configuration','Logical signals only; these are not board connector positions')
 chip(d,350,430,500,490,'STM32F303CBT6','Minimal first project')
 tx(d,80,1090,'PA13',48,TEAL,True);tx(d,80,1180,'PA14',48,TEAL,True)
 arrow(d,[(270,1125),(700,1125)]);arrow(d,[(270,1215),(700,1215)])
 tx(d,750,1090,'SWDIO',48,TEAL,True);tx(d,750,1180,'SWCLK',48,TEAL,True)
 panel(d,80,1370,1040,190,'No application GPIO output is configured',['No PB6 LED output or blink in this project.'])
 tx(d,80,310,'Debug: Serial Wire',48,TEAL,True)
 foot(d,'A complete probe connection also needs reference and ground.');save(im,2)
def figure3():
 im,d=begin('Trace the actual first-project clock','Nominal HSI 8 MHz; the PLL is not the system clock source')
 panel(d,80,300,430,220,'HSI',['Nominal 8 MHz'])
 arrow(d,[(520,410),(670,410)])
 panel(d,680,300,440,220,'SYSCLK',['8 MHz'])
 arrow(d,[(900,535),(900,650)])
 panel(d,680,665,440,220,'AHB divider /1',['HCLK: 8 MHz'])
 arrow(d,[(890,900),(890,1020),(290,1020),(290,1090)])
 arrow(d,[(890,900),(890,1090)])
 panel(d,80,1100,430,220,'APB1 divider /1',['PCLK1: 8 MHz'])
 panel(d,680,1100,440,220,'APB2 divider /1',['PCLK2: 8 MHz'])
 tx(d,80,1430,'Flash latency: 0 wait states',46,TEAL,True)
 tx(d,80,1520,'Board HSE / LSE crystals are not used by this project.',42)
 foot(d,'Configuration values, not a measured oscillator frequency.');save(im,3)
def figure4():
 im,d=begin('Make regeneration deliberate','A conceptual settings map, not a CubeMX screenshot')
 panel(d,95,300,1010,190,'Pin the firmware package',['CubeF3 V1.11.6; do not silently select latest'])
 panel(d,95,610,1010,190,'Separate peripheral source / header pairs',['gpio.c and gpio.h in Core/Src and Core/Inc'])
 panel(d,95,920,1010,190,'Keep protected user code',['Use protected USER CODE blocks for user logic.'])
 panel(d,95,1230,1010,220,'Back up before generation',['Keep .ioc, source and the selected build configuration'])
 for y in [500,810,1120]:arrow(d,[(600,y),(600,y+95)])
 tx(d,95,1510,'Toolchain selection changes generated build files.',43,ORANGE)
 foot(d,'Actual kit uses CMake; native IDE generation is a GUI guide.');save(im,4)
def figure5():
 im,d=begin('Read the delivered project tree','Selected real paths from gebrabit_lesson04_cubemx_v2')
 tx(d,75,300,'Project root',48,TEAL,True)
 entries=[('gebrabit_lesson04_cubemx_v2.ioc','Configuration'),('Core/Src/main.c','Application entry and USER CODE'),('Core/Src/gpio.c','Only GPIOA clock enable here'),('Core/Inc/','Application headers'),('Drivers/','HAL and CMSIS source'),('startup_stm32f303xc.s','Reset entry and vector table'),('STM32F303XX_FLASH.ld','Memory regions and reservations'),('CMakeLists.txt + cmake/','Delivered build definitions')]
 d.line((90,420,90,1500),fill=TEAL,width=5)
 for k,(a,b)in enumerate(entries):
  yy=400+k*143;d.line((90,yy+22,140,yy+22),fill=TEAL,width=5);tx(d,165,yy,a,41,TEAL,True);tx(d,165,yy+60,b,40)
 foot(d,'Selected tree; not a claim of native .project/.cproject files.');save(im,5)
def figure6():
 im,d=begin('Compare the real regeneration snapshots','Protected text survived; one controlled outside comment disappeared')
 tx(d,80,290,'Before regeneration',48,TEAL,True)
 panel(d,80,385,1040,220,'Inside USER CODE blocks',['PV: volatile lesson4_marker initialized to 0','USER CODE 2: assignment to 1'])
 arrow(d,[(600,620),(600,700)])
 panel(d,80,715,1040,180,'After regeneration: both texts preserved',['Outside experiment comment: removed'])
 tx(d,80,1020,'Linker heap reservation',48,TEAL,True)
 tx(d,80,1130,'512 bytes',52,b=True);arrow(d,[(420,1170),(710,1170)]);tx(d,780,1130,'768 bytes',52,b=True)
 tx(d,80,1280,'Linked RAM region: 1584 -> 1840 bytes',45)
 tx(d,80,1380,'Difference: +256 bytes; Flash: 7052 bytes unchanged',42)
 para(d,80,1500,'This is reserved link-region space, not measured malloc use or runtime RAM consumption.',1040,42,ORANGE)
 foot(d,'Evidence is specific to this controlled regeneration experiment.');save(im,6)
def run():
 for n in range(1,7):globals()[f'figure{n}']()
 (OUT/'image-metadata.json').write_text(json.dumps(METADATA,ensure_ascii=False,indent=2),encoding='utf-8')
METADATA=[{'id': 1, 'filename': 'lesson04-refresh-figure1.png', 'alt': 'مسیر تولید پروژه از فایل پیکربندی', 'caption': 'نمودار تألیفی مسیر فایل .ioc و بستهٔ انتخاب\u200cشده تا تولید Core و Drivers و فایل\u200cهای ساخت. منابع دانلود این درس واقعاً برای CMake و GCC تولید و ساخته شده\u200cاند؛ مسیر تولید پروژهٔ بومی CubeIDE در راهنمای رابط توضیح داده شده ولی واردسازی و ساخت آن در GUI آزمایش نشده است.', 'purpose': 'مسیر تولید پروژه از فایل پیکربندی', 'placement': 'در بخش سناریوی آغازین و معرفی مفهوم تولید خودکار کد', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device and logical debug pins'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Actual backend6.14.0/DB6.0.140; CubeF3V1.11.6', 'scope': 'Configuration and generation roles'}, {'url': 'local:regeneration-evidence/', 'version': 'Fresh lesson04 before/after actual source, IOC and linker snapshots', 'scope': 'Protected text, controlled outside comment and heap reservation'}, {'url': 'local:build-report-before.txt and build-report-after.txt', 'version': 'Actual GCC13.2.1 clean builds, flags recorded in kit', 'scope': 'Flash7052 unchanged, linked RAM1584 to1840; no runtime or GUI evidence'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual delivered CMake project and GUI native CubeIDE generation route distinct. No native IDE import/build claim.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 2, 'filename': 'lesson04-refresh-figure2.png', 'alt': 'پیکربندی حداقلی SWD بدون خروجی کاربردی', 'caption': 'نمودار تألیفی سیگنال\u200cهای منطقی PA13/SWDIO و PA14/SWCLK در پروژهٔ تازه. شماره یا جای کانکتور برد نمایش داده نشده است. پروژه PB6 یا خروجی چشمک\u200cزن ندارد؛ اتصال کامل پروب علاوه بر سیگنال\u200cها به زمین و مرجع هدف وابسته است.', 'purpose': 'پیکربندی حداقلی SWD بدون خروجی کاربردی', 'placement': 'در بخش گام 2: نمای پین\u200cها (Pinout View)', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device and logical debug pins'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Actual backend6.14.0/DB6.0.140; CubeF3V1.11.6', 'scope': 'Configuration and generation roles'}, {'url': 'local:regeneration-evidence/', 'version': 'Fresh lesson04 before/after actual source, IOC and linker snapshots', 'scope': 'Protected text, controlled outside comment and heap reservation'}, {'url': 'local:build-report-before.txt and build-report-after.txt', 'version': 'Actual GCC13.2.1 clean builds, flags recorded in kit', 'scope': 'Flash7052 unchanged, linked RAM1584 to1840; no runtime or GUI evidence'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Only logical SWD signals, no invented physical/header positions, no PB6 output or blink.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 3, 'filename': 'lesson04-refresh-figure3.png', 'alt': 'مسیر کلاک واقعی پروژهٔ حداقلی', 'caption': 'نمودار تألیفی مقادیر پیکربندی واقعی: HSI اسمی 8 MHz، SYSCLK و AHB و هر دو APB برابر 8 MHz با تقسیم بر 1، PLL به\u200cعنوان منبع سیستم انتخاب نشده و Flash latency برابر 0 است. کریستال\u200cهای HSE و LSE برد در این پروژه استفاده نشده\u200cاند؛ فرکانس فیزیکی اندازه\u200cگیری نشده است.', 'purpose': 'مسیر کلاک واقعی پروژهٔ حداقلی', 'placement': 'در بخش گام 3: نمای کلاک و اسیلاتور پایه', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device and logical debug pins'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Actual backend6.14.0/DB6.0.140; CubeF3V1.11.6', 'scope': 'Configuration and generation roles'}, {'url': 'local:regeneration-evidence/', 'version': 'Fresh lesson04 before/after actual source, IOC and linker snapshots', 'scope': 'Protected text, controlled outside comment and heap reservation'}, {'url': 'local:build-report-before.txt and build-report-after.txt', 'version': 'Actual GCC13.2.1 clean builds, flags recorded in kit', 'scope': 'Flash7052 unchanged, linked RAM1584 to1840; no runtime or GUI evidence'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Bare HSI8 configuration, not measured oscillator accuracy or later72MHz project.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 4, 'filename': 'lesson04-refresh-figure4.png', 'alt': 'تنظیمات مؤثر در تولید دوبارهٔ پروژه', 'caption': 'نقشهٔ مفهومی تألیفی تثبیت CubeF3 V1.11.6، جفت فایل مجزای پریفرال، حفظ بلوک\u200cهای USER CODE و پشتیبان\u200cگیری. این شکل بازسازی رابط یا تصویر چک\u200cباکس واقعی نیست. فایل تحویلی CMake است و مسیر GUI بومی CubeIDE جدا توضیح داده می\u200cشود.', 'purpose': 'تنظیمات مؤثر در تولید دوبارهٔ پروژه', 'placement': 'در بخش گام 4: تنظیمات Project Manager', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device and logical debug pins'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Actual backend6.14.0/DB6.0.140; CubeF3V1.11.6', 'scope': 'Configuration and generation roles'}, {'url': 'local:regeneration-evidence/', 'version': 'Fresh lesson04 before/after actual source, IOC and linker snapshots', 'scope': 'Protected text, controlled outside comment and heap reservation'}, {'url': 'local:build-report-before.txt and build-report-after.txt', 'version': 'Actual GCC13.2.1 clean builds, flags recorded in kit', 'scope': 'Flash7052 unchanged, linked RAM1584 to1840; no runtime or GUI evidence'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'CoupleFile true, KeepUserCode true, BackupPrevious true, LastFirmware false, actual toolchain CMake; no fake GUI.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 5, 'filename': 'lesson04-refresh-figure5.png', 'alt': 'ساختار واقعی فایل\u200cهای پروژهٔ تحویلی', 'caption': 'درخت تألیفی گزیده\u200cای از مسیرهای واقعی بستهٔ پروژه. فایل startup_stm32f303xc.s در ریشه است؛ gpio.c فقط کلاک GPIOA را فعال می\u200cکند. وجود پروژهٔ بومی .project یا .cproject ادعا نشده است.', 'purpose': 'ساختار واقعی فایل\u200cهای پروژهٔ تحویلی', 'placement': 'در بخش معماری پوشه\u200cهای Core و Drivers', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device and logical debug pins'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Actual backend6.14.0/DB6.0.140; CubeF3V1.11.6', 'scope': 'Configuration and generation roles'}, {'url': 'local:regeneration-evidence/', 'version': 'Fresh lesson04 before/after actual source, IOC and linker snapshots', 'scope': 'Protected text, controlled outside comment and heap reservation'}, {'url': 'local:build-report-before.txt and build-report-after.txt', 'version': 'Actual GCC13.2.1 clean builds, flags recorded in kit', 'scope': 'Flash7052 unchanged, linked RAM1584 to1840; no runtime or GUI evidence'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual project tree inspected; root startup path, Core/Src files, Drivers, linker and CMake. No hypothetical startup subfolder.', 'status': 'prepared-for-final-Codex-visual-review'}, {'id': 6, 'filename': 'lesson04-refresh-figure6.png', 'alt': 'نتیجهٔ مستند تولید دوباره و تغییر رزرو heap', 'caption': 'نمودار تألیفی آزمایش واقعی: متن متغیر lesson4_marker در USER CODE PV و مقداردهی آن در USER CODE 2 حفظ شد و فقط کامنت کنترل\u200cشدهٔ بیرون بلوک حذف شد. رزرو heap از 512 به 768 و ناحیهٔ RAM لینک از 1584 به 1840 بایت افزایش یافت؛ Flash برابر 7052 بایت ماند. این اعداد مصرف زمان اجرای RAM یا malloc نیستند و نتیجهٔ حذف کامنت حکم همهٔ تغییرات بیرون بلوک نیست.', 'purpose': 'نتیجهٔ مستند تولید دوباره و تغییر رزرو heap', 'placement': 'در بخش مرزهای بازسازی کد و آزمایش عملی', 'type': 'original explanatory diagram / model', 'references': [{'url': 'https://www.st.com/resource/en/datasheet/stm32f303cb.pdf', 'version': 'DS9118 Rev14', 'scope': 'Device and logical debug pins'}, {'url': 'https://www.st.com/en/development-tools/stm32cubemx.html', 'version': 'Actual backend6.14.0/DB6.0.140; CubeF3V1.11.6', 'scope': 'Configuration and generation roles'}, {'url': 'local:regeneration-evidence/', 'version': 'Fresh lesson04 before/after actual source, IOC and linker snapshots', 'scope': 'Protected text, controlled outside comment and heap reservation'}, {'url': 'local:build-report-before.txt and build-report-after.txt', 'version': 'Actual GCC13.2.1 clean builds, flags recorded in kit', 'scope': 'Flash7052 unchanged, linked RAM1584 to1840; no runtime or GUI evidence'}], 'rights': 'Original new geometry; no official figure copied; no assumed CC license; system font not redistributed.', 'source': 'Codex original Pillow drawing based on accepted Antigravity plan and checked project facts.', 'physical_measurement': False, 'AI_generated_image': False, 'model_content': 'Actual saved regeneration evidence; +256 linker reservation, not runtime measurement; only controlled outside comment removal, not all outside edits always deleted.', 'status': 'prepared-for-final-Codex-visual-review'}]
if __name__=='__main__':run()

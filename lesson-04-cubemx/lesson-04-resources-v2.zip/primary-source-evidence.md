# Sources and evidence for lesson4

The code-generation experiment is actual CubeMX6.14.0 output, not an invented screenshot or a manual reconstruction of generated code. Full before/after main.c, IOC and linker snapshots plus unified diffs and SHA256 are in regeneration-evidence. The two build reports are actual clean GCC13.2.1 results. No board or IDE GUI result is claimed.

Official nearby template inspected: https://github.com/STMicroelectronics/STM32CubeF3/blob/663d2baae3604244f90ed80d0d757df17e36ada9/Projects/STM32303C_EVAL/Templates/Src/main.c

This template uses HAL_Init, SystemClock_Config and an empty while loop, but an evaluation board and HSE/PLL72MHz. Only its startup organization is a reference; the generated lesson uses HSI8MHz and no PLL system clock source.

CubeMX manual UM1718 covers Project Manager and user-code retention. For this lesson, the retention claim is bounded by direct evidence: our two statements inside PV/USER2 survived and one controlled comment outside END2 disappeared. It is not a universal promise to delete every outside file/change.

Device datasheet: https://www.st.com/resource/en/datasheet/stm32f303cb.pdf
Reference manual: https://www.st.com/resource/en/reference_manual/DM00043574.pdf
Pinned HAL RCC driver: https://github.com/STMicroelectronics/stm32f3xx_hal_driver/blob/953955afe65f89e60e556bbcdba752597f5da65d/Src/stm32f3xx_hal_rcc.c

The delivered RCC source is byte-identical to the previously verified pinned CubeF3V1.11.6 RCC source. Its actual SHA256 is e7d83d2d4d88352b0fdb85cd807b7b3eeee061f1a268b720d686e6f09dfa9e20. The official template SHA256 inspected is 9b1d6b014c206f04d9c384ededbc60bc042d10ea68ad8af8d0406e6aff103f77.

Generated SystemClock_Config selects HSI, AHB/APB1/APB2 divide1 and Flash latency0; it checks HAL_RCC_OscConfig and HAL_RCC_ClockConfig return status and calls Error_Handler on failure. The application does not enable HSE/LSE or use a PLL as system clock. HSI8MHz is nominal, not a board frequency measurement. Error_Handler disables IRQ and spins in the generated implementation; it is not a recovery routine.

The only application user statements are a volatile uint32 marker declaration and an initialization assignment. No application GPIO output is configured. Generated gpio.c enables GPIOA clock for the selected pin set; this is not a GPIO/LED experiment.

Delivered output is CMake. Native CubeIDE generation/import/IDE build are instructions for local execution and remain untested. The delivered package contains no native CubeIDE .project/.cproject files; generate that separate target locally before importing it into the IDE.
